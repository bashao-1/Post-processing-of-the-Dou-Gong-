# Local data directory

Place compatible, locally authorized input fragments and reference meshes here.
The repository does not redistribute the study data. See the top-level README.
