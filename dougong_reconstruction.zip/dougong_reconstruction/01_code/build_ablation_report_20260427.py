import argparse
import json
import sys
from pathlib import Path


THIS_DIR = Path(__file__).resolve().parent
ROOT_DIR = THIS_DIR.parent
CODE_DIR = ROOT_DIR / "code"
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import build_realistic_hybrid_eval_report_20260427 as hybrid_eval


PAPER_PRIORITY = [
    "full",
    "wo_bodyfirst_host_recovery",
    "wo_semantic_structural_rollback",
    "wo_conservative_protection",
]


def mean(values):
    return float(sum(values) / max(len(values), 1))


def load_variant_info(output_dir: Path) -> dict:
    info_path = output_dir / "variant_config.json"
    if info_path.exists():
        return json.loads(info_path.read_text(encoding="utf-8"))
    return {
        "variant_name": output_dir.name,
        "variant_label": output_dir.name,
        "variant_description": "",
        "variant_config": {},
    }


def summarize_outputs(outputs_root: Path, manual_dir: Path) -> dict:
    comparison = {}
    for child in sorted(outputs_root.iterdir()):
        if not child.is_dir():
            continue
        if not (child / "metrics.json").exists():
            continue
        info = load_variant_info(child)
        summary = hybrid_eval.summarize_output(child, manual_dir)
        summary["variant_info"] = info
        comparison[info["variant_name"]] = summary
    return comparison


def delta(value: float, ref: float) -> float:
    return float(value - ref)


def build_markdown(comparison: dict) -> str:
    lines = []
    lines.append("# Ablation Comparison 2026-04-27")
    lines.append("")
    if "full" not in comparison:
        lines.append("`full` variant not found. Report cannot compute deltas against the final model.")
        return "\n".join(lines)

    full = comparison["full"]
    ordered_names = [name for name in PAPER_PRIORITY if name in comparison] + [
        name for name in sorted(comparison.keys()) if name not in PAPER_PRIORITY
    ]

    lines.append("## Recommended Main-Paper Table")
    lines.append("")
    lines.append("| Variant | mean_purity | component_count_diff | semantic_acc | focus_score | pairwise_f1 | mean_fragmentation |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for name in ordered_names:
        row = comparison[name]
        label = row["variant_info"].get("variant_label", name)
        lines.append(
            f"| `{label}` | {row['mean_mean_purity']:.4f} | {row['mean_component_count_diff']:.4f} | "
            f"{row['mean_semantic_acc']:.4f} | {row['focus_score']:.4f} | "
            f"{row['pairwise_f1']:.4f} | {row['mean_fragmentation']:.4f} |"
        )

    lines.append("")
    lines.append("## Delta Against Full Model")
    lines.append("")
    lines.append("| Variant | Delta mean_purity | Delta count_diff | Delta semantic_acc | Delta focus_score | Delta pairwise_f1 | Delta fragmentation |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for name in ordered_names:
        if name == "full":
            continue
        row = comparison[name]
        label = row["variant_info"].get("variant_label", name)
        lines.append(
            f"| `{label}` | {delta(row['mean_mean_purity'], full['mean_mean_purity']):+.4f} | "
            f"{delta(row['mean_component_count_diff'], full['mean_component_count_diff']):+.4f} | "
            f"{delta(row['mean_semantic_acc'], full['mean_semantic_acc']):+.4f} | "
            f"{delta(row['focus_score'], full['focus_score']):+.4f} | "
            f"{delta(row['pairwise_f1'], full['pairwise_f1']):+.4f} | "
            f"{delta(row['mean_fragmentation'], full['mean_fragmentation']):+.4f} |"
        )

    lines.append("")
    lines.append("## Interpretation Notes")
    lines.append("")
    lines.append("- Delta values are computed as `variant - full`. For `component_count_diff` and `mean_fragmentation`, positive values mean the ablation is worse than the full model.")
    lines.append("- `wo_bodyfirst_host_recovery` should mainly be read through `focus_score`, `pairwise_f1` and `mean_fragmentation` on complex samples.")
    lines.append("- `wo_semantic_structural_rollback` should mainly be read through `mean_purity` and whether suspicious large merges increase.")
    lines.append("- `wo_conservative_protection` should mainly be read together with simple-case visualization, especially cases similar to `9fc08a316ad7`.")
    lines.append("- `wo_learned_boundary_optimization` is useful for appendix-level justification of the learned stage-2 split/merge loops.")
    lines.append("")

    lines.append("## Suggested Paper Use")
    lines.append("")
    lines.append("1. Main paper: report `full`, `wo_bodyfirst_host_recovery`, `wo_semantic_structural_rollback`, `wo_conservative_protection`.")
    lines.append("2. Supplementary material: optionally add `wo_learned_boundary_optimization`.")
    lines.append("3. In the text, discuss body-first host recovery as the most likely contributor on complex cases, and conservative protection as the reason simple clean cases are not unnecessarily damaged.")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build an ablation comparison report from completed variant output directories.")
    parser.add_argument("--outputs_root", default=str(ROOT_DIR / "03_outputs" / "ablation_study_20260502_seed0"))
    parser.add_argument("--manual_dir", default=str(ROOT_DIR / "manual_groupings_reference"))
    parser.add_argument("--report_dir", default=str(ROOT_DIR / "05_reports" / "ablation_20260502_seed0"))
    args = parser.parse_args()

    outputs_root = Path(args.outputs_root)
    manual_dir = Path(args.manual_dir)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    comparison = summarize_outputs(outputs_root, manual_dir)
    report_json = report_dir / "ablation_comparison_20260427.json"
    report_md = report_dir / "ablation_comparison_20260427.md"

    report_json.write_text(json.dumps(comparison, ensure_ascii=False, indent=2), encoding="utf-8")
    report_md.write_text(build_markdown(comparison), encoding="utf-8")
    print(f"wrote {report_json}")
    print(f"wrote {report_md}")


if __name__ == "__main__":
    main()
