import argparse
import json
import os
import re
from colorsys import hsv_to_rgb
from typing import Dict, List, Tuple

import numpy as np
import trimesh


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)


def simplify_part_name(name: str) -> str:
    name = str(name)
    if "part_" in name:
        return "part_" + name.rsplit("part_", 1)[-1]
    return name


def infer_seg_id_from_name(name: str, fallback: int) -> int:
    text = str(name)
    m = re.search(r"part_(\d+)$", text)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)$", text)
    if m:
        return int(m.group(1))
    return int(fallback)


def make_palette(n: int, alpha: int = 255) -> np.ndarray:
    if n <= 0:
        return np.zeros((0, 4), dtype=np.uint8)
    colors = []
    for i in range(n):
        h = (i * 0.61803398875) % 1.0
        r, g, b = hsv_to_rgb(h, 0.75, 0.95)
        colors.append([int(r * 255), int(g * 255), int(b * 255), alpha])
    return np.asarray(colors, dtype=np.uint8)


def color_mesh(mesh: trimesh.Trimesh, color: np.ndarray) -> trimesh.Trimesh:
    out = mesh.copy()
    out.visual.vertex_colors = np.tile(np.asarray(color, dtype=np.uint8), (len(out.vertices), 1))
    return out


def load_scene_parts(scene_path: str) -> List[Tuple[str, trimesh.Trimesh]]:
    obj = trimesh.load(scene_path, force=None)
    if isinstance(obj, trimesh.Trimesh):
        return [("mesh", obj)]
    if not isinstance(obj, trimesh.Scene):
        raise ValueError(f"Unsupported scene type: {type(obj)}")

    parts: List[Tuple[str, trimesh.Trimesh]] = []
    for node_name in obj.graph.nodes:
        data = obj.graph[node_name]
        try:
            transform, geom_name = data
        except Exception:
            continue
        if geom_name is None:
            continue
        mesh = obj.geometry[geom_name].copy()
        try:
            mesh.apply_transform(transform)
        except Exception:
            pass
        parts.append((str(node_name), mesh))
    return parts


def export_scene(scene: trimesh.Scene, out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    blob = scene.export(file_type="glb")
    with open(out_path, "wb") as f:
        f.write(blob)


def pca_axis(points: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float32)
    if pts.shape[0] < 3:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    pts = pts - pts.mean(axis=0, keepdims=True)
    cov = pts.T @ pts / max(len(pts) - 1, 1)
    vals, vecs = np.linalg.eigh(cov)
    axis = vecs[:, np.argmax(vals)]
    norm = float(np.linalg.norm(axis))
    if norm < 1e-8:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    return (axis / norm).astype(np.float32)


def horizontal_unit(vec: np.ndarray, fallback: np.ndarray | None = None) -> np.ndarray:
    out = np.asarray([float(vec[0]), 0.0, float(vec[2])], dtype=np.float32)
    norm = float(np.linalg.norm(out))
    if norm >= 1e-8:
        return out / norm
    if fallback is not None:
        return horizontal_unit(fallback, None)
    return np.array([1.0, 0.0, 0.0], dtype=np.float32)


def semantic_offset_weights(semantic: str) -> Tuple[float, float]:
    sem = str(semantic).lower()
    if sem == "gong":
        return 0.95, 0.015
    if sem in {"fang", "chuan"}:
        return 0.80, 0.012
    if sem == "ang":
        return 1.00, 0.020
    if sem == "dou":
        return 0.35, 0.030
    return 0.55, 0.015


def horizontal_pca_axis(points_xz: np.ndarray) -> np.ndarray:
    pts = np.asarray(points_xz, dtype=np.float32)
    if pts.shape[0] < 2:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    centered = pts - pts.mean(axis=0, keepdims=True)
    cov = centered.T @ centered / max(len(pts) - 1, 1)
    vals, vecs = np.linalg.eigh(cov)
    axis2 = vecs[:, np.argmax(vals)]
    axis3 = np.array([float(axis2[0]), 0.0, float(axis2[1])], dtype=np.float32)
    return horizontal_unit(axis3)


def build_component_meshes(
    fragment_glb: str,
    refined_npz: str,
) -> Tuple[Dict[int, trimesh.Trimesh], Dict[int, List[int]]]:
    data = np.load(refined_npz, allow_pickle=True)
    segment_names = [str(x) for x in data["segment_names"].tolist()]
    fragment_labels = data["fragment_labels"].astype(np.int32)
    comp_labels = data["comp_labels"].astype(np.int32)

    seg_to_comp: Dict[int, int] = {}
    for seg_id in np.unique(fragment_labels):
        mask = fragment_labels == seg_id
        vals, cnts = np.unique(comp_labels[mask], return_counts=True)
        seg_to_comp[int(seg_id)] = int(vals[np.argmax(cnts)])

    fragment_parts = load_scene_parts(fragment_glb)
    fragment_map = {name: mesh for name, mesh in fragment_parts}
    groups: Dict[int, List[trimesh.Trimesh]] = {}
    group_seg_ids: Dict[int, List[int]] = {}
    for idx, name in enumerate(segment_names):
        if name not in fragment_map:
            continue
        seg_id = infer_seg_id_from_name(name, idx)
        comp_id = int(seg_to_comp[seg_id])
        groups.setdefault(comp_id, []).append(fragment_map[name].copy())
        group_seg_ids.setdefault(comp_id, []).append(int(seg_id))

    merged_meshes: Dict[int, trimesh.Trimesh] = {}
    for comp_id, meshes in groups.items():
        merged_meshes[comp_id] = meshes[0].copy() if len(meshes) == 1 else trimesh.util.concatenate(meshes)
        group_seg_ids[comp_id] = sorted(group_seg_ids[comp_id])
    return merged_meshes, group_seg_ids


def compute_layout_offsets(
    component_meshes: Dict[int, trimesh.Trimesh],
    structure_components: List[Dict],
    layer_gap_scale: float,
    radial_gap_scale: float,
    tangential_gap_scale: float,
) -> Tuple[Dict[int, np.ndarray], float]:
    if not component_meshes:
        return {}, 1.0

    mins = []
    maxs = []
    for mesh in component_meshes.values():
        mins.append(mesh.bounds[0])
        maxs.append(mesh.bounds[1])
    global_min = np.min(np.vstack(mins), axis=0)
    global_max = np.max(np.vstack(maxs), axis=0)
    global_diag = float(np.linalg.norm(global_max - global_min))
    global_center = 0.5 * (global_min + global_max)

    comp_info_map = {int(item["component_id"]): item for item in structure_components}
    layer_to_comp_ids: Dict[int, List[int]] = {}
    layer_bounds: Dict[int, Tuple[float, float]] = {}
    for comp_id, mesh in component_meshes.items():
        info = comp_info_map.get(int(comp_id), {})
        layer_id = int(info.get("layer_id", 0))
        layer_to_comp_ids.setdefault(layer_id, []).append(int(comp_id))
        b = mesh.bounds
        ymin = float(b[0][1])
        ymax = float(b[1][1])
        if layer_id not in layer_bounds:
            layer_bounds[layer_id] = (ymin, ymax)
        else:
            prev_min, prev_max = layer_bounds[layer_id]
            layer_bounds[layer_id] = (min(prev_min, ymin), max(prev_max, ymax))

    sorted_layers = sorted(layer_to_comp_ids.keys())
    layer_shift_y: Dict[int, float] = {}
    base_layer_step = float(layer_gap_scale * global_diag)
    for idx, layer_id in enumerate(sorted_layers):
        layer_shift_y[layer_id] = float(idx * base_layer_step)

    offsets: Dict[int, np.ndarray] = {}
    for layer_id in sorted_layers:
        comp_ids = sorted(layer_to_comp_ids[layer_id])
        centroids = np.vstack([
            np.asarray(component_meshes[cid].bounds.mean(axis=0), dtype=np.float32)
            for cid in comp_ids
        ])
        layer_center = centroids.mean(axis=0)
        tangent = horizontal_pca_axis(centroids[:, [0, 2]])
        radial_base = horizontal_unit(layer_center - global_center, tangent)
        if len(comp_ids) == 1:
            ordered = comp_ids
            rank_map = {comp_ids[0]: 0.0}
        else:
            proj = [
                float(np.dot(np.asarray(component_meshes[cid].bounds.mean(axis=0), dtype=np.float32) - layer_center, tangent))
                for cid in comp_ids
            ]
            ordered = [cid for _, cid in sorted(zip(proj, comp_ids), key=lambda x: x[0])]
            center_rank = 0.5 * (len(ordered) - 1)
            rank_map = {cid: (idx - center_rank) for idx, cid in enumerate(ordered)}

        for comp_id in ordered:
            mesh = component_meshes[comp_id]
            info = comp_info_map.get(int(comp_id), {})
            semantic = str(info.get("semantic", "other"))
            centroid = np.asarray(mesh.bounds.mean(axis=0), dtype=np.float32)
            radial_local = horizontal_unit(centroid - layer_center, radial_base)
            combined_radial = horizontal_unit(radial_base + 0.65 * radial_local, tangent)
            tangential = np.asarray([-tangent[2], 0.0, tangent[0]], dtype=np.float32)
            if float(np.dot(centroid - layer_center, tangential)) < 0.0:
                tangential = -tangential

            radial_w, semantic_lift_w = semantic_offset_weights(semantic)
            tang_rank = float(rank_map.get(comp_id, 0.0))
            layer_offset = np.array([0.0, layer_shift_y[layer_id], 0.0], dtype=np.float32)
            radial_offset = combined_radial * float(radial_gap_scale * global_diag * radial_w)
            tangential_offset = tangential * float(tang_rank * tangential_gap_scale * global_diag)
            semantic_lift = np.array([0.0, semantic_lift_w * global_diag, 0.0], dtype=np.float32)
            offsets[int(comp_id)] = layer_offset + radial_offset + tangential_offset + semantic_lift
    return offsets, global_diag


def build_exploded_scenes(
    component_meshes: Dict[int, trimesh.Trimesh],
    structure_components: List[Dict],
    shift_scale: float,
    layer_gap_scale: float,
    radial_gap_scale: float,
    tangential_gap_scale: float,
) -> Tuple[trimesh.Scene, trimesh.Scene, Dict[int, List[float]], float]:
    comp_ids = sorted(component_meshes.keys())
    palette = make_palette(len(comp_ids))
    comp_to_color = {cid: palette[i] for i, cid in enumerate(comp_ids)}

    offsets, global_diag = compute_layout_offsets(
        component_meshes=component_meshes,
        structure_components=structure_components,
        layer_gap_scale=layer_gap_scale,
        radial_gap_scale=radial_gap_scale,
        tangential_gap_scale=tangential_gap_scale,
    )
    compare_shift = float(max(global_diag, 1e-6) * shift_scale)

    exploded_scene = trimesh.Scene()
    compare_scene = trimesh.Scene()
    offset_export: Dict[int, List[float]] = {}
    for cid in comp_ids:
        base_mesh = color_mesh(component_meshes[cid], comp_to_color[cid])
        exploded_mesh = base_mesh.copy()
        offset = np.asarray(offsets.get(cid, np.zeros((3,), dtype=np.float32)), dtype=np.float32)
        exploded_mesh.apply_translation(offset)
        exploded_scene.add_geometry(exploded_mesh, node_name=f"exploded_component_{cid}")

        left_mesh = base_mesh.copy()
        left_mesh.apply_translation(np.array([-compare_shift, 0.0, 0.0], dtype=np.float32))
        compare_scene.add_geometry(left_mesh, node_name=f"refined_component_{cid}")
        right_mesh = base_mesh.copy()
        right_mesh.apply_translation(np.array([compare_shift, 0.0, 0.0], dtype=np.float32) + offset)
        compare_scene.add_geometry(right_mesh, node_name=f"exploded_component_{cid}")
        offset_export[int(cid)] = [float(x) for x in offset.tolist()]

    return exploded_scene, compare_scene, offset_export, compare_shift


def run_one(uid: str, args: argparse.Namespace) -> None:
    fragment_glb = os.path.join(args.fragment_dir, f"{uid}.glb")
    refined_npz = os.path.join(args.refined_dir, f"{uid}_refined.npz")
    summary_json = os.path.join(args.refined_dir, f"{uid}_summary.json")
    if not os.path.exists(fragment_glb):
        raise FileNotFoundError(f"fragment glb missing: {fragment_glb}")
    if not os.path.exists(refined_npz):
        raise FileNotFoundError(f"refined npz missing: {refined_npz}")
    if not os.path.exists(summary_json):
        raise FileNotFoundError(f"summary json missing: {summary_json}")

    with open(summary_json, "r", encoding="utf-8") as f:
        summary = json.load(f)
    structure_components = summary.get("structure", {}).get("components", [])
    component_meshes, comp_segments = build_component_meshes(fragment_glb=fragment_glb, refined_npz=refined_npz)

    exploded_scene, compare_scene, offsets, compare_shift = build_exploded_scenes(
        component_meshes=component_meshes,
        structure_components=structure_components,
        shift_scale=args.compare_shift,
        layer_gap_scale=args.layer_gap,
        radial_gap_scale=args.radial_gap,
        tangential_gap_scale=args.tangential_gap,
    )

    out_dir = os.path.join(args.out_dir, uid)
    os.makedirs(out_dir, exist_ok=True)
    exploded_path = os.path.join(out_dir, f"{uid}_exploded_mesh.glb")
    compare_path = os.path.join(out_dir, f"{uid}_refined_vs_exploded_mesh.glb")
    export_scene(exploded_scene, exploded_path)
    export_scene(compare_scene, compare_path)

    report = {
        "uid": uid,
        "num_components": len(component_meshes),
        "files": {
            "exploded_mesh": exploded_path,
            "refined_vs_exploded_mesh": compare_path,
        },
        "layout": {
            "layer_gap_scale": float(args.layer_gap),
            "radial_gap_scale": float(args.radial_gap),
            "tangential_gap_scale": float(args.tangential_gap),
            "compare_shift_scale": float(args.compare_shift),
            "compare_shift": float(compare_shift),
        },
        "components": [
            {
                "component_id": int(item["component_id"]),
                "semantic": str(item.get("semantic", "other")),
                "layer_id": int(item.get("layer_id", 0)),
                "segment_ids": comp_segments.get(int(item["component_id"]), []),
                "offset": offsets.get(int(item["component_id"]), [0.0, 0.0, 0.0]),
            }
            for item in structure_components
            if int(item["component_id"]) in component_meshes
        ],
    }
    with open(os.path.join(out_dir, f"{uid}_exploded_summary.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"[OK] exploded {uid} -> {out_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate exploded mesh views from refined component outputs.")
    parser.add_argument("--uid", default="")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    parser.add_argument("--refined_dir", default=os.path.join(ROOT_DIR, "03_outputs", "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0"))
    parser.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "04_visualizations", "exploded_views_semanticopt_final_examples_20260502_seed0"))
    parser.add_argument("--layer_gap", type=float, default=0.09)
    parser.add_argument("--radial_gap", type=float, default=0.22)
    parser.add_argument("--tangential_gap", type=float, default=0.24)
    parser.add_argument("--compare_shift", type=float, default=1.55)
    args = parser.parse_args()

    if args.all:
        uids = sorted(os.path.splitext(f)[0].replace("_refined", "") for f in os.listdir(args.refined_dir) if f.endswith("_refined.npz"))
        seen = []
        for uid in uids:
            if uid not in seen:
                seen.append(uid)
        ok = 0
        fail = 0
        for uid in seen:
            try:
                run_one(uid, args)
                ok += 1
            except Exception as e:
                fail += 1
                print(f"[FAIL] exploded {uid}: {e}")
        print(f"done. success={ok}, failed={fail}")
        return

    if not args.uid:
        raise ValueError("Please provide --uid or use --all.")
    run_one(args.uid, args)


if __name__ == "__main__":
    main()
