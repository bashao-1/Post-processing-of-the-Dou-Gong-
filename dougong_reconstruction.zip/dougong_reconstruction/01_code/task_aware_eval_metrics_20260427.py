from collections import Counter, defaultdict
from typing import Dict, List, Tuple

import numpy as np

import dougong_refine_v4 as base


MATCH_THRESHOLDS = (0.50, 0.75)


def build_component_points(case_row: dict, comp_map: Dict[int, int]) -> Dict[int, np.ndarray]:
    comp_points = defaultdict(list)
    for seg in case_row["segments"]:
        seg_id = int(seg.seg_id)
        comp_points[int(comp_map[seg_id])].append(np.asarray(seg.points, dtype=np.float32))
    return {cid: np.vstack(v).astype(np.float32) for cid, v in comp_points.items()}


def build_surface_overlap_tables(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[base.Part],
    tau: float,
    max_points: int = 768,
) -> Dict[str, object]:
    pred_ids = sorted(int(cid) for cid in comp_points.keys())
    gt_ids = list(range(len(gt_parts)))
    pred_to_gt = np.zeros((len(pred_ids), len(gt_ids)), dtype=np.float64)
    gt_to_pred = np.zeros((len(pred_ids), len(gt_ids)), dtype=np.float64)
    sym_score = np.zeros((len(pred_ids), len(gt_ids)), dtype=np.float64)

    for i, cid in enumerate(pred_ids):
        pred_pts = np.asarray(comp_points[cid], dtype=np.float32)
        for j, gid in enumerate(gt_ids):
            gt_pts = np.asarray(gt_parts[gid].points, dtype=np.float32)
            score, forward, backward = base.symmetric_component_match_score(
                pred_pts,
                gt_pts,
                tau=tau,
                max_points=max_points,
                beta=1.0,
            )
            pred_to_gt[i, j] = float(forward)
            gt_to_pred[i, j] = float(backward)
            sym_score[i, j] = float(score)

    return {
        "pred_ids": pred_ids,
        "gt_ids": gt_ids,
        "pred_to_gt": pred_to_gt,
        "gt_to_pred": gt_to_pred,
        "sym_score": sym_score,
    }


def _hungarian_min_cost(cost: np.ndarray) -> List[int]:
    matrix = np.asarray(cost, dtype=np.float64)
    if matrix.ndim != 2:
        raise ValueError("cost must be a 2D matrix")
    n_rows, n_cols = matrix.shape
    if n_rows == 0:
        return []
    transposed = False
    if n_rows > n_cols:
        matrix = matrix.T
        n_rows, n_cols = matrix.shape
        transposed = True

    u = np.zeros(n_rows + 1, dtype=np.float64)
    v = np.zeros(n_cols + 1, dtype=np.float64)
    p = np.zeros(n_cols + 1, dtype=np.int32)
    way = np.zeros(n_cols + 1, dtype=np.int32)

    for i in range(1, n_rows + 1):
        p[0] = i
        j0 = 0
        minv = np.full(n_cols + 1, np.inf, dtype=np.float64)
        used = np.zeros(n_cols + 1, dtype=bool)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = np.inf
            j1 = 0
            for j in range(1, n_cols + 1):
                if used[j]:
                    continue
                cur = matrix[i0 - 1, j - 1] - u[i0] - v[j]
                if cur < minv[j]:
                    minv[j] = cur
                    way[j] = j0
                if minv[j] < delta:
                    delta = minv[j]
                    j1 = j
            for j in range(n_cols + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break

    row_to_col_small = [-1] * n_rows
    for j in range(1, n_cols + 1):
        if p[j] > 0:
            row_to_col_small[p[j] - 1] = j - 1

    if not transposed:
        return row_to_col_small

    row_to_col = [-1] * cost.shape[0]
    for gt_row, pred_col in enumerate(row_to_col_small):
        if pred_col >= 0:
            row_to_col[pred_col] = gt_row
    return row_to_col


def solve_optimal_component_matching(overlap_tables: Dict[str, object]) -> Dict[str, object]:
    pred_ids = overlap_tables["pred_ids"]
    gt_ids = overlap_tables["gt_ids"]
    sym_score = np.asarray(overlap_tables["sym_score"], dtype=np.float64)
    pred_to_gt = np.asarray(overlap_tables["pred_to_gt"], dtype=np.float64)
    gt_to_pred = np.asarray(overlap_tables["gt_to_pred"], dtype=np.float64)

    if sym_score.size == 0:
        return {
            "pairs": [],
            "num_pred": len(pred_ids),
            "num_gt": len(gt_ids),
            "score_sum": 0.0,
            "matched_geometry_mean": 0.0,
            "matched_forward_mean": 0.0,
            "matched_backward_mean": 0.0,
        }

    max_score = float(np.max(sym_score)) if sym_score.size else 0.0
    cost = max_score - sym_score
    assignment = _hungarian_min_cost(cost)

    pairs = []
    score_sum = 0.0
    forward_scores = []
    backward_scores = []
    for pred_idx, gt_idx in enumerate(assignment):
        if gt_idx < 0:
            continue
        score = float(sym_score[pred_idx, gt_idx])
        if score <= 1e-8:
            continue
        forward = float(pred_to_gt[pred_idx, gt_idx])
        backward = float(gt_to_pred[pred_idx, gt_idx])
        score_sum += score
        forward_scores.append(forward)
        backward_scores.append(backward)
        pairs.append(
            {
                "pred_idx": int(pred_idx),
                "gt_idx": int(gt_idx),
                "pred_id": int(pred_ids[pred_idx]),
                "gt_id": int(gt_ids[gt_idx]),
                "score": score,
                "forward": forward,
                "backward": backward,
            }
        )

    return {
        "pairs": pairs,
        "num_pred": len(pred_ids),
        "num_gt": len(gt_ids),
        "score_sum": float(score_sum),
        "matched_geometry_mean": float(np.mean([p["score"] for p in pairs])) if pairs else 0.0,
        "matched_forward_mean": float(np.mean(forward_scores)) if forward_scores else 0.0,
        "matched_backward_mean": float(np.mean(backward_scores)) if backward_scores else 0.0,
    }


def component_recovery_metrics(matching: Dict[str, object]) -> Dict[str, float]:
    num_pred = int(matching["num_pred"])
    num_gt = int(matching["num_gt"])
    pairs = matching["pairs"]
    score_sum = float(matching["score_sum"])
    denom = max(num_pred + num_gt, 1)

    out = {
        "num_pred_components_eval": float(num_pred),
        "num_gt_components_eval": float(num_gt),
        "count_error_ratio": float(abs(num_pred - num_gt) / max(num_gt, 1)),
        "component_recovery_score": float(2.0 * score_sum / denom),
        "matched_geometry_mean": float(matching["matched_geometry_mean"]),
        "matched_forward_mean": float(matching["matched_forward_mean"]),
        "matched_backward_mean": float(matching["matched_backward_mean"]),
        "matched_pair_fraction": float(len(pairs) / max(max(num_pred, num_gt), 1)),
    }

    for thr in MATCH_THRESHOLDS:
        matched_thr = [p for p in pairs if float(p["score"]) >= thr]
        tp = len(matched_thr)
        pred_validity = float(tp / max(num_pred, 1))
        gt_recovery = float(tp / max(num_gt, 1))
        out[f"pred_validity_rate_{int(thr * 100):02d}"] = pred_validity
        out[f"gt_recovery_rate_{int(thr * 100):02d}"] = gt_recovery
        out[f"instance_f1_{int(thr * 100):02d}"] = float(base.harmonic_mean_score(pred_validity, gt_recovery))

    return out


def semantic_recovery_metrics(
    matching: Dict[str, object],
    comp_sem: Dict[int, str],
    gt_parts: List[base.Part],
) -> Dict[str, float]:
    num_pred = int(matching["num_pred"])
    num_gt = int(matching["num_gt"])
    pairs = matching["pairs"]
    denom = max(num_pred + num_gt, 1)

    pred_sem_by_id = {int(cid): str(sem) for cid, sem in comp_sem.items()}
    gt_sem_by_idx = {int(idx): str(part.semantic) for idx, part in enumerate(gt_parts)}
    pred_ids = sorted(pred_sem_by_id.keys())
    gt_ids = list(range(len(gt_parts)))
    pred_class_counts = Counter(pred_sem_by_id.get(cid, "unknown") for cid in pred_ids)
    gt_class_counts = Counter(gt_sem_by_idx[gid] for gid in gt_ids)
    classes = sorted(set(pred_class_counts.keys()) | set(gt_class_counts.keys()))

    correct_score_sum = 0.0
    correct_pairs = []
    for pair in pairs:
        pred_sem = pred_sem_by_id.get(int(pair["pred_id"]), "unknown")
        gt_sem = gt_sem_by_idx.get(int(pair["gt_id"]), "unknown")
        if pred_sem == gt_sem:
            correct_score_sum += float(pair["score"])
            correct_pairs.append(pair)

    out = {
        "semantic_recovery_score": float(2.0 * correct_score_sum / denom),
    }

    for thr in MATCH_THRESHOLDS:
        tp_class = Counter()
        correct_thr = 0
        for pair in pairs:
            if float(pair["score"]) < thr:
                continue
            pred_sem = pred_sem_by_id.get(int(pair["pred_id"]), "unknown")
            gt_sem = gt_sem_by_idx.get(int(pair["gt_id"]), "unknown")
            if pred_sem == gt_sem:
                correct_thr += 1
                tp_class[gt_sem] += 1

        pred_precision = float(correct_thr / max(num_pred, 1))
        gt_recall = float(correct_thr / max(num_gt, 1))
        out[f"semantic_instance_f1_{int(thr * 100):02d}"] = float(base.harmonic_mean_score(pred_precision, gt_recall))
        out[f"semantic_gt_recall_{int(thr * 100):02d}"] = gt_recall

        macro_f1s = []
        for cls in classes:
            tp = float(tp_class.get(cls, 0))
            fp = float(pred_class_counts.get(cls, 0) - tp)
            fn = float(gt_class_counts.get(cls, 0) - tp)
            prec = tp / max(tp + fp, 1e-8)
            rec = tp / max(tp + fn, 1e-8)
            f1 = 0.0
            if prec > 0.0 or rec > 0.0:
                f1 = 2.0 * prec * rec / max(prec + rec, 1e-8)
            macro_f1s.append(float(f1))
        out[f"semantic_macro_f1_{int(thr * 100):02d}"] = float(np.mean(macro_f1s)) if macro_f1s else 0.0

    return out


def _support_edge_set(structure: Dict[str, object]) -> set[Tuple[int, int]]:
    support_edges: set[Tuple[int, int]] = set()
    for edge in structure.get("assembly_edges", []):
        if edge.get("relation") != "support":
            continue
        source = int(edge.get("source", -1))
        target = int(edge.get("target", -1))
        if source < 0 or target < 0 or source == target:
            continue
        support_edges.add((source, target))
    return support_edges


def _edge_prf(tp: int, pred_total: int, gt_total: int) -> Tuple[float, float, float]:
    if pred_total <= 0 and gt_total <= 0:
        return 1.0, 1.0, 1.0

    precision = float(tp / pred_total) if pred_total > 0 else 0.0
    recall = float(tp / gt_total) if gt_total > 0 else 1.0
    return precision, recall, float(base.harmonic_mean_score(precision, recall))


def support_edge_recovery_metrics(
    matching: Dict[str, object],
    comp_points: Dict[int, np.ndarray],
    comp_sem: Dict[int, str],
    descriptors: Dict[int, Dict],
    pair_relations: Dict[Tuple[int, int], Dict[str, float]],
    gt_parts: List[base.Part],
    global_meta: Dict[str, np.ndarray] | None = None,
) -> Dict[str, float]:
    if global_meta is None:
        descriptors, pair_relations, global_meta = base.build_component_descriptors(comp_points)

    pred_structure = base.recover_component_structure(
        comp_points,
        comp_sem,
        descriptors,
        pair_relations,
        global_meta,
    )
    pred_support_edges = _support_edge_set(pred_structure)

    gt_comp_points = {
        int(idx): np.asarray(part.points, dtype=np.float32)
        for idx, part in enumerate(gt_parts)
    }
    gt_comp_sem = {
        int(idx): str(part.semantic)
        for idx, part in enumerate(gt_parts)
    }
    gt_descriptors, gt_pair_relations, gt_global_meta = base.build_component_descriptors(gt_comp_points)
    gt_structure = base.recover_component_structure(
        gt_comp_points,
        gt_comp_sem,
        gt_descriptors,
        gt_pair_relations,
        gt_global_meta,
    )
    gt_support_edges = _support_edge_set(gt_structure)

    pred_match = {
        int(pair["pred_id"]): {
            "gt_id": int(pair["gt_id"]),
            "score": float(pair["score"]),
        }
        for pair in matching["pairs"]
    }
    gt_match = {
        int(pair["gt_id"]): {
            "pred_id": int(pair["pred_id"]),
            "score": float(pair["score"]),
        }
        for pair in matching["pairs"]
    }

    mapped_pred_edges = set()
    for source, target in pred_support_edges:
        source_match = pred_match.get(int(source))
        target_match = pred_match.get(int(target))
        if source_match is None or target_match is None:
            continue
        mapped_pred_edges.add((int(source_match["gt_id"]), int(target_match["gt_id"])))

    tp = len(mapped_pred_edges & gt_support_edges)
    precision, recall, f1 = _edge_prf(tp, len(pred_support_edges), len(gt_support_edges))
    out = {
        "num_pred_support_edges_eval": float(len(pred_support_edges)),
        "num_gt_support_edges_eval": float(len(gt_support_edges)),
        "support_edge_precision": precision,
        "support_edge_recall": recall,
        "support_edge_f1": f1,
    }

    for thr in MATCH_THRESHOLDS:
        pred_edges_thr = set()
        for source, target in pred_support_edges:
            source_match = pred_match.get(int(source))
            target_match = pred_match.get(int(target))
            if source_match is None or target_match is None:
                continue
            if float(source_match["score"]) < thr or float(target_match["score"]) < thr:
                continue
            pred_edges_thr.add((int(source_match["gt_id"]), int(target_match["gt_id"])))

        gt_edges_thr = set()
        for source, target in gt_support_edges:
            source_match = gt_match.get(int(source))
            target_match = gt_match.get(int(target))
            if source_match is None or target_match is None:
                continue
            if float(source_match["score"]) < thr or float(target_match["score"]) < thr:
                continue
            gt_edges_thr.add((int(source), int(target)))

        tp_thr = len(pred_edges_thr & gt_edges_thr)
        precision_thr, recall_thr, f1_thr = _edge_prf(tp_thr, len(pred_edges_thr), len(gt_edges_thr))
        suffix = int(thr * 100)
        out[f"support_edge_precision_{suffix:02d}"] = precision_thr
        out[f"support_edge_recall_{suffix:02d}"] = recall_thr
        out[f"support_edge_f1_{suffix:02d}"] = f1_thr

    return out


def structure_plausibility_metrics(
    comp_sem: Dict[int, str],
    descriptors: Dict[int, Dict],
    pair_relations: Dict[Tuple[int, int], Dict[str, float]],
) -> Dict[str, float]:
    if not comp_sem:
        return {
            "structure_plausibility": 0.0,
            "host_legality": 0.0,
            "gong_clean_ratio": 0.0,
            "upper_dou_support_ratio": 0.0,
            "structure_violation_rate": 1.0,
        }

    ctx = base.build_semantic_context(descriptors, pair_relations)
    host_events = 0
    valid_host_events = 0
    gong_total = 0
    gong_clean = 0
    upper_dou_total = 0
    upper_dou_supported = 0

    for cid, sem in comp_sem.items():
        info = ctx.get(cid, {})
        desc = descriptors.get(cid, {})
        small_above = int(info.get("small_above", 0))
        small_below = int(info.get("small_below", 0))

        if small_above > 0:
            host_events += small_above
            if sem == "gong":
                valid_host_events += small_above

        if sem == "gong":
            gong_total += 1
            if small_below <= 0:
                gong_clean += 1

        if sem == "dou" and float(desc.get("z_rank", 0.0)) >= 0.15:
            upper_dou_total += 1
            if float(desc.get("support_below_count", 0.0)) >= 1.0:
                upper_dou_supported += 1

    host_legality = float(valid_host_events / host_events) if host_events > 0 else 1.0
    gong_clean_ratio = float(gong_clean / max(gong_total, 1)) if gong_total > 0 else 1.0
    upper_dou_support_ratio = float(upper_dou_supported / max(upper_dou_total, 1)) if upper_dou_total > 0 else 1.0

    active_scores = []
    if host_events > 0:
        active_scores.append(host_legality)
    if gong_total > 0:
        active_scores.append(gong_clean_ratio)
    if upper_dou_total > 0:
        active_scores.append(upper_dou_support_ratio)

    violation_total = (
        (host_events - valid_host_events)
        + (gong_total - gong_clean)
        + (upper_dou_total - upper_dou_supported)
    )
    opportunity_total = host_events + gong_total + upper_dou_total

    return {
        "structure_plausibility": float(np.mean(active_scores)) if active_scores else 1.0,
        "host_legality": host_legality,
        "gong_clean_ratio": gong_clean_ratio,
        "upper_dou_support_ratio": upper_dou_support_ratio,
        "structure_violation_rate": float(violation_total / max(opportunity_total, 1)),
    }


def compute_task_aware_case_metrics(
    case_row: dict,
    comp_map: Dict[int, int],
    gt_parts: List[base.Part],
    comp_sem: Dict[int, str],
    descriptors: Dict[int, Dict],
    pair_relations: Dict[Tuple[int, int], Dict[str, float]],
    global_meta: Dict[str, np.ndarray] | None = None,
    tau: float | None = None,
    comp_points: Dict[int, np.ndarray] | None = None,
) -> Dict[str, float]:
    if comp_points is None:
        comp_points = build_component_points(case_row, comp_map)

    if tau is None:
        tau = max(0.05, 0.12 * float(case_row.get("global_diag", 1.0)))

    overlap_tables = build_surface_overlap_tables(comp_points, gt_parts, tau=float(tau), max_points=768)
    matching = solve_optimal_component_matching(overlap_tables)
    recovery_metrics = component_recovery_metrics(matching)
    semantic_metrics = semantic_recovery_metrics(matching, comp_sem, gt_parts)
    seg_weights = base.segment_weight_map(case_row["segments"])
    seg_to_gt, _ = base.segment_label_map_from_gt(case_row["segments"], gt_parts)
    semantic_distribution_score = base.semantic_distribution_iou_from_seg_maps(
        comp_map, seg_to_gt, comp_sem, gt_parts, seg_weights
    )
    relation_metrics = support_edge_recovery_metrics(
        matching,
        comp_points,
        comp_sem,
        descriptors,
        pair_relations,
        gt_parts,
        global_meta=global_meta,
    )
    structure_metrics = structure_plausibility_metrics(comp_sem, descriptors, pair_relations)
    num_pred = float(recovery_metrics.get("num_pred_components_eval", 0.0))
    num_gt = float(recovery_metrics.get("num_gt_components_eval", 0.0))
    overmerge_ratio = max(num_gt - num_pred, 0.0) / max(num_gt, 1.0)
    overseg_ratio = max(num_pred - num_gt, 0.0) / max(num_gt, 1.0)
    structure_plausibility_adjusted = float(
        base.harmonic_mean_score(
            float(structure_metrics.get("structure_plausibility", 0.0)),
            float(recovery_metrics.get("gt_recovery_rate_50", 0.0)),
        )
    )
    return {
        **recovery_metrics,
        **semantic_metrics,
        "semantic_distribution_score": semantic_distribution_score,
        **relation_metrics,
        **structure_metrics,
        "structure_plausibility_adjusted": structure_plausibility_adjusted,
        "overmerge_ratio": float(overmerge_ratio),
        "overseg_ratio": float(overseg_ratio),
    }


def summarize_task_aware_rows(rows: List[Dict[str, float]]) -> Dict[str, float]:
    if not rows:
        return {}

    keys = [
        "num_pred_components_eval",
        "num_gt_components_eval",
        "count_error_ratio",
        "component_recovery_score",
        "matched_geometry_mean",
        "matched_forward_mean",
        "matched_backward_mean",
        "matched_pair_fraction",
        "pred_validity_rate_50",
        "gt_recovery_rate_50",
        "instance_f1_50",
        "pred_validity_rate_75",
        "gt_recovery_rate_75",
        "instance_f1_75",
        "semantic_distribution_score",
        "semantic_recovery_score",
        "semantic_instance_f1_50",
        "semantic_gt_recall_50",
        "semantic_macro_f1_50",
        "semantic_instance_f1_75",
        "semantic_gt_recall_75",
        "semantic_macro_f1_75",
        "num_pred_support_edges_eval",
        "num_gt_support_edges_eval",
        "support_edge_precision",
        "support_edge_recall",
        "support_edge_f1",
        "support_edge_precision_50",
        "support_edge_recall_50",
        "support_edge_f1_50",
        "support_edge_precision_75",
        "support_edge_recall_75",
        "support_edge_f1_75",
        "structure_plausibility",
        "structure_plausibility_adjusted",
        "host_legality",
        "gong_clean_ratio",
        "upper_dou_support_ratio",
        "structure_violation_rate",
        "overmerge_ratio",
        "overseg_ratio",
    ]

    summary = {
        "metric_family": "component_matching_from_scratch_v1",
        "matching_basis": "surface_overlap_one_to_one_assignment",
    }
    for key in keys:
        vals = [float(r[key]) for r in rows if key in r]
        if vals:
            summary[f"mean_{key}"] = float(np.mean(vals))
    return summary
