"""Copy saved outputs and replace only component semantic labels in summaries."""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source_dir", type=Path, required=True)
    ap.add_argument("--overlay_dir", type=Path, required=True)
    ap.add_argument("--out_dir", type=Path, required=True)
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for overlay_path in sorted(args.overlay_dir.glob("*_semantic_overlay.json")):
        uid = overlay_path.name.replace("_semantic_overlay.json", "")
        overlay = json.loads(overlay_path.read_text(encoding="utf-8"))
        labels = {int(x["component_id"]): str(x["optimized_semantic"])
                  for x in overlay.get("components", [])}
        src_npz = args.source_dir / f"{uid}_refined.npz"
        src_summary = args.source_dir / f"{uid}_summary.json"
        if not src_npz.exists() or not src_summary.exists():
            raise FileNotFoundError(uid)
        shutil.copy2(src_npz, args.out_dir / src_npz.name)
        summary = json.loads(src_summary.read_text(encoding="utf-8"))
        component_ids = {int(x["component_id"]) for x in summary.get("components", [])}
        if component_ids != set(labels):
            raise ValueError(f"{uid}: overlay/summary component mismatch")
        for item in summary.get("components", []):
            item["semantic"] = labels[int(item["component_id"])]
            item["semantic_model"] = "final_nested_loco_semantic_predictor_fixed_config"
        summary["semantic_overlay_applied"] = True
        summary["merge_partition_frozen"] = True
        (args.out_dir / src_summary.name).write_text(
            json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        count += 1
    print(json.dumps({"cases": count, "out_dir": str(args.out_dir)}))


if __name__ == "__main__":
    main()
