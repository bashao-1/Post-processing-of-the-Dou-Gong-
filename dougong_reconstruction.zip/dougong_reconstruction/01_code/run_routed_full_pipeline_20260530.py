import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CODE_DIR = ROOT / "01_code"

ROUTER_SCRIPT = CODE_DIR / "route_overseg_then_refine_20260530.py"
PURE_REPORT_SCRIPT = CODE_DIR / "build_pure_eval_report_routed_20260530.py"
SOFT_EVAL_SCRIPT = CODE_DIR / "evaluate_saved_outputs_softmetrics_20260519.py"

ROUTED_OUTPUT_DIR = ROOT / "03_outputs" / "outputs_overseg_router_eval_20260530_seed0"
RAW_OUTPUT_DIR = ROOT / "03_outputs" / "outputs_raw_partgen_1_5_eval_20260502_seed0"
GENERIC_OUTPUT_DIR = ROOT / "03_outputs" / "outputs_generic_graph_baseline_eval_20260502_seed0"
LEGACY_FULL_OUTPUT_DIR = ROOT / "03_outputs" / "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0"
SOFT_EVAL_OUT = ROOT / "05_reports" / "soft_eval_routed_20260530"


def run_cmd(args: list[str]) -> None:
    print("[pipeline]", " ".join(str(x) for x in args))
    subprocess.run(args, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the routed overseg bundle pipeline: routed merge/eval, pure report, and soft-eval report."
    )
    parser.add_argument("--skip_eval", action="store_true")
    parser.add_argument("--skip_pure_report", action="store_true")
    parser.add_argument("--run_advantage_report", action="store_true")
    parser.add_argument("--skip_soft_eval", action="store_true")
    args = parser.parse_args()

    if not args.skip_eval:
        run_cmd([sys.executable, str(ROUTER_SCRIPT), "evaluate"])

    if not args.skip_pure_report:
        run_cmd([sys.executable, str(PURE_REPORT_SCRIPT)])

    if args.run_advantage_report:
        advantage_report_script = CODE_DIR / "build_router_advantage_report_20260531.py"
        run_cmd([sys.executable, str(advantage_report_script)])

    if not args.skip_soft_eval:
        run_cmd(
            [
                sys.executable,
                str(SOFT_EVAL_SCRIPT),
                "eval_targets",
                "--out_root",
                str(SOFT_EVAL_OUT),
                "--target",
                f"raw_partgen_1_5={RAW_OUTPUT_DIR}",
                "--target",
                f"generic_graph_baseline={GENERIC_OUTPUT_DIR}",
                "--target",
                f"routed_overseg_system={ROUTED_OUTPUT_DIR}",
                "--target",
                f"legacy_full_system={LEGACY_FULL_OUTPUT_DIR}",
            ]
        )


if __name__ == "__main__":
    main()
