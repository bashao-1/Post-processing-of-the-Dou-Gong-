import argparse
import json
import os
import sys
from collections import Counter, defaultdict
from typing import Dict, List, Tuple

import numpy as np


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)
SOURCE_BUNDLE_ROOT = ROOT_DIR
SOURCE_CODE_DIR = os.path.join(SOURCE_BUNDLE_ROOT, "01_code")
if SOURCE_BUNDLE_ROOT not in sys.path:
    sys.path.insert(0, SOURCE_BUNDLE_ROOT)
if SOURCE_CODE_DIR not in sys.path:
    sys.path.insert(0, SOURCE_CODE_DIR)

import dougong_refine_v4 as base
import dougong_refine_fragmentrefresh_stage1_stage2_standalone_bodyfirst_20260419 as fullsys
import dougong_refine_v7_fragmentrefresh_20260418_core as core
import task_aware_eval_metrics_20260427 as task_eval
import fragmentrefresh_stage2_utils_bodyfirst_20260419 as stage2_utils


DEFAULT_OUTPUT_DIR = os.path.join(ROOT_DIR, "03_outputs", "outputs_overseg_router_eval_20260530_seed0")
DEFAULT_FRAGMENT_DIR = r"data/fragments/glb"
DEFAULT_GT_DIR = r"data"
DEFAULT_MODEL_DIR = os.path.join(SOURCE_BUNDLE_ROOT, "02_models", "02_models")
DEFAULT_SEMANTIC_LABEL_MODEL_DIR = os.path.join(DEFAULT_MODEL_DIR, "semantic_label_aug_20260409")
DEFAULT_MODEL_DIR_STAGE2 = os.path.join(SOURCE_BUNDLE_ROOT, "02_models", "models_fragmentrefresh_realign_20260418")
DEFAULT_STAGE2_MODEL_JSON = os.path.join(DEFAULT_MODEL_DIR_STAGE2, "stage2_component_models.json")
DEFAULT_GONG_PRIOR_JSON = os.path.join(DEFAULT_MODEL_DIR_STAGE2, "gong_prior_models_realign.json")
DEFAULT_MANUAL_EDGE_CALIBRATOR_JSON = os.path.join(DEFAULT_MODEL_DIR_STAGE2, "manual_edge_calibrator_realign.json")

FULL_ROUTE_NAME = "full_overseg_route"
CONSERVATIVE_ROUTE_NAME = "conservative_route"

CONSERVATIVE_VARIANT = {
    "enable_split_loop": True,
    "enable_merge_loop": False,
    "enable_bodyfirst_host_recovery": False,
    "enable_semantic_structural_rollback": True,
    "enable_conservative_protection": True,
    "enable_stage1_bodyfirst": False,
    "enable_stage1_semantic_guidance": True,
    "enable_stage1_learned_priors": True,
    "enable_stage1_manual_edge_calibrator": True,
    "enable_stage1_learned_edge_scoring": True,
    "enable_stage1_augmented_edges": True,
    "enable_stage1_bottom_dou_detach": True,
}

DIAG_STAGE1_FLAGS = {
    "enable_stage1_bodyfirst": False,
    "enable_stage1_semantic_guidance": True,
    "enable_stage1_learned_priors": True,
    "enable_stage1_manual_edge_calibrator": True,
    "enable_stage1_learned_edge_scoring": True,
    "enable_stage1_augmented_edges": True,
    "enable_stage1_bottom_dou_detach": True,
}


def build_component_points(case_row: dict, comp_map: Dict[int, int]) -> Dict[int, np.ndarray]:
    comp_points = defaultdict(list)
    for seg in case_row["segments"]:
        seg_id = int(seg.seg_id)
        comp_points[int(comp_map[seg_id])].append(np.asarray(seg.points, dtype=np.float32))
    return {cid: np.vstack(v).astype(np.float32) for cid, v in comp_points.items()}


def dou_gong_host_score(
    dou_desc: Dict,
    gong_desc: Dict,
    rel: Dict[str, float],
    global_meta: Dict[str, np.ndarray],
) -> float:
    gh = max(float(global_meta.get("global_height", np.array([1.0], dtype=np.float32))[0]), 1e-8)
    gap = float(rel.get("gap", 1.0))
    xy_overlap = float(rel.get("xy_overlap", 0.0))
    axis_dot = float(rel.get("axis_dot", 0.0))
    size_ratio = float(rel.get("size_ratio", 0.0))
    dou_above_gong = 1.0 if float(dou_desc["centroid"][2]) > float(gong_desc["centroid"][2]) else 0.0
    top_gap_abs = abs(float(dou_desc["bbox_min"][2] - gong_desc["bbox_max"][2])) / gh
    vertical_center_gap = abs(float(dou_desc["centroid"][2] - gong_desc["centroid"][2])) / gh
    score = (
        2.5 * xy_overlap
        + 1.9 * max(0.0, 0.12 - gap) / 0.12
        + 1.1 * axis_dot
        + 0.9 * max(0.0, 0.07 - top_gap_abs) / 0.07
        + 0.5 * dou_above_gong
        + 0.4 * min(size_ratio / 0.45, 1.0)
        - 0.4 * max(0.0, vertical_center_gap - 0.30) / 0.30
    )
    return float(score)


def dou_like_margin(raw_scores: Dict[str, float]) -> float:
    raw_dou = float(raw_scores.get("dou", 1e9))
    others = [
        float(raw_scores.get("gong", 1e9)),
        float(raw_scores.get("ang", 1e9)),
        float(raw_scores.get("fang", 1e9)),
        float(raw_scores.get("other", 1e9)),
        float(raw_scores.get("chuan", 1e9)),
    ]
    return float(min(others) - raw_dou)


def diagnose_model_overseg(
    uid: str,
    args: argparse.Namespace,
    merge_semantic_model: Dict,
) -> Tuple[dict, dict]:
    case_row = stage2_utils.build_stage1_case_data(
        uid=uid,
        fragment_dir=args.fragment_dir,
        model_dir=args.model_dir,
        merge_semantic_model_dir=args.merge_semantic_model_dir,
        gong_prior_model_json=args.gong_prior_model_json,
        manual_edge_calibrator_json=args.manual_edge_calibrator_json,
        max_points=args.max_points,
        neighbor_ratio=args.neighbor_ratio,
        contact_eps=args.contact_eps,
        **DIAG_STAGE1_FLAGS,
    )
    comp_map = case_row["comp_map"]
    comp_points = build_component_points(case_row, comp_map)
    comp_sem, descriptors, pair_relations, global_meta, raw_scores = base.predict_component_semantics(comp_points, merge_semantic_model)

    gong_ids = [int(cid) for cid, sem in comp_sem.items() if str(sem) == "gong"]
    dou_ids = [int(cid) for cid, sem in comp_sem.items() if str(sem) == "dou"]
    dou_candidates = []
    host_counter = Counter()
    bindable_count = 0
    bindable_scores = []

    for dou_id in dou_ids:
        dou_desc = descriptors[dou_id]
        best = None
        for gong_id in gong_ids:
            key = tuple(sorted((int(dou_id), int(gong_id))))
            rel = pair_relations.get(key)
            if rel is None:
                continue
            gong_desc = descriptors[gong_id]
            score = dou_gong_host_score(dou_desc, gong_desc, rel, global_meta)
            candidate = {
                "dou_component_id": int(dou_id),
                "gong_component_id": int(gong_id),
                "score": float(score),
                "xy_overlap": float(rel.get("xy_overlap", 0.0)),
                "gap": float(rel.get("gap", 1.0)),
                "axis_dot": float(rel.get("axis_dot", 0.0)),
                "size_ratio": float(rel.get("size_ratio", 0.0)),
                "dou_margin": float(dou_like_margin(raw_scores.get(dou_id, {}))),
            }
            if best is None or score > best["score"]:
                best = candidate
        if best is None:
            continue
        is_bindable = bool(best["score"] >= args.bind_score_threshold)
        best["bindable"] = is_bindable
        dou_candidates.append(best)
        if is_bindable:
            bindable_count += 1
            bindable_scores.append(float(best["score"]))
            host_counter[int(best["gong_component_id"])] += 1

    bindable_candidates = [c for c in dou_candidates if bool(c["bindable"])]
    small_bindable = [c for c in bindable_candidates if float(c["size_ratio"]) <= float(args.small_dou_size_ratio)]
    strong_small_bindable = [
        c
        for c in small_bindable
        if float(c["dou_margin"]) >= float(args.min_dou_margin)
    ]
    repeated_host_counter = Counter(int(c["gong_component_id"]) for c in strong_small_bindable)

    mean_bindable_score = float(np.mean(bindable_scores)) if bindable_scores else 0.0
    max_bindable_score = float(np.max(bindable_scores)) if bindable_scores else 0.0
    num_host_gongs = len(host_counter)
    num_small_bindable = len(small_bindable)
    num_strong_small_bindable = len(strong_small_bindable)
    num_repeated_hosts = sum(1 for v in repeated_host_counter.values() if int(v) >= int(args.min_repeated_small_dou_per_host))
    max_repeated_host_count = max(repeated_host_counter.values()) if repeated_host_counter else 0
    dual_host_pair_candidates = [
        c for c in bindable_candidates
        if float(c["size_ratio"]) <= float(args.dual_host_pair_max_size_ratio)
    ]
    large_fragment_candidates = [
        c
        for c in bindable_candidates
        if float(args.large_fragment_min_size_ratio) <= float(c["size_ratio"]) <= float(args.large_fragment_max_size_ratio)
        and float(c["dou_margin"]) >= float(args.large_fragment_min_margin)
        and float(c["score"]) >= float(args.large_fragment_min_score)
        and float(c["xy_overlap"]) <= float(args.large_fragment_max_xy_overlap)
    ]

    overseg_score = (
        0.55 * min(num_strong_small_bindable / max(float(args.min_strong_small_dou), 1.0), 1.0)
        + 0.30 * min(max_repeated_host_count / max(float(args.min_repeated_small_dou_per_host), 1.0), 1.0)
        + 0.15 * min(mean_bindable_score / max(args.bind_score_threshold, 1e-8), 1.0)
    )

    multi_host_pattern = bool(
        num_repeated_hosts >= 1
        and num_strong_small_bindable >= int(args.min_strong_small_dou)
    )
    single_host_cluster_pattern = bool(
        num_host_gongs == 1
        and max_repeated_host_count >= int(args.min_single_host_cluster_dou)
        and num_strong_small_bindable >= int(args.min_single_host_cluster_dou)
    )
    high_confidence_sparse_pattern = bool(
        num_host_gongs >= 2
        and num_strong_small_bindable >= int(args.min_sparse_host_dou)
        and mean_bindable_score >= float(args.min_sparse_host_mean_score)
    )
    dual_host_pair_pattern = bool(
        bindable_count == 2
        and num_host_gongs == 2
        and len(dual_host_pair_candidates) == 2
        and max_bindable_score >= float(args.dual_host_pair_min_max_score)
    )
    single_host_large_fragment_pattern = bool(
        len(gong_ids) == 1
        and len(dou_ids) >= int(args.large_fragment_min_dou_components)
        and len(large_fragment_candidates) >= 1
    )
    has_overseg = bool(
        multi_host_pattern
        or single_host_cluster_pattern
        or high_confidence_sparse_pattern
        or dual_host_pair_pattern
        or single_host_large_fragment_pattern
        or overseg_score >= args.model_overseg_threshold
    )

    diagnosis = {
        "uid": str(uid),
        "has_overseg": has_overseg,
        "route_name": FULL_ROUTE_NAME if has_overseg else CONSERVATIVE_ROUTE_NAME,
        "num_components_diag": len(comp_points),
        "num_gong_components": len(gong_ids),
        "num_dou_components": len(dou_ids),
        "num_bindable_dou": int(bindable_count),
        "num_host_gongs_with_bindable_dou": int(num_host_gongs),
        "num_small_bindable_dou": int(num_small_bindable),
        "num_strong_small_bindable_dou": int(num_strong_small_bindable),
        "num_repeated_small_dou_hosts": int(num_repeated_hosts),
        "max_repeated_small_dou_per_host": int(max_repeated_host_count),
        "mean_bindable_dou_score": mean_bindable_score,
        "max_bindable_dou_score": max_bindable_score,
        "overseg_score": float(overseg_score),
        "pattern_flags": {
            "multi_host_pattern": bool(multi_host_pattern),
            "single_host_cluster_pattern": bool(single_host_cluster_pattern),
            "high_confidence_sparse_pattern": bool(high_confidence_sparse_pattern),
            "dual_host_pair_pattern": bool(dual_host_pair_pattern),
            "single_host_large_fragment_pattern": bool(single_host_large_fragment_pattern),
        },
        "thresholds": {
            "bind_score_threshold": float(args.bind_score_threshold),
            "min_bindable_dou": int(args.min_bindable_dou),
            "model_overseg_threshold": float(args.model_overseg_threshold),
            "small_dou_size_ratio": float(args.small_dou_size_ratio),
            "min_dou_margin": float(args.min_dou_margin),
            "min_strong_small_dou": int(args.min_strong_small_dou),
            "min_repeated_small_dou_per_host": int(args.min_repeated_small_dou_per_host),
            "min_single_host_cluster_dou": int(args.min_single_host_cluster_dou),
            "min_sparse_host_dou": int(args.min_sparse_host_dou),
            "min_sparse_host_mean_score": float(args.min_sparse_host_mean_score),
            "dual_host_pair_max_size_ratio": float(args.dual_host_pair_max_size_ratio),
            "dual_host_pair_min_max_score": float(args.dual_host_pair_min_max_score),
            "large_fragment_min_dou_components": int(args.large_fragment_min_dou_components),
            "large_fragment_min_size_ratio": float(args.large_fragment_min_size_ratio),
            "large_fragment_max_size_ratio": float(args.large_fragment_max_size_ratio),
            "large_fragment_min_margin": float(args.large_fragment_min_margin),
            "large_fragment_min_score": float(args.large_fragment_min_score),
            "large_fragment_max_xy_overlap": float(args.large_fragment_max_xy_overlap),
        },
        "dou_candidates": dou_candidates,
        "component_semantics": {str(cid): str(comp_sem[cid]) for cid in sorted(comp_sem.keys())},
    }
    return case_row, diagnosis


def apply_stage2_refinement_variant(
    comp_map: dict,
    seg_points: dict,
    score_map: dict,
    semantic_model: dict,
    stage2_model: dict,
    variant: dict,
) -> dict:
    comp_map = stage2_utils.relabel_component_map(comp_map)
    split_model = stage2_model.get("split_classifier", {})
    merge_model = stage2_model.get("merge_classifier", {})
    split_threshold = float(stage2_model.get("split_threshold", 1.0))
    merge_threshold = float(stage2_model.get("merge_threshold", 1.5))
    next_cid = max(comp_map.values()) + 1 if comp_map else 0

    if bool(variant.get("enable_split_loop", True)):
        changed = True
        while changed:
            changed = False
            members = stage2_utils.collect_component_members(comp_map)
            best = None
            for cid, segs in members.items():
                segs = sorted(segs)
                if len(segs) < 2 or len(segs) > 6:
                    continue
                for subset_size in (1, 2):
                    if subset_size >= len(segs):
                        continue
                    for subset in stage2_utils.itertools.combinations(segs, subset_size):
                        rest = [sid for sid in segs if sid not in subset]
                        feat = stage2_utils.subset_feature(list(subset), rest, seg_points, score_map, semantic_model)[None, :]
                        logit = float(stage2_utils.predict_logit(feat, split_model)[0])
                        if best is None or logit > best[0]:
                            best = (logit, int(cid), [int(x) for x in subset])
            if best and best[0] > split_threshold:
                _, source_cid, subset_ids = best
                for seg_id in subset_ids:
                    if comp_map.get(seg_id) == source_cid:
                        comp_map[seg_id] = next_cid
                next_cid += 1
                comp_map = stage2_utils.relabel_component_map(comp_map)
                changed = True

    if bool(variant.get("enable_merge_loop", True)):
        changed = True
        while changed:
            changed = False
            members = stage2_utils.collect_component_members(comp_map)
            best = None
            cids = sorted(members.keys())
            for i, cid_a in enumerate(cids):
                group_a = sorted(members[cid_a])
                for cid_b in cids[i + 1:]:
                    group_b = sorted(members[cid_b])
                    feat = stage2_utils.merge_feature(group_a, group_b, seg_points, semantic_model)[None, :]
                    logit = float(stage2_utils.predict_logit(feat, merge_model)[0])
                    if best is None or logit > best[0]:
                        best = (logit, int(cid_a), int(cid_b))
            if best and best[0] > merge_threshold:
                _, cid_a, cid_b = best
                for seg_id, cid in list(comp_map.items()):
                    if cid == cid_b:
                        comp_map[seg_id] = cid_a
                comp_map = stage2_utils.relabel_component_map(comp_map)
                changed = True

    if bool(variant.get("enable_bodyfirst_host_recovery", True)):
        comp_map = stage2_utils.reassign_alien_segments_from_vertical_hosts(comp_map, seg_points, score_map)
        comp_map = stage2_utils.attach_vertical_body_upper_caps(comp_map, seg_points, score_map)
        comp_map = stage2_utils.split_out_strong_sloped_gong_segments(comp_map, seg_points, score_map, semantic_model)
        comp_map = stage2_utils.attach_upper_dou_segments_to_sloped_hosts(comp_map, seg_points, score_map, semantic_model)

    if bool(variant.get("enable_semantic_structural_rollback", True)):
        comp_map = stage2_utils.split_large_uncertain_components(comp_map, seg_points, score_map, semantic_model)

    if bool(variant.get("enable_conservative_protection", True)):
        comp_map = stage2_utils.maybe_restore_identity_for_clean_tiny_case(comp_map, seg_points, score_map)

    return stage2_utils.relabel_component_map(comp_map)


def refine_case_routed(
    uid: str,
    args: argparse.Namespace,
    stage2_model: Dict,
    merge_semantic_model: Dict,
) -> Tuple[dict, dict, dict]:
    diag_case_row, diagnosis = diagnose_model_overseg(uid, args, merge_semantic_model)
    if diagnosis["has_overseg"]:
        case_row, refined_map = fullsys.refine_case(uid, args, stage2_model, merge_semantic_model)
        diagnosis["route_name"] = FULL_ROUTE_NAME
        diagnosis["route_description"] = "Use the original full body-first merge-heavy route."
    else:
        case_row = stage2_utils.build_stage1_case_data(
            uid=uid,
            fragment_dir=args.fragment_dir,
            model_dir=args.model_dir,
            merge_semantic_model_dir=args.merge_semantic_model_dir,
            gong_prior_model_json=args.gong_prior_model_json,
            manual_edge_calibrator_json=args.manual_edge_calibrator_json,
            max_points=args.max_points,
            neighbor_ratio=args.neighbor_ratio,
            contact_eps=args.contact_eps,
            enable_stage1_bodyfirst=bool(CONSERVATIVE_VARIANT["enable_stage1_bodyfirst"]),
            enable_stage1_semantic_guidance=bool(CONSERVATIVE_VARIANT["enable_stage1_semantic_guidance"]),
            enable_stage1_learned_priors=bool(CONSERVATIVE_VARIANT["enable_stage1_learned_priors"]),
            enable_stage1_manual_edge_calibrator=bool(CONSERVATIVE_VARIANT["enable_stage1_manual_edge_calibrator"]),
            enable_stage1_learned_edge_scoring=bool(CONSERVATIVE_VARIANT["enable_stage1_learned_edge_scoring"]),
            enable_stage1_augmented_edges=bool(CONSERVATIVE_VARIANT["enable_stage1_augmented_edges"]),
            enable_stage1_bottom_dou_detach=bool(CONSERVATIVE_VARIANT["enable_stage1_bottom_dou_detach"]),
        )
        refined_map = apply_stage2_refinement_variant(
            comp_map=case_row["comp_map"],
            seg_points=case_row["seg_points"],
            score_map=case_row["score_map"],
            semantic_model=merge_semantic_model,
            stage2_model=stage2_model,
            variant=CONSERVATIVE_VARIANT,
        )
        diagnosis["route_name"] = CONSERVATIVE_ROUTE_NAME
        diagnosis["route_description"] = "Use a conservative route: no merge loop, no body-first host recovery, keep rollback and conservative protection."
    return case_row, refined_map, diagnosis


def refine_one(args: argparse.Namespace) -> None:
    np.random.seed(int(args.seed))
    stage2_model, merge_semantic_model, label_semantic_model = fullsys.load_runtime_models(args)
    case_row, refined_map, diagnosis = refine_case_routed(args.uid, args, stage2_model, merge_semantic_model)
    os.makedirs(args.out_dir, exist_ok=True)
    fullsys.save_refined_outputs(
        uid=args.uid,
        case_row=case_row,
        comp_map=refined_map,
        semantic_model=label_semantic_model,
        out_dir=args.out_dir,
    )
    with open(os.path.join(args.out_dir, f"{args.uid}_route_diagnosis.json"), "w", encoding="utf-8") as f:
        json.dump(diagnosis, f, ensure_ascii=False, indent=2)
    print(
        f"refined {args.uid}: route={diagnosis['route_name']}, "
        f"has_overseg={diagnosis['has_overseg']}, bindable_dou={diagnosis['num_bindable_dou']}"
    )


def evaluate_all(args: argparse.Namespace) -> None:
    np.random.seed(int(args.seed))
    stage2_model, merge_semantic_model, label_semantic_model = fullsys.load_runtime_models(args)
    ids = base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    os.makedirs(args.out_dir, exist_ok=True)
    results = []
    route_rows = []
    route_counts = Counter()
    for uid in ids:
        case_row, refined_map, diagnosis = refine_case_routed(uid, args, stage2_model, merge_semantic_model)
        route_rows.append(diagnosis)
        route_counts[str(diagnosis["route_name"])] += 1
        fullsys.save_refined_outputs(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=label_semantic_model,
            out_dir=args.out_dir,
        )
        with open(os.path.join(args.out_dir, f"{uid}_route_diagnosis.json"), "w", encoding="utf-8") as f:
            json.dump(diagnosis, f, ensure_ascii=False, indent=2)
        row = fullsys.evaluate_case(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=label_semantic_model,
            gt_dir=args.gt_dir,
            gt_samples=args.gt_samples,
        )
        if row is not None:
            row["route_name"] = diagnosis["route_name"]
            row["has_overseg"] = bool(diagnosis["has_overseg"])
            results.append(row)
            print(
                f"evaluated {uid}: route={diagnosis['route_name']}, "
                f"components={row['num_components']}, cluster_f1={row['segment_partition_f1']:.4f}"
            )

    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.out_dir, "route_diagnosis_rows.json"), "w", encoding="utf-8") as f:
        json.dump(route_rows, f, ensure_ascii=False, indent=2)

    summary = {
        "num_models": len(results),
        "route_counts": dict(route_counts),
        "mean_num_components": float(np.mean([r["num_components"] for r in results])) if results else 0.0,
        "mean_segment_partition_f1": float(np.mean([r["segment_partition_f1"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_f1": float(np.mean([r["gt_bcubed_f1"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_f1": float(np.mean([r["gt_pairwise_f1"] for r in results])) if results else 0.0,
        "mean_segment_semantic_acc": float(np.mean([r["segment_semantic_acc"] for r in results])) if results else 0.0,
    }
    summary.update(task_eval.summarize_task_aware_rows(results))
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Route models by gong-dou over-segmentation before refinement.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_ref = sub.add_parser("refine")
    p_ref.add_argument("--uid", required=True)
    p_ref.add_argument("--fragment_dir", default=DEFAULT_FRAGMENT_DIR)
    p_ref.add_argument("--model_dir", default=DEFAULT_MODEL_DIR)
    p_ref.add_argument("--merge_semantic_model_dir", default=DEFAULT_MODEL_DIR)
    p_ref.add_argument("--semantic_label_model_dir", default=DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    p_ref.add_argument("--gong_prior_model_json", default=DEFAULT_GONG_PRIOR_JSON)
    p_ref.add_argument("--manual_edge_calibrator_json", default=DEFAULT_MANUAL_EDGE_CALIBRATOR_JSON)
    p_ref.add_argument("--stage2_model_json", default=DEFAULT_STAGE2_MODEL_JSON)
    p_ref.add_argument("--out_dir", default=DEFAULT_OUTPUT_DIR)
    p_ref.add_argument("--max_points", type=int, default=512)
    p_ref.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_ref.add_argument("--contact_eps", type=float, default=0.01)
    p_ref.add_argument("--seed", type=int, default=0)
    p_ref.add_argument("--bind_score_threshold", type=float, default=2.2)
    p_ref.add_argument("--min_bindable_dou", type=int, default=2)
    p_ref.add_argument("--model_overseg_threshold", type=float, default=0.95)
    p_ref.add_argument("--small_dou_size_ratio", type=float, default=0.45)
    p_ref.add_argument("--min_dou_margin", type=float, default=1.2)
    p_ref.add_argument("--min_strong_small_dou", type=int, default=3)
    p_ref.add_argument("--min_repeated_small_dou_per_host", type=int, default=3)
    p_ref.add_argument("--min_single_host_cluster_dou", type=int, default=3)
    p_ref.add_argument("--min_sparse_host_dou", type=int, default=3)
    p_ref.add_argument("--min_sparse_host_mean_score", type=float, default=4.8)
    p_ref.add_argument("--dual_host_pair_max_size_ratio", type=float, default=0.46)
    p_ref.add_argument("--dual_host_pair_min_max_score", type=float, default=5.2)
    p_ref.add_argument("--large_fragment_min_dou_components", type=int, default=4)
    p_ref.add_argument("--large_fragment_min_size_ratio", type=float, default=0.60)
    p_ref.add_argument("--large_fragment_max_size_ratio", type=float, default=0.80)
    p_ref.add_argument("--large_fragment_min_margin", type=float, default=4.0)
    p_ref.add_argument("--large_fragment_min_score", type=float, default=3.4)
    p_ref.add_argument("--large_fragment_max_xy_overlap", type=float, default=0.12)

    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("--fragment_dir", default=DEFAULT_FRAGMENT_DIR)
    p_eval.add_argument("--gt_dir", default=DEFAULT_GT_DIR)
    p_eval.add_argument("--model_dir", default=DEFAULT_MODEL_DIR)
    p_eval.add_argument("--merge_semantic_model_dir", default=DEFAULT_MODEL_DIR)
    p_eval.add_argument("--semantic_label_model_dir", default=DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    p_eval.add_argument("--gong_prior_model_json", default=DEFAULT_GONG_PRIOR_JSON)
    p_eval.add_argument("--manual_edge_calibrator_json", default=DEFAULT_MANUAL_EDGE_CALIBRATOR_JSON)
    p_eval.add_argument("--stage2_model_json", default=DEFAULT_STAGE2_MODEL_JSON)
    p_eval.add_argument("--out_dir", default=DEFAULT_OUTPUT_DIR)
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_eval.add_argument("--contact_eps", type=float, default=0.01)
    p_eval.add_argument("--seed", type=int, default=0)
    p_eval.add_argument("--bind_score_threshold", type=float, default=2.2)
    p_eval.add_argument("--min_bindable_dou", type=int, default=2)
    p_eval.add_argument("--model_overseg_threshold", type=float, default=0.95)
    p_eval.add_argument("--small_dou_size_ratio", type=float, default=0.45)
    p_eval.add_argument("--min_dou_margin", type=float, default=1.2)
    p_eval.add_argument("--min_strong_small_dou", type=int, default=3)
    p_eval.add_argument("--min_repeated_small_dou_per_host", type=int, default=3)
    p_eval.add_argument("--min_single_host_cluster_dou", type=int, default=3)
    p_eval.add_argument("--min_sparse_host_dou", type=int, default=3)
    p_eval.add_argument("--min_sparse_host_mean_score", type=float, default=4.8)
    p_eval.add_argument("--dual_host_pair_max_size_ratio", type=float, default=0.46)
    p_eval.add_argument("--dual_host_pair_min_max_score", type=float, default=5.2)
    p_eval.add_argument("--large_fragment_min_dou_components", type=int, default=4)
    p_eval.add_argument("--large_fragment_min_size_ratio", type=float, default=0.60)
    p_eval.add_argument("--large_fragment_max_size_ratio", type=float, default=0.80)
    p_eval.add_argument("--large_fragment_min_margin", type=float, default=4.0)
    p_eval.add_argument("--large_fragment_min_score", type=float, default=3.4)
    p_eval.add_argument("--large_fragment_max_xy_overlap", type=float, default=0.12)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.cmd == "refine":
        refine_one(args)
    elif args.cmd == "evaluate":
        evaluate_all(args)


if __name__ == "__main__":
    main()
