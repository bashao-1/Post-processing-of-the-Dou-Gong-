import argparse
import json
import os
import re
from colorsys import hsv_to_rgb
from typing import Dict, List, Tuple

import numpy as np
import trimesh


THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)


def simplify_part_name(name: str) -> str:
    name = str(name)
    if "part_" in name:
        return "part_" + name.rsplit("part_", 1)[-1]
    return name


def infer_seg_id_from_name(name: str, fallback: int) -> int:
    text = str(name)
    m = re.search(r"part_(\d+)$", text)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)$", text)
    if m:
        return int(m.group(1))
    return int(fallback)


def make_palette(n: int, alpha: int = 255) -> np.ndarray:
    if n <= 0:
        return np.zeros((0, 4), dtype=np.uint8)
    colors = []
    for i in range(n):
        h = (i * 0.61803398875) % 1.0
        r, g, b = hsv_to_rgb(h, 0.75, 0.95)
        colors.append([int(r * 255), int(g * 255), int(b * 255), alpha])
    return np.array(colors, dtype=np.uint8)


def color_mesh(mesh: trimesh.Trimesh, color: np.ndarray) -> trimesh.Trimesh:
    out = mesh.copy()
    color = np.asarray(color, dtype=np.uint8)
    # Use vertex colors directly to avoid scipy requirement inside face->vertex conversion.
    out.visual.vertex_colors = np.tile(color, (len(out.vertices), 1))
    return out


def load_scene_parts(scene_path: str) -> List[Tuple[str, trimesh.Trimesh]]:
    obj = trimesh.load(scene_path, force=None)
    if isinstance(obj, trimesh.Trimesh):
        return [("mesh", obj)]
    if not isinstance(obj, trimesh.Scene):
        raise ValueError(f"Unsupported scene type: {type(obj)}")

    parts: List[Tuple[str, trimesh.Trimesh]] = []
    for node_name in obj.graph.nodes:
        data = obj.graph[node_name]
        try:
            transform, geom_name = data
        except Exception:
            continue
        if geom_name is None:
            continue
        mesh = obj.geometry[geom_name].copy()
        try:
            mesh.apply_transform(transform)
        except Exception:
            pass
        parts.append((str(node_name), mesh))
    return parts


def build_colored_scene(parts: List[Tuple[str, trimesh.Trimesh]], labels: List[int], scene_name: str) -> trimesh.Scene:
    unique = sorted(set(labels))
    palette = make_palette(len(unique))
    label_to_idx = {v: i for i, v in enumerate(unique)}

    scene = trimesh.Scene()
    for i, ((name, mesh), label) in enumerate(zip(parts, labels)):
        c = palette[label_to_idx[int(label)]]
        cm = color_mesh(mesh, c)
        simple_name = simplify_part_name(name)
        scene.add_geometry(cm, node_name=simple_name)
    return scene


def build_merged_scene(parts: List[Tuple[str, trimesh.Trimesh]], labels: List[int], scene_name: str) -> Tuple[trimesh.Scene, List[Tuple[int, trimesh.Trimesh]]]:
    groups: Dict[int, List[trimesh.Trimesh]] = {}
    for (_, mesh), label in zip(parts, labels):
        groups.setdefault(int(label), []).append(mesh.copy())

    group_ids = sorted(groups.keys())
    palette = make_palette(len(group_ids))
    id_to_color = {gid: palette[i] for i, gid in enumerate(group_ids)}

    scene = trimesh.Scene()
    merged_list: List[Tuple[int, trimesh.Trimesh]] = []
    for gid in group_ids:
        meshes = groups[gid]
        if len(meshes) == 1:
            merged = meshes[0]
        else:
            merged = trimesh.util.concatenate(meshes)
        merged = color_mesh(merged, id_to_color[gid])
        merged_list.append((gid, merged.copy()))
        scene.add_geometry(merged, node_name=f"{scene_name}_component_{gid}")
    return scene, merged_list


def scene_bounds_diag(parts: List[Tuple[str, trimesh.Trimesh]]) -> float:
    if not parts:
        return 1.0
    mins = []
    maxs = []
    for _, m in parts:
        mins.append(m.bounds[0])
        maxs.append(m.bounds[1])
    bmin = np.min(np.vstack(mins), axis=0)
    bmax = np.max(np.vstack(maxs), axis=0)
    return float(np.linalg.norm(bmax - bmin))


def export_scene(scene: trimesh.Scene, out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    blob = scene.export(file_type="glb")
    with open(out_path, "wb") as f:
        f.write(blob)


def main():
    parser = argparse.ArgumentParser(description="Mesh-level visualization for fragment/refined/gt.")
    parser.add_argument("--uid", default="")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    parser.add_argument("--gt_dir", default=r"data")
    parser.add_argument("--refined_npz", default="")
    parser.add_argument("--refined_dir", default=os.path.join(ROOT_DIR, "03_outputs", "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0"))
    parser.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "04_visualizations", "visualizations_mesh_bodyfirst_semanticopt_final_full_eval_20260502_seed0"))
    parser.add_argument("--spacing", type=float, default=1.8, help="Multiplier over global diag")
    args = parser.parse_args()

    def run_one(uid: str) -> None:
        fragment_glb = os.path.join(args.fragment_dir, f"{uid}.glb")
        gt_glb = os.path.join(args.gt_dir, f"{uid}.glb")
        refined_npz = args.refined_npz or os.path.join(args.refined_dir, f"{uid}_refined.npz")

        if not os.path.exists(fragment_glb):
            raise FileNotFoundError(f"fragment glb missing: {fragment_glb}")
        if not os.path.exists(gt_glb):
            raise FileNotFoundError(f"gt glb missing: {gt_glb}")
        if not os.path.exists(refined_npz):
            raise FileNotFoundError(f"refined npz missing: {refined_npz}")

        data = np.load(refined_npz, allow_pickle=True)
        if "segment_names" not in data.files:
            raise RuntimeError("refined npz has no segment_names. Please rerun refine with updated dougong_refine.py.")
        segment_names = [str(x) for x in data["segment_names"].tolist()]
        fragment_labels = data["fragment_labels"].astype(np.int32)
        comp_labels = data["comp_labels"].astype(np.int32)

        # segment -> component mapping from point labels
        seg_to_comp: Dict[int, int] = {}
        for seg_id in np.unique(fragment_labels):
            mask = fragment_labels == seg_id
            vals, cnts = np.unique(comp_labels[mask], return_counts=True)
            seg_to_comp[int(seg_id)] = int(vals[np.argmax(cnts)])

        fragment_parts = load_scene_parts(fragment_glb)
        gt_parts = load_scene_parts(gt_glb)
        fragment_map = {name: mesh for name, mesh in fragment_parts}

        ordered_fragment: List[Tuple[str, trimesh.Trimesh]] = []
        ordered_seg_ids: List[int] = []
        missing = []
        for idx, name in enumerate(segment_names):
            seg_id = infer_seg_id_from_name(name, idx)
            if name not in fragment_map:
                missing.append(name)
                continue
            ordered_fragment.append((name, fragment_map[name]))
            ordered_seg_ids.append(seg_id)
        if not ordered_fragment:
            raise RuntimeError("No fragment meshes matched segment_names from refined npz.")

        fragment_scene = build_colored_scene(ordered_fragment, ordered_seg_ids, "fragment")
        refined_labels = [seg_to_comp[sid] for sid in ordered_seg_ids]
        refined_scene, refined_merged = build_merged_scene(ordered_fragment, refined_labels, "refined")
        gt_scene = build_colored_scene(gt_parts, list(range(len(gt_parts))), "gt")

        diag = max(scene_bounds_diag(ordered_fragment), scene_bounds_diag(gt_parts))
        shift = args.spacing * max(diag, 1e-6)

        # Combined comparison scene: left fragment, middle refined, right gt
        triplet = trimesh.Scene()
        for i, (name, mesh) in enumerate(ordered_fragment):
            cmesh = color_mesh(mesh, make_palette(len(ordered_seg_ids))[i])
            cmesh.apply_translation([-shift, 0.0, 0.0])
            triplet.add_geometry(cmesh, node_name=simplify_part_name(name))
        for gid, mesh in refined_merged:
            cmesh = mesh.copy()
            triplet.add_geometry(cmesh, node_name=f"refined_component_{gid}")
        gt_palette = make_palette(len(gt_parts))
        for i, (name, mesh) in enumerate(gt_parts):
            cmesh = color_mesh(mesh, gt_palette[i])
            cmesh.apply_translation([shift, 0.0, 0.0])
            triplet.add_geometry(cmesh, node_name=f"gt_{simplify_part_name(name)}")

        out_uid_dir = os.path.join(args.out_dir, uid)
        os.makedirs(out_uid_dir, exist_ok=True)

        fragment_out = os.path.join(out_uid_dir, f"{uid}_fragment_mesh.glb")
        refined_out = os.path.join(out_uid_dir, f"{uid}_refined_mesh.glb")
        gt_out = os.path.join(out_uid_dir, f"{uid}_gt_mesh.glb")
        triplet_out = os.path.join(out_uid_dir, f"{uid}_triplet_mesh.glb")
        export_scene(fragment_scene, fragment_out)
        export_scene(refined_scene, refined_out)
        export_scene(gt_scene, gt_out)
        export_scene(triplet, triplet_out)

        summary = {
            "uid": uid,
            "fragment_parts": len(ordered_fragment),
            "refined_parts": len(set(refined_labels)),
            "gt_parts": len(gt_parts),
            "missing_segment_names": missing,
            "files": {
                "fragment_mesh": fragment_out,
                "refined_mesh": refined_out,
                "gt_mesh": gt_out,
                "triplet_mesh": triplet_out,
            },
            "layout": {
                "left": "fragment",
                "middle": "refined",
                "right": "gt",
                "shift": shift,
            },
        }
        summary_out = os.path.join(out_uid_dir, f"{uid}_mesh_vis_summary.json")
        with open(summary_out, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)

        print(f"[OK] {uid} -> {out_uid_dir}")

    if args.all:
        uids = sorted(os.path.splitext(f)[0] for f in os.listdir(args.fragment_dir) if f.lower().endswith(".glb"))
        ok = 0
        fail = 0
        for uid in uids:
            try:
                run_one(uid)
                ok += 1
            except Exception as e:
                fail += 1
                print(f"[FAIL] {uid}: {e}")
        print(f"done. success={ok}, failed={fail}")
    else:
        if not args.uid:
            raise ValueError("Please provide --uid or use --all.")
        run_one(args.uid)


if __name__ == "__main__":
    main()
