from __future__ import annotations

import csv
import json
from pathlib import Path


PKG = Path(__file__).resolve().parents[1]
REPORT = PKG / "05_reports"
SEM = REPORT / "semantic"
METHODS = ["raw_partgen_1_5", "agglomerative_graph_baseline", "generic_graph_baseline", "final_system"]
DISPLAY = {
    "raw_partgen_1_5": "Raw PartGen 1.5",
    "agglomerative_graph_baseline": "Average-link agglomerative graph baseline",
    "generic_graph_baseline": "Generic graph baseline",
    "final_system": "Final system",
}


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def main() -> None:
    pure = json.loads((REPORT / "unified_main_metrics" / "pure_eval_summary.json").read_text(encoding="utf-8"))
    table_rows = []
    class_rows = []
    case_rows = []
    semantic_payload = {}
    for method in METHODS:
        semantic_dir = "final_system_exact" if method == "final_system" else method
        sem = json.loads((SEM / semantic_dir / "semantic_evaluation.json").read_text(encoding="utf-8"))
        semantic_payload[method] = sem
        m = pure["comparison"][method]
        table_rows.append({
            "method": method,
            "method_name": DISPLAY[method],
            "partition_f1": m["component_partition_f1"],
            "count_deviation": m["component_count_deviation"],
            "bcubed_f1": m["bcubed_f1"],
            "pairwise_f1": m["pairwise_f1"],
            "semantic_mass_accuracy": sem["dataset_semantic_accuracy_mass"],
            "semantic_macro_f1": sem["dataset_semantic_macro_f1"],
            "semantic_weighted_f1": sem["dataset_semantic_weighted_f1"],
            "distribution_consistency": sem["mean_semantic_distribution_consistency"],
            "component_purity": sem["mean_semantic_component_purity"],
            "structure_violation_rate": m.get("structure_violation_rate"),
        })
        for cls, vals in sem["dataset_per_class"].items():
            class_rows.append({"method": method, "method_name": DISPLAY[method], "class": cls, **vals})
        for row in sem["casewise"]:
            case_rows.append({"method": method, "method_name": DISPLAY[method], **row})

    out = REPORT / "unified_final"
    out.mkdir(parents=True, exist_ok=True)
    fields = list(table_rows[0])
    with (out / "table4_unified_main.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(table_rows)
    fields = list(class_rows[0])
    with (out / "semantic_classwise_all_methods.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(class_rows)
    fields = list(case_rows[0])
    with (out / "semantic_casewise_all_methods.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(case_rows)
    (out / "unified_final_report.json").write_text(json.dumps({
        "protocol": {
            "cases": 26,
            "dataset_version": "26case_replaced5_20260603",
            "geometry_source": "unified_main_metrics/pure_eval_summary.json",
            "semantic_source": "semantic/<method>/semantic_evaluation.json",
            "semantic_model": "final_nested_loco_semantic_predictor_fixed_config",
            "gt_source": "meshes/<uid>.glb with part_info.json",
            "samples": 512,
            "merge_frozen": True,
            "all_metrics_recomputed_in_new_package": True,
        },
        "table4": table_rows,
        "semantic_classwise": class_rows,
        "semantic_casewise": case_rows,
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"methods": METHODS, "table4": str(out / "table4_unified_main.csv"), "cases": len(case_rows)}))


if __name__ == "__main__":
    main()
