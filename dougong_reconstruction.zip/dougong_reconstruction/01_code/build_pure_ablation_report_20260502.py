import argparse
import csv
import json
from pathlib import Path
from statistics import median
from typing import Dict, Iterable, List


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ABLATION_ROOT = ROOT / "03_outputs" / "ablation_study_20260502_seed0"
DEFAULT_OUT_DIR = ROOT / "05_reports" / "ablation_20260502_seed0"
DEFAULT_VARIANTS = [
    ("full", "Full Model"),
    ("wo_bodyfirst_host_recovery", "w/o Body-First Host Recovery"),
    ("wo_conservative_protection", "w/o Conservative Protection"),
    ("wo_learned_boundary_optimization", "w/o Learned Boundary Optimization"),
    ("wo_semantic_structural_rollback", "w/o Semantic-Structural Rollback"),
]
DEFAULT_VARIANT_LABELS = {name: label for name, label in DEFAULT_VARIANTS}


def parse_variant_spec(text: str) -> tuple[str, str]:
    if "=" in text:
        name, label = text.split("=", 1)
        return name.strip(), label.strip()
    name = text.strip()
    return name, DEFAULT_VARIANT_LABELS.get(name, name)


def safe_mean(values: Iterable[float]) -> float:
    values = list(values)
    return float(sum(values) / len(values)) if values else 0.0


def safe_median(values: Iterable[float]) -> float:
    values = list(values)
    return float(median(values)) if values else 0.0


def load_metrics_rows(variant_dir: Path) -> List[Dict[str, object]]:
    path = variant_dir / "metrics.json"
    rows = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError(f"invalid metrics file: {path}")
    return rows


def summarize_distribution(values: List[float]) -> Dict[str, float]:
    return {
        "mean": safe_mean(values),
        "median": safe_median(values),
        "ge_0_50_rate": safe_mean(1.0 if v >= 0.50 else 0.0 for v in values),
        "ge_0_60_rate": safe_mean(1.0 if v >= 0.60 else 0.0 for v in values),
        "ge_0_70_rate": safe_mean(1.0 if v >= 0.70 else 0.0 for v in values),
        "ge_0_80_rate": safe_mean(1.0 if v >= 0.80 else 0.0 for v in values),
        "min": min(values) if values else 0.0,
        "max": max(values) if values else 0.0,
    }


def summarize_variant(variant_dir: Path) -> Dict[str, object]:
    summary_path = variant_dir / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    rows = load_metrics_rows(variant_dir)

    partition_values = [float(r.get("segment_partition_f1", r.get("mean_purity", 0.0))) for r in rows]
    semantic_values = [
        float(r.get("semantic_distribution_score", r.get("semantic_acc", 0.0)))
        for r in rows
    ]
    count_values = [float(r.get("component_count_diff", 0.0)) for r in rows]
    bcubed_values = [float(r.get("gt_bcubed_f1", 0.0)) for r in rows]
    pairwise_values = [float(r.get("gt_pairwise_f1", 0.0)) for r in rows]
    component_recovery_values = [float(r.get("component_recovery_score", 0.0)) for r in rows]
    instance_f1_50_values = [float(r.get("instance_f1_50", 0.0)) for r in rows]
    instance_f1_75_values = [float(r.get("instance_f1_75", 0.0)) for r in rows]
    semantic_distribution_values = [
        float(r.get("semantic_distribution_score", r.get("semantic_acc", 0.0)))
        for r in rows
    ]
    semantic_recovery_values = [float(r.get("semantic_recovery_score", 0.0)) for r in rows]
    semantic_instance_f1_50_values = [float(r.get("semantic_instance_f1_50", 0.0)) for r in rows]
    semantic_instance_f1_75_values = [float(r.get("semantic_instance_f1_75", 0.0)) for r in rows]
    support_edge_precision_values = [float(r.get("support_edge_precision", 0.0)) for r in rows]
    support_edge_recall_values = [float(r.get("support_edge_recall", 0.0)) for r in rows]
    support_edge_f1_values = [float(r.get("support_edge_f1", 0.0)) for r in rows]
    support_edge_f1_50_values = [float(r.get("support_edge_f1_50", 0.0)) for r in rows]
    support_edge_f1_75_values = [float(r.get("support_edge_f1_75", 0.0)) for r in rows]
    structure_values = [float(r.get("structure_plausibility", 0.0)) for r in rows]
    host_legality_values = [float(r.get("host_legality", 0.0)) for r in rows]
    gong_clean_values = [float(r.get("gong_clean_ratio", 0.0)) for r in rows]
    upper_dou_values = [float(r.get("upper_dou_support_ratio", 0.0)) for r in rows]
    violation_values = [float(r.get("structure_violation_rate", 0.0)) for r in rows]
    support_edge_values = [float(r.get("num_support_edges", 0.0)) for r in rows]

    return {
        "variant_name": summary["variant_name"],
        "variant_label": summary["variant_label"],
        "partition_quality_f1": float(summary["mean_segment_partition_f1"]),
        "count_deviation": float(summary["mean_component_count_diff"]),
        "semantic_accuracy": float(summary.get("mean_semantic_distribution_score", summary["mean_semantic_acc"])),
        "bcubed_f1": float(summary["mean_gt_bcubed_f1"]),
        "pairwise_f1": float(summary["mean_gt_pairwise_f1"]),
        "partition_quality_distribution": summarize_distribution(partition_values),
        "semantic_distribution": summarize_distribution(semantic_values),
        "count_distribution": summarize_distribution(count_values),
        "bcubed_distribution": summarize_distribution(bcubed_values),
        "pairwise_distribution": summarize_distribution(pairwise_values),
        "component_recovery_score": safe_mean(component_recovery_values),
        "instance_f1_50": safe_mean(instance_f1_50_values),
        "instance_f1_75": safe_mean(instance_f1_75_values),
        "semantic_distribution_score": safe_mean(semantic_distribution_values),
        "semantic_recovery_score": safe_mean(semantic_recovery_values),
        "semantic_instance_f1_50": safe_mean(semantic_instance_f1_50_values),
        "semantic_instance_f1_75": safe_mean(semantic_instance_f1_75_values),
        "support_edge_precision": safe_mean(support_edge_precision_values),
        "support_edge_recall": safe_mean(support_edge_recall_values),
        "support_edge_f1": safe_mean(support_edge_f1_values),
        "support_edge_f1_50": safe_mean(support_edge_f1_50_values),
        "support_edge_f1_75": safe_mean(support_edge_f1_75_values),
        "structure_plausibility": safe_mean(structure_values),
        "host_legality": safe_mean(host_legality_values),
        "gong_clean_ratio": safe_mean(gong_clean_values),
        "upper_dou_support_ratio": safe_mean(upper_dou_values),
        "structure_violation_rate": safe_mean(violation_values),
        "mean_num_support_edges": safe_mean(support_edge_values),
    }


def build_ablation_rows(summaries: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for item in summaries:
        rows.append(
            {
                "Variant": item["variant_label"],
                "Partition Quality (F1)": round(float(item["partition_quality_f1"]), 4),
                "Count Deviation": round(float(item["count_deviation"]), 4),
                "Semantic Accuracy": round(float(item["semantic_accuracy"]), 4),
                "B-Cubed F1": round(float(item["bcubed_f1"]), 4),
                "Pairwise F1": round(float(item["pairwise_f1"]), 4),
            }
        )
    return rows


def build_distribution_rows(summaries: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for item in summaries:
        dist = item["partition_quality_distribution"]
        rows.append(
            {
                "Variant": item["variant_label"],
                "Partition Mean": round(float(dist["mean"]), 4),
                "Partition Median": round(float(dist["median"]), 4),
                "Rate >= 0.50": round(float(dist["ge_0_50_rate"]), 4),
                "Rate >= 0.60": round(float(dist["ge_0_60_rate"]), 4),
                "Rate >= 0.70": round(float(dist["ge_0_70_rate"]), 4),
                "Rate >= 0.80": round(float(dist["ge_0_80_rate"]), 4),
                "Partition Min": round(float(dist["min"]), 4),
                "Partition Max": round(float(dist["max"]), 4),
            }
        )
    return rows


def build_taskaware_rows(summaries: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for item in summaries:
        rows.append(
            {
                "Variant": item["variant_label"],
                "Component Recovery Score": round(float(item["component_recovery_score"]), 4),
                "Instance F1@0.50": round(float(item["instance_f1_50"]), 4),
                "Instance F1@0.75": round(float(item["instance_f1_75"]), 4),
                "Semantic Distribution Score": round(float(item["semantic_distribution_score"]), 4),
                "Semantic Recovery Score": round(float(item["semantic_recovery_score"]), 4),
                "Semantic Instance F1@0.50": round(float(item["semantic_instance_f1_50"]), 4),
                "Semantic Instance F1@0.75": round(float(item["semantic_instance_f1_75"]), 4),
            }
        )
    return rows


def build_structure_rows(summaries: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for item in summaries:
        rows.append(
            {
                "Variant": item["variant_label"],
                "Structure Plausibility": round(float(item["structure_plausibility"]), 4),
                "Host Legality": round(float(item["host_legality"]), 4),
                "Gong Clean Ratio": round(float(item["gong_clean_ratio"]), 4),
                "Upper-Dou Support Ratio": round(float(item["upper_dou_support_ratio"]), 4),
                "Structure Violation Rate": round(float(item["structure_violation_rate"]), 4),
                "Mean Support Edges": round(float(item["mean_num_support_edges"]), 4),
            }
        )
    return rows


def build_relation_rows(summaries: List[Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for item in summaries:
        rows.append(
            {
                "Variant": item["variant_label"],
                "Support Edge Precision": round(float(item["support_edge_precision"]), 4),
                "Support Edge Recall": round(float(item["support_edge_recall"]), 4),
                "Support Edge F1": round(float(item["support_edge_f1"]), 4),
                "Support Edge F1@0.50": round(float(item["support_edge_f1_50"]), 4),
                "Support Edge F1@0.75": round(float(item["support_edge_f1_75"]), 4),
            }
        )
    return rows


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def fmt(v: float) -> str:
    return f"{float(v):.4f}"


def build_markdown(
    main_rows: List[Dict[str, object]],
    taskaware_rows: List[Dict[str, object]],
    relation_rows: List[Dict[str, object]],
    structure_rows: List[Dict[str, object]],
    distribution_rows: List[Dict[str, object]],
) -> str:
    main_map = {row["Variant"]: row for row in main_rows}
    dist_map = {row["Variant"]: row for row in distribution_rows}
    lines: List[str] = []
    lines.append("# Pure-Format Ablation Report")
    lines.append("")
    lines.append("## 1. Main Table")
    lines.append("")
    lines.append("| Variant | Partition Quality (F1) | Count Deviation | Semantic Accuracy | B-Cubed F1 | Pairwise F1 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
    for row in main_rows:
        lines.append(
            f"| {row['Variant']} | {fmt(row['Partition Quality (F1)'])} | {fmt(row['Count Deviation'])} | "
            f"{fmt(row['Semantic Accuracy'])} | {fmt(row['B-Cubed F1'])} | {fmt(row['Pairwise F1'])} |"
        )

    lines.append("")
    lines.append("## 2. Task-Aware Recovery Metrics")
    lines.append("")
    lines.append("| Variant | Component Recovery Score | Instance F1@0.50 | Instance F1@0.75 | Semantic Distribution Score | Semantic Recovery Score | Semantic Instance F1@0.50 | Semantic Instance F1@0.75 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
    for row in taskaware_rows:
        lines.append(
            f"| {row['Variant']} | {fmt(row['Component Recovery Score'])} | {fmt(row['Instance F1@0.50'])} | "
            f"{fmt(row['Instance F1@0.75'])} | {fmt(row['Semantic Distribution Score'])} | {fmt(row['Semantic Recovery Score'])} | "
            f"{fmt(row['Semantic Instance F1@0.50'])} | {fmt(row['Semantic Instance F1@0.75'])} |"
        )
    lines.append("")
    lines.append("## 3. Direct Relation Recovery Metrics")
    lines.append("")
    lines.append("| Variant | Support Edge Precision | Support Edge Recall | Support Edge F1 | Support Edge F1@0.50 | Support Edge F1@0.75 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
    for row in relation_rows:
        lines.append(
            f"| {row['Variant']} | {fmt(row['Support Edge Precision'])} | {fmt(row['Support Edge Recall'])} | "
            f"{fmt(row['Support Edge F1'])} | {fmt(row['Support Edge F1@0.50'])} | {fmt(row['Support Edge F1@0.75'])} |"
        )
    lines.append("")
    lines.append("## 4. Structure Plausibility Metrics")
    lines.append("")
    lines.append("| Variant | Structure Plausibility | Host Legality | Gong Clean Ratio | Upper-Dou Support Ratio | Structure Violation Rate | Mean Support Edges |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for row in structure_rows:
        lines.append(
            f"| {row['Variant']} | {fmt(row['Structure Plausibility'])} | {fmt(row['Host Legality'])} | "
            f"{fmt(row['Gong Clean Ratio'])} | {fmt(row['Upper-Dou Support Ratio'])} | "
            f"{fmt(row['Structure Violation Rate'])} | {fmt(row['Mean Support Edges'])} |"
        )
    lines.append("")
    lines.append("## 5. Partition Quality Distribution")
    lines.append("")
    lines.append("| Variant | Mean | Median | >=0.50 | >=0.60 | >=0.70 | >=0.80 | Min | Max |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
    for row in distribution_rows:
        lines.append(
            f"| {row['Variant']} | {fmt(row['Partition Mean'])} | {fmt(row['Partition Median'])} | "
            f"{fmt(row['Rate >= 0.50'])} | {fmt(row['Rate >= 0.60'])} | {fmt(row['Rate >= 0.70'])} | "
            f"{fmt(row['Rate >= 0.80'])} | {fmt(row['Partition Min'])} | {fmt(row['Partition Max'])} |"
        )

    lines.append("")
    lines.append("## 6. Interpretation")
    lines.append("")
    if "w/o Learned Boundary Optimization" in main_map:
        lines.append("- `w/o Learned Boundary Optimization` shows the clearest overall degradation. This remains the strongest evidence that learned local boundary refinement is a major performance source.")
    if "w/o Body-First Host Recovery" in main_map:
        lines.append("- `w/o Body-First Host Recovery` mainly hurts partition quality and pairwise consistency, which matches the intended role of host-centered repair on complex assemblies.")
    if "w/o Conservative Protection" in main_map and "w/o Semantic-Structural Rollback" in main_map:
        lines.append("- `w/o Conservative Protection` and `w/o Semantic-Structural Rollback` should be read as stability-control variants rather than pure score boosters. Their main purpose is to change the system's risk preference, not to maximize a single mean metric.")
    elif "w/o Conservative Protection" in main_map:
        lines.append("- `w/o Conservative Protection` should be interpreted as a stability-control variant. It tests whether a more aggressive policy changes average scores at the cost of robustness.")
    elif "w/o Semantic-Structural Rollback" in main_map:
        lines.append("- `w/o Semantic-Structural Rollback` should be interpreted as a stability-control variant. It tests whether removing rollback improves some averages by allowing more aggressive merges.")
    if "Full Model" in dist_map:
        full_dist = dist_map["Full Model"]
        lines.append(
            f"- The full model reaches a partition-quality mean of about `{fmt(full_dist['Partition Mean'])}` with a median near `{fmt(full_dist['Partition Median'])}`. "
            "The gap indicates that a small number of hard cases still dominate the tail."
        )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a pure-format ablation report from existing ablation outputs.")
    parser.add_argument("--ablation_root", default=str(DEFAULT_ABLATION_ROOT))
    parser.add_argument("--out_dir", default=str(DEFAULT_OUT_DIR))
    parser.add_argument("--variant", action="append", default=[], help="Variant spec in the form name or name=label. If omitted, built-in defaults are used.")
    args = parser.parse_args()

    ablation_root = Path(args.ablation_root)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    variant_specs = [parse_variant_spec(v) for v in args.variant] if args.variant else DEFAULT_VARIANTS
    summaries: List[Dict[str, object]] = []
    for variant_name, variant_label in variant_specs:
        item = summarize_variant(ablation_root / variant_name)
        item["variant_label"] = variant_label
        summaries.append(item)

    main_rows = build_ablation_rows(summaries)
    taskaware_rows = build_taskaware_rows(summaries)
    relation_rows = build_relation_rows(summaries)
    structure_rows = build_structure_rows(summaries)
    distribution_rows = build_distribution_rows(summaries)

    write_csv(
        out_dir / "pure_ablation_table_paper.csv",
        main_rows,
        ["Variant", "Partition Quality (F1)", "Count Deviation", "Semantic Accuracy", "B-Cubed F1", "Pairwise F1"],
    )
    write_csv(
        out_dir / "pure_ablation_distribution.csv",
        distribution_rows,
        ["Variant", "Partition Mean", "Partition Median", "Rate >= 0.50", "Rate >= 0.60", "Rate >= 0.70", "Rate >= 0.80", "Partition Min", "Partition Max"],
    )
    write_csv(
        out_dir / "pure_ablation_taskaware.csv",
        taskaware_rows,
        ["Variant", "Component Recovery Score", "Instance F1@0.50", "Instance F1@0.75", "Semantic Distribution Score", "Semantic Recovery Score", "Semantic Instance F1@0.50", "Semantic Instance F1@0.75"],
    )
    write_csv(
        out_dir / "pure_ablation_relation.csv",
        relation_rows,
        ["Variant", "Support Edge Precision", "Support Edge Recall", "Support Edge F1", "Support Edge F1@0.50", "Support Edge F1@0.75"],
    )
    write_csv(
        out_dir / "pure_ablation_structure.csv",
        structure_rows,
        ["Variant", "Structure Plausibility", "Host Legality", "Gong Clean Ratio", "Upper-Dou Support Ratio", "Structure Violation Rate", "Mean Support Edges"],
    )

    report = {
        "summaries": summaries,
    }
    (out_dir / "pure_ablation_summary.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (out_dir / "pure_ablation_report_zh.md").write_text(
        build_markdown(main_rows, taskaware_rows, relation_rows, structure_rows, distribution_rows),
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
