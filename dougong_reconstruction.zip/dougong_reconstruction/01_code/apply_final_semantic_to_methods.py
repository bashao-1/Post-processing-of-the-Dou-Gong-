"""Apply the frozen final semantic predictor to each method's own partition.

This script never changes an NPZ or merge map. It creates one semantic overlay
per method, using a fixed configuration selected by the final nested semantic
package and leave-one-case-out training across the 26 cases.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[1]
SEM_MODEL = PROJECT / "02_models" / "semantic_model"
sys.path.insert(0, str(SEM_MODEL))
import evaluate_frozen_semantics as ev  # type: ignore

CLASSES = ("gong", "dou", "fang", "chuan", "ang", "other")
WEIGHTS = (4.0, 1.0, 1.0)
K = 11
ALPHA = 0.25
TEMP = 0.6
FANG_BOOST = 1.5
GLOBAL_GATE = 0.05
FORBIDDEN = {("dou", "other"), ("dou", "gong"), ("ang", "gong")}


def grouped_distance(test: np.ndarray, train: np.ndarray) -> np.ndarray:
    return (
        WEIGHTS[0] * ((test[:, None, :6] - train[None, :, :6]) ** 2).mean(2)
        + WEIGHTS[1] * ((test[:, None, 6:39] - train[None, :, 6:39]) ** 2).mean(2)
        + WEIGHTS[2] * ((test[:, None, 39:53] - train[None, :, 39:53]) ** 2).mean(2)
    )


def predict(records: list[dict], held_out_uid: str) -> dict[int, str]:
    train = [r for r in records if r["uid"] != held_out_uid]
    test = [r for r in records if r["uid"] == held_out_uid]
    if not train or not test:
        return {}
    xtr = np.asarray([r["feature"] for r in train], dtype=float)
    xte = np.asarray([r["feature"] for r in test], dtype=float)
    mean = xtr.mean(0)
    std = np.maximum(xtr.std(0), 1e-5)
    ztr = np.clip((xtr - mean) / std, -6, 6)
    zte = np.clip((xte - mean) / std, -6, 6)
    d = grouped_distance(zte, ztr)
    order = np.argsort(d, axis=1)[:, :K]
    y = np.asarray([CLASSES.index(str(r["target"])) for r in train], dtype=int)
    purity = np.asarray([float(r.get("purity", 1.0)) for r in train], dtype=float)
    class_balance = np.maximum(np.bincount(y, minlength=6), 1.0) ** (-ALPHA)
    out: dict[int, str] = {}
    for j, record in enumerate(test):
        ix = order[j]
        dd = d[j, ix]
        weights = np.exp(-(dd - dd.min()) / TEMP) * purity[ix] * class_balance[y[ix]]
        q = np.zeros(6, dtype=float)
        for label, weight in zip(y[ix], weights):
            q[int(label)] += float(weight)
        q /= max(float(q.sum()), 1e-12)
        q[2] *= FANG_BOOST
        q /= max(float(q.sum()), 1e-12)
        candidate = int(np.argmax(q))
        old = CLASSES.index(str(record.get("original_semantic", "other")))
        label = CLASSES[candidate]
        if candidate != old and float(q[candidate] - q[old]) < GLOBAL_GATE:
            label = CLASSES[old]
        if (str(record.get("original_semantic", "other")), label) in FORBIDDEN:
            label = str(record.get("original_semantic", "other"))
        out[int(record["component_id"])] = label
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", type=Path, required=True)
    ap.add_argument("--output_dir", type=Path, required=True)
    ap.add_argument("--out_dir", type=Path, required=True)
    args = ap.parse_args()
    records_by_case = json.loads(args.records.read_text(encoding="utf-8"))
    records = [r for uid in sorted(records_by_case) for r in records_by_case[uid]]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    changed = 0
    for uid in sorted(records_by_case):
        labels = predict(records, uid)
        saved = ev.saved.load_saved_case(str(args.output_dir), uid)
        invariant = ev.frozen_invariants(saved)
        components = []
        for record in records_by_case[uid]:
            cid = int(record["component_id"])
            old = str(record.get("original_semantic", "other"))
            label = labels.get(cid, old)
            changed += int(label != old)
            components.append({
                "component_id": cid,
                "segment_ids": record["segment_ids"],
                "original_semantic": old,
                "optimized_semantic": label,
            })
        payload = {
            "uid": uid,
            "method": "final_nested_loco_semantic_predictor_fixed_config",
            "merge_frozen": True,
            "uid_specific_rules": False,
            "config": {"weights": WEIGHTS, "k": K, "alpha": ALPHA, "temperature": TEMP,
                       "fang_boost": FANG_BOOST, "global_gate": GLOBAL_GATE},
            "forbidden_transitions": [list(x) for x in sorted(FORBIDDEN)],
            "source_invariants": invariant,
            "components": components,
        }
        (args.out_dir / f"{uid}_semantic_overlay.json").write_text(
            json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    (args.out_dir / "manifest.json").write_text(json.dumps({
        "method": "final_nested_loco_semantic_predictor_fixed_config",
        "cases": len(records_by_case),
        "merge_frozen": True,
        "uid_specific_rules": False,
        "config": {"weights": WEIGHTS, "k": K, "alpha": ALPHA, "temperature": TEMP,
                   "fang_boost": FANG_BOOST, "global_gate": GLOBAL_GATE},
        "forbidden_transitions": [list(x) for x in sorted(FORBIDDEN)],
        "changed_labels": changed,
    }, indent=2), encoding="utf-8")
    print(json.dumps({"cases": len(records_by_case), "changed_labels": changed,
                      "out_dir": str(args.out_dir)}))


if __name__ == "__main__":
    main()
