import argparse
import csv
import json
from pathlib import Path
from statistics import mean, median
from typing import Dict, Iterable, List, Tuple


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT_DIR = ROOT / "05_reports" / "pure_eval_20260502_seed0"
DEFAULT_TARGETS = [
    ("raw_partgen_1_5", ROOT / "03_outputs" / "outputs_raw_partgen_1_5_eval_20260502_seed0"),
    ("generic_graph_baseline", ROOT / "03_outputs" / "outputs_generic_graph_baseline_eval_20260502_seed0"),
    ("final_system", ROOT / "03_outputs" / "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0"),
]
DISPLAY_NAMES = {
    "raw_partgen_1_5": "raw partgen 1.5",
    "generic_graph_baseline": "generic graph baseline",
    "agglomerative_graph_baseline": "agglomerative graph baseline",
    "knowledge_guided_rule_only_baseline": "knowledge-guided rule-only baseline",
    "final_system": "final system",
    "full_model": "full model",
}
PAPER_COLUMN_NAMES = {
    "component_partition_f1": "Partition Quality (F1)",
    "component_count_deviation": "Count Deviation",
    "semantic_accuracy": "Semantic Accuracy",
    "bcubed_f1": "B-Cubed F1",
    "pairwise_f1": "Pairwise F1",
}
TASK_AWARE_RECOVERY_COLUMNS = {
    "component_recovery_score": "Component Recovery Score",
    "instance_f1_50": "Instance F1@0.50",
    "instance_f1_75": "Instance F1@0.75",
    "semantic_recovery_score": "Semantic Recovery Score",
    "semantic_instance_f1_50": "Semantic Instance F1@0.50",
    "semantic_instance_f1_75": "Semantic Instance F1@0.75",
}
RELATION_COLUMNS = {
    "support_edge_precision": "Support Edge Precision",
    "support_edge_recall": "Support Edge Recall",
    "support_edge_f1": "Support Edge F1",
    "support_edge_f1_50": "Support Edge F1@0.50",
    "support_edge_f1_75": "Support Edge F1@0.75",
}
STRUCTURE_COLUMNS = {
    "structure_plausibility": "Structure Plausibility",
    "host_legality": "Host Legality",
    "gong_clean_ratio": "Gong Clean Ratio",
    "upper_dou_support_ratio": "Upper-Dou Support Ratio",
    "structure_violation_rate": "Structure Violation Rate",
    "mean_num_support_edges": "Mean Support Edges",
}


def parse_target_spec(text: str) -> Tuple[str, Path]:
    if "=" not in text:
        raise ValueError(f"invalid target spec: {text}")
    name, path_text = text.split("=", 1)
    return name.strip(), Path(path_text.strip())


def harmonic_mean(a: float, b: float) -> float:
    if a <= 0.0 or b <= 0.0:
        return 0.0
    return float(2.0 * a * b / max(a + b, 1e-8))


def safe_mean(values: Iterable[float]) -> float:
    values = list(values)
    return float(mean(values)) if values else 0.0


def safe_median(values: Iterable[float]) -> float:
    values = list(values)
    return float(median(values)) if values else 0.0


def normalized_partition_f1(row: Dict[str, object]) -> float:
    if "segment_partition_f1" in row:
        return float(row["segment_partition_f1"])
    purity = row.get("segment_mean_purity")
    completeness = row.get("segment_mean_completeness")
    if purity is not None and completeness is not None:
        return harmonic_mean(float(purity), float(completeness))
    return float(row.get("mean_purity", 0.0))


def normalized_count_error(row: Dict[str, object]) -> float:
    if "component_count_diff" in row:
        return float(row["component_count_diff"])
    num_components = float(row.get("num_components", 0.0))
    num_gt_parts = float(row.get("num_gt_parts", 0.0))
    return abs(num_components - num_gt_parts)


def normalized_semantic_acc(row: Dict[str, object]) -> float:
    if "semantic_acc" in row:
        return float(row["semantic_acc"])
    if "segment_semantic_acc" in row:
        return float(row["segment_semantic_acc"])
    return 0.0


def normalized_recoverable_case(row: Dict[str, object]) -> bool:
    if "recoverable_case" in row:
        return bool(row["recoverable_case"])
    return int(row.get("num_segments", 0)) >= int(row.get("num_gt_parts", 0))


def load_rows(output_dir: Path) -> List[Dict[str, object]]:
    metrics_path = output_dir / "metrics.json"
    if not metrics_path.exists():
        raise FileNotFoundError(f"metrics.json not found: {metrics_path}")
    rows = json.loads(metrics_path.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError(f"metrics.json is not a list: {metrics_path}")

    normalized_rows: List[Dict[str, object]] = []
    for row in rows:
        normalized_rows.append(
            {
                "uid": str(row["uid"]),
                "num_segments": int(row.get("num_segments", 0)),
                "num_components": int(row.get("num_components", 0)),
                "num_gt_parts": int(row.get("num_gt_parts", 0)),
                "partition_f1": normalized_partition_f1(row),
                "count_error": normalized_count_error(row),
                "semantic_acc": normalized_semantic_acc(row),
                "bcubed_precision": float(row.get("gt_bcubed_precision", 0.0)),
                "bcubed_recall": float(row.get("gt_bcubed_recall", 0.0)),
                "bcubed_f1": float(row.get("gt_bcubed_f1", 0.0)),
                "pairwise_precision": float(row.get("gt_pairwise_precision", 0.0)),
                "pairwise_recall": float(row.get("gt_pairwise_recall", 0.0)),
                "pairwise_f1": float(row.get("gt_pairwise_f1", 0.0)),
                "component_recovery_score": float(row.get("component_recovery_score", 0.0)),
                "instance_f1_50": float(row.get("instance_f1_50", 0.0)),
                "instance_f1_75": float(row.get("instance_f1_75", 0.0)),
                "semantic_recovery_score": float(row.get("semantic_recovery_score", 0.0)),
                "semantic_instance_f1_50": float(row.get("semantic_instance_f1_50", 0.0)),
                "semantic_instance_f1_75": float(row.get("semantic_instance_f1_75", 0.0)),
                "semantic_gt_recall_50": float(row.get("semantic_gt_recall_50", 0.0)),
                "semantic_gt_recall_75": float(row.get("semantic_gt_recall_75", 0.0)),
                "semantic_macro_f1_50": float(row.get("semantic_macro_f1_50", 0.0)),
                "semantic_macro_f1_75": float(row.get("semantic_macro_f1_75", 0.0)),
                "num_pred_support_edges_eval": float(row.get("num_pred_support_edges_eval", 0.0)),
                "num_gt_support_edges_eval": float(row.get("num_gt_support_edges_eval", 0.0)),
                "support_edge_precision": float(row.get("support_edge_precision", 0.0)),
                "support_edge_recall": float(row.get("support_edge_recall", 0.0)),
                "support_edge_f1": float(row.get("support_edge_f1", 0.0)),
                "support_edge_precision_50": float(row.get("support_edge_precision_50", 0.0)),
                "support_edge_recall_50": float(row.get("support_edge_recall_50", 0.0)),
                "support_edge_f1_50": float(row.get("support_edge_f1_50", 0.0)),
                "support_edge_precision_75": float(row.get("support_edge_precision_75", 0.0)),
                "support_edge_recall_75": float(row.get("support_edge_recall_75", 0.0)),
                "support_edge_f1_75": float(row.get("support_edge_f1_75", 0.0)),
                "structure_plausibility": float(row.get("structure_plausibility", 0.0)),
                "host_legality": float(row.get("host_legality", 0.0)),
                "gong_clean_ratio": float(row.get("gong_clean_ratio", 0.0)),
                "upper_dou_support_ratio": float(row.get("upper_dou_support_ratio", 0.0)),
                "structure_violation_rate": float(row.get("structure_violation_rate", 0.0)),
                "num_support_edges": float(row.get("num_support_edges", 0.0)),
                "recoverable_case": normalized_recoverable_case(row),
                "segment_mean_purity": float(row.get("segment_mean_purity", 0.0)),
                "segment_mean_completeness": float(row.get("segment_mean_completeness", 0.0)),
            }
        )
    normalized_rows.sort(key=lambda x: x["uid"])
    return normalized_rows


def summarize_rows(rows: List[Dict[str, object]]) -> Dict[str, object]:
    partition_values = [float(r["partition_f1"]) for r in rows]
    count_values = [float(r["count_error"]) for r in rows]
    semantic_values = [float(r["semantic_acc"]) for r in rows]
    bcubed_f1_values = [float(r["bcubed_f1"]) for r in rows]
    pairwise_f1_values = [float(r["pairwise_f1"]) for r in rows]
    return {
        "num_models": len(rows),
        "partition_f1": safe_mean(partition_values),
        "count_error": safe_mean(count_values),
        "semantic_acc": safe_mean(semantic_values),
        "component_partition_f1": safe_mean(partition_values),
        "component_count_deviation": safe_mean(count_values),
        "semantic_accuracy": safe_mean(semantic_values),
        "bcubed_precision": safe_mean(float(r["bcubed_precision"]) for r in rows),
        "bcubed_recall": safe_mean(float(r["bcubed_recall"]) for r in rows),
        "bcubed_f1": safe_mean(bcubed_f1_values),
        "pairwise_precision": safe_mean(float(r["pairwise_precision"]) for r in rows),
        "pairwise_recall": safe_mean(float(r["pairwise_recall"]) for r in rows),
        "pairwise_f1": safe_mean(pairwise_f1_values),
        "component_recovery_score": safe_mean(float(r["component_recovery_score"]) for r in rows),
        "instance_f1_50": safe_mean(float(r["instance_f1_50"]) for r in rows),
        "instance_f1_75": safe_mean(float(r["instance_f1_75"]) for r in rows),
        "semantic_recovery_score": safe_mean(float(r["semantic_recovery_score"]) for r in rows),
        "semantic_instance_f1_50": safe_mean(float(r["semantic_instance_f1_50"]) for r in rows),
        "semantic_instance_f1_75": safe_mean(float(r["semantic_instance_f1_75"]) for r in rows),
        "semantic_gt_recall_50": safe_mean(float(r["semantic_gt_recall_50"]) for r in rows),
        "semantic_gt_recall_75": safe_mean(float(r["semantic_gt_recall_75"]) for r in rows),
        "semantic_macro_f1_50": safe_mean(float(r["semantic_macro_f1_50"]) for r in rows),
        "semantic_macro_f1_75": safe_mean(float(r["semantic_macro_f1_75"]) for r in rows),
        "num_pred_support_edges_eval": safe_mean(float(r["num_pred_support_edges_eval"]) for r in rows),
        "num_gt_support_edges_eval": safe_mean(float(r["num_gt_support_edges_eval"]) for r in rows),
        "support_edge_precision": safe_mean(float(r["support_edge_precision"]) for r in rows),
        "support_edge_recall": safe_mean(float(r["support_edge_recall"]) for r in rows),
        "support_edge_f1": safe_mean(float(r["support_edge_f1"]) for r in rows),
        "support_edge_precision_50": safe_mean(float(r["support_edge_precision_50"]) for r in rows),
        "support_edge_recall_50": safe_mean(float(r["support_edge_recall_50"]) for r in rows),
        "support_edge_f1_50": safe_mean(float(r["support_edge_f1_50"]) for r in rows),
        "support_edge_precision_75": safe_mean(float(r["support_edge_precision_75"]) for r in rows),
        "support_edge_recall_75": safe_mean(float(r["support_edge_recall_75"]) for r in rows),
        "support_edge_f1_75": safe_mean(float(r["support_edge_f1_75"]) for r in rows),
        "structure_plausibility": safe_mean(float(r["structure_plausibility"]) for r in rows),
        "host_legality": safe_mean(float(r["host_legality"]) for r in rows),
        "gong_clean_ratio": safe_mean(float(r["gong_clean_ratio"]) for r in rows),
        "upper_dou_support_ratio": safe_mean(float(r["upper_dou_support_ratio"]) for r in rows),
        "structure_violation_rate": safe_mean(float(r["structure_violation_rate"]) for r in rows),
        "mean_num_support_edges": safe_mean(float(r["num_support_edges"]) for r in rows),
        "partition_f1_median": safe_median(partition_values),
        "count_error_median": safe_median(count_values),
        "semantic_acc_median": safe_median(semantic_values),
        "exact_count_match_rate": safe_mean(1.0 if float(r["count_error"]) == 0.0 else 0.0 for r in rows),
        "recoverable_case_rate": safe_mean(1.0 if bool(r["recoverable_case"]) else 0.0 for r in rows),
        "mean_num_segments": safe_mean(float(r["num_segments"]) for r in rows),
        "mean_num_components": safe_mean(float(r["num_components"]) for r in rows),
        "mean_num_gt_parts": safe_mean(float(r["num_gt_parts"]) for r in rows),
    }


def build_uid_index(rows: List[Dict[str, object]]) -> Dict[str, Dict[str, object]]:
    return {str(row["uid"]): row for row in rows}


def compute_pairwise_wins(candidate_rows: List[Dict[str, object]], reference_rows: List[Dict[str, object]]) -> Dict[str, object]:
    candidate_index = build_uid_index(candidate_rows)
    reference_index = build_uid_index(reference_rows)
    shared_uids = sorted(set(candidate_index) & set(reference_index))
    partition_better = 0
    count_better = 0
    semantic_better = 0
    all_three_better = 0
    all_three_not_worse = 0
    case_rows = []

    for uid in shared_uids:
        cand = candidate_index[uid]
        ref = reference_index[uid]
        delta_partition = float(cand["partition_f1"]) - float(ref["partition_f1"])
        delta_count = float(ref["count_error"]) - float(cand["count_error"])
        delta_semantic = float(cand["semantic_acc"]) - float(ref["semantic_acc"])
        better_partition = delta_partition > 1e-8
        better_count = delta_count > 1e-8
        better_semantic = delta_semantic > 1e-8
        not_worse_partition = delta_partition >= -1e-8
        not_worse_count = delta_count >= -1e-8
        not_worse_semantic = delta_semantic >= -1e-8

        partition_better += int(better_partition)
        count_better += int(better_count)
        semantic_better += int(better_semantic)
        all_three_better += int(better_partition and better_count and better_semantic)
        all_three_not_worse += int(not_worse_partition and not_worse_count and not_worse_semantic)

        case_rows.append(
            {
                "uid": uid,
                "delta_partition_f1": delta_partition,
                "delta_count_error": float(cand["count_error"]) - float(ref["count_error"]),
                "count_deviation_reduction": delta_count,
                "delta_semantic_acc": delta_semantic,
            }
        )

    return {
        "num_shared_cases": len(shared_uids),
        "partition_better_cases": partition_better,
        "count_error_better_cases": count_better,
        "semantic_better_cases": semantic_better,
        "component_partition_better_cases": partition_better,
        "component_count_deviation_better_cases": count_better,
        "semantic_accuracy_better_cases": semantic_better,
        "all_three_better_cases": all_three_better,
        "all_three_not_worse_cases": all_three_not_worse,
        "mean_delta_partition_f1": safe_mean(r["delta_partition_f1"] for r in case_rows),
        "mean_delta_count_error": safe_mean(r["delta_count_error"] for r in case_rows),
        "mean_count_deviation_reduction": safe_mean(r["count_deviation_reduction"] for r in case_rows),
        "mean_delta_semantic_acc": safe_mean(r["delta_semantic_acc"] for r in case_rows),
        "mean_delta_component_partition_f1": safe_mean(r["delta_partition_f1"] for r in case_rows),
        "mean_delta_component_count_deviation": safe_mean(r["delta_count_error"] for r in case_rows),
        "mean_component_count_deviation_reduction": safe_mean(r["count_deviation_reduction"] for r in case_rows),
        "mean_delta_semantic_accuracy": safe_mean(r["delta_semantic_acc"] for r in case_rows),
        "case_rows": case_rows,
    }


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_main_table_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "method_key": key,
                "method_name": DISPLAY_NAMES.get(key, key),
                "component_partition_f1": round(float(summary["component_partition_f1"]), 6),
                "component_count_deviation": round(float(summary["component_count_deviation"]), 6),
                "semantic_accuracy": round(float(summary["semantic_accuracy"]), 6),
                "bcubed_f1": round(float(summary["bcubed_f1"]), 6),
                "pairwise_f1": round(float(summary["pairwise_f1"]), 6),
                "exact_count_match_rate": round(float(summary["exact_count_match_rate"]), 6),
                "recoverable_case_rate": round(float(summary["recoverable_case_rate"]), 6),
            }
        )
    return rows


def build_paper_table_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "Method": DISPLAY_NAMES.get(key, key),
                PAPER_COLUMN_NAMES["component_partition_f1"]: round(float(summary["component_partition_f1"]), 4),
                PAPER_COLUMN_NAMES["component_count_deviation"]: round(float(summary["component_count_deviation"]), 4),
                PAPER_COLUMN_NAMES["semantic_accuracy"]: round(float(summary["semantic_accuracy"]), 4),
                PAPER_COLUMN_NAMES["bcubed_f1"]: round(float(summary["bcubed_f1"]), 4),
                PAPER_COLUMN_NAMES["pairwise_f1"]: round(float(summary["pairwise_f1"]), 4),
            }
        )
    return rows


def build_universal_table_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "method_key": key,
                "method_name": DISPLAY_NAMES.get(key, key),
                "bcubed_precision": round(float(summary["bcubed_precision"]), 6),
                "bcubed_recall": round(float(summary["bcubed_recall"]), 6),
                "bcubed_f1": round(float(summary["bcubed_f1"]), 6),
                "pairwise_precision": round(float(summary["pairwise_precision"]), 6),
                "pairwise_recall": round(float(summary["pairwise_recall"]), 6),
                "pairwise_f1": round(float(summary["pairwise_f1"]), 6),
            }
        )
    return rows


def build_taskaware_recovery_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "method_key": key,
                "method_name": DISPLAY_NAMES.get(key, key),
                "component_recovery_score": round(float(summary["component_recovery_score"]), 6),
                "instance_f1_50": round(float(summary["instance_f1_50"]), 6),
                "instance_f1_75": round(float(summary["instance_f1_75"]), 6),
                "semantic_recovery_score": round(float(summary["semantic_recovery_score"]), 6),
                "semantic_instance_f1_50": round(float(summary["semantic_instance_f1_50"]), 6),
                "semantic_instance_f1_75": round(float(summary["semantic_instance_f1_75"]), 6),
            }
        )
    return rows


def build_relation_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "method_key": key,
                "method_name": DISPLAY_NAMES.get(key, key),
                "support_edge_precision": round(float(summary["support_edge_precision"]), 6),
                "support_edge_recall": round(float(summary["support_edge_recall"]), 6),
                "support_edge_f1": round(float(summary["support_edge_f1"]), 6),
                "support_edge_f1_50": round(float(summary["support_edge_f1_50"]), 6),
                "support_edge_f1_75": round(float(summary["support_edge_f1_75"]), 6),
            }
        )
    return rows


def build_structure_rows(comparison: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    rows = []
    for key, summary in comparison.items():
        rows.append(
            {
                "method_key": key,
                "method_name": DISPLAY_NAMES.get(key, key),
                "structure_plausibility": round(float(summary["structure_plausibility"]), 6),
                "host_legality": round(float(summary["host_legality"]), 6),
                "gong_clean_ratio": round(float(summary["gong_clean_ratio"]), 6),
                "upper_dou_support_ratio": round(float(summary["upper_dou_support_ratio"]), 6),
                "structure_violation_rate": round(float(summary["structure_violation_rate"]), 6),
                "mean_num_support_edges": round(float(summary["mean_num_support_edges"]), 6),
            }
        )
    return rows


def build_case_metric_rows(all_rows: Dict[str, List[Dict[str, object]]], metric_names: List[str]) -> List[Dict[str, object]]:
    method_keys = list(all_rows.keys())
    uid_set = set()
    for rows in all_rows.values():
        uid_set.update(str(row["uid"]) for row in rows)

    indices = {key: build_uid_index(rows) for key, rows in all_rows.items()}
    records: List[Dict[str, object]] = []
    for uid in sorted(uid_set):
        row: Dict[str, object] = {"uid": uid}
        for key in method_keys:
            data = indices[key].get(uid)
            for metric_name in metric_names:
                field_name = f"{key}_{metric_name}"
                row[field_name] = "" if data is None else round(float(data[metric_name]), 6)
        records.append(row)
    return records


def build_case_table_rows(all_rows: Dict[str, List[Dict[str, object]]]) -> List[Dict[str, object]]:
    method_keys = list(all_rows.keys())
    uid_set = set()
    for rows in all_rows.values():
        uid_set.update(str(row["uid"]) for row in rows)

    indices = {key: build_uid_index(rows) for key, rows in all_rows.items()}
    records: List[Dict[str, object]] = []
    for uid in sorted(uid_set):
        row: Dict[str, object] = {"uid": uid}
        for key in method_keys:
            data = indices[key].get(uid)
            row[f"{key}_component_partition_f1"] = "" if data is None else round(float(data["partition_f1"]), 6)
            row[f"{key}_component_count_deviation"] = "" if data is None else round(float(data["count_error"]), 6)
            row[f"{key}_semantic_accuracy"] = "" if data is None else round(float(data["semantic_acc"]), 6)
            row[f"{key}_bcubed_f1"] = "" if data is None else round(float(data["bcubed_f1"]), 6)
            row[f"{key}_pairwise_f1"] = "" if data is None else round(float(data["pairwise_f1"]), 6)
        records.append(row)
    return records


def fmt(v: float) -> str:
    return f"{float(v):.4f}"


def build_markdown(comparison: Dict[str, Dict[str, object]], pairwise: Dict[str, Dict[str, object]], output_dirs: Dict[str, str]) -> str:
    ordered_keys = list(comparison.keys())
    num_models = int(comparison[ordered_keys[0]].get("num_models", 0)) if ordered_keys else 0

    lines: List[str] = []
    lines.append("# Pure-Format Evaluation Summary")
    lines.append("")
    lines.append("## 1. Evaluation Scope")
    lines.append("")
    lines.append(f"- Active evaluation set: `{num_models}` models.")
    lines.append("- The headline table evaluates partition quality, component-count deviation, and semantic accuracy.")
    lines.append("- Formal manual grouping references are limited to the six original annotated cases and are not used as the main paper metric source here.")
    lines.append("")
    lines.append("## 2. Headline Metrics")
    lines.append("")
    lines.append("1. `component_partition_f1 = H(segment_mean_purity, segment_mean_completeness)`. This jointly penalizes over-merging and over-fragmentation.")
    lines.append("2. `component_count_deviation = |N_pred - N_ref|`. This measures only scale mismatch between predicted and reference component counts.")
    lines.append("3. `semantic_accuracy` measures semantic correctness on matched components and should be interpreted together with partition quality.")
    lines.append("4. Task-aware recovery and structure diagnostics are also reported below so the summary reflects more than flat clustering scores.")
    lines.append("")
    lines.append("## 3. Main Table")
    lines.append("")
    lines.append("| Method | Partition Quality (F1) | Count Deviation | Semantic Accuracy |")
    lines.append("| --- | ---: | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(
            f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['component_partition_f1'])} | "
            f"{fmt(summary['component_count_deviation'])} | {fmt(summary['semantic_accuracy'])} |"
        )
    lines.append("")
    lines.append("## 4. Universal Clustering Metrics")
    lines.append("")
    lines.append("| Method | B-Cubed F1 | Pairwise F1 |")
    lines.append("| --- | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['bcubed_f1'])} | {fmt(summary['pairwise_f1'])} |")
    lines.append("")
    lines.append("## 5. Task-Aware Recovery Metrics")
    lines.append("")
    lines.append("| Method | Component Recovery Score | Instance F1@0.50 | Instance F1@0.75 | Semantic Recovery Score | Semantic Instance F1@0.50 | Semantic Instance F1@0.75 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(
            f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['component_recovery_score'])} | {fmt(summary['instance_f1_50'])} | "
            f"{fmt(summary['instance_f1_75'])} | {fmt(summary['semantic_recovery_score'])} | "
            f"{fmt(summary['semantic_instance_f1_50'])} | {fmt(summary['semantic_instance_f1_75'])} |"
        )
    lines.append("")
    lines.append("## 6. Direct Relation Recovery Metrics")
    lines.append("")
    lines.append("| Method | Support Edge Precision | Support Edge Recall | Support Edge F1 | Support Edge F1@0.50 | Support Edge F1@0.75 |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(
            f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['support_edge_precision'])} | {fmt(summary['support_edge_recall'])} | "
            f"{fmt(summary['support_edge_f1'])} | {fmt(summary['support_edge_f1_50'])} | {fmt(summary['support_edge_f1_75'])} |"
        )
    lines.append("")
    lines.append("## 7. Structure Plausibility Metrics")
    lines.append("")
    lines.append("| Method | Structure Plausibility | Host Legality | Gong Clean Ratio | Upper-Dou Support Ratio | Structure Violation Rate | Mean Support Edges |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(
            f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['structure_plausibility'])} | {fmt(summary['host_legality'])} | "
            f"{fmt(summary['gong_clean_ratio'])} | {fmt(summary['upper_dou_support_ratio'])} | "
            f"{fmt(summary['structure_violation_rate'])} | {fmt(summary['mean_num_support_edges'])} |"
        )
    lines.append("")
    lines.append("## 8. Context Metrics")
    lines.append("")
    lines.append("| Method | exact_count_match_rate | recoverable_case_rate |")
    lines.append("| --- | ---: | ---: |")
    for key in ordered_keys:
        summary = comparison[key]
        lines.append(
            f"| {DISPLAY_NAMES.get(key, key)} | {fmt(summary['exact_count_match_rate'])} | "
            f"{fmt(summary['recoverable_case_rate'])} |"
        )
    lines.append("")
    lines.append("## 9. Pairwise Win Statistics")
    lines.append("")
    for name, stats in pairwise.items():
        lines.append(f"### {name}")
        lines.append("")
        lines.append(f"- Better cases in `component_partition_f1`: {stats['component_partition_better_cases']}/{stats['num_shared_cases']}")
        lines.append(f"- Better cases in `component_count_deviation`: {stats['component_count_deviation_better_cases']}/{stats['num_shared_cases']}")
        lines.append(f"- Better cases in `semantic_accuracy`: {stats['semantic_accuracy_better_cases']}/{stats['num_shared_cases']}")
        lines.append(f"- Better on all three headline metrics: {stats['all_three_better_cases']}/{stats['num_shared_cases']}")
        lines.append(f"- Not worse on all three headline metrics: {stats['all_three_not_worse_cases']}/{stats['num_shared_cases']}")
        lines.append(
            f"- Mean deltas: `component_partition_f1 {fmt(stats['mean_delta_component_partition_f1'])}`, "
            f"`component_count_deviation {fmt(stats['mean_delta_component_count_deviation'])}`, "
            f"`count_deviation_reduction {fmt(stats['mean_component_count_deviation_reduction'])}`, "
            f"`semantic_accuracy {fmt(stats['mean_delta_semantic_accuracy'])}`"
        )
        lines.append("")
    lines.append("## 10. Reading Notes")
    lines.append("")
    lines.append("- `raw partgen 1.5` preserves all initial segments. A raw segment-preservation metric can therefore look artificially favorable even when component recovery is poor.")
    lines.append("- `component_count_deviation` is not a geometry-quality score. It only reports how far the predicted component count departs from the reference count.")
    lines.append("- `B-Cubed F1` and `Pairwise F1` are retained as universal clustering metrics so the evaluation is not purely task-specific.")
    lines.append("- `support_edge_precision`, `support_edge_recall`, and `support_edge_f1` directly compare recovered support relations against GT-derived assembly relations after one-to-one component matching.")
    lines.append("- `support_edge_f1@0.50/@0.75` restrict relation scoring to cases where both edge endpoints are matched with sufficient component quality, so they separate endpoint localization errors from relation inference errors.")
    lines.append("- `structure_plausibility`, `host_legality`, `gong_clean_ratio`, and `upper_dou_support_ratio` remain structural diagnostics. They measure self-consistency of the recovered structure and now explicitly supplement, rather than stand in for, direct relation recovery metrics.")
    lines.append("- Manual-reference metrics remain supplementary and should not dominate the main paper conclusion.")
    lines.append("")
    lines.append("## 11. Input Directories")
    lines.append("")
    for key in ordered_keys:
        lines.append(f"- `{DISPLAY_NAMES.get(key, key)}`: `{output_dirs[key]}`")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a pure-format evaluation report from existing metrics.json outputs.")
    parser.add_argument("--target", action="append", default=[], help="Target spec in the form name=path. If omitted, built-in defaults are used.")
    parser.add_argument("--out_dir", default=str(DEFAULT_OUT_DIR), help="Directory to save pure-format evaluation reports.")
    args = parser.parse_args()

    target_specs = [parse_target_spec(t) for t in args.target] if args.target else DEFAULT_TARGETS
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    all_rows: Dict[str, List[Dict[str, object]]] = {}
    comparison: Dict[str, Dict[str, object]] = {}
    output_dirs: Dict[str, str] = {}

    for key, output_dir in target_specs:
        rows = load_rows(output_dir)
        all_rows[key] = rows
        comparison[key] = summarize_rows(rows)
        output_dirs[key] = str(output_dir)

    pairwise: Dict[str, Dict[str, object]] = {}
    final_key = "final_system" if "final_system" in all_rows else ("full_model" if "full_model" in all_rows else None)
    if final_key and "raw_partgen_1_5" in all_rows:
        pairwise[f"{final_key} vs raw_partgen_1_5"] = compute_pairwise_wins(all_rows[final_key], all_rows["raw_partgen_1_5"])
    if final_key and "generic_graph_baseline" in all_rows:
        pairwise[f"{final_key} vs generic_graph_baseline"] = compute_pairwise_wins(all_rows[final_key], all_rows["generic_graph_baseline"])
    if final_key and "knowledge_guided_rule_only_baseline" in all_rows:
        pairwise[f"{final_key} vs knowledge_guided_rule_only_baseline"] = compute_pairwise_wins(
            all_rows[final_key],
            all_rows["knowledge_guided_rule_only_baseline"],
        )
    if final_key and "agglomerative_graph_baseline" in all_rows:
        pairwise[f"{final_key} vs agglomerative_graph_baseline"] = compute_pairwise_wins(
            all_rows[final_key],
            all_rows["agglomerative_graph_baseline"],
        )

    main_rows = build_main_table_rows(comparison)
    paper_rows = build_paper_table_rows(comparison)
    universal_rows = build_universal_table_rows(comparison)
    taskaware_rows = build_taskaware_recovery_rows(comparison)
    relation_rows = build_relation_rows(comparison)
    structure_rows = build_structure_rows(comparison)
    case_rows = build_case_table_rows(all_rows)
    taskaware_case_rows = build_case_metric_rows(
        all_rows,
        [
            "component_recovery_score",
            "semantic_recovery_score",
            "instance_f1_50",
            "semantic_instance_f1_50",
            "support_edge_precision",
            "support_edge_recall",
            "support_edge_f1",
            "support_edge_f1_50",
            "support_edge_f1_75",
            "structure_plausibility",
            "structure_violation_rate",
            "host_legality",
            "gong_clean_ratio",
            "upper_dou_support_ratio",
            "num_support_edges",
        ],
    )
    summary = {
        "comparison": comparison,
        "pairwise_wins": pairwise,
        "output_dirs": output_dirs,
    }

    write_csv(
        out_dir / "pure_eval_main_table.csv",
        main_rows,
        ["method_key", "method_name", "component_partition_f1", "component_count_deviation", "semantic_accuracy", "bcubed_f1", "pairwise_f1", "exact_count_match_rate", "recoverable_case_rate"],
    )
    write_csv(
        out_dir / "pure_eval_main_table_paper.csv",
        paper_rows,
        ["Method", "Partition Quality (F1)", "Count Deviation", "Semantic Accuracy", "B-Cubed F1", "Pairwise F1"],
    )
    write_csv(
        out_dir / "pure_eval_universal_metrics.csv",
        universal_rows,
        ["method_key", "method_name", "bcubed_precision", "bcubed_recall", "bcubed_f1", "pairwise_precision", "pairwise_recall", "pairwise_f1"],
    )
    write_csv(
        out_dir / "pure_eval_taskaware_recovery.csv",
        taskaware_rows,
        ["method_key", "method_name", "component_recovery_score", "instance_f1_50", "instance_f1_75", "semantic_recovery_score", "semantic_instance_f1_50", "semantic_instance_f1_75"],
    )
    write_csv(
        out_dir / "pure_eval_relation_metrics.csv",
        relation_rows,
        ["method_key", "method_name", "support_edge_precision", "support_edge_recall", "support_edge_f1", "support_edge_f1_50", "support_edge_f1_75"],
    )
    write_csv(
        out_dir / "pure_eval_structure_metrics.csv",
        structure_rows,
        ["method_key", "method_name", "structure_plausibility", "host_legality", "gong_clean_ratio", "upper_dou_support_ratio", "structure_violation_rate", "mean_num_support_edges"],
    )

    case_fieldnames = ["uid"]
    for key, _ in target_specs:
        case_fieldnames.extend(
            [
                f"{key}_component_partition_f1",
                f"{key}_component_count_deviation",
                f"{key}_semantic_accuracy",
                f"{key}_bcubed_f1",
                f"{key}_pairwise_f1",
        ]
    )
    write_csv(out_dir / "pure_eval_casewise_table.csv", case_rows, case_fieldnames)

    taskaware_case_fieldnames = ["uid"]
    for key, _ in target_specs:
        taskaware_case_fieldnames.extend(
            [
                f"{key}_component_recovery_score",
                f"{key}_semantic_recovery_score",
                f"{key}_instance_f1_50",
                f"{key}_semantic_instance_f1_50",
                f"{key}_support_edge_precision",
                f"{key}_support_edge_recall",
                f"{key}_support_edge_f1",
                f"{key}_support_edge_f1_50",
                f"{key}_support_edge_f1_75",
                f"{key}_structure_plausibility",
                f"{key}_structure_violation_rate",
                f"{key}_host_legality",
                f"{key}_gong_clean_ratio",
                f"{key}_upper_dou_support_ratio",
                f"{key}_num_support_edges",
            ]
        )
    write_csv(out_dir / "pure_eval_taskaware_casewise_table.csv", taskaware_case_rows, taskaware_case_fieldnames)

    (out_dir / "pure_eval_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "pure_eval_report_zh.md").write_text(build_markdown(comparison, pairwise, output_dirs), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
