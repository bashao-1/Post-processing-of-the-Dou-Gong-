from __future__ import annotations

import json
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
final = PKG / "06_final_semantic_model" / "overlays" / "final_system_exact"
rows = []
errors = []
for p in sorted(final.glob("*_semantic_overlay.json")):
    d = json.loads(p.read_text(encoding="utf-8"))
    inv = d.get("source_invariants", {})
    rows.append({"uid": d["uid"], "comp_map_sha256": inv.get("comp_map_sha256"),
                 "num_components": inv.get("num_components"), "num_fragments": inv.get("num_fragments")})
    if not inv.get("comp_map_sha256"):
        errors.append(f"{p.name}: missing comp_map_sha256")
if len(rows) != 26:
    errors.append(f"expected 26 final overlays, found {len(rows)}")
payload = {"status": "ok" if not errors else "failed", "errors": errors, "cases": rows,
           "interpretation": "all semantic-module rows use these frozen component-map invariants"}
out = PKG / "05_reports" / "semantic_module" / "semantic_merge_invariants.json"
out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(json.dumps({"status": payload["status"], "cases": len(rows), "errors": errors}))
if errors:
    raise SystemExit(1)
