import argparse
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Dict, Iterable, List, Tuple


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT_DIR = ROOT / "05_reports" / "router_advantage_report_20260531"
DEFAULT_TARGETS = [
    ("raw_partgen_1_5", ROOT / "03_outputs" / "outputs_raw_partgen_1_5_eval_20260502_seed0"),
    ("generic_graph_baseline", ROOT / "03_outputs" / "outputs_generic_graph_baseline_eval_20260502_seed0"),
    ("routed_overseg_system", ROOT / "03_outputs" / "outputs_overseg_router_eval_20260530_seed0"),
    ("legacy_full_system", ROOT / "03_outputs" / "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0"),
]
DISPLAY_NAMES = {
    "raw_partgen_1_5": "raw partgen 1.5",
    "generic_graph_baseline": "generic graph baseline",
    "routed_overseg_system": "routed overseg system",
    "legacy_full_system": "legacy full system",
}
KNOWN_OVERSEG_UIDS = {
    "2167d7e3c5e8",
    "0274e0b63d6b",
    "f624e1a47839",
    "0f5c68e92f93",
    "fa90363bc291",
    "88b2100aad54",
    "751837c802c5",
    "e0c87a48f5a5",
    "a28db58955f9",
    "6fe3f6959d49",
}
BOUNDARY_UIDS = {
    "18cf8c57e511",
}


def parse_target_spec(text: str) -> Tuple[str, Path]:
    if "=" not in text:
        raise ValueError(f"invalid target spec: {text}")
    name, path_text = text.split("=", 1)
    return name.strip(), Path(path_text.strip())


def safe_mean(values: Iterable[float]) -> float:
    values = list(values)
    return float(mean(values)) if values else 0.0


def load_rows(output_dir: Path) -> List[Dict[str, object]]:
    metrics_path = output_dir / "metrics.json"
    rows = json.loads(metrics_path.read_text(encoding="utf-8"))
    out: List[Dict[str, object]] = []
    for row in rows:
        out.append(
            {
                "uid": str(row["uid"]),
                "partition_f1": float(row.get("segment_partition_f1", row.get("mean_purity", 0.0))),
                "count_error": float(row.get("component_count_diff", 0.0)),
                "semantic_acc": float(row.get("segment_semantic_acc", row.get("semantic_acc", 0.0))),
                "pairwise_f1": float(row.get("gt_pairwise_f1", 0.0)),
                "bcubed_f1": float(row.get("gt_bcubed_f1", 0.0)),
                "component_recovery_score": float(row.get("component_recovery_score", 0.0)),
                "gt_recovery_rate_50": float(row.get("gt_recovery_rate_50", 0.0)),
                "structure_plausibility": float(row.get("structure_plausibility", 0.0)),
                "route_name": str(row.get("route_name", "")),
                "has_overseg": bool(row.get("has_overseg", False)),
            }
        )
    out.sort(key=lambda x: x["uid"])
    return out


def summarize_subset(rows: List[Dict[str, object]]) -> Dict[str, float]:
    return {
        "num_cases": len(rows),
        "partition_f1": safe_mean(float(r["partition_f1"]) for r in rows),
        "count_error": safe_mean(float(r["count_error"]) for r in rows),
        "semantic_acc": safe_mean(float(r["semantic_acc"]) for r in rows),
        "bcubed_f1": safe_mean(float(r["bcubed_f1"]) for r in rows),
        "pairwise_f1": safe_mean(float(r["pairwise_f1"]) for r in rows),
        "component_recovery_score": safe_mean(float(r["component_recovery_score"]) for r in rows),
        "gt_recovery_rate_50": safe_mean(float(r["gt_recovery_rate_50"]) for r in rows),
        "structure_plausibility": safe_mean(float(r["structure_plausibility"]) for r in rows),
    }


def select_subset(rows: List[Dict[str, object]], subset_name: str) -> List[Dict[str, object]]:
    if subset_name == "all_cases":
        return rows
    if subset_name == "known_overseg_cases":
        return [r for r in rows if str(r["uid"]) in KNOWN_OVERSEG_UIDS]
    if subset_name == "non_overseg_cases":
        return [r for r in rows if str(r["uid"]) not in KNOWN_OVERSEG_UIDS and str(r["uid"]) not in BOUNDARY_UIDS]
    if subset_name == "boundary_cases":
        return [r for r in rows if str(r["uid"]) in BOUNDARY_UIDS]
    raise ValueError(f"unknown subset: {subset_name}")


def build_subset_rows(all_rows: Dict[str, List[Dict[str, object]]]) -> List[Dict[str, object]]:
    subset_order = ["all_cases", "known_overseg_cases", "non_overseg_cases", "boundary_cases"]
    records: List[Dict[str, object]] = []
    for subset_name in subset_order:
        for method_key, rows in all_rows.items():
            subset_rows = select_subset(rows, subset_name)
            summary = summarize_subset(subset_rows)
            records.append(
                {
                    "subset": subset_name,
                    "method_key": method_key,
                    "method_name": DISPLAY_NAMES.get(method_key, method_key),
                    "num_cases": summary["num_cases"],
                    "partition_f1": round(summary["partition_f1"], 6),
                    "count_error": round(summary["count_error"], 6),
                    "semantic_acc": round(summary["semantic_acc"], 6),
                    "bcubed_f1": round(summary["bcubed_f1"], 6),
                    "pairwise_f1": round(summary["pairwise_f1"], 6),
                    "component_recovery_score": round(summary["component_recovery_score"], 6),
                    "gt_recovery_rate_50": round(summary["gt_recovery_rate_50"], 6),
                    "structure_plausibility": round(summary["structure_plausibility"], 6),
                }
            )
    return records


def build_subset_summary_map(subset_rows: List[Dict[str, object]]) -> Dict[Tuple[str, str], Dict[str, object]]:
    return {
        (str(row["subset"]), str(row["method_key"])): row
        for row in subset_rows
    }


def build_delta_rows(subset_rows: List[Dict[str, object]]) -> List[Dict[str, object]]:
    summary_map = build_subset_summary_map(subset_rows)
    subset_order = ["all_cases", "known_overseg_cases", "non_overseg_cases", "boundary_cases"]
    reference_keys = ["legacy_full_system", "generic_graph_baseline", "raw_partgen_1_5"]
    metric_keys = [
        "partition_f1",
        "count_error",
        "semantic_acc",
        "bcubed_f1",
        "pairwise_f1",
        "component_recovery_score",
        "gt_recovery_rate_50",
        "structure_plausibility",
    ]
    rows: List[Dict[str, object]] = []
    for subset_name in subset_order:
        routed = summary_map.get((subset_name, "routed_overseg_system"))
        if routed is None:
            continue
        for ref_key in reference_keys:
            ref = summary_map.get((subset_name, ref_key))
            if ref is None:
                continue
            row = {
                "subset": subset_name,
                "candidate_key": "routed_overseg_system",
                "candidate_name": DISPLAY_NAMES["routed_overseg_system"],
                "reference_key": ref_key,
                "reference_name": DISPLAY_NAMES.get(ref_key, ref_key),
                "num_cases": routed["num_cases"],
            }
            for key in metric_keys:
                delta = float(routed[key]) - float(ref[key])
                row[f"delta_{key}"] = round(delta, 6)
            row["count_error_reduction"] = round(float(ref["count_error"]) - float(routed["count_error"]), 6)
            rows.append(row)
    return rows


def build_router_summary(routed_rows: List[Dict[str, object]]) -> Dict[str, object]:
    predicted_overseg = {str(r["uid"]) for r in routed_rows if str(r.get("route_name", "")) == "full_overseg_route"}
    predicted_conservative = {str(r["uid"]) for r in routed_rows if str(r.get("route_name", "")) == "conservative_route"}
    gt_overseg = set(KNOWN_OVERSEG_UIDS)
    universe = {str(r["uid"]) for r in routed_rows if str(r["uid"]) not in BOUNDARY_UIDS}
    gt_non_overseg = universe - gt_overseg

    tp = len(predicted_overseg & gt_overseg)
    fp = len((predicted_overseg - gt_overseg) - BOUNDARY_UIDS)
    fn = len(gt_overseg - predicted_overseg)
    tn = len(gt_non_overseg & predicted_conservative)
    precision = float(tp / max(tp + fp, 1))
    recall = float(tp / max(tp + fn, 1))
    f1 = float(2.0 * precision * recall / max(precision + recall, 1e-8)) if (precision > 0.0 or recall > 0.0) else 0.0
    conservative_protection = float(tn / max(len(gt_non_overseg), 1))

    return {
        "known_overseg_case_count": len(gt_overseg),
        "known_non_overseg_case_count": len(gt_non_overseg),
        "predicted_full_overseg_route_count": len(predicted_overseg),
        "predicted_conservative_route_count": len(predicted_conservative),
        "known_overseg_hit_count": tp,
        "known_overseg_miss_count": fn,
        "known_non_overseg_protected_count": tn,
        "known_overseg_route_precision": precision,
        "known_overseg_route_recall": recall,
        "known_overseg_route_f1": f1,
        "conservative_protection_rate": conservative_protection,
        "missed_overseg_uids": sorted(gt_overseg - predicted_overseg),
        "false_positive_overseg_uids": sorted((predicted_overseg - gt_overseg) - BOUNDARY_UIDS),
        "boundary_uids": sorted(BOUNDARY_UIDS),
    }


def fmt(v: float) -> str:
    return f"{float(v):.4f}"


def build_markdown(subset_rows: List[Dict[str, object]], router_summary: Dict[str, object]) -> str:
    summary_map = build_subset_summary_map(subset_rows)
    lines: List[str] = []
    lines.append("# Router Advantage Report")
    lines.append("")
    lines.append("## 1. Design Goal")
    lines.append("")
    lines.append("- This report does not replace the original global evaluation.")
    lines.append("- It highlights the routed system where it is actually designed to help: known over-segmentation cases and conservative protection on non-overseg cases.")
    lines.append("- Metrics remain the original ones; only the reading angle is changed.")
    lines.append("")
    lines.append("## 2. Router Hit Summary")
    lines.append("")
    lines.append(f"- Known overseg cases: `{router_summary['known_overseg_case_count']}`")
    lines.append(f"- Known non-overseg cases: `{router_summary['known_non_overseg_case_count']}`")
    lines.append(f"- Full overseg route chosen: `{router_summary['predicted_full_overseg_route_count']}`")
    lines.append(f"- Conservative route chosen: `{router_summary['predicted_conservative_route_count']}`")
    lines.append(f"- Known overseg hit count: `{router_summary['known_overseg_hit_count']}`")
    lines.append(f"- Known overseg route recall: `{fmt(router_summary['known_overseg_route_recall'])}`")
    lines.append(f"- Known overseg route precision: `{fmt(router_summary['known_overseg_route_precision'])}`")
    lines.append(f"- Known overseg route F1: `{fmt(router_summary['known_overseg_route_f1'])}`")
    lines.append(f"- Conservative protection rate on known non-overseg cases: `{fmt(router_summary['conservative_protection_rate'])}`")
    if router_summary["missed_overseg_uids"]:
        lines.append(f"- Missed known overseg cases: `{', '.join(router_summary['missed_overseg_uids'])}`")
    if router_summary["false_positive_overseg_uids"]:
        lines.append(f"- Extra full-route cases outside known overseg set: `{', '.join(router_summary['false_positive_overseg_uids'])}`")
    lines.append("")
    lines.append("## 3. Headline Gains")
    lines.append("")
    for subset_name, subset_title in [
        ("known_overseg_cases", "Known Overseg Cases"),
        ("non_overseg_cases", "Known Non-Overseg Cases"),
    ]:
        routed = summary_map.get((subset_name, "routed_overseg_system"))
        legacy = summary_map.get((subset_name, "legacy_full_system"))
        generic = summary_map.get((subset_name, "generic_graph_baseline"))
        if routed is None:
            continue
        lines.append(f"### {subset_title}")
        lines.append("")
        if legacy is not None:
            lines.append(
                f"- Compared with `legacy full system`, routed changes are: "
                f"`Partition F1 {float(routed['partition_f1']) - float(legacy['partition_f1']):+.4f}`, "
                f"`Pairwise F1 {float(routed['pairwise_f1']) - float(legacy['pairwise_f1']):+.4f}`, "
                f"`Component Recovery {float(routed['component_recovery_score']) - float(legacy['component_recovery_score']):+.4f}`, "
                f"`Structure Plausibility {float(routed['structure_plausibility']) - float(legacy['structure_plausibility']):+.4f}`."
            )
        if generic is not None:
            lines.append(
                f"- Compared with `generic graph baseline`, routed changes are: "
                f"`Partition F1 {float(routed['partition_f1']) - float(generic['partition_f1']):+.4f}`, "
                f"`Pairwise F1 {float(routed['pairwise_f1']) - float(generic['pairwise_f1']):+.4f}`, "
                f"`Component Recovery {float(routed['component_recovery_score']) - float(generic['component_recovery_score']):+.4f}`, "
                f"`Structure Plausibility {float(routed['structure_plausibility']) - float(generic['structure_plausibility']):+.4f}`."
            )
        lines.append("")
    lines.append("## 4. Subset Comparison")
    lines.append("")
    for subset_name, subset_title in [
        ("all_cases", "All Cases"),
        ("known_overseg_cases", "Known Overseg Cases"),
        ("non_overseg_cases", "Known Non-Overseg Cases"),
        ("boundary_cases", "Boundary Cases"),
    ]:
        lines.append(f"### {subset_title}")
        lines.append("")
        lines.append("| Method | Cases | Partition F1 | Count Deviation | Semantic Acc | B-Cubed F1 | Pairwise F1 | Component Recovery | GT Recovery@0.50 | Structure Plausibility |")
        lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
        for row in subset_rows:
            if row["subset"] != subset_name:
                continue
            lines.append(
                f"| {row['method_name']} | {row['num_cases']} | {fmt(row['partition_f1'])} | {fmt(row['count_error'])} | "
                f"{fmt(row['semantic_acc'])} | {fmt(row['bcubed_f1'])} | {fmt(row['pairwise_f1'])} | "
                f"{fmt(row['component_recovery_score'])} | {fmt(row['gt_recovery_rate_50'])} | {fmt(row['structure_plausibility'])} |"
            )
        lines.append("")
    lines.append("## 5. Reading Notes")
    lines.append("")
    lines.append("- `known_overseg_cases` is the user-confirmed 10-case set where the main target is repairing gong-dou over-segmentation.")
    lines.append("- `non_overseg_cases` is used to show whether the router preserves safer behavior outside the target subset.")
    lines.append("- The intent here is to express where the routed system is strong, not to replace the original whole-set paper table.")
    lines.append("")
    return "\n".join(lines)


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a supplementary advantage report for the overseg router system.")
    parser.add_argument("--target", action="append", default=[], help="Target spec in the form name=path. If omitted, built-in defaults are used.")
    parser.add_argument("--out_dir", default=str(DEFAULT_OUT_DIR), help="Directory to save router advantage reports.")
    args = parser.parse_args()

    target_specs = [parse_target_spec(t) for t in args.target] if args.target else DEFAULT_TARGETS
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    all_rows: Dict[str, List[Dict[str, object]]] = {}
    for key, output_dir in target_specs:
        all_rows[key] = load_rows(output_dir)

    subset_rows = build_subset_rows(all_rows)
    delta_rows = build_delta_rows(subset_rows)
    router_summary = build_router_summary(all_rows["routed_overseg_system"])
    summary = {
        "router_summary": router_summary,
        "subset_rows": subset_rows,
        "delta_rows": delta_rows,
        "known_overseg_uids": sorted(KNOWN_OVERSEG_UIDS),
        "boundary_uids": sorted(BOUNDARY_UIDS),
    }

    write_csv(
        out_dir / "router_advantage_subset_metrics.csv",
        subset_rows,
        [
            "subset",
            "method_key",
            "method_name",
            "num_cases",
            "partition_f1",
            "count_error",
            "semantic_acc",
            "bcubed_f1",
            "pairwise_f1",
            "component_recovery_score",
            "gt_recovery_rate_50",
            "structure_plausibility",
        ],
    )
    write_csv(
        out_dir / "router_advantage_deltas.csv",
        delta_rows,
        [
            "subset",
            "candidate_key",
            "candidate_name",
            "reference_key",
            "reference_name",
            "num_cases",
            "delta_partition_f1",
            "count_error_reduction",
            "delta_count_error",
            "delta_semantic_acc",
            "delta_bcubed_f1",
            "delta_pairwise_f1",
            "delta_component_recovery_score",
            "delta_gt_recovery_rate_50",
            "delta_structure_plausibility",
        ],
    )
    (out_dir / "router_advantage_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "router_advantage_report_zh.md").write_text(build_markdown(subset_rows, router_summary), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
