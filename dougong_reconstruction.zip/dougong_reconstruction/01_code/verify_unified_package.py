from __future__ import annotations

import csv
import json
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
METHODS = ["raw_partgen_1_5", "agglomerative_graph_baseline", "generic_graph_baseline", "final_system"]
errors: list[str] = []

for method in METHODS:
    output = next((PKG / "03_outputs").glob(f"*{method}*"), None)
    if method == "final_system":
        output = PKG / "03_outputs" / "outputs_overseg_router_eval_replaced5_semanticdist_20260604"
    overlay = PKG / "06_final_semantic_model" / "overlays" / ("final_system_exact" if method == "final_system" else method)
    if output is None or not output.exists():
        errors.append(f"missing output: {method}")
        continue
    outputs = sorted(output.glob("*_summary.json"))
    overlays = sorted(overlay.glob("*_semantic_overlay.json"))
    if len(outputs) != 26:
        errors.append(f"{method}: {len(outputs)} summaries, expected 26")
    if len(overlays) != 26:
        errors.append(f"{method}: {len(overlays)} overlays, expected 26")
    for op in overlays:
        uid = op.name.replace("_semantic_overlay.json", "")
        summary = output / f"{uid}_summary.json"
        if not summary.exists():
            errors.append(f"{method}/{uid}: missing summary")
            continue
        overlay_data = json.loads(op.read_text(encoding="utf-8"))
        summary_data = json.loads(summary.read_text(encoding="utf-8"))
        overlay_ids = {int(x["component_id"]) for x in overlay_data.get("components", [])}
        summary_ids = {int(x["component_id"]) for x in summary_data.get("components", [])}
        if overlay_ids != summary_ids:
            errors.append(f"{method}/{uid}: component IDs differ")

table = PKG / "05_reports" / "unified_final" / "table4_unified_main.csv"
if table.exists():
    with table.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if {r["method"] for r in rows} != set(METHODS):
        errors.append("Table 4 method rows do not match four-method contract")
else:
    errors.append("missing unified Table 4")

result = {"status": "ok" if not errors else "failed", "errors": errors, "methods": METHODS}
(PKG / "07_manifests" / "verification_result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if errors:
    raise SystemExit(1)
