"""Class-wise semantic evaluation for saved dougong outputs.

This evaluation separates component matching/recovery from semantic labeling.
Only one-to-one geometry matches above a declared overlap threshold contribute to
classification scores; unmatched predictions and GT components are reported
separately instead of being silently discarded.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROJECT = ROOT.parent.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT))
import dougong_refine_v4 as base  # noqa: E402
import evaluate_saved_outputs_softmetrics_20260519 as saved  # noqa: E402
import task_aware_eval_metrics_20260427 as task_eval  # noqa: E402

CLASSES = ["gong", "dou", "fang", "chuan", "ang", "other"]


def f1(p: float, r: float) -> float:
    return 2.0 * p * r / (p + r) if p + r > 0 else 0.0


def evaluate_case(uid: str, output_dir: Path, fragment_dir: Path, gt_dir: Path,
                  threshold: float, samples: int) -> Tuple[dict, Counter, Counter, List[Tuple[str, str]]]:
    case = saved.build_case_row(uid, str(fragment_dir), samples)
    out = saved.load_saved_case(str(output_dir), uid)
    comp_points = saved.build_component_points(case, out["comp_map"])
    gt_parts = base.load_gt_parts_auto(str(gt_dir), uid, case["center"], case["scale"], samples)
    tables = task_eval.build_surface_overlap_tables(comp_points, gt_parts, tau=0.12 * case["global_diag"], max_points=768)
    matching = task_eval.solve_optimal_component_matching(tables)
    pairs = [p for p in matching["pairs"] if float(p["score"]) >= threshold]
    pred_sem = out["comp_sem"]
    gt_sem = {i: str(p.semantic) for i, p in enumerate(gt_parts)}
    valid = [(str(pred_sem.get(int(p["pred_id"]), "unknown")), gt_sem[int(p["gt_id"])]) for p in pairs]
    pred_counts = Counter(str(v) for v in pred_sem.values())
    gt_counts = Counter(gt_sem.values())
    correct = sum(a == b for a, b in valid)
    per_class = {}
    for cls in CLASSES:
        tp = sum(a == cls and b == cls for a, b in valid)
        fp = sum(a == cls and b != cls for a, b in valid)
        fn = sum(a != cls and b == cls for a, b in valid)
        # Unmatched predictions/GT are counted as errors for end-to-end coverage.
        matched_pred = {int(p["pred_id"]) for p in pairs}
        matched_gt = {int(p["gt_id"]) for p in pairs}
        fp += sum(1 for cid, label in pred_sem.items() if int(cid) not in matched_pred and str(label) == cls)
        fn += sum(1 for gid, label in gt_sem.items() if int(gid) not in matched_gt and label == cls)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        per_class[cls] = {"tp": tp, "fp": fp, "fn": fn, "precision": precision,
                          "recall": recall, "f1": f1(precision, recall)}
    cm = {g: {p: 0 for p in CLASSES} for g in CLASSES}
    for pred, gold in valid:
        if gold in cm and pred in cm[gold]:
            cm[gold][pred] += 1
    macro = float(np.mean([per_class[c]["f1"] for c in CLASSES]))
    accuracy = correct / len(valid) if valid else 0.0
    all_correct = correct / max(len(pred_sem) + len(gt_sem) - len(pairs), 1)
    row = {"uid": uid, "num_pred": len(pred_sem), "num_gt": len(gt_sem),
           "matched": len(pairs), "match_precision": len(pairs) / max(len(pred_sem), 1),
           "match_recall": len(pairs) / max(len(gt_sem), 1),
           "classification_accuracy_matched": accuracy, "end_to_end_semantic_accuracy": all_correct,
           "macro_f1": macro, "per_class": per_class, "confusion_matrix": cm,
           "pred_distribution": dict(pred_counts), "gt_distribution": dict(gt_counts)}
    return row, pred_counts, gt_counts, valid


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fragment_dir", type=Path, default=PROJECT / "meshes" / "fragment" / "glb")
    ap.add_argument("--gt_dir", type=Path, default=PROJECT / "meshes")
    ap.add_argument("--output_root", type=Path, default=ROOT / "03_outputs")
    ap.add_argument("--method", action="append", required=True, help="name=directory")
    ap.add_argument("--out_dir", type=Path, default=ROOT / "05_reports" / "semantic_classwise_20260814")
    ap.add_argument("--threshold", type=float, default=0.50)
    ap.add_argument("--samples", type=int, default=512)
    args = ap.parse_args()
    methods = {}
    for spec in args.method:
        name, path = spec.split("=", 1)
        methods[name] = Path(path)
    ids = sorted({p.name.replace("_summary.json", "") for d in methods.values() for p in d.glob("*_summary.json")})
    args.out_dir.mkdir(parents=True, exist_ok=True)
    summary = {}
    for name, directory in methods.items():
        rows = []
        cm_total = {g: {p: 0 for p in CLASSES} for g in CLASSES}
        for uid in ids:
            try:
                row, _, _, _ = evaluate_case(uid, directory, args.fragment_dir, args.gt_dir, args.threshold, args.samples)
            except Exception as exc:
                print(f"skip {name}/{uid}: {exc}", file=sys.stderr)
                continue
            rows.append(row)
            for g in CLASSES:
                for p in CLASSES:
                    cm_total[g][p] += row["confusion_matrix"][g][p]
        metrics = {}
        for cls in CLASSES:
            vals = [r["per_class"][cls] for r in rows]
            metrics[cls] = {k: float(np.mean([v[k] for v in vals])) for k in ("precision", "recall", "f1")} if vals else {"precision": 0.0, "recall": 0.0, "f1": 0.0}
        summary[name] = {"num_cases": len(rows), "matched_accuracy": float(np.mean([r["classification_accuracy_matched"] for r in rows])) if rows else 0.0,
                         "end_to_end_accuracy": float(np.mean([r["end_to_end_semantic_accuracy"] for r in rows])) if rows else 0.0,
                         "macro_f1": float(np.mean([r["macro_f1"] for r in rows])) if rows else 0.0,
                         "match_precision": float(np.mean([r["match_precision"] for r in rows])) if rows else 0.0,
                         "match_recall": float(np.mean([r["match_recall"] for r in rows])) if rows else 0.0,
                         "per_class": metrics, "confusion_matrix": cm_total, "casewise": rows}
    (args.out_dir / "semantic_classwise_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    with (args.out_dir / "semantic_classwise_main.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["method", "cases", "matched_accuracy", "end_to_end_accuracy", "macro_f1", "match_precision", "match_recall"])
        for name, s in summary.items(): w.writerow([name, s["num_cases"], s["matched_accuracy"], s["end_to_end_accuracy"], s["macro_f1"], s["match_precision"], s["match_recall"]])
    print(json.dumps({k: {x: v[x] for x in ("num_cases", "matched_accuracy", "end_to_end_accuracy", "macro_f1", "match_precision", "match_recall")} for k, v in summary.items()}, indent=2))


if __name__ == "__main__":
    main()
