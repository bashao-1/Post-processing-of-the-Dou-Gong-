import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np


THIS_DIR = Path(__file__).resolve().parent
ROOT_DIR = THIS_DIR.parent
CODE_DIR = ROOT_DIR / "code"
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import dougong_refine_v4 as base
import dougong_refine_fragmentrefresh_stage1_stage2_standalone_bodyfirst_20260419 as fullsys
import task_aware_eval_metrics_20260427 as task_eval
import fragmentrefresh_stage2_utils_bodyfirst_20260419 as stage2_utils


VARIANTS = {
    "full": {
        "label": "Full Model",
        "description": "Current final system with all learned refinement, body-first host recovery, semantic rollback and conservative protection enabled.",
        "enable_split_loop": True,
        "enable_merge_loop": True,
        "enable_bodyfirst_host_recovery": True,
        "enable_semantic_structural_rollback": True,
        "enable_conservative_protection": True,
        "enable_stage1_bodyfirst": True,
        "enable_stage1_semantic_guidance": True,
        "enable_stage1_learned_priors": True,
        "enable_stage1_manual_edge_calibrator": True,
        "enable_stage1_learned_edge_scoring": True,
        "enable_stage1_augmented_edges": True,
        "enable_stage1_bottom_dou_detach": True,
    },
    "wo_learned_boundary_optimization": {
        "label": "w/o Learned Boundary Optimization",
        "description": "Disable learned split and merge classifier loops, and also remove learned stage1 edge scoring and score calibration while preserving deterministic structural repairs.",
        "enable_split_loop": False,
        "enable_merge_loop": False,
        "enable_bodyfirst_host_recovery": True,
        "enable_semantic_structural_rollback": True,
        "enable_conservative_protection": True,
        "enable_stage1_bodyfirst": True,
        "enable_stage1_semantic_guidance": True,
        "enable_stage1_learned_priors": True,
        "enable_stage1_manual_edge_calibrator": False,
        "enable_stage1_learned_edge_scoring": False,
        "enable_stage1_augmented_edges": True,
        "enable_stage1_bottom_dou_detach": True,
    },
    "wo_bodyfirst_host_recovery": {
        "label": "w/o Body-First Host Recovery",
        "description": "Disable host-centered body-first recovery in both stage1 and stage2, including prototype body recovery, host reassignment, upper-cap attachment, sloped-gong host split and upper-dou host attachment.",
        "enable_split_loop": True,
        "enable_merge_loop": True,
        "enable_bodyfirst_host_recovery": False,
        "enable_semantic_structural_rollback": True,
        "enable_conservative_protection": True,
        "enable_stage1_bodyfirst": False,
        "enable_stage1_semantic_guidance": True,
        "enable_stage1_learned_priors": True,
        "enable_stage1_manual_edge_calibrator": True,
        "enable_stage1_learned_edge_scoring": True,
        "enable_stage1_augmented_edges": True,
        "enable_stage1_bottom_dou_detach": True,
    },
    "wo_semantic_structural_rollback": {
        "label": "w/o Semantic-Structural Rollback",
        "description": "Disable semantic-aware rollback of suspicious large uncertain merged components, including the stage1 bottom dou-like detach safeguard.",
        "enable_split_loop": True,
        "enable_merge_loop": True,
        "enable_bodyfirst_host_recovery": True,
        "enable_semantic_structural_rollback": False,
        "enable_conservative_protection": True,
        "enable_stage1_bodyfirst": True,
        "enable_stage1_semantic_guidance": True,
        "enable_stage1_learned_priors": True,
        "enable_stage1_manual_edge_calibrator": True,
        "enable_stage1_learned_edge_scoring": True,
        "enable_stage1_augmented_edges": True,
        "enable_stage1_bottom_dou_detach": False,
    },
    "wo_conservative_protection": {
        "label": "w/o Conservative Protection",
        "description": "Disable clean tiny-case identity restore so the system becomes more aggressive on already-good small inputs.",
        "enable_split_loop": True,
        "enable_merge_loop": True,
        "enable_bodyfirst_host_recovery": True,
        "enable_semantic_structural_rollback": True,
        "enable_conservative_protection": False,
        "enable_stage1_bodyfirst": True,
        "enable_stage1_semantic_guidance": True,
        "enable_stage1_learned_priors": True,
        "enable_stage1_manual_edge_calibrator": True,
        "enable_stage1_learned_edge_scoring": True,
        "enable_stage1_augmented_edges": True,
        "enable_stage1_bottom_dou_detach": True,
    },
}


def apply_stage2_refinement_variant(
    comp_map: dict,
    seg_points: dict,
    score_map: dict,
    semantic_model: dict,
    stage2_model: dict,
    variant: dict,
) -> dict:
    comp_map = stage2_utils.relabel_component_map(comp_map)
    split_model = stage2_model.get("split_classifier", {})
    merge_model = stage2_model.get("merge_classifier", {})
    split_threshold = float(stage2_model.get("split_threshold", 1.0))
    merge_threshold = float(stage2_model.get("merge_threshold", 1.5))
    next_cid = max(comp_map.values()) + 1 if comp_map else 0

    if bool(variant.get("enable_split_loop", True)):
        changed = True
        while changed:
            changed = False
            members = stage2_utils.collect_component_members(comp_map)
            best = None
            for cid, segs in members.items():
                segs = sorted(segs)
                if len(segs) < 2 or len(segs) > 6:
                    continue
                for subset_size in (1, 2):
                    if subset_size >= len(segs):
                        continue
                    for subset in stage2_utils.itertools.combinations(segs, subset_size):
                        rest = [sid for sid in segs if sid not in subset]
                        feat = stage2_utils.subset_feature(list(subset), rest, seg_points, score_map, semantic_model)[None, :]
                        logit = float(stage2_utils.predict_logit(feat, split_model)[0])
                        if best is None or logit > best[0]:
                            best = (logit, int(cid), [int(x) for x in subset])
            if best and best[0] > split_threshold:
                _, source_cid, subset_ids = best
                for seg_id in subset_ids:
                    if comp_map.get(seg_id) == source_cid:
                        comp_map[seg_id] = next_cid
                next_cid += 1
                comp_map = stage2_utils.relabel_component_map(comp_map)
                changed = True

    if bool(variant.get("enable_merge_loop", True)):
        changed = True
        while changed:
            changed = False
            members = stage2_utils.collect_component_members(comp_map)
            best = None
            cids = sorted(members.keys())
            for i, cid_a in enumerate(cids):
                group_a = sorted(members[cid_a])
                for cid_b in cids[i + 1:]:
                    group_b = sorted(members[cid_b])
                    feat = stage2_utils.merge_feature(group_a, group_b, seg_points, semantic_model)[None, :]
                    logit = float(stage2_utils.predict_logit(feat, merge_model)[0])
                    if best is None or logit > best[0]:
                        best = (logit, int(cid_a), int(cid_b))
            if best and best[0] > merge_threshold:
                _, cid_a, cid_b = best
                for seg_id, cid in list(comp_map.items()):
                    if cid == cid_b:
                        comp_map[seg_id] = cid_a
                comp_map = stage2_utils.relabel_component_map(comp_map)
                changed = True

    if bool(variant.get("enable_bodyfirst_host_recovery", True)):
        comp_map = stage2_utils.reassign_alien_segments_from_vertical_hosts(comp_map, seg_points, score_map)
        comp_map = stage2_utils.attach_vertical_body_upper_caps(comp_map, seg_points, score_map)
        comp_map = stage2_utils.split_out_strong_sloped_gong_segments(comp_map, seg_points, score_map, semantic_model)
        comp_map = stage2_utils.attach_upper_dou_segments_to_sloped_hosts(comp_map, seg_points, score_map, semantic_model)

    if bool(variant.get("enable_semantic_structural_rollback", True)):
        comp_map = stage2_utils.split_large_uncertain_components(comp_map, seg_points, score_map, semantic_model)

    if bool(variant.get("enable_conservative_protection", True)):
        comp_map = stage2_utils.maybe_restore_identity_for_clean_tiny_case(comp_map, seg_points, score_map)

    return stage2_utils.relabel_component_map(comp_map)


def summarize_results(results: list, variant_name: str, variant: dict, args) -> dict:
    summary = {
        "variant_name": variant_name,
        "variant_label": variant["label"],
        "variant_description": variant["description"],
        "variant_config": {k: v for k, v in variant.items() if k.startswith("enable_")},
        "num_models": len(results),
        "mean_purity_definition": "harmonic_mean(segment_mean_purity, segment_mean_completeness)",
        "mean_num_components": float(np.mean([r["num_components"] for r in results])) if results else 0.0,
        "mean_component_count_diff": float(np.mean([r["component_count_diff"] for r in results])) if results else 0.0,
        "mean_purity": float(np.mean([r["mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_purity": float(np.mean([r["segment_mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_completeness": float(np.mean([r["segment_mean_completeness"] for r in results])) if results else 0.0,
        "mean_segment_partition_f1": float(np.mean([r["segment_partition_f1"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_precision": float(np.mean([r["gt_bcubed_precision"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_recall": float(np.mean([r["gt_bcubed_recall"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_f1": float(np.mean([r["gt_bcubed_f1"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_precision": float(np.mean([r["gt_pairwise_precision"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_recall": float(np.mean([r["gt_pairwise_recall"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_f1": float(np.mean([r["gt_pairwise_f1"] for r in results])) if results else 0.0,
        "mean_geometry_purity": float(np.mean([r["geometry_mean_purity"] for r in results])) if results else 0.0,
        "mean_geometry_pred_score": float(np.mean([r["geometry_pred_score"] for r in results])) if results else 0.0,
        "mean_geometry_gt_score": float(np.mean([r["geometry_gt_score"] for r in results])) if results else 0.0,
        "mean_geometry_balanced_score": float(np.mean([r["geometry_balanced_score"] for r in results])) if results else 0.0,
        "mean_purity_legacy": float(np.mean([r["mean_purity_legacy"] for r in results])) if results else 0.0,
        "mean_forward_cover": float(np.mean([r["mean_forward_cover"] for r in results])) if results else 0.0,
        "mean_backward_cover": float(np.mean([r["mean_backward_cover"] for r in results])) if results else 0.0,
        "mean_gt_cover": float(np.mean([r["mean_gt_cover"] for r in results])) if results else 0.0,
        "mean_matched_component_purity": float(np.mean([r["mean_matched_component_purity"] for r in results])) if results else 0.0,
        "mean_semantic_acc": float(np.mean([r["semantic_acc"] for r in results])) if results else 0.0,
        "mean_segment_semantic_acc": float(np.mean([r["segment_semantic_acc"] for r in results])) if results else 0.0,
        "mean_num_support_edges": float(np.mean([r["num_support_edges"] for r in results])) if results else 0.0,
        "mean_num_layers": float(np.mean([r["num_layers"] for r in results])) if results else 0.0,
        "fragment_dir": str(args.fragment_dir),
        "gt_dir": str(args.gt_dir),
    }
    summary.update(task_eval.summarize_task_aware_rows(results))
    manual_rows = [r for r in results if "manual_pairwise_f1" in r]
    if manual_rows:
        summary["manual_case_count"] = len(manual_rows)
        summary["mean_manual_pairwise_precision"] = float(np.mean([r["manual_pairwise_precision"] for r in manual_rows]))
        summary["mean_manual_pairwise_recall"] = float(np.mean([r["manual_pairwise_recall"] for r in manual_rows]))
        summary["mean_manual_pairwise_f1"] = float(np.mean([r["manual_pairwise_f1"] for r in manual_rows]))
        summary["mean_manual_bcubed_f1"] = float(np.mean([r["manual_bcubed_f1"] for r in manual_rows]))
        summary["mean_manual_segment_purity"] = float(np.mean([r["manual_segment_mean_purity"] for r in manual_rows]))
        summary["mean_manual_segment_completeness"] = float(np.mean([r["manual_segment_mean_completeness"] for r in manual_rows]))
        summary["mean_manual_segment_partition_f1"] = float(np.mean([r["manual_segment_partition_f1"] for r in manual_rows]))
    return summary


def run_variant(variant_name: str, variant: dict, args) -> None:
    out_dir = Path(args.out_root) / variant_name
    out_dir.mkdir(parents=True, exist_ok=True)

    np.random.seed(int(args.seed))
    stage2_model, merge_semantic_model, label_semantic_model = fullsys.load_runtime_models(args)
    ids = list(args.uids) if args.uids else base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    results = []
    for uid in ids:
        if variant_name == "full":
            case_row, refined_map = fullsys.refine_case(uid, args, stage2_model, merge_semantic_model)
        else:
            case_row = stage2_utils.build_stage1_case_data(
                uid=uid,
                fragment_dir=args.fragment_dir,
                model_dir=args.model_dir,
                merge_semantic_model_dir=args.merge_semantic_model_dir,
                gong_prior_model_json=args.gong_prior_model_json,
                manual_edge_calibrator_json=args.manual_edge_calibrator_json,
                max_points=args.max_points,
                neighbor_ratio=args.neighbor_ratio,
                contact_eps=args.contact_eps,
                enable_stage1_bodyfirst=bool(variant.get("enable_stage1_bodyfirst", True)),
                enable_stage1_semantic_guidance=bool(variant.get("enable_stage1_semantic_guidance", True)),
                enable_stage1_learned_priors=bool(variant.get("enable_stage1_learned_priors", True)),
                enable_stage1_manual_edge_calibrator=bool(variant.get("enable_stage1_manual_edge_calibrator", True)),
                enable_stage1_learned_edge_scoring=bool(variant.get("enable_stage1_learned_edge_scoring", True)),
                enable_stage1_augmented_edges=bool(variant.get("enable_stage1_augmented_edges", True)),
                enable_stage1_bottom_dou_detach=bool(variant.get("enable_stage1_bottom_dou_detach", True)),
            )
            refined_map = apply_stage2_refinement_variant(
                comp_map=case_row["comp_map"],
                seg_points=case_row["seg_points"],
                score_map=case_row["score_map"],
                semantic_model=merge_semantic_model,
                stage2_model=stage2_model,
                variant=variant,
            )
        fullsys.save_refined_outputs(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=label_semantic_model,
            out_dir=str(out_dir),
        )
        row = fullsys.evaluate_case(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=label_semantic_model,
            gt_dir=args.gt_dir,
            gt_samples=args.gt_samples,
        )
        if row is None:
            continue
        results.append(row)
        manual_msg = ""
        if "manual_pairwise_f1" in row:
            manual_msg = f", manual_pairwise_f1={row['manual_pairwise_f1']:.4f}"
        print(
            f"[{variant_name}] {uid}: components={row['num_components']}, "
            f"mean_purity={row['mean_purity']:.4f}, semantic_acc={row['semantic_acc']:.4f}{manual_msg}"
        )

    summary = summarize_results(results, variant_name, variant, args)
    with open(out_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    with open(out_dir / "summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    with open(out_dir / "variant_config.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "variant_name": variant_name,
                "variant_label": variant["label"],
                "variant_description": variant["description"],
                "variant_config": {k: v for k, v in variant.items() if k.startswith("enable_")},
            },
            f,
            ensure_ascii=False,
            indent=2,
        )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run ablation variants for the current final post-processing system.")
    parser.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    parser.add_argument("--gt_dir", default=r"data")
    parser.add_argument("--model_dir", default=str(ROOT_DIR / "02_models" / "02_models"))
    parser.add_argument("--merge_semantic_model_dir", default=str(ROOT_DIR / "02_models" / "02_models"))
    parser.add_argument("--semantic_label_model_dir", default=fullsys.DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    parser.add_argument("--gong_prior_model_json", default=stage2_utils.DEFAULT_STAGE1_GONG_PRIOR)
    parser.add_argument("--manual_edge_calibrator_json", default=stage2_utils.DEFAULT_STAGE1_MANUAL_CALIBRATOR)
    parser.add_argument("--stage2_model_json", default=fullsys.DEFAULT_STAGE2_MODEL)
    parser.add_argument("--out_root", default=str(ROOT_DIR / "03_outputs" / "ablation_study_20260502_seed0"))
    parser.add_argument("--max_points", type=int, default=512)
    parser.add_argument("--gt_samples", type=int, default=512)
    parser.add_argument("--neighbor_ratio", type=float, default=0.08)
    parser.add_argument("--contact_eps", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--variants", nargs="*", default=list(VARIANTS.keys()))
    parser.add_argument("--uids", nargs="*", default=[])
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    unknown = [name for name in args.variants if name not in VARIANTS]
    if unknown:
        raise ValueError(f"unknown variants: {unknown}")

    out_root = Path(args.out_root)
    out_root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "variants": args.variants,
        "uids": list(args.uids),
        "fragment_dir": args.fragment_dir,
        "gt_dir": args.gt_dir,
    }
    with open(out_root / "suite_manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    for variant_name in args.variants:
        run_variant(variant_name, VARIANTS[variant_name], args)


if __name__ == "__main__":
    main()
