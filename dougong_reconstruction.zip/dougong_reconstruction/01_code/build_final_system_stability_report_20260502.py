import argparse
import csv
import json
from pathlib import Path
from statistics import mean, pstdev
from typing import Dict, Iterable, List, Tuple


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIRS = [
    ROOT / "03_outputs" / "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0",
]
DEFAULT_OUT_DIR = ROOT / "05_reports" / "final_system_stability_20260502"
SUMMARY_FIELDS = [
    "mean_segment_partition_f1",
    "mean_component_count_diff",
    "mean_semantic_acc",
    "mean_gt_bcubed_f1",
    "mean_gt_pairwise_f1",
    "mean_component_recovery_score",
    "mean_semantic_recovery_score",
    "mean_instance_f1_50",
    "mean_instance_f1_75",
    "mean_semantic_instance_f1_50",
    "mean_semantic_instance_f1_75",
    "mean_support_edge_precision",
    "mean_support_edge_recall",
    "mean_support_edge_f1",
    "mean_support_edge_f1_50",
    "mean_support_edge_f1_75",
    "mean_structure_plausibility",
    "mean_host_legality",
    "mean_gong_clean_ratio",
    "mean_upper_dou_support_ratio",
    "mean_structure_violation_rate",
]
ROW_FIELDS = [
    "segment_partition_f1",
    "component_count_diff",
    "semantic_acc",
    "gt_bcubed_f1",
    "gt_pairwise_f1",
    "component_recovery_score",
    "semantic_recovery_score",
    "instance_f1_50",
    "instance_f1_75",
    "semantic_instance_f1_50",
    "semantic_instance_f1_75",
    "support_edge_precision",
    "support_edge_recall",
    "support_edge_f1",
    "support_edge_f1_50",
    "support_edge_f1_75",
    "structure_plausibility",
    "host_legality",
    "gong_clean_ratio",
    "upper_dou_support_ratio",
    "structure_violation_rate",
]


def safe_mean(values: Iterable[float]) -> float:
    values = list(values)
    return float(mean(values)) if values else 0.0


def safe_std(values: Iterable[float]) -> float:
    values = list(values)
    return float(pstdev(values)) if len(values) > 1 else 0.0


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_output_dir(output_dir: Path) -> Tuple[Dict[str, float], Dict[str, Dict[str, float]]]:
    summary_path = output_dir / "summary.json"
    metrics_path = output_dir / "metrics.json"
    if not summary_path.exists():
        raise FileNotFoundError(f"missing summary.json: {summary_path}")
    if not metrics_path.exists():
        raise FileNotFoundError(f"missing metrics.json: {metrics_path}")

    summary = load_json(summary_path)
    metrics = load_json(metrics_path)
    if not isinstance(metrics, list):
        raise ValueError(f"invalid metrics.json: {metrics_path}")

    case_rows: Dict[str, Dict[str, float]] = {}
    for row in metrics:
        uid = str(row["uid"])
        case_rows[uid] = {
            "segment_partition_f1": float(row.get("segment_partition_f1", row.get("mean_purity", 0.0))),
            "component_count_diff": float(row.get("component_count_diff", 0.0)),
            "semantic_acc": float(row.get("semantic_acc", 0.0)),
            "gt_bcubed_f1": float(row.get("gt_bcubed_f1", 0.0)),
            "gt_pairwise_f1": float(row.get("gt_pairwise_f1", 0.0)),
            "component_recovery_score": float(row.get("component_recovery_score", 0.0)),
            "semantic_recovery_score": float(row.get("semantic_recovery_score", 0.0)),
            "instance_f1_50": float(row.get("instance_f1_50", 0.0)),
            "instance_f1_75": float(row.get("instance_f1_75", 0.0)),
            "semantic_instance_f1_50": float(row.get("semantic_instance_f1_50", 0.0)),
            "semantic_instance_f1_75": float(row.get("semantic_instance_f1_75", 0.0)),
            "support_edge_precision": float(row.get("support_edge_precision", 0.0)),
            "support_edge_recall": float(row.get("support_edge_recall", 0.0)),
            "support_edge_f1": float(row.get("support_edge_f1", 0.0)),
            "support_edge_f1_50": float(row.get("support_edge_f1_50", 0.0)),
            "support_edge_f1_75": float(row.get("support_edge_f1_75", 0.0)),
            "structure_plausibility": float(row.get("structure_plausibility", 0.0)),
            "host_legality": float(row.get("host_legality", 0.0)),
            "gong_clean_ratio": float(row.get("gong_clean_ratio", 0.0)),
            "upper_dou_support_ratio": float(row.get("upper_dou_support_ratio", 0.0)),
            "structure_violation_rate": float(row.get("structure_violation_rate", 0.0)),
        }
    return summary, case_rows


def build_summary_table(summaries: List[Dict[str, float]]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for field in SUMMARY_FIELDS:
        values = [float(s.get(field, 0.0)) for s in summaries]
        rows.append(
            {
                "metric": field,
                "mean_across_seeds": safe_mean(values),
                "std_across_seeds": safe_std(values),
                "min_across_seeds": min(values) if values else 0.0,
                "max_across_seeds": max(values) if values else 0.0,
            }
        )
    return rows


def build_case_table(seed_case_rows: List[Tuple[str, Dict[str, Dict[str, float]]]]) -> List[Dict[str, object]]:
    shared_uids = None
    for _, case_rows in seed_case_rows:
        uids = set(case_rows.keys())
        shared_uids = uids if shared_uids is None else shared_uids & uids
    shared_uids = sorted(shared_uids or [])

    rows: List[Dict[str, object]] = []
    for uid in shared_uids:
        row: Dict[str, object] = {"uid": uid}
        for field in ROW_FIELDS:
            values = [case_rows[uid][field] for _, case_rows in seed_case_rows]
            row[f"{field}_mean"] = safe_mean(values)
            row[f"{field}_std"] = safe_std(values)
        rows.append(row)
    return rows


def write_csv(path: Path, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def fmt(v: float) -> str:
    return f"{float(v):.4f}"


def build_markdown(seed_dirs: List[Path], summary_rows: List[Dict[str, object]], case_rows: List[Dict[str, object]]) -> str:
    lines: List[str] = []
    lines.append("# Final System Stability Report")
    lines.append("")
    lines.append("## Seed Runs")
    for d in seed_dirs:
        lines.append(f"- `{d.name}`")
    lines.append("")
    lines.append("## Aggregate Stability")
    lines.append("")
    lines.append("| Metric | Mean Across Seeds | Std Across Seeds | Min | Max |")
    lines.append("| --- | ---: | ---: | ---: | ---: |")
    for row in summary_rows:
        lines.append(
            f"| {row['metric']} | {fmt(row['mean_across_seeds'])} | {fmt(row['std_across_seeds'])} | "
            f"{fmt(row['min_across_seeds'])} | {fmt(row['max_across_seeds'])} |"
        )
    lines.append("")
    lines.append("## Casewise Stability")
    lines.append("")
    lines.append("| uid | partition mean | partition std | semantic mean | semantic std | structure mean | structure std |")
    lines.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    for row in case_rows[:20]:
        lines.append(
            f"| {row['uid']} | {fmt(row['segment_partition_f1_mean'])} | {fmt(row['segment_partition_f1_std'])} | "
            f"{fmt(row['semantic_acc_mean'])} | {fmt(row['semantic_acc_std'])} | "
            f"{fmt(row['structure_plausibility_mean'])} | {fmt(row['structure_plausibility_std'])} |"
        )
    lines.append("")
    lines.append("## Reading Note")
    lines.append("")
    lines.append("- Low std across seeds means the method is not overly seed-sensitive.")
    lines.append("- Casewise std is the better signal for hard cases than a single global mean.")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a multi-seed stability report for the final system.")
    parser.add_argument("--output_dirs", nargs="+", default=[str(p) for p in DEFAULT_OUTPUT_DIRS])
    parser.add_argument("--out_dir", default=str(DEFAULT_OUT_DIR))
    args = parser.parse_args()

    output_dirs = [Path(p) for p in args.output_dirs]
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    seed_summaries: List[Dict[str, float]] = []
    seed_case_rows: List[Tuple[str, Dict[str, Dict[str, float]]]] = []
    for output_dir in output_dirs:
        summary, case_rows = load_output_dir(output_dir)
        seed_summaries.append(summary)
        seed_case_rows.append((output_dir.name, case_rows))

    summary_rows = build_summary_table(seed_summaries)
    case_rows = build_case_table(seed_case_rows)

    write_csv(
        out_dir / "final_system_seed_stability_summary.csv",
        summary_rows,
        ["metric", "mean_across_seeds", "std_across_seeds", "min_across_seeds", "max_across_seeds"],
    )
    write_csv(
        out_dir / "final_system_seed_stability_casewise.csv",
        case_rows,
        [
            "uid",
            "segment_partition_f1_mean",
            "segment_partition_f1_std",
            "component_count_diff_mean",
            "component_count_diff_std",
            "semantic_acc_mean",
            "semantic_acc_std",
            "gt_bcubed_f1_mean",
            "gt_bcubed_f1_std",
            "gt_pairwise_f1_mean",
            "gt_pairwise_f1_std",
            "component_recovery_score_mean",
            "component_recovery_score_std",
            "semantic_recovery_score_mean",
            "semantic_recovery_score_std",
            "instance_f1_50_mean",
            "instance_f1_50_std",
            "instance_f1_75_mean",
            "instance_f1_75_std",
            "semantic_instance_f1_50_mean",
            "semantic_instance_f1_50_std",
            "semantic_instance_f1_75_mean",
            "semantic_instance_f1_75_std",
            "support_edge_precision_mean",
            "support_edge_precision_std",
            "support_edge_recall_mean",
            "support_edge_recall_std",
            "support_edge_f1_mean",
            "support_edge_f1_std",
            "support_edge_f1_50_mean",
            "support_edge_f1_50_std",
            "support_edge_f1_75_mean",
            "support_edge_f1_75_std",
            "structure_plausibility_mean",
            "structure_plausibility_std",
            "host_legality_mean",
            "host_legality_std",
            "gong_clean_ratio_mean",
            "gong_clean_ratio_std",
            "upper_dou_support_ratio_mean",
            "upper_dou_support_ratio_std",
            "structure_violation_rate_mean",
            "structure_violation_rate_std",
        ],
    )
    (out_dir / "final_system_seed_stability_report_zh.md").write_text(
        build_markdown(output_dirs, summary_rows, case_rows), encoding="utf-8"
    )
    (out_dir / "final_system_seed_stability_summary.json").write_text(
        json.dumps(
            {
                "seed_dirs": [str(p) for p in output_dirs],
                "summary_rows": summary_rows,
                "case_rows": case_rows,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
