r"""
Dougong role-aware template refinement v7 xy-fix experiment.

This branch preserves the v7 pipeline but repairs the planar body selection so
that x- and y-oriented gong proposals are scored independently instead of
sharing nearly equivalent planar features.
"""

import argparse
import json
import os
import sys
from itertools import combinations
from typing import Dict, List, Set, Tuple, Optional

import numpy as np

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import dougong_refine_v4 as base


Segment = base.Segment


PROPOSAL_FEATURE_NAMES = [
    "diag_rel",
    "z_norm",
    "horizontal_elongation",
    "height_ratio",
    "vertical_ratio",
    "num_segments_norm",
    "end_lift_rel",
    "end_sym_rel",
    "end_width_asym",
    "bottom_std",
    "bottom_range",
    "symmetry_score",
    "gong_semantic_bonus",
    "dou_semantic_bonus",
    "body_score",
    "top_count",
    "left_present",
    "right_present",
    "center_present",
    "mean_top_attach",
    "mean_xy_overlap",
    "mean_long_overlap",
    "mean_bottom_penalty",
    "left_right_along_gap",
    "left_right_z_gap",
    "shape_penalty",
    "downward_penalty",
]


# ============================================================
# Basic helpers
# ============================================================

def singleton_component_map(segments: List[Segment]) -> Dict[int, int]:
    return {s.seg_id: s.seg_id for s in segments}


def safe_norm(v: np.ndarray, eps: float = 1e-8) -> float:
    return float(max(np.linalg.norm(v), eps))


def component_diag_rel(comp: Dict, global_ctx: Dict) -> float:
    return float(comp["bbox_diag"] / max(float(global_ctx["global_diag"][0]), 1e-8))


def component_z_norm(comp: Dict, global_ctx: Dict) -> float:
    global_min = global_ctx["global_min"]
    global_height = max(float(global_ctx["global_height"][0]), 1e-8)
    return float((comp["centroid"][2] - global_min[2]) / global_height)


def component_axis_alignment(comp: Dict, axis_xy: np.ndarray) -> float:
    axis = np.asarray(axis_xy, dtype=np.float32)
    norm = safe_norm(axis)
    axis = axis / norm
    return float(abs(np.dot(comp["axis_xy"], axis)))


def orthogonal_axis_xy(axis_xy: np.ndarray) -> np.ndarray:
    axis = np.asarray(axis_xy, dtype=np.float32)
    return np.array([-axis[1], axis[0], 0.0], dtype=np.float32)


def canonical_planar_axes() -> List[Tuple[str, np.ndarray]]:
    return [
        ("x", np.array([1.0, 0.0, 0.0], dtype=np.float32)),
        ("y", np.array([0.0, 1.0, 0.0], dtype=np.float32)),
    ]


def best_planar_alignment(comp: Dict, primary_axis: np.ndarray) -> float:
    primary = np.asarray(primary_axis, dtype=np.float32)
    ortho = orthogonal_axis_xy(primary)
    return float(max(component_axis_alignment(comp, primary), component_axis_alignment(comp, ortho)))


def best_planar_elongation(comp: Dict, primary_axis: np.ndarray) -> float:
    primary = np.asarray(primary_axis, dtype=np.float32)
    ortho = orthogonal_axis_xy(primary)
    points = comp["points"] - comp["centroid"]

    def axis_elong(axis_xy: np.ndarray) -> float:
        axis = np.asarray(axis_xy, dtype=np.float32)
        axis = axis / safe_norm(axis)
        lat = orthogonal_axis_xy(axis)
        along = points @ axis
        lateral = points @ lat
        along_span = max(float(along.max() - along.min()), 1e-8)
        lateral_span = max(float(lateral.max() - lateral.min()), 1e-8)
        return float(along_span / lateral_span)

    return float(max(axis_elong(primary), axis_elong(ortho)))


def best_planar_height_ratio(comp: Dict, primary_axis: np.ndarray) -> float:
    primary = np.asarray(primary_axis, dtype=np.float32)
    ortho = orthogonal_axis_xy(primary)
    points = comp["points"] - comp["centroid"]
    z_vals = points[:, 2]
    z_span = max(float(z_vals.max() - z_vals.min()), 1e-8)

    def axis_height_ratio(axis_xy: np.ndarray) -> float:
        axis = np.asarray(axis_xy, dtype=np.float32)
        axis = axis / safe_norm(axis)
        along = points @ axis
        along_span = max(float(along.max() - along.min()), 1e-8)
        return float(z_span / along_span)

    return float(min(axis_height_ratio(primary), axis_height_ratio(ortho)))


def axis_elongation(comp: Dict, axis_xy: np.ndarray) -> float:
    axis = np.asarray(axis_xy, dtype=np.float32)
    axis = axis / safe_norm(axis)
    lat = orthogonal_axis_xy(axis)
    points = comp["points"] - comp["centroid"]
    along = points @ axis
    lateral = points @ lat
    along_span = max(float(along.max() - along.min()), 1e-8)
    lateral_span = max(float(lateral.max() - lateral.min()), 1e-8)
    return float(along_span / lateral_span)


def axis_height_ratio(comp: Dict, axis_xy: np.ndarray) -> float:
    axis = np.asarray(axis_xy, dtype=np.float32)
    axis = axis / safe_norm(axis)
    points = comp["points"] - comp["centroid"]
    along = points @ axis
    z_vals = points[:, 2]
    along_span = max(float(along.max() - along.min()), 1e-8)
    z_span = max(float(z_vals.max() - z_vals.min()), 1e-8)
    return float(z_span / along_span)


def component_extents(comp: Dict) -> np.ndarray:
    return (comp["bbox_max"] - comp["bbox_min"]).astype(np.float32)


def component_vertical_elongation(comp: Dict) -> float:
    ext = component_extents(comp)
    xy_span = max(float(ext[0]), float(ext[1]), 1e-8)
    return float(float(ext[2]) / xy_span)


def component_xy_cross_ratio(comp: Dict) -> float:
    ext = component_extents(comp)
    xy_max = max(float(ext[0]), float(ext[1]), 1e-8)
    xy_min = min(float(ext[0]), float(ext[1]))
    return float(xy_min / xy_max)


def bbox_xy_overlap_ratio(a_min: np.ndarray, a_max: np.ndarray, b_min: np.ndarray, b_max: np.ndarray) -> float:
    ix = max(0.0, min(float(a_max[0]), float(b_max[0])) - max(float(a_min[0]), float(b_min[0])))
    iy = max(0.0, min(float(a_max[1]), float(b_max[1])) - max(float(a_min[1]), float(b_min[1])))
    inter = ix * iy
    area_a = max(float(a_max[0] - a_min[0]), 0.0) * max(float(a_max[1] - a_min[1]), 0.0)
    area_b = max(float(b_max[0] - b_min[0]), 0.0) * max(float(b_max[1] - b_min[1]), 0.0)
    denom = max(min(area_a, area_b), 1e-8)
    return float(inter / denom)


def interval_overlap_ratio(a0: float, a1: float, b0: float, b1: float) -> float:
    lo = max(min(a0, a1), min(b0, b1))
    hi = min(max(a0, a1), max(b0, b1))
    inter = max(0.0, hi - lo)
    len_a = max(abs(a1 - a0), 1e-8)
    len_b = max(abs(b1 - b0), 1e-8)
    return float(inter / max(min(len_a, len_b), 1e-8))


def component_axis_interval(comp: Dict, axis_xy: np.ndarray) -> Tuple[float, float]:
    axis = np.asarray(axis_xy, dtype=np.float32)
    axis = axis / safe_norm(axis)
    proj = comp["points"] @ axis
    return float(proj.min()), float(proj.max())


def interval_gap_1d(a0: float, a1: float, b0: float, b1: float) -> float:
    return float(max(0.0, max(b0 - a1, a0 - b1)))


def component_lateral_overlap_ratio(comp_a: Dict, comp_b: Dict, primary_axis: np.ndarray) -> float:
    lateral_axis = orthogonal_axis_xy(primary_axis)
    a0, a1 = component_axis_interval(comp_a, lateral_axis)
    b0, b1 = component_axis_interval(comp_b, lateral_axis)
    return interval_overlap_ratio(a0, a1, b0, b1)


def cluster_parallel_lanes(
    comp_ids: List[int],
    comps: Dict[int, Dict],
    primary_axis: np.ndarray,
    global_ctx: Dict,
    lane_gap_ratio: float = 0.04,
) -> List[List[int]]:
    if not comp_ids:
        return []

    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    lateral_axis = orthogonal_axis_xy(primary_axis)
    lane_gap = lane_gap_ratio * gd

    items = []
    for cid in comp_ids:
        c0, c1 = component_axis_interval(comps[cid], lateral_axis)
        center = 0.5 * (c0 + c1)
        items.append((center, cid, c0, c1))
    items.sort()

    lanes: List[List[int]] = []
    current_ids: List[int] = []
    current_lo = None
    current_hi = None

    for _, cid, c0, c1 in items:
        if current_lo is None:
            current_ids = [cid]
            current_lo = c0
            current_hi = c1
            continue

        gap = interval_gap_1d(current_lo, current_hi, c0, c1)
        if gap <= lane_gap:
            current_ids.append(cid)
            current_lo = min(current_lo, c0)
            current_hi = max(current_hi, c1)
        else:
            lanes.append(sorted(current_ids))
            current_ids = [cid]
            current_lo = c0
            current_hi = c1

    if current_ids:
        lanes.append(sorted(current_ids))

    return lanes


def upper_layer_candidates_for_lane(
    lane_ids: List[int],
    upper_layer_ids: List[int],
    comps: Dict[int, Dict],
    primary_axis: np.ndarray,
    global_ctx: Dict,
) -> List[int]:
    if not lane_ids or not upper_layer_ids:
        return []

    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    lateral_axis = orthogonal_axis_xy(primary_axis)
    lane_lo = min(component_axis_interval(comps[cid], lateral_axis)[0] for cid in lane_ids)
    lane_hi = max(component_axis_interval(comps[cid], lateral_axis)[1] for cid in lane_ids)

    selected: List[int] = []
    for cid in upper_layer_ids:
        cand = comps[cid]
        c0, c1 = component_axis_interval(cand, lateral_axis)
        gap = interval_gap_1d(lane_lo, lane_hi, c0, c1)
        overlap = interval_overlap_ratio(lane_lo, lane_hi, c0, c1)
        if gap <= 0.05 * gd or overlap >= 0.18:
            selected.append(cid)
    return sorted(selected)


def build_component_from_seg_ids(seg_ids: List[int], seg_by_id: Dict[int, Segment]) -> Dict:
    tmp_segments = [seg_by_id[sid] for sid in seg_ids]
    tmp_map = {sid: 0 for sid in seg_ids}
    return base.build_components_from_map(tmp_map, tmp_segments)[0]


def load_semantic_model_with_roles(model_dir: str) -> Dict:
    candidates = [
        os.path.join(model_dir, "semantic_prototypes_with_roles.json"),
        os.path.join(model_dir, "semantic_prototypes.json"),
    ]
    for path in candidates:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            try:
                return base.normalize_semantic_model(data)
            except Exception:
                return data
    return {}


def load_label_semantic_model(label_model_dir: str, fallback_model_dir: str) -> Dict:
    target_dir = label_model_dir if label_model_dir else fallback_model_dir
    model = load_semantic_model_with_roles(target_dir)
    if not model:
        raise FileNotFoundError(
            "semantic label model not found. Expected semantic_prototypes_with_roles.json "
            f"or semantic_prototypes.json in: {target_dir}"
        )
    return model


def load_merge_semantic_model(merge_model_dir: str, fallback_model_dir: str) -> Dict:
    target_dir = merge_model_dir if merge_model_dir else fallback_model_dir
    model = load_semantic_model_with_roles(target_dir)
    if not model:
        raise FileNotFoundError(
            "merge semantic model not found. Expected semantic_prototypes_with_roles.json "
            f"or semantic_prototypes.json in: {target_dir}"
        )
    return model


def load_gong_prior_models(gong_prior_model_json: str, fallback_model_dir: str) -> Dict:
    candidates = []
    if gong_prior_model_json:
        candidates.append(gong_prior_model_json)
    candidates.append(os.path.join(fallback_model_dir, "gong_prior_models.json"))
    for path in candidates:
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def load_manual_edge_calibrator(manual_edge_calibrator_json: str, fallback_model_dir: str) -> Dict:
    candidates = []
    if manual_edge_calibrator_json:
        candidates.append(manual_edge_calibrator_json)
    candidates.append(os.path.join(fallback_model_dir, "manual_edge_calibrator.json"))
    for path in candidates:
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def predict_binary_logit(features: np.ndarray, model_item: Dict) -> float:
    if not model_item:
        return 0.0
    x = np.asarray(features, dtype=np.float32)
    mean = np.asarray(model_item.get("standardize_mean", []), dtype=np.float32)
    std = np.asarray(model_item.get("standardize_std", []), dtype=np.float32)
    w = np.asarray(model_item.get("weights", []), dtype=np.float32)
    b = float(model_item.get("bias", 0.0))
    if mean.shape[0] != x.shape[0] or std.shape[0] != x.shape[0] or w.shape[0] != x.shape[0]:
        return 0.0
    std = std.copy()
    std[std < 1e-6] = 1.0
    x_norm = (x - mean) / std
    return float(x_norm @ w + b)


def ensure_required_file(path: str, message: str):
    if not os.path.exists(path):
        raise FileNotFoundError(f"{message}: {path}")


def load_manual_grouping_map(uid: str, manual_group_dir: str, segments: List[Segment]) -> Dict[int, int]:
    if not manual_group_dir:
        return {}
    path = os.path.join(manual_group_dir, f"{uid}_groups_draft.json")
    if not os.path.exists(path):
        return {}

    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    groups = data.get("groups", {})
    if not groups:
        return {}

    manual_map: Dict[int, int] = {}
    seen: Dict[int, str] = {}
    for cid, group_name in enumerate(sorted(groups.keys())):
        for seg_id in groups[group_name]:
            seg_id = int(seg_id)
            if seg_id in seen:
                raise ValueError(
                    f"manual grouping for {uid} duplicates seg_id {seg_id} in "
                    f"{seen[seg_id]} and {group_name}"
                )
            seen[seg_id] = str(group_name)
            manual_map[seg_id] = cid

    expected_ids = {int(s.seg_id) for s in segments}
    missing = sorted(expected_ids - set(manual_map.keys()))
    extra = sorted(set(manual_map.keys()) - expected_ids)
    if missing or extra:
        raise ValueError(
            f"manual grouping for {uid} mismatches current segments: "
            f"missing={missing}, extra={extra}"
        )
    return base.relabel_components(manual_map)


# ============================================================
# Semantics helpers
# ============================================================

def semantic_margin(comp: Dict, semantic_model: Dict, cls_name: str, others: List[str]) -> float:
    if not semantic_model:
        return 0.0
    descriptors, _, _ = base.build_component_descriptors({0: comp["points"]})
    if 0 not in descriptors:
        return 0.0
    scores = base.semantic_scores_from_descriptor(descriptors[0], semantic_model)
    target = float(scores.get(cls_name, 1e9))
    alt = min(float(scores.get(x, 1e9)) for x in others)
    return float(np.clip(alt - target, -4.0, 4.0))


def gong_semantic_bonus(comp: Dict, semantic_model: Dict) -> float:
    return semantic_margin(comp, semantic_model, "gong", ["fang", "chuan", "ang", "dou"])


def dou_semantic_bonus(comp: Dict, semantic_model: Dict) -> float:
    return semantic_margin(comp, semantic_model, "dou", ["gong", "fang", "chuan", "ang"])


# ============================================================
# Geometry descriptors
# ============================================================

def component_bottom_profile_stats(comp: Dict, global_ctx: Dict, num_bins: int = 5) -> Tuple[float, float]:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    centered = comp["points"] - comp["centroid"]
    long_coords = centered @ comp["axis_xy"]
    z_coords = centered[:, 2]
    if len(long_coords) < 40:
        return 1.0, 1.0
    edges = np.linspace(float(long_coords.min()), float(long_coords.max()), num_bins + 1)
    bottoms: List[float] = []
    for i in range(num_bins):
        if i == num_bins - 1:
            mask = (long_coords >= edges[i]) & (long_coords <= edges[i + 1])
        else:
            mask = (long_coords >= edges[i]) & (long_coords < edges[i + 1])
        if int(mask.sum()) < 8:
            continue
        bottoms.append(float(np.percentile(z_coords[mask], 8)))
    if len(bottoms) < 3:
        return 1.0, 1.0
    bottoms = np.asarray(bottoms, dtype=np.float32)
    return float(np.std(bottoms) / gh), float((bottoms.max() - bottoms.min()) / gh)


def component_side_symmetry_score(comp: Dict, global_ctx: Dict) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    end_sym = float(comp.get("end_symmetry", 1.0) / gh)
    width_asym = float(comp.get("end_width_asym", 1.0))
    score = (
        0.6 * max(0.0, 0.12 - end_sym) / 0.12
        + 0.4 * max(0.0, 0.40 - width_asym) / 0.40
    )
    return float(score)


def body_shape_preservation_penalty(seed: Dict, merged: Dict, global_ctx: Dict) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    seed_bottom_std, seed_bottom_range = component_bottom_profile_stats(seed, global_ctx)
    merged_bottom_std, merged_bottom_range = component_bottom_profile_stats(merged, global_ctx)
    seed_sym = component_side_symmetry_score(seed, global_ctx)
    merged_sym = component_side_symmetry_score(merged, global_ctx)
    down_expand = max(0.0, float(seed["bbox_min"][2] - merged["bbox_min"][2])) / gh

    penalty = 0.0
    penalty += 5.0 * down_expand
    penalty += 6.0 * max(0.0, merged_bottom_std - seed_bottom_std - 0.010)
    penalty += 6.0 * max(0.0, merged_bottom_range - seed_bottom_range - 0.020)
    penalty += 0.75 * max(0.0, seed_sym - merged_sym - 0.12)
    return float(penalty)


def build_learned_template_feature_vector(
    comp: Dict,
    global_ctx: Dict,
    semantic_model: Dict,
) -> np.ndarray:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    ext = component_extents(comp)
    vertical_ratio = float(ext[2] / gh)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    symmetry = component_side_symmetry_score(comp, global_ctx)
    return np.asarray([
        component_diag_rel(comp, global_ctx),
        component_z_norm(comp, global_ctx),
        float(comp.get("horizontal_elongation", comp.get("elongation", 1.0))),
        float(comp.get("height_ratio", 1.0)),
        vertical_ratio,
        float(len(comp.get("segment_ids", []))) / 8.0,
        float(comp.get("end_lift_min", 0.0) / gh),
        float(comp.get("end_symmetry", 0.0) / gh),
        float(comp.get("end_width_asym", 1.0)),
        float(bottom_std),
        float(bottom_range),
        float(symmetry),
        float(gong_semantic_bonus(comp, semantic_model)),
        float(dou_semantic_bonus(comp, semantic_model)),
    ], dtype=np.float32)


def build_learned_attachment_feature_vector(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    semantic_model: Dict,
) -> np.ndarray:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(cand, global_ctx)
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
    height_ratio = float(cand.get("height_ratio", 1.0))
    align_seed = component_axis_alignment(cand, seed["axis_xy"])
    align_primary = component_axis_alignment(cand, primary_axis)
    vertical_ratio = float((cand["bbox_max"][2] - cand["bbox_min"][2]) / gh)
    return np.asarray([
        rel["along"],
        rel["lateral"],
        rel["z_delta"],
        rel["gap"],
        rel["top_gap"],
        rel["bottom_gap"],
        rel["long_overhang"],
        rel["lateral_overhang"],
        rel["xy_overlap"],
        rel["long_overlap"],
        rel["top_attach"],
        rel["bottom_attach"],
        rel["above_seed"],
        rel["below_seed"],
        rel["above_seed_top"],
        rel["below_seed_bottom"],
        diag_rel,
        horiz_elong,
        height_ratio,
        align_seed,
        align_primary,
        vertical_ratio,
        float(dou_semantic_bonus(cand, semantic_model)),
    ], dtype=np.float32)


def learned_template_logit(
    comp: Dict,
    global_ctx: Dict,
    semantic_model: Dict,
    learned_priors: Dict = None,
) -> float:
    if not learned_priors:
        return 0.0
    item = learned_priors.get("gong_template_classifier", {})
    if not item:
        return 0.0
    feats = build_learned_template_feature_vector(comp, global_ctx, semantic_model)
    return predict_binary_logit(feats, item)


def learned_attachment_logit(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    semantic_model: Dict,
    learned_priors: Dict = None,
) -> float:
    if not learned_priors:
        return 0.0
    item = learned_priors.get("upper_attachment_classifier", {})
    if not item:
        return 0.0
    feats = build_learned_attachment_feature_vector(
        seed=seed,
        cand=cand,
        rel=rel,
        global_ctx=global_ctx,
        primary_axis=primary_axis,
        semantic_model=semantic_model,
    )
    return predict_binary_logit(feats, item)


def learned_body_extension_logit(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    semantic_model: Dict,
    learned_priors: Dict = None,
) -> float:
    if not learned_priors:
        return 0.0
    item = learned_priors.get("body_extension_classifier", {})
    if not item:
        return 0.0
    feats = build_learned_attachment_feature_vector(
        seed=seed,
        cand=cand,
        rel=rel,
        global_ctx=global_ctx,
        primary_axis=primary_axis,
        semantic_model=semantic_model,
    )
    return predict_binary_logit(feats, item)


def build_learned_proposal_feature_vector(
    merged_comp: Dict,
    body_comp: Dict,
    body_score: float,
    upper_clusters: Dict[str, Tuple[List[int], Dict, float]],
    rel_map: Dict[int, Dict[str, float]],
    global_ctx: Dict,
    semantic_model: Dict,
    original_seed: Dict,
) -> np.ndarray:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    ext = merged_comp["bbox_max"] - merged_comp["bbox_min"]
    vertical_ratio = float(ext[2] / gh)
    bottom_std, bottom_range = component_bottom_profile_stats(merged_comp, global_ctx)
    symmetry = component_side_symmetry_score(merged_comp, global_ctx)
    top_ids = [sid for slot_data in upper_clusters.values() for sid in slot_data[0]]
    top_count = float(sum(1 for slot in ["left", "right", "center"] if slot in upper_clusters))
    if top_ids:
        mean_top_attach = float(np.mean([rel_map[sid]["top_attach"] for sid in top_ids]))
        mean_xy_overlap = float(np.mean([rel_map[sid]["xy_overlap"] for sid in top_ids]))
        mean_long_overlap = float(np.mean([rel_map[sid]["long_overlap"] for sid in top_ids]))
        mean_bottom_penalty = float(np.mean([
            rel_map[sid]["bottom_attach"] + rel_map[sid]["below_seed_bottom"] for sid in top_ids
        ]))
    else:
        mean_top_attach = 0.0
        mean_xy_overlap = 0.0
        mean_long_overlap = 0.0
        mean_bottom_penalty = 0.0
    if "left" in upper_clusters and "right" in upper_clusters:
        l_sid = upper_clusters["left"][0][0]
        r_sid = upper_clusters["right"][0][0]
        left_right_along_gap = abs(abs(rel_map[l_sid]["along"]) - abs(rel_map[r_sid]["along"]))
        left_right_z_gap = abs(rel_map[l_sid]["z_delta"] - rel_map[r_sid]["z_delta"])
    else:
        left_right_along_gap = 1.0
        left_right_z_gap = 1.0
    shape_penalty = float(body_shape_preservation_penalty(original_seed, merged_comp, global_ctx))
    downward_penalty = float(merged_downward_absorption_penalty(original_seed, merged_comp, global_ctx))
    return np.asarray([
        component_diag_rel(merged_comp, global_ctx),
        component_z_norm(merged_comp, global_ctx),
        float(merged_comp.get("horizontal_elongation", merged_comp.get("elongation", 1.0))),
        float(merged_comp.get("height_ratio", 1.0)),
        vertical_ratio,
        float(len(merged_comp.get("segment_ids", []))) / 8.0,
        float(merged_comp.get("end_lift_min", 0.0) / gh),
        float(merged_comp.get("end_symmetry", 0.0) / gh),
        float(merged_comp.get("end_width_asym", 1.0)),
        float(bottom_std),
        float(bottom_range),
        float(symmetry),
        float(gong_semantic_bonus(merged_comp, semantic_model)),
        float(dou_semantic_bonus(merged_comp, semantic_model)),
        float(body_score),
        top_count,
        1.0 if "left" in upper_clusters else 0.0,
        1.0 if "right" in upper_clusters else 0.0,
        1.0 if "center" in upper_clusters else 0.0,
        mean_top_attach,
        mean_xy_overlap,
        mean_long_overlap,
        mean_bottom_penalty,
        float(left_right_along_gap),
        float(left_right_z_gap),
        shape_penalty,
        downward_penalty,
    ], dtype=np.float32)


def learned_proposal_logit(
    merged_comp: Dict,
    body_comp: Dict,
    body_score: float,
    upper_clusters: Dict[str, Tuple[List[int], Dict, float]],
    rel_map: Dict[int, Dict[str, float]],
    global_ctx: Dict,
    semantic_model: Dict,
    original_seed: Dict,
    learned_priors: Dict = None,
) -> float:
    if not learned_priors:
        return 0.0
    item = learned_priors.get("gong_proposal_classifier", {})
    if not item:
        return 0.0
    feats = build_learned_proposal_feature_vector(
        merged_comp=merged_comp,
        body_comp=body_comp,
        body_score=body_score,
        upper_clusters=upper_clusters,
        rel_map=rel_map,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
        original_seed=original_seed,
    )
    return predict_binary_logit(feats, item)


def learned_proposal_rank_utility(
    merged_comp: Dict,
    body_comp: Dict,
    body_score: float,
    upper_clusters: Dict[str, Tuple[List[int], Dict, float]],
    rel_map: Dict[int, Dict[str, float]],
    global_ctx: Dict,
    semantic_model: Dict,
    original_seed: Dict,
    learned_priors: Dict = None,
) -> float:
    if not learned_priors:
        return 0.0
    item = learned_priors.get("gong_proposal_ranker", {})
    if not item:
        return 0.0
    feats = build_learned_proposal_feature_vector(
        merged_comp=merged_comp,
        body_comp=body_comp,
        body_score=body_score,
        upper_clusters=upper_clusters,
        rel_map=rel_map,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
        original_seed=original_seed,
    )
    mean = np.asarray(item.get("candidate_mean", [0.0] * len(feats)), dtype=np.float32)
    std = np.asarray(item.get("candidate_std", [1.0] * len(feats)), dtype=np.float32)
    std[std < 1e-6] = 1.0
    w = np.asarray(item.get("weights", [0.0] * len(feats)), dtype=np.float32)
    b = float(item.get("bias", 0.0))
    if mean.shape[0] != feats.shape[0] or std.shape[0] != feats.shape[0] or w.shape[0] != feats.shape[0]:
        return 0.0
    x_norm = (feats - mean) / std
    return float(x_norm @ w + b)


def upper_dou_hard_gate(seed: Dict, cand: Dict, rel: Dict[str, float], global_ctx: Dict) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(cand, global_ctx)
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
    height_ratio = float(cand.get("height_ratio", 1.0))
    vertical_ratio = float((cand["bbox_max"][2] - cand["bbox_min"][2]) / gh)
    same_layer_topish = bool(rel.get("same_layer_topish", 0.0) > 0.5)

    if is_base_dou_segment(cand, global_ctx):
        return False
    if rel["below_seed_bottom"] > 0.25 or rel["bottom_attach"] > 0.30:
        return False
    if rel["above_seed"] < 0.5 and rel["above_seed_top"] < 0.5 and not same_layer_topish:
        return False
    if not same_layer_topish and float(cand["bbox_min"][2]) < float(seed["bbox_min"][2]) + 0.10 * gh:
        return False
    if same_layer_topish and float(seed["bbox_min"][2] - cand["bbox_min"][2]) / gh > 0.08:
        return False
    if rel["gap"] > 0.24:
        return False
    if rel["lateral_overhang"] > 0.16 or rel["long_overhang"] > 0.22:
        return False
    if diag_rel > 0.22 or horiz_elong > 3.8 or vertical_ratio > 0.24:
        return False
    if height_ratio > 2.5:
        return False
    return True


def gong_body_structural_hard_gate(comp: Dict, global_ctx: Dict) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    vertical_ratio = float((comp["bbox_max"][2] - comp["bbox_min"][2]) / gh)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    symmetry = component_side_symmetry_score(comp, global_ctx)

    if diag_rel < 0.18 or horiz_elong < 2.55:
        return False
    if height_ratio > 0.54 or vertical_ratio > 0.24:
        return False
    if bottom_std > 0.085 or bottom_range > 0.115:
        return False
    if symmetry < 0.14:
        return False
    return True


def gong_body_structural_score(comp: Dict, global_ctx: Dict) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    vertical_ratio = float((comp["bbox_max"][2] - comp["bbox_min"][2]) / gh)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    symmetry = component_side_symmetry_score(comp, global_ctx)

    score = 0.0
    score += 1.0 * max(0.0, min(diag_rel / 0.26, 1.0))
    score += 1.3 * max(0.0, min(horiz_elong / 4.6, 1.0))
    score += 1.1 * max(0.0, 0.62 - height_ratio) / 0.62
    score += 1.0 * max(0.0, 0.24 - vertical_ratio) / 0.24
    score += 1.1 * max(0.0, 0.070 - bottom_std) / 0.070
    score += 0.9 * max(0.0, 0.100 - bottom_range) / 0.100
    # Raw gong bodies in refreshed fragment are often not fully symmetric yet.
    score += 0.35 * max(0.0, symmetry)

    if diag_rel < 0.14:
        score -= 1.6
    if horiz_elong < 2.15:
        score -= 2.0
    if height_ratio > 0.70:
        score -= 1.4
    if vertical_ratio > 0.30:
        score -= 1.4
    if bottom_std > 0.12:
        score -= 1.4
    if bottom_range > 0.16:
        score -= 1.0
    if symmetry < 0.04:
        score -= 0.35
    return float(score)


def upper_dou_structural_law(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    slot: str = "",
) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    same_layer_topish = bool(rel.get("same_layer_topish", 0.0) > 0.5)

    if not upper_dou_hard_gate(seed, cand, rel, global_ctx):
        return False
    if rel["below_seed_bottom"] > 0.22 or rel["bottom_attach"] > 0.24:
        return False
    if rel["top_support"] < 0.12:
        return False
    if rel["above_seed_top"] < 0.5 and not same_layer_topish:
        return False
    if float(cand["bbox_min"][2]) < float(seed["bbox_min"][2]) + 0.02 * gh:
        return False
    if slot == "center":
        if rel["centerish"] < 0.5 or rel["xy_overlap"] < 0.18:
            return False
    elif slot in {"left", "right"}:
        if rel["near_end"] < 0.5 and abs(rel["along"]) < 0.10:
            return False
    return True


# ============================================================
# Basic shape heuristics
# ============================================================

def is_blocky_dou_segment(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    z_norm = component_z_norm(comp, global_ctx)
    return bool(
        diag_rel <= 0.18
        and horiz_elong <= 3.1
        and 0.42 <= height_ratio <= 2.2
        and z_norm >= 0.08
    )


def is_base_dou_segment(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    z_norm = component_z_norm(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    return bool(
        diag_rel <= 0.20
        and z_norm <= 0.14
        and horiz_elong <= 2.8
        and height_ratio >= 0.40
    )


def irregular_upper_dou_context_score(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(cand, global_ctx)
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
    height_ratio = float(cand.get("height_ratio", 1.0))
    vertical_ratio = float((cand["bbox_max"][2] - cand["bbox_min"][2]) / gh)

    if is_base_dou_segment(cand, global_ctx):
        return -1e9
    if diag_rel > 0.20 or horiz_elong > 4.6 or vertical_ratio > 0.30:
        return -1e9
    if rel["gap"] > 0.18 or rel["lateral_overhang"] > 0.12 or rel["long_overhang"] > 0.18:
        return -1e9
    if rel["below_seed_bottom"] > 0.18 or rel["bottom_attach"] > 0.18:
        return -1e9
    if rel["top_support"] < 0.22:
        return -1e9
    if rel["same_layer_topish"] < 0.5 and rel["above_seed_top"] < 0.5:
        return -1e9

    score = 0.0
    score += 1.2 * rel["top_support"]
    score += 0.9 * rel["xy_overlap"]
    score += 0.7 * rel["long_overlap"]
    score += 0.5 * rel["same_layer_topish"]
    score += 0.4 * rel["above_seed_top"]
    score += 0.7 * max(0.0, 0.18 - diag_rel) / 0.18
    score += 0.4 * max(0.0, 0.30 - vertical_ratio) / 0.30
    score += 0.4 * max(0.0, 0.16 - rel["gap"]) / 0.16
    score += 0.3 * max(0.0, 0.15 - rel["lateral_overhang"]) / 0.15
    score -= 0.35 * max(0.0, horiz_elong - 3.4) / 1.2
    score -= 0.30 * max(0.0, 0.35 - height_ratio) / 0.35
    return float(score)


def is_gong_body_seed(comp: Dict, primary_axis: np.ndarray, global_ctx: Dict) -> bool:
    return bool(score_body_candidate(comp, primary_axis, global_ctx, None) > 4.6)


def is_z_gong_body_seed(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    z_norm = component_z_norm(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    vert_elong = component_vertical_elongation(comp)
    cross_ratio = component_xy_cross_ratio(comp)
    return bool(
        not is_base_dou_segment(comp, global_ctx)
        and 0.30 <= diag_rel <= 0.72
        and z_norm >= 0.14
        and horiz_elong <= 1.9
        and height_ratio >= 3.0
        and vert_elong >= 4.2
        and cross_ratio >= 0.72
    )


def infer_primary_axis(comps: Dict[int, Dict], global_ctx: Dict) -> np.ndarray:
    candidates = []
    for comp in comps.values():
        diag_rel = component_diag_rel(comp, global_ctx)
        horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
        height_ratio = float(comp.get("height_ratio", 1.0))
        if diag_rel >= 0.10 and horiz_elong >= 2.3 and height_ratio <= 0.55:
            candidates.append(comp)
    if not candidates:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)

    accum = np.zeros(3, dtype=np.float32)
    for comp in sorted(candidates, key=lambda c: c["bbox_diag"], reverse=True):
        axis = comp["axis_xy"].astype(np.float32)
        if safe_norm(accum) > 1e-8 and float(np.dot(accum, axis)) < 0.0:
            axis = -axis
        accum += axis * float(comp["bbox_diag"])

    norm = safe_norm(accum)
    if norm < 1e-8:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    return (accum / norm).astype(np.float32)


def cluster_layers(comp_ids: List[int], comps: Dict[int, Dict], global_ctx: Dict, gap_ratio: float = 0.11) -> List[List[int]]:
    ordered = sorted(comp_ids, key=lambda cid: comps[cid]["centroid"][2])
    layers: List[List[int]] = []
    current: List[int] = []
    mean_z = None
    gh = max(float(global_ctx["global_height"][0]), 1e-8)

    for cid in ordered:
        z = float(comps[cid]["centroid"][2])
        if mean_z is None or abs(z - mean_z) / gh <= gap_ratio:
            current.append(cid)
            mean_z = float(np.mean([float(comps[x]["centroid"][2]) for x in current]))
        else:
            layers.append(current)
            current = [cid]
            mean_z = z
    if current:
        layers.append(current)
    return layers


# ============================================================
# Rich relation descriptor
# ============================================================

def describe_candidate_to_seed(seed: Dict, cand: Dict, global_ctx: Dict) -> Dict[str, float]:
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    gh = max(float(global_ctx["global_height"][0]), 1e-8)

    rel = cand["centroid"] - seed["centroid"]
    rel_xy = np.array([rel[0], rel[1], 0.0], dtype=np.float32)

    along = float(np.dot(rel_xy, seed["axis_xy"]))
    lateral = float(np.dot(rel_xy, seed["lateral_xy"]))

    seed_half = 0.5 * float(seed["long_span"])
    cand_half = 0.5 * float(cand["long_span"])
    endness = abs(along) / max(seed_half, 1e-8)

    gap = float(base.bbox_gap(seed["bbox_min"], seed["bbox_max"], cand["bbox_min"], cand["bbox_max"]) / gd)
    z_delta = float(rel[2] / gh)

    top_gap = float((cand["bbox_min"][2] - seed["bbox_max"][2]) / gh)
    bottom_gap = float((seed["bbox_min"][2] - cand["bbox_max"][2]) / gh)

    long_overhang = max(0.0, abs(along) - (seed_half + 0.75 * cand_half)) / gd
    lateral_overhang = max(
        0.0,
        abs(lateral) - (0.5 * float(seed["lat_span"]) + 0.95 * 0.5 * float(cand["lat_span"]))
    ) / gd

    xy_overlap = bbox_xy_overlap_ratio(seed["bbox_min"], seed["bbox_max"], cand["bbox_min"], cand["bbox_max"])

    seed_l0 = float(seed["centroid"] @ seed["axis_xy"] - 0.5 * seed["long_span"])
    seed_l1 = float(seed["centroid"] @ seed["axis_xy"] + 0.5 * seed["long_span"])
    cand_l0 = float(cand["centroid"] @ seed["axis_xy"] - 0.5 * cand["long_span"])
    cand_l1 = float(cand["centroid"] @ seed["axis_xy"] + 0.5 * cand["long_span"])
    long_overlap = interval_overlap_ratio(seed_l0, seed_l1, cand_l0, cand_l1)

    seed_top = float(seed["bbox_max"][2])
    seed_bot = float(seed["bbox_min"][2])
    cand_top = float(cand["bbox_max"][2])
    cand_bot = float(cand["bbox_min"][2])

    top_attach = max(0.0, 0.08 - abs(cand_bot - seed_top) / gh) / 0.08
    bottom_attach = max(0.0, 0.08 - abs(cand_top - seed_bot) / gh) / 0.08
    top_rise = float((cand_top - seed_top) / gh)
    bottom_drop = float((seed_bot - cand_bot) / gh)

    above_seed = float(cand_bot >= seed["centroid"][2] - 0.02 * gh)
    below_seed = float(cand_top <= seed["centroid"][2] + 0.01 * gh)
    above_seed_top = float(cand["centroid"][2] >= seed_top - 0.02 * gh)
    below_seed_bottom = float(cand["centroid"][2] <= seed_bot + 0.02 * gh)
    same_layer_topish = float(
        abs(z_delta) <= 0.10
        and top_rise >= -0.02
        and bottom_drop <= 0.08
    )
    top_support = max(
        float(top_attach),
        float(max(0.0, 0.03 + top_rise) / 0.10) * max(float(above_seed_top), same_layer_topish),
    )

    return {
        "along": along / gd,
        "lateral": lateral / gd,
        "endness": endness,
        "gap": gap,
        "z_delta": z_delta,
        "top_gap": top_gap,
        "bottom_gap": bottom_gap,
        "long_overhang": float(long_overhang),
        "lateral_overhang": float(lateral_overhang),
        "xy_overlap": float(xy_overlap),
        "long_overlap": float(long_overlap),
        "top_attach": float(top_attach),
        "top_rise": float(top_rise),
        "bottom_drop": float(bottom_drop),
        "same_layer_topish": float(same_layer_topish),
        "top_support": float(np.clip(top_support, 0.0, 1.0)),
        "bottom_attach": float(bottom_attach),
        "above_seed": above_seed,
        "below_seed": below_seed,
        "above_seed_top": above_seed_top,
        "below_seed_bottom": below_seed_bottom,
        "near_end": float(0.50 <= endness <= 1.55),
        "centerish": float(endness <= 0.32),
    }


# ============================================================
# Role classifier
# ============================================================

def role_classifier_score(features: List[float], role_name: str, semantic_model: Dict) -> Optional[float]:
    if not semantic_model:
        return None
    role_model = semantic_model.get("role_classifier", {})
    if not role_model:
        return None
    item = role_model.get(role_name)
    if not item:
        return None

    w = np.asarray(item.get("weights", []), dtype=np.float32)
    b = float(item.get("bias", 0.0))
    x = np.asarray(features, dtype=np.float32)

    if w.shape[0] != x.shape[0]:
        return None

    mean = semantic_model.get("role_feature_standardize_mean", None)
    std = semantic_model.get("role_feature_standardize_std", None)
    if mean is not None and std is not None:
        mean = np.asarray(mean, dtype=np.float32)
        std = np.asarray(std, dtype=np.float32)
        std[std < 1e-6] = 1.0
        if mean.shape[0] == x.shape[0] and std.shape[0] == x.shape[0]:
            x = (x - mean) / std

    return float(np.dot(w, x) + b)


def classify_candidate_role(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict = None,
) -> Tuple[str, float]:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(cand, global_ctx)
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
    height_ratio = float(cand.get("height_ratio", 1.0))
    align_seed = component_axis_alignment(cand, seed["axis_xy"])
    align_primary = component_axis_alignment(cand, primary_axis)
    vertical_ratio = float((cand["bbox_max"][2] - cand["bbox_min"][2]) / gh)
    dou_bonus = dou_semantic_bonus(cand, semantic_model)
    irregular_upper_ctx = irregular_upper_dou_context_score(seed, cand, rel, global_ctx)

    feats = [
        rel["along"], rel["lateral"], rel["z_delta"], rel["gap"],
        rel["top_gap"], rel["bottom_gap"], rel["long_overhang"], rel["lateral_overhang"],
        rel["xy_overlap"], rel["long_overlap"], rel["top_attach"], rel["bottom_attach"],
        rel["above_seed"], rel["below_seed"], rel["above_seed_top"], rel["below_seed_bottom"],
        diag_rel, horiz_elong, height_ratio, align_seed, align_primary, vertical_ratio, dou_bonus,
    ]

    learned_scores = {}
    for role_name in ["upper_dou", "body_extension", "lower_support", "other"]:
        s = role_classifier_score(feats, role_name, semantic_model)
        if s is not None:
            learned_scores[role_name] = s

    if learned_scores:
        best_role = max(learned_scores.items(), key=lambda kv: kv[1])[0]
        best_score = float(learned_scores[best_role])

        # safety gate
        if best_role == "upper_dou":
            if (
                rel["below_seed_bottom"] > 0.5
                or rel["bottom_attach"] > 0.55
                or not upper_dou_hard_gate(seed, cand, rel, global_ctx)
            ):
                best_role = "lower_support"
                best_score -= 0.8
        elif best_role == "lower_support":
            if rel["above_seed_top"] > 0.5 and rel["top_attach"] > 0.45:
                best_role = "upper_dou"
                best_score -= 0.4
        elif (
            best_role in {"body_extension", "other"}
            and irregular_upper_ctx >= 2.45
            and learned_scores.get("upper_dou", -1e9) >= best_score - 0.55
            and align_seed <= 0.88
            and horiz_elong <= 4.4
        ):
            best_role = "upper_dou"
            best_score = max(best_score, learned_scores.get("upper_dou", best_score) + 0.15)
        return best_role, best_score

    upper_score = 0.0
    lower_score = 0.0
    body_score = 0.0
    raised_body_score = score_raised_body_extension(
        seed=seed,
        cand=cand,
        rel=rel,
        primary_axis=primary_axis,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
    )

    upper_score += 1.6 * rel["top_support"]
    upper_score += 1.0 * rel["xy_overlap"]
    upper_score += 0.9 * rel["long_overlap"]
    upper_score += 0.7 * rel["above_seed"]
    upper_score += 0.8 * rel["above_seed_top"]
    upper_score += 0.9 * rel["same_layer_topish"]
    upper_score += 0.6 * max(0.0, 0.18 - rel["gap"]) / 0.18
    upper_score += 0.6 * max(0.0, 0.14 - rel["lateral_overhang"]) / 0.14
    upper_score += 0.4 * max(0.0, 0.20 - rel["long_overhang"]) / 0.20
    upper_score += 0.8 * max(0.0, 3.2 - horiz_elong) / 3.2
    upper_score += 0.6 * max(0.0, 0.22 - vertical_ratio) / 0.22
    upper_score += 0.4 * max(dou_bonus, 0.0)
    upper_score += 0.30 * max(0.0, irregular_upper_ctx)
    if not upper_dou_hard_gate(seed, cand, rel, global_ctx):
        upper_score -= 3.0

    lower_score += 1.5 * rel["bottom_attach"]
    lower_score += 1.0 * rel["below_seed"]
    lower_score += 0.9 * rel["below_seed_bottom"]
    lower_score += 0.8 * rel["xy_overlap"]
    lower_score += 0.7 * rel["long_overlap"]
    lower_score += 0.6 * max(0.0, 0.18 - rel["gap"]) / 0.18
    lower_score += 0.6 * max(0.0, 3.0 - horiz_elong) / 3.0
    lower_score += 0.6 * max(0.0, 0.20 - vertical_ratio) / 0.20
    lower_score += 0.4 * max(dou_bonus, 0.0)

    body_score += 1.2 * align_seed
    body_score += 0.8 * align_primary
    body_score += 0.8 * max(0.0, horiz_elong - 1.8) / 3.0
    body_score += 0.7 * max(0.0, 0.95 - height_ratio) / 0.95
    body_score += 0.7 * max(0.0, 0.18 - rel["gap"]) / 0.18
    body_score += 0.6 * max(0.0, 0.12 - rel["lateral_overhang"]) / 0.12
    body_score += 0.5 * max(0.0, 0.18 - rel["long_overhang"]) / 0.18
    body_score += 0.4 * max(0.0, 0.08 - abs(rel["z_delta"])) / 0.08
    body_score += 0.5 * rel["long_overlap"]
    body_score += 0.3 * rel["xy_overlap"]

    if rel["below_seed_bottom"] > 0.5:
        body_score -= 2.2
    if is_blocky_dou_segment(cand, global_ctx):
        body_score -= 1.2
        raised_body_score -= 1.2
    if rel["above_seed_top"] > 0.5 or rel["same_layer_topish"] > 0.5:
        lower_score -= 1.4
    if rel["below_seed_bottom"] > 0.5:
        upper_score -= 1.6

    bottom_interference_body = bool(
        rel["below_seed_bottom"] > 0.75
        and rel["long_overlap"] > 0.95
        and rel["centerish"] > 0.5
        and rel["gap"] < 0.14
        and component_diag_rel(cand, global_ctx) >= 0.28
        and component_vertical_elongation(cand) >= 2.0
        and not is_base_dou_segment(cand, global_ctx)
        and not is_blocky_dou_segment(cand, global_ctx)
    )
    if bottom_interference_body:
        body_score += 1.2
        raised_body_score += 1.8
        lower_score -= 1.4

    scores = {
        "upper_dou": upper_score,
        "lower_support": lower_score,
        "body_extension": max(body_score, raised_body_score),
        "other": 0.0,
    }
    best_role, best_score = max(scores.items(), key=lambda kv: kv[1])
    if best_role == "lower_support" and bottom_interference_body and max(body_score, raised_body_score) >= best_score - 0.25:
        best_role = "body_extension"
        best_score = max(body_score, raised_body_score)
    if best_score < 1.1:
        return "other", best_score
    return best_role, float(best_score)


# ============================================================
# Upper dou group modeling
# ============================================================

def classify_upper_slot(rel: Dict[str, float]) -> str:
    if rel["centerish"] > 0.5 and abs(rel["along"]) <= 0.12:
        return "center"
    return "left" if rel["along"] < 0.0 else "right"


def upper_subset_connected(
    subset: List[int],
    rel_map: Dict[int, Dict[str, float]],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
) -> bool:
    if len(subset) <= 1:
        return True
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    for a, b in combinations(subset, 2):
        along_gap = abs(rel_map[a]["along"] - rel_map[b]["along"])
        z_gap = abs(raw_comps[a]["centroid"][2] - raw_comps[b]["centroid"][2]) / gh
        bbox_gap = float(base.bbox_gap(
            raw_comps[a]["bbox_min"], raw_comps[a]["bbox_max"],
            raw_comps[b]["bbox_min"], raw_comps[b]["bbox_max"]
        ) / gd)
        if along_gap > 0.22 or z_gap > 0.10 or bbox_gap > 0.16:
            return False
    return True


def score_upper_dou_cluster(
    seed: Dict,
    merged: Dict,
    member_ids: List[int],
    rel_infos: List[Dict[str, float]],
    slot: str,
    global_ctx: Dict,
    semantic_model: Dict = None,
) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(merged, global_ctx)
    horiz_elong = float(merged.get("horizontal_elongation", merged.get("elongation", 1.0)))
    height_ratio = float(merged.get("height_ratio", 1.0))
    vertical_ratio = float((merged["bbox_max"][2] - merged["bbox_min"][2]) / gh)
    dou_bonus = dou_semantic_bonus(merged, semantic_model)

    mean_gap = float(np.mean([r["gap"] for r in rel_infos]))
    mean_top_attach = float(np.mean([r["top_support"] for r in rel_infos]))
    mean_xy_overlap = float(np.mean([r["xy_overlap"] for r in rel_infos]))
    mean_long_overlap = float(np.mean([r["long_overlap"] for r in rel_infos]))
    below_penalty = float(np.mean([r["bottom_attach"] + r["below_seed_bottom"] for r in rel_infos]))
    mean_learned_attach = float(np.mean([float(r.get("learned_attach_logit", 0.0)) for r in rel_infos]))

    along_vals = [r["along"] for r in rel_infos]
    z_vals = [r["z_delta"] for r in rel_infos]
    endness_vals = [r["endness"] for r in rel_infos]
    along_spread = max(along_vals) - min(along_vals) if along_vals else 0.0
    z_spread = max(z_vals) - min(z_vals) if z_vals else 0.0
    mean_abs_along = float(np.mean([abs(v) for v in along_vals])) if along_vals else 0.0
    mean_endness = float(np.mean(endness_vals)) if endness_vals else 0.0
    if diag_rel > 0.32 or horiz_elong > 4.4 or vertical_ratio > 0.30:
        return -1e9

    structural_violations = sum(
        1 for rel in rel_infos if not upper_dou_structural_law(seed, merged, rel, global_ctx, slot=slot)
    )

    score = 0.0
    score += 1.4 * mean_top_attach
    score += 1.0 * mean_xy_overlap
    score += 0.9 * mean_long_overlap
    score += 1.0 * max(0.0, 0.16 - mean_gap) / 0.16
    score += 0.8 * max(0.0, 0.25 - vertical_ratio) / 0.25
    score += 0.8 * max(0.0, 3.8 - horiz_elong) / 3.8
    score += 0.4 * max(dou_bonus, 0.0)
    score += 0.38 * max(0.0, mean_learned_attach) / 2.0
    if mean_learned_attach < -2.4:
        score -= 0.26

    score -= 1.5 * below_penalty
    score -= 0.8 * along_spread / 0.22
    score -= 0.5 * z_spread / 0.10
    score -= 0.85 * float(structural_violations)
    score -= 1.2 * max(0.0, below_penalty - 0.16) / 0.16

    if slot in {"left", "right"}:
        score += 0.18
        score += 0.85 * max(0.0, 0.35 - abs(mean_endness - 1.0)) / 0.35
        score -= 0.50 * max(0.0, 0.08 - mean_abs_along) / 0.08
    if slot == "center":
        score += 0.10
        score += 0.75 * max(0.0, 0.10 - mean_abs_along) / 0.10
        score -= 0.65 * max(0.0, mean_endness - 0.45) / 0.55
    score += 0.35 * min(len(member_ids), 3)
    return float(score)


def select_best_upper_clusters(
    seed: Dict,
    candidate_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    seg_by_id: Dict[int, Segment],
    primary_axis: np.ndarray,
    semantic_model: Dict = None,
    learned_priors: Dict = None,
) -> Tuple[float, Dict[str, Tuple[List[int], Dict, float]], Dict[int, Dict[str, float]], Dict[int, str]]:
    rel_map: Dict[int, Dict[str, float]] = {}
    role_map: Dict[int, str] = {}
    slots: Dict[str, List[int]] = {"left": [], "center": [], "right": []}
    pos_support = 0.0
    neg_support = 0.0

    for cid in sorted(candidate_ids):
        rel = describe_candidate_to_seed(seed, raw_comps[cid], global_ctx)
        role, role_score = classify_candidate_role(seed, raw_comps[cid], rel, primary_axis, global_ctx, semantic_model)
        rel["learned_attach_logit"] = learned_attachment_logit(
            seed=seed,
            cand=raw_comps[cid],
            rel=rel,
            global_ctx=global_ctx,
            primary_axis=primary_axis,
            semantic_model=semantic_model,
            learned_priors=learned_priors,
        )
        rel_map[cid] = rel
        role_map[cid] = role
        if (
            role == "upper_dou"
            and role_score >= 1.1
            and upper_dou_hard_gate(seed, raw_comps[cid], rel, global_ctx)
        ):
            if rel["learned_attach_logit"] < -2.6 and not (
                rel["same_layer_topish"] > 0.5 and rel["top_support"] > 0.60 and rel["xy_overlap"] > 0.42
            ):
                continue
            if rel["lateral"] >= 0.0:
                pos_support += rel["top_support"]
            else:
                neg_support += rel["top_support"]
            slot = classify_upper_slot(rel)
            if slot in {"left", "right"} and rel["near_end"] < 0.5:
                continue
            if slot == "center":
                if rel["centerish"] < 0.5:
                    continue
                center_diag_rel = component_diag_rel(raw_comps[cid], global_ctx)
                if rel["same_layer_topish"] > 0.5:
                    if center_diag_rel > 0.13:
                        continue
                else:
                    if center_diag_rel > 0.15:
                        continue
                    if rel["xy_overlap"] < 0.04 and abs(rel["lateral"]) > 0.06:
                        continue
            slots[slot].append(cid)

    preferred_sign = 1.0 if pos_support >= neg_support else -1.0
    for slot, slot_ids in list(slots.items()):
        if not slot_ids:
            continue
        slot_ids = [
            cid for cid in slot_ids
            if rel_map[cid]["lateral"] * preferred_sign >= -0.01
        ]
        if not slot_ids:
            slots[slot] = []
            continue
        same_layer_ids = [cid for cid in slot_ids if rel_map[cid]["same_layer_topish"] > 0.5]
        upper_layer_ids = [cid for cid in slot_ids if rel_map[cid]["same_layer_topish"] <= 0.5]
        # Do not discard upper-layer candidates outright: refreshed fragment often splits
        # one logical upper dou into mixed same-layer / upper-layer pieces.
        if same_layer_ids:
            slot_ids = same_layer_ids
        slots[slot] = slot_ids

    total_score = 0.0
    chosen: Dict[str, Tuple[List[int], Dict, float]] = {}

    for slot, slot_ids in slots.items():
        if not slot_ids:
            continue
        best = None
        max_group = min(3, len(slot_ids))
        for size in range(1, max_group + 1):
            for subset in combinations(slot_ids, size):
                subset_ids = list(subset)
                if not upper_subset_connected(subset_ids, rel_map, raw_comps, global_ctx):
                    continue
                merged = build_component_from_seg_ids(subset_ids, seg_by_id)
                rel_infos = [rel_map[cid] for cid in subset_ids]
                score = score_upper_dou_cluster(seed, merged, subset_ids, rel_infos, slot, global_ctx, semantic_model)
                if score < 1.2:
                    continue
                if best is None or score > best[2]:
                    best = (subset_ids, merged, score)
        if best is not None:
            chosen[slot] = best
            total_score += best[2]

    return total_score, chosen, rel_map, role_map


# ============================================================
# Body extension / template scoring
# ============================================================

def score_straight_gong_body_candidate(
    comp: Dict,
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = best_planar_elongation(comp, primary_axis)
    height_ratio = best_planar_height_ratio(comp, primary_axis)
    align = best_planar_alignment(comp, primary_axis)
    vertical_ratio = float((comp["bbox_max"][2] - comp["bbox_min"][2]) / gh)
    long_ratio = float(comp["long_span"] / gd)
    z_norm = component_z_norm(comp, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    symmetry_score = component_side_symmetry_score(comp, global_ctx)
    structural_score = gong_body_structural_score(comp, global_ctx)

    if diag_rel < 0.16:
        return -1e9
    if align < 0.68:
        return -1e9
    if horiz_elong < 2.30:
        return -1e9
    if height_ratio > 0.72:
        return -1e9
    if z_norm < 0.08:
        return -1e9
    if vertical_ratio > 0.30:
        return -1e9

    return float(
        1.5 * min(long_ratio / 0.42, 1.0)
        + 1.0 * min(diag_rel / 0.32, 1.0)
        + 1.3 * min(horiz_elong / 6.0, 1.0)
        + 0.9 * align
        + 0.9 * max(0.0, 0.62 - height_ratio) / 0.62
        + 0.7 * max(0.0, 0.24 - vertical_ratio) / 0.24
        + 1.0 * max(0.0, 0.040 - bottom_std) / 0.040
        + 0.9 * max(0.0, 0.060 - bottom_range) / 0.060
        + 0.35 * symmetry_score
        + 0.65 * max(structural_score, -2.0) / 3.0
        + 0.45 * gong_semantic_bonus(comp, semantic_model)
    )


def score_raised_gong_body_candidate(
    comp: Dict,
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = best_planar_elongation(comp, primary_axis)
    height_ratio = best_planar_height_ratio(comp, primary_axis)
    align = best_planar_alignment(comp, primary_axis)
    vertical_ratio = float((comp["bbox_max"][2] - comp["bbox_min"][2]) / gh)
    vertical_elong = component_vertical_elongation(comp)
    cross_ratio = component_xy_cross_ratio(comp)
    long_ratio = float(comp["long_span"] / gd)
    z_norm = component_z_norm(comp, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    symmetry_score = component_side_symmetry_score(comp, global_ctx)
    structural_score = gong_body_structural_score(comp, global_ctx)
    lift = float(comp.get("end_lift_min", 0.0) / gh)

    if is_base_dou_segment(comp, global_ctx) or is_blocky_dou_segment(comp, global_ctx):
        return -1e9
    if diag_rel < 0.22 or diag_rel > 0.78:
        return -1e9
    if align < 0.52:
        return -1e9
    if long_ratio < 0.08:
        return -1e9
    if z_norm < 0.14:
        return -1e9
    if height_ratio < 0.75 or height_ratio > 8.8:
        return -1e9
    if vertical_ratio < 0.24 or vertical_ratio > 0.98:
        return -1e9
    if vertical_elong < 1.25 or vertical_elong > 9.8:
        return -1e9
    if cross_ratio < 0.70 or cross_ratio > 1.02:
        return -1e9
    if bottom_std > 0.20 or bottom_range > 0.48:
        return -1e9

    return float(
        1.0 * min(diag_rel / 0.42, 1.0)
        + 0.7 * align
        + 0.7 * min(long_ratio / 0.18, 1.0)
        + 0.9 * max(0.0, min(vertical_ratio, 0.90) - 0.24) / 0.66
        + 0.9 * max(0.0, min(vertical_elong, 5.0) - 1.25) / 3.75
        + 0.25 * max(0.0, 1.02 - cross_ratio) / 1.02
        + 0.35 * max(0.0, 0.20 - bottom_std) / 0.20
        + 0.30 * max(0.0, 0.48 - bottom_range) / 0.48
        + 0.25 * max(0.0, lift + 0.02) / 0.12
        + 0.12 * symmetry_score
        + 0.40 * max(structural_score, -2.0) / 3.0
        + 0.20 * gong_semantic_bonus(comp, semantic_model)
    )


def score_body_candidate(comp: Dict, primary_axis: np.ndarray, global_ctx: Dict, semantic_model: Dict) -> float:
    straight_score = score_straight_gong_body_candidate(comp, primary_axis, global_ctx, semantic_model)
    raised_score = score_raised_gong_body_candidate(comp, primary_axis, global_ctx, semantic_model)
    return float(max(straight_score, raised_score))


def score_z_gong_body_candidate(comp: Dict, global_ctx: Dict, semantic_model: Dict) -> float:
    if not is_z_gong_body_seed(comp, global_ctx):
        return -1e9

    diag_rel = component_diag_rel(comp, global_ctx)
    z_norm = component_z_norm(comp, global_ctx)
    vert_elong = component_vertical_elongation(comp)
    cross_ratio = component_xy_cross_ratio(comp)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    return float(
        1.8 * min(vert_elong / 6.8, 1.0)
        + 1.5 * max(0.0, cross_ratio - 0.72) / 0.28
        + 0.8 * min(diag_rel / 0.60, 1.0)
        + 0.7 * max(0.0, 2.0 - horiz_elong) / 1.2
        + 0.8 * min(height_ratio / 6.5, 1.0)
        + 0.5 * min(z_norm / 0.60, 1.0)
        + 0.15 * gong_semantic_bonus(comp, semantic_model)
    )


def score_z_gong_attachment_candidate(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    semantic_model: Dict = None,
) -> float:
    diag_rel = component_diag_rel(cand, global_ctx)
    vert_elong = component_vertical_elongation(cand)
    cross_ratio = component_xy_cross_ratio(cand)
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))

    abs_along = abs(float(rel["along"]))
    abs_lateral = abs(float(rel["lateral"]))
    abs_z_delta = abs(float(rel["z_delta"]))

    if diag_rel > 0.17 or vert_elong > 2.2 or cross_ratio < 0.22:
        return -1e9
    if rel["gap"] > 0.03 or abs_lateral > 0.020:
        return -1e9
    if abs_along < 0.028 or abs_along > 0.085:
        return -1e9
    if abs_z_delta > 0.58:
        return -1e9
    if rel["xy_overlap"] < 0.02 or rel["long_overlap"] < 0.18:
        return -1e9
    if horiz_elong > 3.8:
        return -1e9

    score = 0.0
    score += 1.2 * max(0.0, 0.03 - rel["gap"]) / 0.03
    score += 1.1 * max(0.0, 0.020 - abs_lateral) / 0.020
    score += 1.0 * max(0.0, 0.030 - abs(abs_along - 0.055)) / 0.030
    score += 0.5 * max(0.0, 0.17 - diag_rel) / 0.17
    score += 0.5 * max(0.0, 0.58 - abs_z_delta) / 0.58
    score += 0.45 * rel["xy_overlap"]
    score += 0.30 * rel["long_overlap"]
    score += 0.25 * max(0.0, cross_ratio - 0.22) / 0.58
    if is_blocky_dou_segment(cand, global_ctx):
        score += 0.35
    score += 0.15 * max(0.0, dou_semantic_bonus(cand, semantic_model))
    return float(score)


def score_z_gong_template(
    seed: Dict,
    merged: Dict,
    body_score: float,
    attachment_scores: List[float],
    rel_infos: List[Dict[str, float]],
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    if not rel_infos:
        return -1e9

    diag_rel = component_diag_rel(merged, global_ctx)
    merged_vert_elong = component_vertical_elongation(merged)
    merged_cross_ratio = component_xy_cross_ratio(merged)
    seed_vert_elong = component_vertical_elongation(seed)
    seed_cross_ratio = component_xy_cross_ratio(seed)

    if diag_rel > 0.75 or merged_vert_elong < 3.6 or merged_cross_ratio < 0.72:
        return -1e9

    abs_alongs = [abs(float(r["along"])) for r in rel_infos]
    abs_laterals = [abs(float(r["lateral"])) for r in rel_infos]
    z_vals = [float(r["z_delta"]) for r in rel_infos]
    mean_gap = float(np.mean([float(r["gap"]) for r in rel_infos]))
    z_spread = max(z_vals) - min(z_vals)
    along_spread = max(abs_alongs) - min(abs_alongs)

    if z_spread < 0.28:
        return -1e9

    vert_drop = max(0.0, seed_vert_elong - merged_vert_elong)
    cross_drop = max(0.0, seed_cross_ratio - merged_cross_ratio)

    score = 0.0
    score += 0.75 * body_score
    score += 1.7 * min(merged_vert_elong / 5.8, 1.0)
    score += 1.5 * max(0.0, merged_cross_ratio - 0.72) / 0.28
    score += 0.9 * max(0.0, z_spread - 0.28) / 0.40
    score += 0.55 * min(len(rel_infos), 4)
    score += 0.60 * float(np.mean(attachment_scores))
    score += 0.25 * max(0.0, gong_semantic_bonus(merged, semantic_model))

    score -= 1.2 * mean_gap / 0.03
    score -= 0.8 * float(np.mean(abs_laterals)) / 0.020
    score -= 0.6 * along_spread / 0.040
    score -= 1.4 * max(0.0, vert_drop - 0.55) / 0.90
    score -= 1.0 * max(0.0, cross_drop - 0.10) / 0.18
    return float(score)


def score_body_extension(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict = None,
    learned_priors: Dict = None,
) -> float:
    align = component_axis_alignment(cand, seed["axis_xy"])
    if align < 0.55:
        return -1e9

    height_ratio = float(cand.get("height_ratio", 1.0))
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))

    if horiz_elong < 1.5 or height_ratio > 1.15:
        return -1e9
    if rel["gap"] > 0.16 or rel["lateral_overhang"] > 0.10 or rel["long_overhang"] > 0.18:
        return -1e9
    if rel["centerish"] < 0.5 and rel["xy_overlap"] < 0.18:
        return -1e9
    if rel["xy_overlap"] < 0.035:
        return -1e9
    # Prevent center-aligned but non-overlapping fragments from being absorbed
    # as body pieces just because they share the same longitudinal span.
    if rel["centerish"] > 0.5 and rel["same_layer_topish"] > 0.5 and rel["xy_overlap"] < 0.10:
        return -1e9
    if rel["centerish"] > 0.5 and rel["top_support"] > 0.42:
        return -1e9

    # Strong downward suppression
    if rel["z_delta"] < -0.03:
        return -1e9
    if rel["below_seed_bottom"] > 0.5:
        return -1e9
    if rel["bottom_attach"] > 0.55:
        return -1e9

    bodyext_logit = learned_body_extension_logit(
        seed=seed,
        cand=cand,
        rel=rel,
        global_ctx=global_ctx,
        primary_axis=primary_axis,
        semantic_model=semantic_model,
        learned_priors=learned_priors,
    )
    raised_score = score_raised_body_extension(
        seed=seed,
        cand=cand,
        rel=rel,
        primary_axis=primary_axis,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
    )

    score = 0.0
    score += 1.5 * align
    score += 1.0 * max(0.0, 0.10 - rel["lateral_overhang"]) / 0.10
    score += 0.9 * max(0.0, 0.16 - rel["gap"]) / 0.16
    score += 0.7 * max(0.0, 0.10 - abs(rel["z_delta"])) / 0.10
    score += 0.5 * rel["long_overlap"]
    score += 0.4 * rel["xy_overlap"]
    score += 0.5 * rel["centerish"]

    if rel["near_end"] > 0.5:
        score -= 0.8
    if component_axis_alignment(cand, primary_axis) >= 0.72:
        score += 0.2
    if is_blocky_dou_segment(cand, global_ctx):
        score -= 0.65
    score += 0.18 * max(0.0, bodyext_logit)
    score -= 0.32 * max(0.0, -bodyext_logit)
    return float(max(score, raised_score))


def score_raised_body_extension(
    seed: Dict,
    cand: Dict,
    rel: Dict[str, float],
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict = None,
) -> float:
    align = component_axis_alignment(cand, seed["axis_xy"])
    diag_rel = component_diag_rel(cand, global_ctx)
    height_ratio = float(cand.get("height_ratio", 1.0))
    horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
    vertical_ratio = component_vertical_elongation(cand)
    cross_ratio = component_xy_cross_ratio(cand)
    symmetry_score = component_side_symmetry_score(cand, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(cand, global_ctx)

    if align < 0.0:
        return -1e9
    if rel["below_seed_bottom"] > 0.18 or rel["bottom_attach"] > 0.20:
        return -1e9
    if rel["long_overlap"] < 0.90:
        return -1e9
    if rel["centerish"] < 0.5:
        return -1e9
    if rel["gap"] > 0.16:
        return -1e9
    if abs(rel["lateral"]) > 0.24:
        return -1e9
    if rel["z_delta"] < -0.08 or rel["z_delta"] > 0.32:
        return -1e9
    if diag_rel < 0.28 or diag_rel > 0.70:
        return -1e9
    if vertical_ratio < 1.4 or vertical_ratio > 9.5:
        return -1e9
    if cross_ratio > 1.02:
        return -1e9
    if bottom_range > 0.48:
        return -1e9

    score = 0.0
    score += 1.25 * rel["long_overlap"]
    score += 0.95 * rel["centerish"]
    score += 0.75 * max(0.0, 0.16 - rel["gap"]) / 0.16
    score += 0.70 * max(0.0, 0.24 - abs(rel["lateral"])) / 0.24
    score += 0.85 * max(0.0, min(rel["z_delta"], 0.22)) / 0.22
    score += 0.55 * max(0.0, min(vertical_ratio, 5.0) - 1.4) / 3.6
    score += 0.25 * max(0.0, 1.02 - cross_ratio) / 1.02
    score += 0.35 * max(0.0, 0.18 - bottom_std) / 0.18
    score += 0.25 * max(0.0, 0.48 - bottom_range) / 0.48
    score += 0.15 * symmetry_score
    score -= 0.35 * max(0.0, align - 0.75) / 0.25
    score -= 0.20 * max(0.0, horiz_elong - 2.1) / 1.5
    score -= 0.15 * max(0.0, 0.8 - height_ratio) / 0.8
    return float(score)


def body_extension_merge_gate(
    current_body: Dict,
    cand: Dict,
    merged: Dict,
    rel: Dict[str, float],
    primary_axis: np.ndarray,
    global_ctx: Dict,
    semantic_model: Dict = None,
) -> bool:
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)
    gh = max(float(global_ctx["global_height"][0]), 1e-8)

    current_body_score = score_body_candidate(current_body, primary_axis, global_ctx, semantic_model)
    merged_body_score = score_body_candidate(merged, primary_axis, global_ctx, semantic_model)
    raised_score = score_raised_body_extension(
        seed=current_body,
        cand=cand,
        rel=rel,
        primary_axis=primary_axis,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
    )
    if merged_body_score <= -1e8 and raised_score < 2.2:
        return False

    long_gain = max(0.0, float(merged["long_span"] - current_body["long_span"])) / gd
    lat_gain = max(0.0, float(merged["lat_span"] - current_body["lat_span"])) / gd
    vert_gain = max(
        0.0,
        float((merged["bbox_max"][2] - merged["bbox_min"][2]) - (current_body["bbox_max"][2] - current_body["bbox_min"][2])),
    ) / gh
    score_gain = float(merged_body_score - current_body_score) if merged_body_score > -1e8 else 0.0
    cand_height_ratio = float(cand.get("height_ratio", 1.0))

    # A valid body extension should primarily extend along the gong axis,
    # not simply thicken the body sideways or vertically.
    if long_gain < 0.010 and lat_gain > 0.020:
        return False
    if long_gain < 0.010 and vert_gain > 0.018:
        return False
    if rel.get("centerish", 0.0) > 0.5 and long_gain < 0.010:
        return False
    if rel.get("same_layer_topish", 0.0) > 0.5 and rel.get("top_support", 0.0) < 0.15 and long_gain < 0.015:
        return False
    if rel.get("centerish", 0.0) > 0.5 and rel.get("same_layer_topish", 0.0) > 0.5 and rel.get("xy_overlap", 0.0) < 0.10:
        return False
    if is_blocky_dou_segment(cand, global_ctx) and long_gain < 0.020:
        return False
    if cand_height_ratio > 0.82 and long_gain < 0.020:
        return False
    if lat_gain > max(0.020, 1.4 * long_gain):
        return False
    if vert_gain > max(0.016, 1.2 * long_gain):
        return False
    if score_gain < -0.12:
        return False
    if raised_score >= 2.2:
        return True
    return True


def grow_body_with_raised_segments(
    body_ids: List[int],
    body_comp: Dict,
    candidate_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
) -> Tuple[List[int], Dict, float]:
    chosen_ids = sorted(set(int(x) for x in body_ids))
    current_body = body_comp
    total_score = 0.0

    for _ in range(2):
        scored: List[Tuple[float, int]] = []
        for cid in candidate_ids:
            if cid in chosen_ids:
                continue
            cand = raw_comps[cid]
            rel = describe_candidate_to_seed(current_body, cand, global_ctx)
            role, role_score = classify_candidate_role(
                current_body, cand, rel, primary_axis, global_ctx, semantic_model
            )
            raised_score = score_raised_body_extension(
                seed=current_body,
                cand=cand,
                rel=rel,
                primary_axis=primary_axis,
                global_ctx=global_ctx,
                semantic_model=semantic_model,
            )
            if raised_score <= 2.2:
                continue
            if role == "upper_dou" and role_score >= raised_score - 0.2:
                continue
            scored.append((float(raised_score), cid))

        if not scored:
            break
        scored.sort(reverse=True)

        added = False
        for raised_score, cid in scored:
            cand = raw_comps[cid]
            rel = describe_candidate_to_seed(current_body, cand, global_ctx)
            trial_ids = sorted(set(chosen_ids + [cid]))
            trial_merged = build_component_from_seg_ids(trial_ids, seg_by_id)
            if not body_extension_merge_gate(
                current_body=current_body,
                cand=cand,
                merged=trial_merged,
                rel=rel,
                primary_axis=primary_axis,
                global_ctx=global_ctx,
                semantic_model=semantic_model,
            ):
                continue
            if merged_downward_absorption_penalty(current_body, trial_merged, global_ctx) > 0.12:
                continue
            chosen_ids = trial_ids
            current_body = trial_merged
            total_score += float(raised_score)
            added = True
            break

        if not added:
            break

    return chosen_ids, current_body, total_score


def merged_downward_absorption_penalty(seed: Dict, merged: Dict, global_ctx: Dict) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    down_expand = max(0.0, float(seed["bbox_min"][2] - merged["bbox_min"][2])) / gh
    up_expand = max(0.0, float(merged["bbox_max"][2] - seed["bbox_max"][2])) / gh
    penalty = 3.0 * down_expand - 0.4 * up_expand
    return float(max(penalty, 0.0))


def gong_template_score(
    body_comp: Dict,
    body_score: float,
    upper_clusters: Dict[str, Tuple[List[int], Dict, float]],
    rel_map: Dict[int, Dict[str, float]],
    role_map: Dict[int, str],
    global_ctx: Dict,
    semantic_model: Dict,
    original_seed: Dict,
    learned_priors: Dict = None,
) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    horiz_elong = float(body_comp.get("horizontal_elongation", body_comp.get("elongation", 1.0)))
    diag_rel = component_diag_rel(body_comp, global_ctx)
    height_ratio = float(body_comp.get("height_ratio", 1.0))
    lift = float(body_comp.get("end_lift_min", 0.0) / gh)
    end_sym = float(body_comp.get("end_symmetry", 0.0) / gh)
    width_asym = float(body_comp.get("end_width_asym", 1.0))
    bottom_std, bottom_range = component_bottom_profile_stats(body_comp, global_ctx)
    symmetry_score = component_side_symmetry_score(body_comp, global_ctx)
    structural_score = gong_body_structural_score(body_comp, global_ctx)
    learned_template = learned_template_logit(
        comp=body_comp,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
        learned_priors=learned_priors,
    )
    learned_proposal = learned_proposal_logit(
        merged_comp=body_comp,
        body_comp=original_seed,
        body_score=body_score,
        upper_clusters=upper_clusters,
        rel_map=rel_map,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
        original_seed=original_seed,
        learned_priors=learned_priors,
    )
    rank_utility = learned_proposal_rank_utility(
        merged_comp=body_comp,
        body_comp=original_seed,
        body_score=body_score,
        upper_clusters=upper_clusters,
        rel_map=rel_map,
        global_ctx=global_ctx,
        semantic_model=semantic_model,
        original_seed=original_seed,
        learned_priors=learned_priors,
    )
    left = upper_clusters.get("left")
    right = upper_clusters.get("right")
    center = upper_clusters.get("center")
    top_count = len(upper_clusters)
    num_segments = len(body_comp.get("segment_ids", []))

    score = 0.0
    score += 0.75 * body_score
    score += 1.5 * min(horiz_elong / 4.2, 1.0)
    score += 0.9 * min(diag_rel / 0.30, 1.0)
    score += 0.8 * max(0.0, 0.75 - height_ratio) / 0.75
    score += 0.9 * max(0.0, lift + 0.03) / 0.18
    score += 0.6 * max(0.0, 0.12 - end_sym) / 0.12
    score += 0.6 * max(0.0, 0.34 - width_asym) / 0.34
    score += 1.2 * max(0.0, 0.035 - bottom_std) / 0.035
    score += 1.2 * max(0.0, 0.055 - bottom_range) / 0.055
    score += 1.1 * symmetry_score
    score += 0.45 * gong_semantic_bonus(body_comp, semantic_model)
    score += 0.60 * max(structural_score, -2.0) / 3.0
    score += 0.65 * max(0.0, learned_template) / 2.0
    score += 0.90 * max(0.0, learned_proposal) / 2.0
    score += 0.95 * max(0.0, rank_utility) / 2.0
    if top_count > 0:
        small_merge_penalty_scale = float(np.clip((6.0 - float(num_segments)) / 3.0, 0.0, 1.0))
        score -= 1.15 * small_merge_penalty_scale * max(0.0, -learned_proposal) / 2.0
    if learned_template < -2.4:
        score -= 0.35
    if learned_proposal < -3.2:
        score -= 0.10
    if rank_utility < -1.2:
        score -= 0.45
    elif rank_utility < 0.0:
        score -= 0.25 * max(0.0, -rank_utility) / 2.0

    if top_count == 0:
        score += 0.10
    if left is not None:
        score += 0.35 + 0.60 * left[2]
    if right is not None:
        score += 0.35 + 0.60 * right[2]
    if center is not None:
        score += 0.20 + 0.45 * center[2]

    if left is not None and right is not None:
        l_rel = rel_map[left[0][0]]
        r_rel = rel_map[right[0][0]]
        proj_gap = abs(abs(l_rel["along"]) - abs(r_rel["along"]))
        z_gap = abs(l_rel["z_delta"] - r_rel["z_delta"])
        score += 1.55 * max(0.0, 0.10 - proj_gap) / 0.10
        score += 1.20 * max(0.0, 0.10 - z_gap) / 0.10
        if center is not None:
            score += 0.55
    elif top_count >= 2 and (left is None or right is None):
        score -= 0.85
    elif center is not None and (left is None or right is None):
        score -= 1.40
    elif top_count == 1 and center is None:
        score -= 0.35

    if top_count > 3:
        score -= 1.8

    seed_horiz_elong = float(original_seed.get("horizontal_elongation", original_seed.get("elongation", 1.0)))
    seed_height_ratio = float(original_seed.get("height_ratio", 1.0))
    seed_diag_rel = component_diag_rel(original_seed, global_ctx)
    flat_same_layer_attach_count = 0
    structural_violation_count = 0
    for slot, value in upper_clusters.items():
        seg_ids, cluster_comp, slot_score = value
        cluster_rel_infos = [rel_map[sid] for sid in seg_ids]
        structural_violation_count += sum(
            1
            for info in cluster_rel_infos
            if not upper_dou_structural_law(original_seed, cluster_comp, info, global_ctx, slot=slot)
        )
        score += 0.25 * slot_score
        for sid in seg_ids:
            info = rel_map[sid]
            score += 0.60 * info["top_attach"]
            score += 0.45 * info["xy_overlap"]
            score += 0.35 * info["long_overlap"]
            score += 0.16 * max(0.0, float(info.get("learned_attach_logit", 0.0))) / 2.0
            if float(info.get("learned_attach_logit", 0.0)) < -2.4:
                score -= 0.16
            score -= 0.90 * info["bottom_attach"]
            score -= 0.80 * info["below_seed_bottom"]
            if (
                info.get("same_layer_topish", 0.0) > 0.5
                and info.get("above_seed_top", 0.0) < 0.25
                and info.get("top_attach", 0.0) < 0.05
                ):
                flat_same_layer_attach_count += 1

    score -= 0.90 * float(structural_violation_count)

    if flat_same_layer_attach_count > 0 and top_count > 0:
        small_same_layer_scale = float(np.clip((5.0 - float(num_segments)) / 2.0, 0.0, 1.0))
        score -= (
            3.00
            * float(flat_same_layer_attach_count)
            * small_same_layer_scale
            * max(0.0, -learned_proposal)
            / 2.0
        )

    score -= 1.8 * body_shape_preservation_penalty(original_seed, body_comp, global_ctx)
    score -= 2.2 * merged_downward_absorption_penalty(original_seed, body_comp, global_ctx)
    return float(score)


# ============================================================
# Layer-wise prototype assembly
# ============================================================

def select_symmetric_same_layer_end_pair(
    seed_cid: int,
    seed: Dict,
    layer_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
) -> Tuple[List[int], float]:
    seed_elong = float(seed.get("horizontal_elongation", seed.get("elongation", 1.0)))
    seed_height_ratio = float(seed.get("height_ratio", 1.0))
    if seed_elong < 6.0 or seed_height_ratio > 0.22:
        return [], 0.0

    seed_gong_bonus = gong_semantic_bonus(seed, semantic_model)
    seed_sym = component_side_symmetry_score(seed, global_ctx)
    candidates: List[Tuple[int, Dict[str, float]]] = []

    for cid in layer_ids:
        if cid == seed_cid:
            continue
        cand = raw_comps[cid]
        rel = describe_candidate_to_seed(seed, cand, global_ctx)
        if rel["same_layer_topish"] < 0.5:
            continue
        if rel["near_end"] < 0.5 or rel["endness"] < 0.72:
            continue
        if rel["centerish"] > 0.5:
            continue
        if rel["gap"] > 0.03:
            continue
        if rel["xy_overlap"] > 0.12:
            continue
        if rel["long_overlap"] < 0.70:
            continue
        if abs(rel["lateral"]) > 0.08:
            continue
        if is_base_dou_segment(cand, global_ctx):
            continue
        if component_diag_rel(cand, global_ctx) > 0.14:
            continue
        horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
        if horiz_elong > 2.2:
            continue
        candidates.append((cid, rel))

    best = None
    for left_id, left_rel in candidates:
        for right_id, right_rel in candidates:
            if left_id >= right_id:
                continue
            if left_rel["along"] * right_rel["along"] >= 0.0:
                continue

            trial_ids = sorted({seed_cid, left_id, right_id})
            merged = build_component_from_seg_ids(trial_ids, seg_by_id)
            shape_pen = body_shape_preservation_penalty(seed, merged, global_ctx)
            if shape_pen > 0.22:
                continue

            merged_bonus = gong_semantic_bonus(merged, semantic_model)
            merged_sym = component_side_symmetry_score(merged, global_ctx)
            along_gap = abs(abs(left_rel["along"]) - abs(right_rel["along"]))
            z_gap = abs(left_rel["z_delta"] - right_rel["z_delta"])
            top_gap = abs(left_rel["top_support"] - right_rel["top_support"])
            long_min = min(left_rel["long_overlap"], right_rel["long_overlap"])

            score = 0.0
            score += 1.3 * max(0.0, 0.10 - along_gap) / 0.10
            score += 1.0 * max(0.0, 0.10 - z_gap) / 0.10
            score += 0.7 * max(0.0, 0.45 - top_gap) / 0.45
            score += 0.7 * max(0.0, long_min - 0.70) / 0.30
            score += 1.2 * max(0.0, merged_sym - 0.55) / 0.45
            score += 0.9 * max(0.0, merged_bonus - seed_gong_bonus)
            score += 0.4 * max(0.0, merged_sym - seed_sym + 0.10) / 0.20
            score -= 2.0 * shape_pen

            if merged_bonus < seed_gong_bonus + 1.0:
                continue
            if merged_sym < seed_sym - 0.08:
                continue
            if score < 3.3:
                continue

            item = (float(score), [left_id, right_id])
            if best is None or item[0] > best[0]:
                best = item

    if best is None:
        return [], 0.0
    return best[1], float(best[0])


def select_same_layer_shoulder_pair(
    body_ids: List[int],
    body_comp: Dict,
    layer_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
) -> Tuple[List[int], float]:
    body_elong = float(body_comp.get("horizontal_elongation", body_comp.get("elongation", 1.0)))
    body_height_ratio = float(body_comp.get("height_ratio", 1.0))
    if len(body_ids) < 2 or body_elong < 3.0 or body_elong > 4.8 or body_height_ratio > 0.30:
        return [], 0.0

    body_sym = component_side_symmetry_score(body_comp, global_ctx)
    body_gong = gong_semantic_bonus(body_comp, semantic_model)
    candidates: List[Tuple[int, Dict[str, float]]] = []

    for cid in layer_ids:
        if cid in body_ids:
            continue
        cand = raw_comps[cid]
        rel = describe_candidate_to_seed(body_comp, cand, global_ctx)
        if rel["same_layer_topish"] < 0.5:
            continue
        if abs(rel["along"]) < 0.05 or abs(rel["along"]) > 0.28:
            continue
        if abs(rel["lateral"]) > 0.11:
            continue
        if rel["gap"] > 0.03:
            continue
        if is_base_dou_segment(cand, global_ctx):
            continue
        if component_diag_rel(cand, global_ctx) > 0.16:
            continue
        horiz_elong = float(cand.get("horizontal_elongation", cand.get("elongation", 1.0)))
        if horiz_elong > 1.9:
            continue
        candidates.append((cid, rel))

    best = None
    for a_id, a_rel in candidates:
        for b_id, b_rel in candidates:
            if a_id >= b_id:
                continue
            if a_rel["along"] * b_rel["along"] >= 0.0:
                continue

            trial_ids = sorted(set(body_ids + [a_id, b_id]))
            merged = build_component_from_seg_ids(trial_ids, seg_by_id)
            shape_pen = body_shape_preservation_penalty(body_comp, merged, global_ctx)
            down_pen = merged_downward_absorption_penalty(body_comp, merged, global_ctx)
            if shape_pen > 0.18 or down_pen > 0.10:
                continue

            merged_sym = component_side_symmetry_score(merged, global_ctx)
            merged_gong = gong_semantic_bonus(merged, semantic_model)
            sym_gain = merged_sym - body_sym
            gong_gain = merged_gong - body_gong

            if sym_gain < 0.08:
                continue
            if gong_gain < -0.12:
                continue

            along_gap = abs(abs(a_rel["along"]) - abs(b_rel["along"]))
            lateral_mean = 0.5 * (abs(a_rel["lateral"]) + abs(b_rel["lateral"]))

            score = 0.0
            score += 1.8 * sym_gain
            score += 0.9 * (gong_gain + 0.12)
            score += 0.8 * max(0.0, 0.16 - along_gap) / 0.16
            score += 0.4 * max(0.0, 0.11 - lateral_mean) / 0.11
            score -= 1.6 * shape_pen
            score -= 1.2 * down_pen

            if score < 0.84:
                continue

            item = (float(score), [a_id, b_id])
            if best is None or item[0] > best[0]:
                best = item

    if best is None:
        return [], 0.0
    return best[1], float(best[0])


def grow_body_from_existing_nucleus(
    nucleus_ids: List[int],
    nucleus_comp: Dict,
    layer_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
    learned_priors: Dict = None,
) -> Tuple[List[int], Dict, float]:
    chosen_ids = sorted(set(int(x) for x in nucleus_ids))
    current_body = nucleus_comp
    total_score = 0.0

    for _ in range(2):
        scores: List[Tuple[float, int]] = []
        for cid in layer_ids:
            if cid in chosen_ids:
                continue
            rel = describe_candidate_to_seed(current_body, raw_comps[cid], global_ctx)
            role, role_score = classify_candidate_role(
                current_body, raw_comps[cid], rel, primary_axis, global_ctx, semantic_model
            )
            if role == "upper_dou" and role_score >= 1.1:
                continue
            s = score_body_extension(
                current_body,
                raw_comps[cid],
                rel,
                primary_axis,
                global_ctx,
                semantic_model=semantic_model,
                learned_priors=learned_priors,
            )
            if s > 1.35:
                scores.append((float(s), cid))

        if not scores:
            break
        scores.sort(reverse=True)

        added = False
        for s, cid in scores:
            trial_ids = sorted(set(chosen_ids + [cid]))
            trial_merged = build_component_from_seg_ids(trial_ids, seg_by_id)
            rel = describe_candidate_to_seed(current_body, raw_comps[cid], global_ctx)
            if not body_extension_merge_gate(
                current_body=current_body,
                cand=raw_comps[cid],
                merged=trial_merged,
                rel=rel,
                primary_axis=primary_axis,
                global_ctx=global_ctx,
                semantic_model=semantic_model,
            ):
                continue
            if body_shape_preservation_penalty(current_body, trial_merged, global_ctx) > 0.42:
                continue
            if merged_downward_absorption_penalty(current_body, trial_merged, global_ctx) > 0.12:
                continue
            chosen_ids = trial_ids
            current_body = trial_merged
            total_score += float(s)
            added = True
            break

        if not added:
            break

    shoulder_pair_ids, shoulder_pair_score = select_same_layer_shoulder_pair(
        body_ids=chosen_ids,
        body_comp=current_body,
        layer_ids=layer_ids,
        raw_comps=raw_comps,
        global_ctx=global_ctx,
        seg_by_id=seg_by_id,
        semantic_model=semantic_model,
    )
    if shoulder_pair_ids:
        chosen_ids = sorted(set(chosen_ids + shoulder_pair_ids))
        current_body = build_component_from_seg_ids(chosen_ids, seg_by_id)
        total_score += float(shoulder_pair_score)

    return chosen_ids, current_body, total_score


def generate_same_layer_body_pair_candidates(
    layer_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
) -> List[Dict]:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    pair_items: List[Dict] = []

    for a_id, b_id in combinations(sorted(layer_ids), 2):
        a = raw_comps[a_id]
        b = raw_comps[b_id]

        if is_base_dou_segment(a, global_ctx) or is_base_dou_segment(b, global_ctx):
            continue
        if component_axis_alignment(a, primary_axis) < 0.78 or component_axis_alignment(b, primary_axis) < 0.78:
            continue

        a_vert = float((a["bbox_max"][2] - a["bbox_min"][2]) / gh)
        b_vert = float((b["bbox_max"][2] - b["bbox_min"][2]) / gh)
        if a_vert > 0.24 or b_vert > 0.24:
            continue

        rel_ab = describe_candidate_to_seed(a, b, global_ctx)
        rel_ba = describe_candidate_to_seed(b, a, global_ctx)
        if rel_ab["same_layer_topish"] < 0.5 or rel_ba["same_layer_topish"] < 0.5:
            continue
        if abs(rel_ab["lateral"]) > 0.08:
            continue
        if abs(rel_ab["along"]) < 0.035 or abs(rel_ab["along"]) > 0.30:
            continue
        if rel_ab["gap"] > 0.06 and rel_ab["xy_overlap"] < 0.08:
            continue
        if rel_ab["bottom_attach"] > 0.16 or rel_ba["bottom_attach"] > 0.16:
            continue
        if rel_ab["below_seed_bottom"] > 0.22 or rel_ba["below_seed_bottom"] > 0.22:
            continue
        if is_blocky_dou_segment(a, global_ctx) and is_blocky_dou_segment(b, global_ctx):
            continue

        merged = build_component_from_seg_ids([a_id, b_id], seg_by_id)
        merged_body_score = score_body_candidate(merged, primary_axis, global_ctx, semantic_model)
        if merged_body_score <= -1e8:
            continue

        score_a = score_body_candidate(a, primary_axis, global_ctx, semantic_model)
        score_b = score_body_candidate(b, primary_axis, global_ctx, semantic_model)
        valid_single_scores = [s for s in [score_a, score_b] if s > -1e8]
        best_single = max(valid_single_scores) if valid_single_scores else 0.0
        improvement = float(merged_body_score - best_single)
        if valid_single_scores and improvement < 0.18:
            continue

        merged_gong = gong_semantic_bonus(merged, semantic_model)
        merged_sym = component_side_symmetry_score(merged, global_ctx)
        best_single_gong = max(gong_semantic_bonus(a, semantic_model), gong_semantic_bonus(b, semantic_model))
        best_single_sym = max(component_side_symmetry_score(a, global_ctx), component_side_symmetry_score(b, global_ctx))
        sem_gain = float(merged_gong - best_single_gong)
        sym_gain = float(merged_sym - best_single_sym)
        if sem_gain < -0.10:
            continue
        if merged_sym < best_single_sym - 0.08:
            continue

        shape_pen = max(
            body_shape_preservation_penalty(a, merged, global_ctx),
            body_shape_preservation_penalty(b, merged, global_ctx),
        )
        down_pen = max(
            merged_downward_absorption_penalty(a, merged, global_ctx),
            merged_downward_absorption_penalty(b, merged, global_ctx),
        )
        if shape_pen > 0.40 or down_pen > 0.08:
            continue

        pair_bonus = 0.0
        pair_bonus += 0.95 * max(0.0, improvement + 0.08)
        pair_bonus += 0.75 * max(0.0, sem_gain + 0.08)
        pair_bonus += 0.70 * max(0.0, sym_gain + 0.08)
        pair_bonus += 0.55 * max(0.0, 0.08 - abs(rel_ab["lateral"])) / 0.08
        pair_bonus += 0.45 * max(0.0, 0.06 - rel_ab["gap"]) / 0.06
        pair_bonus += 0.35 * max(0.0, 0.16 - abs(abs(rel_ab["along"]) - 0.11)) / 0.16
        pair_bonus -= 1.6 * shape_pen
        pair_bonus -= 1.2 * down_pen

        if pair_bonus < 0.85:
            continue

        pair_items.append({
            "kind": "pair",
            "body_ids": [int(a_id), int(b_id)],
            "seed_comp": merged,
            "body_score": float(merged_body_score),
            "pair_bonus": float(pair_bonus),
        })

    pair_items.sort(key=lambda item: item["body_score"] + 0.30 * item["pair_bonus"], reverse=True)
    return pair_items


def build_body_with_extensions(
    seed_cid: int,
    seed: Dict,
    layer_ids: List[int],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
    primary_axis: np.ndarray,
    seg_by_id: Dict[int, Segment],
    semantic_model: Dict = None,
    learned_priors: Dict = None,
) -> Tuple[List[int], Dict, float]:
    chosen_ids = [seed_cid]
    scores: List[Tuple[float, int]] = []

    for cid in layer_ids:
        if cid == seed_cid:
            continue
        rel = describe_candidate_to_seed(seed, raw_comps[cid], global_ctx)
        role, role_score = classify_candidate_role(
            seed, raw_comps[cid], rel, primary_axis, global_ctx, semantic_model
        )
        if role == "upper_dou" and role_score >= 1.1:
            continue
        s = score_body_extension(
            seed,
            raw_comps[cid],
            rel,
            primary_axis,
            global_ctx,
            semantic_model=semantic_model,
            learned_priors=learned_priors,
        )
        if s > 1.3:
            scores.append((s, cid))

    scores.sort(reverse=True)
    total_score = 0.0
    for s, cid in scores:
        if len(chosen_ids) >= 3:
            break
        trial_ids = sorted(set(chosen_ids + [cid]))
        trial_merged = build_component_from_seg_ids(trial_ids, seg_by_id)
        rel = describe_candidate_to_seed(seed, raw_comps[cid], global_ctx)
        if not body_extension_merge_gate(
            current_body=seed,
            cand=raw_comps[cid],
            merged=trial_merged,
            rel=rel,
            primary_axis=primary_axis,
            global_ctx=global_ctx,
            semantic_model=semantic_model,
        ):
            continue
        if body_shape_preservation_penalty(seed, trial_merged, global_ctx) > 0.55:
            continue
        chosen_ids = trial_ids
        total_score += float(s)

    end_pair_ids, end_pair_score = select_symmetric_same_layer_end_pair(
        seed_cid=seed_cid,
        seed=seed,
        layer_ids=layer_ids,
        raw_comps=raw_comps,
        global_ctx=global_ctx,
        seg_by_id=seg_by_id,
        semantic_model=semantic_model,
    )
    if end_pair_ids:
        pair_ids = sorted(set([seed_cid] + end_pair_ids))
        pair_merged = build_component_from_seg_ids(pair_ids, seg_by_id)
        pair_quality = (
            1.3 * gong_semantic_bonus(pair_merged, semantic_model)
            + 1.1 * component_side_symmetry_score(pair_merged, global_ctx)
            - 2.0 * body_shape_preservation_penalty(seed, pair_merged, global_ctx)
        )

        current_merged = build_component_from_seg_ids(sorted(set(chosen_ids)), seg_by_id)
        current_quality = (
            1.3 * gong_semantic_bonus(current_merged, semantic_model)
            + 1.1 * component_side_symmetry_score(current_merged, global_ctx)
            - 2.0 * body_shape_preservation_penalty(seed, current_merged, global_ctx)
        )

        if len(chosen_ids) == 1 or pair_quality > current_quality + 0.55:
            chosen_ids = pair_ids
            total_score = float(end_pair_score)

    current_body = build_component_from_seg_ids(sorted(set(chosen_ids)), seg_by_id)
    shoulder_pair_ids, shoulder_pair_score = select_same_layer_shoulder_pair(
        body_ids=sorted(set(chosen_ids)),
        body_comp=current_body,
        layer_ids=layer_ids,
        raw_comps=raw_comps,
        global_ctx=global_ctx,
        seg_by_id=seg_by_id,
        semantic_model=semantic_model,
    )
    if shoulder_pair_ids:
        chosen_ids = sorted(set(chosen_ids + shoulder_pair_ids))
        total_score += float(shoulder_pair_score)

    merged = build_component_from_seg_ids(sorted(set(chosen_ids)), seg_by_id)
    return sorted(set(chosen_ids)), merged, total_score


def layerwise_gong_prototype_map(
    segments: List[Segment],
    semantic_model: Dict = None,
    learned_priors: Dict = None,
) -> Dict[int, int]:
    if not segments:
        return {}

    seg_by_id = {s.seg_id: s for s in segments}
    raw_map = singleton_component_map(segments)
    raw_comps = base.build_components_from_map(raw_map, segments)
    raw_ctx = base.compute_global_component_context(raw_comps)
    layers = cluster_layers(sorted(raw_comps.keys()), raw_comps, raw_ctx)

    prototypes: List[Tuple[float, List[int]]] = []

    for layer_idx, layer in enumerate(layers):
        for _, primary_axis in canonical_planar_axes():
            for lane_ids in cluster_parallel_lanes(layer, raw_comps, primary_axis, raw_ctx):
                lane_seed_scores: List[Tuple[float, int, Dict]] = []
                for cid in lane_ids:
                    comp = raw_comps[cid]
                    body_score = score_body_candidate(comp, primary_axis, raw_ctx, semantic_model)
                    if body_score > -1e8:
                        lane_seed_scores.append((body_score, cid, comp))
                lane_seed_scores.sort(reverse=True)
                nucleus_candidates: List[Dict] = [
                    {
                        "kind": "single",
                        "seed_cid": int(cid),
                        "body_ids": [int(cid)],
                        "seed_comp": comp,
                        "body_score": float(body_score),
                        "pair_bonus": 0.0,
                    }
                    for body_score, cid, comp in lane_seed_scores[:5]
                ]
                nucleus_candidates.extend(
                    generate_same_layer_body_pair_candidates(
                        layer_ids=lane_ids,
                        raw_comps=raw_comps,
                        global_ctx=raw_ctx,
                        primary_axis=primary_axis,
                        seg_by_id=seg_by_id,
                        semantic_model=semantic_model,
                    )[:4]
                )

                for nucleus in nucleus_candidates:
                    raised_candidate_ids = set(lane_ids)
                    if layer_idx > 0:
                        raised_candidate_ids.update(
                            upper_layer_candidates_for_lane(
                                lane_ids=nucleus["body_ids"],
                                upper_layer_ids=layers[layer_idx - 1],
                                comps=raw_comps,
                                primary_axis=primary_axis,
                                global_ctx=raw_ctx,
                            )
                        )
                    if layer_idx + 1 < len(layers):
                        raised_candidate_ids.update(
                            upper_layer_candidates_for_lane(
                                lane_ids=nucleus["body_ids"],
                                upper_layer_ids=layers[layer_idx + 1],
                                comps=raw_comps,
                                primary_axis=primary_axis,
                                global_ctx=raw_ctx,
                            )
                        )

                    if nucleus["kind"] == "single":
                        seed_cid = int(nucleus["seed_cid"])
                        seed = nucleus["seed_comp"]
                        body_ids, merged_body_seed, ext_score = build_body_with_extensions(
                            seed_cid=seed_cid,
                            seed=seed,
                            layer_ids=lane_ids,
                            raw_comps=raw_comps,
                            global_ctx=raw_ctx,
                            primary_axis=primary_axis,
                            seg_by_id=seg_by_id,
                            semantic_model=semantic_model,
                            learned_priors=learned_priors,
                        )
                        if len(body_ids) == 1:
                            end_pair_ids, end_pair_score = select_symmetric_same_layer_end_pair(
                                seed_cid=seed_cid,
                                seed=seed,
                                layer_ids=lane_ids,
                                raw_comps=raw_comps,
                                global_ctx=raw_ctx,
                                seg_by_id=seg_by_id,
                                semantic_model=semantic_model,
                            )
                            if end_pair_ids:
                                body_ids = sorted(set(body_ids + end_pair_ids))
                                merged_body_seed = build_component_from_seg_ids(body_ids, seg_by_id)
                                ext_score += float(end_pair_score)
                        body_ids, merged_body_seed, raised_ext_score = grow_body_with_raised_segments(
                            body_ids=body_ids,
                            body_comp=merged_body_seed,
                            candidate_ids=sorted(raised_candidate_ids),
                            raw_comps=raw_comps,
                            global_ctx=raw_ctx,
                            primary_axis=primary_axis,
                            seg_by_id=seg_by_id,
                            semantic_model=semantic_model,
                        )
                        body_total_score = float(nucleus["body_score"]) + 0.35 * ext_score
                        body_total_score += 0.18 * raised_ext_score
                    else:
                        body_ids, merged_body_seed, ext_score = grow_body_from_existing_nucleus(
                            nucleus_ids=nucleus["body_ids"],
                            nucleus_comp=nucleus["seed_comp"],
                            layer_ids=lane_ids,
                            raw_comps=raw_comps,
                            global_ctx=raw_ctx,
                            primary_axis=primary_axis,
                            seg_by_id=seg_by_id,
                            semantic_model=semantic_model,
                            learned_priors=learned_priors,
                        )
                        body_ids, merged_body_seed, raised_ext_score = grow_body_with_raised_segments(
                            body_ids=body_ids,
                            body_comp=merged_body_seed,
                            candidate_ids=sorted(raised_candidate_ids),
                            raw_comps=raw_comps,
                            global_ctx=raw_ctx,
                            primary_axis=primary_axis,
                            seg_by_id=seg_by_id,
                            semantic_model=semantic_model,
                        )
                        body_total_score = (
                            float(nucleus["body_score"])
                            + 0.30 * float(nucleus["pair_bonus"])
                            + 0.25 * ext_score
                        )
                        body_total_score += 0.18 * raised_ext_score

                    candidate_pool = set(cid for cid in lane_ids if cid not in body_ids)
                    if layer_idx + 1 < len(layers):
                        candidate_pool.update(
                            upper_layer_candidates_for_lane(
                                lane_ids=body_ids if body_ids else lane_ids,
                                upper_layer_ids=layers[layer_idx + 1],
                                comps=raw_comps,
                                primary_axis=primary_axis,
                                global_ctx=raw_ctx,
                            )
                        )

                    combos: List[List[str]] = [
                        [],
                        ["left"],
                        ["right"],
                        ["left", "right"],
                        ["left", "right", "center"],
                    ]

                    best_single = None
                    best_non_single = None
                    _, best_upper_slots, rel_map, role_map = select_best_upper_clusters(
                        seed=merged_body_seed,
                        candidate_ids=sorted(candidate_pool),
                        raw_comps=raw_comps,
                        global_ctx=raw_ctx,
                        seg_by_id=seg_by_id,
                        primary_axis=primary_axis,
                        semantic_model=semantic_model,
                        learned_priors=learned_priors,
                    )

                    for combo in combos:
                        if any(slot not in best_upper_slots for slot in combo):
                            continue

                        combo_ids = list(body_ids)
                        upper_clusters: Dict[str, Tuple[List[int], Dict, float]] = {}
                        for slot in combo:
                            subset_ids, merged_cluster, slot_score = best_upper_slots[slot]
                            combo_ids.extend(subset_ids)
                            upper_clusters[slot] = (subset_ids, merged_cluster, slot_score)

                        combo_ids = sorted(set(combo_ids))
                        merged = build_component_from_seg_ids(combo_ids, seg_by_id)

                        merged_score = gong_template_score(
                            body_comp=merged,
                            body_score=body_total_score,
                            upper_clusters=upper_clusters,
                            rel_map=rel_map,
                            role_map=role_map,
                            global_ctx=raw_ctx,
                            semantic_model=semantic_model,
                            original_seed=merged_body_seed,
                            learned_priors=learned_priors,
                        )

                        if len(combo_ids) == 1:
                            if best_single is None or merged_score > best_single[0]:
                                best_single = (merged_score, combo_ids)
                        else:
                            if best_non_single is None or merged_score > best_non_single[0]:
                                best_non_single = (merged_score, combo_ids)

                    best = best_non_single
                    if best_single is not None:
                        if best_non_single is None:
                            best = best_single
                        elif best_single[0] >= best_non_single[0] + 1.5:
                            best = best_single

                    if best is None:
                        continue
                    score, combo_ids = best
                    if score < 4.2:
                        continue
                    prototypes.append((score, combo_ids))

    prototypes.sort(key=lambda item: item[0], reverse=True)

    assigned: Dict[int, int] = {}
    used: Set[int] = set()
    next_cid = 0
    for score, seg_ids in prototypes:
        unique_seg_ids = [sid for sid in seg_ids if sid not in used]
        if len(unique_seg_ids) != len(seg_ids):
            continue
        if len(seg_ids) == 1:
            comp = build_component_from_seg_ids(seg_ids, seg_by_id)
            horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
            height_ratio = float(comp.get("height_ratio", 1.0))
            diag_rel = component_diag_rel(comp, raw_ctx)
            sym = component_side_symmetry_score(comp, raw_ctx)
            bottom_std, bottom_range = component_bottom_profile_stats(comp, raw_ctx)
            structural_score = gong_body_structural_score(comp, raw_ctx)
            gong_bonus = gong_semantic_bonus(comp, semantic_model)
            strong_semantic_singleton = (
                score >= 14.5
                and diag_rel >= 0.32
                and horiz_elong >= 3.8
                and height_ratio <= 0.22
                and sym >= 0.52
                and bottom_range <= 0.070
                and gong_bonus >= 0.8
            )
            strong_geometric_singleton = (
                score >= 14.6
                and diag_rel >= 0.48
                and horiz_elong >= 5.2
                and height_ratio <= 0.16
                and sym >= 0.78
                and bottom_std <= 0.020
                and bottom_range <= 0.040
                and structural_score >= 0.85
            )
            if not (strong_semantic_singleton or strong_geometric_singleton):
                continue
        elif len(seg_ids) <= 1:
            continue
        for sid in seg_ids:
            assigned[sid] = next_cid
            used.add(sid)
        next_cid += 1

    return base.relabel_components(assigned)


def build_z_attachment_clusters(
    sign_items: List[Tuple[float, int, Dict[str, float]]],
    raw_comps: Dict[int, Dict],
    global_ctx: Dict,
) -> List[Tuple[float, List[int]]]:
    if not sign_items:
        return []

    rel_map = {cid: rel for _, cid, rel in sign_items}
    score_map = {cid: score for score, cid, _ in sign_items}
    ids = [cid for _, cid, _ in sign_items]
    clusters: List[List[int]] = []
    visited: Set[int] = set()
    gd = max(float(global_ctx["global_diag"][0]), 1e-8)

    for start in ids:
        if start in visited:
            continue
        queue = [start]
        visited.add(start)
        cluster = [start]
        while queue:
            cur = queue.pop()
            for other in ids:
                if other in visited:
                    continue
                gap = float(base.bbox_gap(
                    raw_comps[cur]["bbox_min"], raw_comps[cur]["bbox_max"],
                    raw_comps[other]["bbox_min"], raw_comps[other]["bbox_max"],
                ) / gd)
                z_gap = abs(float(rel_map[cur]["z_delta"]) - float(rel_map[other]["z_delta"]))
                if gap <= 0.08 and z_gap <= 0.18:
                    visited.add(other)
                    queue.append(other)
                    cluster.append(other)
        clusters.append(sorted(cluster))

    out: List[Tuple[float, List[int]]] = []
    for cluster_ids in clusters:
        cluster_score = float(np.mean([score_map[cid] for cid in cluster_ids]) + 0.20 * (len(cluster_ids) - 1))
        out.append((cluster_score, cluster_ids))
    out.sort(reverse=True)
    return out


def z_oriented_gong_prototype_map(
    segments: List[Segment],
    semantic_model: Dict = None,
    context_segments: Optional[List[Segment]] = None,
    learned_priors: Dict = None,
) -> Dict[int, int]:
    if not segments:
        return {}

    seg_by_id = {s.seg_id: s for s in segments}
    raw_map = singleton_component_map(segments)
    raw_comps = base.build_components_from_map(raw_map, segments)
    ctx_segments = context_segments if context_segments else segments
    ctx_map = singleton_component_map(ctx_segments)
    ctx_comps = base.build_components_from_map(ctx_map, ctx_segments)
    raw_ctx = base.compute_global_component_context(ctx_comps)

    seed_candidates: List[Tuple[float, int, Dict]] = []
    for cid, comp in raw_comps.items():
        body_score = score_z_gong_body_candidate(comp, raw_ctx, semantic_model)
        if body_score > -1e8:
            seed_candidates.append((body_score, cid, comp))
    seed_candidates.sort(reverse=True)

    prototypes: List[Tuple[float, List[int]]] = []
    for body_score, seed_cid, seed in seed_candidates[:8]:
        sign_groups: Dict[int, List[Tuple[float, int, Dict[str, float]]]] = {1: [], -1: []}
        for cid, cand in raw_comps.items():
            if cid == seed_cid:
                continue
            rel = describe_candidate_to_seed(seed, cand, raw_ctx)
            attach_score = score_z_gong_attachment_candidate(seed, cand, rel, raw_ctx, semantic_model)
            if attach_score <= 1.55:
                continue
            sign = 1 if rel["along"] >= 0.0 else -1
            sign_groups[sign].append((attach_score, cid, rel))

        best = None
        for sign_items in sign_groups.values():
            if len(sign_items) < 2:
                continue
            sign_items.sort(reverse=True)
            sign_items = sign_items[:6]
            rel_map = {cid: rel for _, cid, rel in sign_items}
            score_map = {cid: attach_score for attach_score, cid, _ in sign_items}
            clusters = build_z_attachment_clusters(sign_items, raw_comps, raw_ctx)
            if len(clusters) < 2:
                continue
            max_group = min(3, len(clusters))
            for size in range(2, max_group + 1):
                for cluster_subset in combinations(clusters, size):
                    subset = sorted({cid for _, cluster_ids in cluster_subset for cid in cluster_ids})
                    rel_infos = [rel_map[cid] for cid in subset]
                    z_vals = [float(r["z_delta"]) for r in rel_infos]
                    if max(z_vals) - min(z_vals) < 0.28:
                        continue
                    merged = build_component_from_seg_ids([seed_cid] + list(subset), seg_by_id)
                    template_score = score_z_gong_template(
                        seed=seed,
                        merged=merged,
                        body_score=body_score,
                        attachment_scores=[score_map[cid] for cid in subset],
                        rel_infos=rel_infos,
                        global_ctx=raw_ctx,
                        semantic_model=semantic_model,
                    )
                    if size == 3:
                        template_score += 0.35
                    if template_score < 5.2:
                        continue
                    item = (float(template_score), [seed_cid] + list(subset))
                    if best is None or item[0] > best[0]:
                        best = item
        if best is not None:
            prototypes.append(best)

    prototypes.sort(key=lambda item: item[0], reverse=True)

    assigned: Dict[int, int] = {}
    used: Set[int] = set()
    next_cid = 0
    for score, seg_ids in prototypes:
        unique_seg_ids = [sid for sid in seg_ids if sid not in used]
        if len(unique_seg_ids) != len(seg_ids):
            continue
        if len(seg_ids) <= 2:
            continue
        for sid in seg_ids:
            assigned[sid] = next_cid
            used.add(sid)
        next_cid += 1

    return base.relabel_components(assigned)


# ============================================================
# Merge maps
# ============================================================

def merge_partial_maps(segments: List[Segment], partial_maps: List[Dict[int, int]]) -> Dict[int, int]:
    merged: Dict[int, int] = {}
    next_cid = 0
    for partial in partial_maps:
        groups: Dict[int, List[int]] = {}
        for seg_id, cid in partial.items():
            if seg_id in merged:
                continue
            groups.setdefault(cid, []).append(seg_id)
        for _, seg_ids in sorted(groups.items(), key=lambda kv: (len(kv[1]), kv[0]), reverse=True):
            for seg_id in seg_ids:
                merged[seg_id] = next_cid
            next_cid += 1
    for seg in segments:
        if seg.seg_id not in merged:
            merged[seg.seg_id] = next_cid
            next_cid += 1
    return base.relabel_components(merged)


def build_augmented_edges(
    segments: List[Segment],
    global_diag: float,
    neighbor_ratio: float,
    contact_eps: float,
) -> Tuple[List[Tuple[int, int]], List[Dict[str, float]]]:
    edges, feats = base.build_edges(
        segments,
        global_diag=global_diag,
        neighbor_ratio=neighbor_ratio,
        contact_eps=contact_eps,
    )
    existing = {tuple(sorted((int(a), int(b)))) for a, b in edges}

    raw_map = singleton_component_map(segments)
    raw_comps = base.build_components_from_map(raw_map, segments)
    raw_ctx = base.compute_global_component_context(raw_comps)
    layers = cluster_layers(sorted(raw_comps.keys()), raw_comps, raw_ctx)
    comp_to_layer: Dict[int, int] = {}
    for layer_idx, layer in enumerate(layers):
        for cid in layer:
            comp_to_layer[int(cid)] = int(layer_idx)

    seg_by_id = {int(s.seg_id): s for s in segments}
    ids = sorted(raw_comps.keys())

    for i, a_id in enumerate(ids):
        a = raw_comps[a_id]
        for b_id in ids[i + 1:]:
            key = tuple(sorted((int(a_id), int(b_id))))
            if key in existing:
                continue

            b = raw_comps[b_id]
            layer_gap = abs(comp_to_layer.get(int(a_id), 0) - comp_to_layer.get(int(b_id), 0))
            if layer_gap > 1:
                continue

            rel_ab = describe_candidate_to_seed(a, b, raw_ctx)
            rel_ba = describe_candidate_to_seed(b, a, raw_ctx)
            min_gap = min(float(rel_ab["gap"]), float(rel_ba["gap"]))
            max_xy_overlap = max(float(rel_ab["xy_overlap"]), float(rel_ba["xy_overlap"]))
            max_long_overlap = max(float(rel_ab["long_overlap"]), float(rel_ba["long_overlap"]))
            same_layer_topish = max(float(rel_ab["same_layer_topish"]), float(rel_ba["same_layer_topish"]))
            vertical_attach = max(float(rel_ab["above_seed_top"]), float(rel_ba["above_seed_top"]))
            end_attach = max(
                float(rel_ab["near_end"]) * float(rel_ab["top_support"]),
                float(rel_ba["near_end"]) * float(rel_ba["top_support"]),
            )
            small_block_pair = bool(
                (component_diag_rel(a, raw_ctx) <= 0.16 and component_diag_rel(b, raw_ctx) <= 0.40)
                or (component_diag_rel(b, raw_ctx) <= 0.16 and component_diag_rel(a, raw_ctx) <= 0.40)
            )

            if min_gap > 0.24:
                continue
            if not (
                max_xy_overlap >= 0.08
                or max_long_overlap >= 0.52
                or same_layer_topish > 0.5
                or vertical_attach > 0.5
                or end_attach >= 0.18
            ):
                continue
            if layer_gap == 1 and not (vertical_attach > 0.5 or end_attach >= 0.18):
                continue
            if max_xy_overlap < 0.05 and max_long_overlap < 0.42 and not small_block_pair:
                continue

            edges.append((int(a_id), int(b_id)))
            feats.append(base.edge_features(seg_by_id[int(a_id)], seg_by_id[int(b_id)], contact_eps, global_diag))
            existing.add(key)

    return edges, feats


def fuse_edge_scores(
    base_scores: np.ndarray,
    x: np.ndarray,
    feature_names: List[str],
    manual_edge_calibrator: Dict,
) -> np.ndarray:
    if x.shape[0] == 0 or not manual_edge_calibrator:
        return base_scores

    calib_names = manual_edge_calibrator.get("feature_names", [])
    if calib_names and list(calib_names) != list(feature_names):
        return base_scores

    manual_scores = base.score_edges(x, manual_edge_calibrator)
    return base_scores + 0.30 * manual_scores


def upper_dou_slot_name(seed: Dict, cand: Dict, global_ctx: Dict) -> str:
    rel = describe_candidate_to_seed(seed, cand, global_ctx)
    seed_half = max(0.5 * float(seed["long_span"]), 1e-8)
    along_norm = float(rel["along"] * max(float(global_ctx["global_diag"][0]), 1e-8) / seed_half)
    if abs(along_norm) <= 0.34:
        return "center"
    return "left" if along_norm < 0.0 else "right"


def is_strong_gong_host_for_upper_dou(big: Dict, global_ctx: Dict, semantic_model: Dict) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
    diag_rel = component_diag_rel(big, global_ctx)
    vertical_ratio = float((big["bbox_max"][2] - big["bbox_min"][2]) / gh)
    sym = component_side_symmetry_score(big, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(big, global_ctx)
    structural_score = gong_body_structural_score(big, global_ctx)
    host_gong = gong_semantic_bonus(big, semantic_model)
    strong_geometric_host = (
        diag_rel >= 0.42
        and horiz_elong >= 4.8
        and vertical_ratio <= 0.18
        and sym >= 0.78
        and bottom_std <= 0.020
        and bottom_range <= 0.040
        and structural_score >= 0.85
    )
    return bool(
        0.20 <= diag_rel <= 0.78
        and horiz_elong >= 2.45
        and vertical_ratio <= 0.24
        and sym >= 0.52
        and bottom_std <= 0.060
        and bottom_range <= 0.085
        and (host_gong >= 1.10 or strong_geometric_host)
    )


def is_relaxed_gong_host_for_upper_dou(big: Dict, global_ctx: Dict, semantic_model: Dict) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
    diag_rel = component_diag_rel(big, global_ctx)
    vertical_ratio = float((big["bbox_max"][2] - big["bbox_min"][2]) / gh)
    sym = component_side_symmetry_score(big, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(big, global_ctx)
    structural_score = gong_body_structural_score(big, global_ctx)
    host_gong = gong_semantic_bonus(big, semantic_model)
    return bool(
        0.18 <= diag_rel <= 0.80
        and horiz_elong >= 2.20
        and vertical_ratio <= 0.32
        and bottom_std <= 0.085
        and bottom_range <= 0.12
        and (host_gong >= 0.4 or structural_score >= 1.4 or (sym >= 0.46 and horiz_elong >= 2.6))
    )


def max_upper_dou_slots_for_host(big: Dict, global_ctx: Dict, semantic_model: Dict) -> int:
    horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
    sym = component_side_symmetry_score(big, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(big, global_ctx)
    structural_score = gong_body_structural_score(big, global_ctx)
    host_gong = gong_semantic_bonus(big, semantic_model)
    strong_geometric_host = (
        horiz_elong >= 4.8
        and sym >= 0.78
        and bottom_std <= 0.020
        and bottom_range <= 0.040
        and structural_score >= 0.85
    )
    if strong_geometric_host:
        return 3
    if host_gong >= 2.8 and sym >= 0.74 and bottom_range <= 0.055 and horiz_elong >= 2.8:
        return 3
    if host_gong >= 2.0 and sym >= 0.60 and bottom_range <= 0.070 and horiz_elong >= 2.6:
        return 2
    return 1


def score_upper_dou_host_attachment(
    big: Dict,
    small: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
    sym = component_side_symmetry_score(big, global_ctx)
    bottom_std, bottom_range = component_bottom_profile_stats(big, global_ctx)
    host_gong = gong_semantic_bonus(big, semantic_model)
    small_dou = dou_semantic_bonus(small, semantic_model)
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    top_gap_abs = abs(float(small["bbox_min"][2] - big["bbox_max"][2])) / gh
    slot = upper_dou_slot_name(big, small, global_ctx)

    score = 0.0
    score += 2.6 * rel["top_support"]
    score += 1.8 * rel["xy_overlap"]
    score += 0.9 * rel["long_overlap"]
    score += 0.6 * rel["same_layer_topish"]
    score += 0.5 * rel["above_seed_top"]
    score += 0.7 * max(0.0, 0.22 - rel["gap"]) / 0.22
    score += 0.55 * max(0.0, host_gong)
    score += 0.30 * max(0.0, small_dou)
    score += 0.35 * max(0.0, min(horiz_elong, 4.2) - 2.4)
    score += 0.45 * sym
    score += 0.35 * max(0.0, 0.065 - bottom_range) / 0.065
    score += 0.15 * max(0.0, 0.030 - bottom_std) / 0.030
    score += 1.45 * max(0.0, 0.050 - top_gap_abs) / 0.050
    score -= 0.8 * rel["bottom_attach"]
    score -= 1.2 * rel["below_seed_bottom"]
    score -= 0.45 * max(0.0, abs(rel["lateral"]) - 0.055) / 0.055
    if slot == "center":
        score += 0.35 * rel["centerish"]
        score -= 0.30 * max(0.0, rel["near_end"] - 0.5) / 0.5
    else:
        score += 0.30 * rel["near_end"]
        score -= 0.25 * max(0.0, rel["centerish"] - 0.5) / 0.5
    return float(score)


def score_relaxed_upper_dou_host_attachment(
    big: Dict,
    small: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    score = score_upper_dou_host_attachment(big, small, rel, global_ctx, semantic_model)
    if score <= -1e8:
        return score
    score += 0.8 * rel["long_overlap"]
    score += 0.4 * max(0.0, 0.18 - abs(rel["lateral"])) / 0.18
    score += 0.4 * max(0.0, 0.14 - rel["gap"]) / 0.14
    score += 0.35 * max(0.0, gong_body_structural_score(big, global_ctx))
    score -= 0.6 * max(0.0, 0.18 - rel["xy_overlap"]) / 0.18
    return float(score)


def host_is_shadowed_by_higher_candidate(
    big_id: int,
    big: Dict,
    small: Dict,
    rel: Dict[str, float],
    comps: Dict[int, Dict],
    global_ctx: Dict,
    semantic_model: Dict,
) -> bool:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    my_top_gap = abs(float(small["bbox_min"][2] - big["bbox_max"][2])) / gh
    my_slot = upper_dou_slot_name(big, small, global_ctx)

    for other_id, other in comps.items():
        if other_id == big_id:
            continue
        if not is_strong_gong_host_for_upper_dou(other, global_ctx, semantic_model):
            continue
        if float(other["bbox_max"][2]) <= float(big["bbox_max"][2]) + 0.025 * gh:
            continue

        other_rel = describe_candidate_to_seed(other, small, global_ctx)
        if other_rel["below_seed_bottom"] > 0.22:
            continue
        if other_rel["bottom_attach"] > 0.22:
            continue
        if other_rel["gap"] > 0.18:
            continue
        if other_rel["same_layer_topish"] < 0.5 and other_rel["above_seed_top"] < 0.5:
            continue
        if other_rel["xy_overlap"] < max(0.18, rel["xy_overlap"] - 0.12) and other_rel["long_overlap"] < max(0.74, rel["long_overlap"] - 0.10):
            continue

        other_slot = upper_dou_slot_name(other, small, global_ctx)
        if other_slot != my_slot:
            continue

        other_top_gap = abs(float(small["bbox_min"][2] - other["bbox_max"][2])) / gh
        if other_top_gap + 0.015 < my_top_gap:
            return True
    return False


def postprocess_attach_small_upper_dou(
    comp_map: Dict[int, int],
    segments: List[Segment],
    semantic_model: Dict,
) -> Dict[int, int]:
    if not comp_map or not segments:
        return comp_map

    work_map = dict(comp_map)

    for _ in range(2):
        comps = base.build_components_from_map(work_map, segments)
        if len(comps) <= 1:
            break
        global_ctx = base.compute_global_component_context(comps)

        comp_to_seg_ids: Dict[int, List[int]] = {}
        for seg_id, cid in work_map.items():
            comp_to_seg_ids.setdefault(cid, []).append(seg_id)

        proposals: List[Tuple[float, int, int]] = []
        for small_id, small in comps.items():
            seg_ids = comp_to_seg_ids.get(small_id, [])
            if len(seg_ids) > 2:
                continue
            if component_diag_rel(small, global_ctx) > 0.14:
                continue
            if component_z_norm(small, global_ctx) < 0.16:
                continue
            if is_base_dou_segment(small, global_ctx):
                continue
            if not (is_blocky_dou_segment(small, global_ctx) or dou_semantic_bonus(small, semantic_model) > 1.0):
                continue

            best = None
            second = None
            for big_id, big in comps.items():
                if big_id == small_id:
                    continue
                if big["bbox_diag"] < small["bbox_diag"] * 1.8:
                    continue
                if not (
                    is_strong_gong_host_for_upper_dou(big, global_ctx, semantic_model)
                    or is_relaxed_gong_host_for_upper_dou(big, global_ctx, semantic_model)
                ):
                    continue
                horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
                if horiz_elong < 2.2:
                    continue

                rel = describe_candidate_to_seed(big, small, global_ctx)
                if rel["below_seed_bottom"] > 0.30:
                    continue
                if rel["bottom_attach"] > 0.35:
                    continue
                if rel["gap"] > 0.18:
                    continue
                if abs(float(small["bbox_min"][2] - big["bbox_max"][2])) / max(float(global_ctx["global_height"][0]), 1e-8) > 0.075:
                    continue
                if rel["same_layer_topish"] < 0.5 and rel["above_seed_top"] < 0.5:
                    continue
                if rel["xy_overlap"] < 0.22 and rel["long_overlap"] < 0.80:
                    continue
                slot = upper_dou_slot_name(big, small, global_ctx)
                if slot == "center":
                    if rel["centerish"] < 0.5 or rel["xy_overlap"] < 0.34:
                        continue
                else:
                    if rel["near_end"] < 0.5 or rel["top_support"] < 0.24:
                        continue

                if host_is_shadowed_by_higher_candidate(big_id, big, small, rel, comps, global_ctx, semantic_model):
                    continue

                if is_strong_gong_host_for_upper_dou(big, global_ctx, semantic_model):
                    score = score_upper_dou_host_attachment(big, small, rel, global_ctx, semantic_model)
                else:
                    score = score_relaxed_upper_dou_host_attachment(big, small, rel, global_ctx, semantic_model)
                item = (float(score), small_id, big_id)
                if best is None or item[0] > best[0]:
                    second = best
                    best = item
                elif second is None or item[0] > second[0]:
                    second = item

            if best is None:
                continue
            margin = best[0] - (second[0] if second is not None else -1e9)
            if best[0] < 4.0:
                continue
            if second is not None and margin < 0.55:
                continue
            proposals.append(best)

        if not proposals:
            break

        proposals.sort(reverse=True)
        used_small: Set[int] = set()
        used_big_slots: Set[Tuple[int, str]] = set()
        big_slot_counts: Dict[int, int] = {}
        changed = False
        for _, small_id, big_id in proposals:
            if small_id in used_small:
                continue
            if small_id not in comp_to_seg_ids or big_id not in comp_to_seg_ids:
                continue
            slot = upper_dou_slot_name(comps[big_id], comps[small_id], global_ctx)
            if (big_id, slot) in used_big_slots:
                continue
            max_slots = max_upper_dou_slots_for_host(comps[big_id], global_ctx, semantic_model)
            if big_slot_counts.get(big_id, 0) >= max_slots:
                continue
            for seg_id in comp_to_seg_ids[small_id]:
                work_map[seg_id] = big_id
            used_small.add(small_id)
            used_big_slots.add((big_id, slot))
            big_slot_counts[big_id] = big_slot_counts.get(big_id, 0) + 1
            changed = True

        if not changed:
            break
        work_map = base.relabel_components(work_map)

    return base.relabel_components(work_map)


def postprocess_attach_strict_upper_dou(
    comp_map: Dict[int, int],
    segments: List[Segment],
    semantic_model: Dict,
) -> Dict[int, int]:
    if not comp_map or not segments:
        return comp_map

    work_map = dict(comp_map)
    comps = base.build_components_from_map(work_map, segments)
    global_ctx = base.compute_global_component_context(comps)

    comp_to_seg_ids: Dict[int, List[int]] = {}
    for seg_id, cid in work_map.items():
        comp_to_seg_ids.setdefault(cid, []).append(seg_id)

    proposals: List[Tuple[float, int, int]] = []
    for small_id, small in comps.items():
        seg_ids = sorted(comp_to_seg_ids.get(small_id, []))
        if len(seg_ids) > 1:
            continue
        if component_diag_rel(small, global_ctx) > 0.115:
            continue
        if component_z_norm(small, global_ctx) < 0.18:
            continue
        if is_base_dou_segment(small, global_ctx):
            continue
        if dou_semantic_bonus(small, semantic_model) < 0.7:
            continue

        best = None
        second = None
        for big_id, big in comps.items():
            if big_id == small_id:
                continue
            if component_diag_rel(big, global_ctx) < 0.32 or component_diag_rel(big, global_ctx) > 0.44:
                continue
            horiz_elong = float(big.get("horizontal_elongation", big.get("elongation", 1.0)))
            if horiz_elong < 2.7 or horiz_elong > 3.4:
                continue
            if gong_semantic_bonus(big, semantic_model) < 2.8:
                continue
            if component_side_symmetry_score(big, global_ctx) < 0.72:
                continue

            rel = describe_candidate_to_seed(big, small, global_ctx)
            if rel["same_layer_topish"] < 0.5:
                continue
            if rel["top_support"] < 0.26:
                continue
            if rel["xy_overlap"] < 0.45:
                continue
            slot = upper_dou_slot_name(big, small, global_ctx)
            if slot == "center":
                if rel["centerish"] < 0.5:
                    continue
            else:
                if rel["near_end"] < 0.5:
                    continue
            if abs(rel["lateral"]) > 0.05:
                continue
            if abs(rel["along"]) > 0.22:
                continue
            if rel["below_seed_bottom"] > 0.2 or rel["bottom_attach"] > 0.2:
                continue

            score = 0.0
            score += 2.8 * rel["top_support"]
            score += 2.2 * rel["xy_overlap"]
            score += 0.8 * rel["long_overlap"]
            score += 0.5 * gong_semantic_bonus(big, semantic_model)

            item = (float(score), small_id, big_id)
            if best is None or item[0] > best[0]:
                second = best
                best = item
            elif second is None or item[0] > second[0]:
                second = item

        if best is None:
            continue
        margin = best[0] - (second[0] if second is not None else -1e9)
        if best[0] < 4.0:
            continue
        if second is not None and margin < 0.55:
            continue
        proposals.append(best)

    if not proposals:
        return base.relabel_components(work_map)

    proposals.sort(reverse=True)
    used_small: Set[int] = set()
    used_big_slots: Set[Tuple[int, str]] = set()
    big_slot_counts: Dict[int, int] = {}
    for _, small_id, big_id in proposals:
        if small_id in used_small:
            continue
        slot = upper_dou_slot_name(comps[big_id], comps[small_id], global_ctx)
        if (big_id, slot) in used_big_slots:
            continue
        max_slots = max_upper_dou_slots_for_host(comps[big_id], global_ctx, semantic_model)
        if big_slot_counts.get(big_id, 0) >= max_slots:
            continue
        for seg_id in comp_to_seg_ids[small_id]:
            work_map[seg_id] = big_id
        used_small.add(small_id)
        used_big_slots.add((big_id, slot))
        big_slot_counts[big_id] = big_slot_counts.get(big_id, 0) + 1

    return base.relabel_components(work_map)


def gong_body_guard_score(comp: Dict, global_ctx: Dict, semantic_model: Dict) -> float:
    gh = max(float(global_ctx["global_height"][0]), 1e-8)
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    vertical_ratio = float((comp["bbox_max"][2] - comp["bbox_min"][2]) / gh)
    bottom_std, bottom_range = component_bottom_profile_stats(comp, global_ctx)
    sym = component_side_symmetry_score(comp, global_ctx)
    gong_bonus = gong_semantic_bonus(comp, semantic_model)

    score = 0.0
    score += 1.4 * max(0.0, min(diag_rel, 0.62) - 0.18) / 0.44
    score += 2.1 * max(0.0, min(horiz_elong, 4.8) - 2.2) / 2.6
    score += 1.6 * max(0.0, 0.34 - height_ratio) / 0.34
    score += 1.1 * max(0.0, 0.070 - bottom_range) / 0.070
    score += 0.6 * max(0.0, 0.040 - bottom_std) / 0.040
    score += 0.9 * sym
    score += 0.7 * max(0.0, gong_bonus)
    score -= 1.2 * max(0.0, height_ratio - 0.42) / 0.42
    score -= 1.0 * max(0.0, vertical_ratio - 0.28) / 0.28
    score -= 0.8 * max(0.0, 0.50 - sym) / 0.50
    return float(score)


def detachable_dou_guard_score(
    subset: Dict,
    host: Dict,
    rel: Dict[str, float],
    global_ctx: Dict,
    semantic_model: Dict,
) -> float:
    diag_rel = component_diag_rel(subset, global_ctx)
    horiz_elong = float(subset.get("horizontal_elongation", subset.get("elongation", 1.0)))
    height_ratio = float(subset.get("height_ratio", 1.0))
    z_norm = component_z_norm(subset, global_ctx)
    vertical_ratio = component_vertical_elongation(subset)
    cross_ratio = component_xy_cross_ratio(subset)
    dou_bonus = dou_semantic_bonus(subset, semantic_model)

    is_blocky = is_blocky_dou_segment(subset, global_ctx)
    is_base = is_base_dou_segment(subset, global_ctx)
    is_irregular_small_dou = bool(
        diag_rel <= 0.28
        and horiz_elong <= 4.8
        and vertical_ratio <= 1.7
        and cross_ratio >= 0.12
        and z_norm >= 0.02
        and float(subset["bbox_diag"]) < float(host["bbox_diag"]) * 0.82
    )
    if not (is_blocky or is_base or is_irregular_small_dou or dou_bonus > -0.30):
        return -1e9

    score = 0.0
    if is_blocky:
        score += 1.0
    if is_base:
        score += 1.0
    if is_irregular_small_dou:
        score += 0.7
    score += 0.35 * max(0.0, 0.28 - diag_rel) / 0.28
    score += 0.25 * max(0.0, 4.8 - horiz_elong) / 4.8
    score += 0.25 * max(0.0, cross_ratio - 0.12) / 0.38
    score += 0.25 * max(0.0, min(height_ratio, 1.8) - 0.25) / 1.55
    score += 0.30 * max(0.0, min(vertical_ratio, 1.5)) / 1.5
    score += 0.35 * max(0.0, dou_bonus)
    score += 0.80 * rel["below_seed_bottom"]
    score += 0.70 * rel["bottom_attach"]
    score -= 0.55 * rel["top_support"]
    return float(score)


def postprocess_detach_bottom_dou_like(
    comp_map: Dict[int, int],
    segments: List[Segment],
    semantic_model: Dict,
) -> Dict[int, int]:
    if not comp_map or not segments:
        return comp_map

    work_map = dict(comp_map)
    seg_by_id = {int(s.seg_id): s for s in segments}

    for _ in range(3):
        comps = base.build_components_from_map(work_map, segments)
        if len(comps) <= 1:
            break
        global_ctx = base.compute_global_component_context(comps)
        gh = max(float(global_ctx["global_height"][0]), 1e-8)

        comp_to_seg_ids: Dict[int, List[int]] = {}
        for seg_id, cid in work_map.items():
            comp_to_seg_ids.setdefault(cid, []).append(int(seg_id))

        best_action = None
        next_cid = max(work_map.values()) + 1 if work_map else 0

        for cid, seg_ids in comp_to_seg_ids.items():
            seg_ids = sorted(seg_ids)
            if len(seg_ids) <= 1:
                continue

            full = comps[cid]
            full_score = gong_body_guard_score(full, global_ctx, semantic_model)
            full_bottom_std, full_bottom_range = component_bottom_profile_stats(full, global_ctx)
            full_sym = component_side_symmetry_score(full, global_ctx)
            weak_full = bool(full_score < 0.5 and len(seg_ids) >= 4)

            subset_candidates = [[sid] for sid in seg_ids]
            if len(seg_ids) <= 6:
                subset_candidates.extend([list(pair) for pair in combinations(seg_ids, 2)])

            comp_best = None
            for subset_ids in subset_candidates:
                rest_ids = [sid for sid in seg_ids if sid not in subset_ids]
                if not rest_ids:
                    continue

                subset = build_component_from_seg_ids(subset_ids, seg_by_id)
                host = build_component_from_seg_ids(rest_ids, seg_by_id)
                if float(subset["bbox_diag"]) >= float(host["bbox_diag"]) * 0.82:
                    continue

                rel = describe_candidate_to_seed(host, subset, global_ctx)
                if rel["gap"] > 0.18:
                    continue
                if rel["xy_overlap"] < 0.10 and rel["long_overlap"] < 0.26:
                    continue
                bottom_like = not (
                    rel["below_seed_bottom"] < 0.50
                    and rel["bottom_attach"] < 0.32
                    and float(subset["bbox_max"][2]) > float(host["bbox_min"][2]) + 0.04 * gh
                )
                weak_split_ok = bool(
                    weak_full
                    and float(subset["bbox_diag"]) < float(host["bbox_diag"]) * 0.82
                    and rel["gap"] <= 0.10
                    and (rel["xy_overlap"] >= 0.15 or rel["long_overlap"] >= 0.60)
                )
                if not bottom_like and not weak_split_ok:
                    continue
                if bottom_like and (rel["top_support"] > 0.30 or rel["above_seed_top"] > 0.5):
                    continue

                subset_score = detachable_dou_guard_score(subset, host, rel, global_ctx, semantic_model)
                if subset_score < (1.2 if bottom_like else 0.4):
                    continue

                host_score = gong_body_guard_score(host, global_ctx, semantic_model)
                host_bottom_std, host_bottom_range = component_bottom_profile_stats(host, global_ctx)
                host_sym = component_side_symmetry_score(host, global_ctx)

                bottom_raise = max(0.0, float(host["bbox_min"][2] - full["bbox_min"][2])) / gh
                bottom_range_gain = max(0.0, full_bottom_range - host_bottom_range)
                bottom_std_gain = max(0.0, full_bottom_std - host_bottom_std)
                sym_gain = max(0.0, host_sym - full_sym)

                if bottom_like:
                    if host_score < 2.2:
                        continue
                    if (
                        host_score < full_score + 0.55
                        and bottom_raise < 0.020
                        and bottom_range_gain < 0.015
                        and bottom_std_gain < 0.010
                        and sym_gain < 0.06
                    ):
                        continue

                    detach_score = subset_score
                    detach_score += 1.4 * (host_score - full_score)
                    detach_score += 8.0 * bottom_raise
                    detach_score += 10.0 * bottom_range_gain
                    detach_score += 8.0 * bottom_std_gain
                    detach_score += 1.8 * sym_gain
                else:
                    if full_score > -4.0:
                        continue
                    if host_score < full_score + 0.55:
                        continue
                    if bottom_range_gain < 0.015 and bottom_std_gain < 0.010 and sym_gain < 0.45:
                        continue
                    if subset_score < 0.20:
                        continue

                    detach_score = 0.5 * subset_score
                    detach_score += 1.4 * (host_score - full_score)
                    detach_score += 4.0 * bottom_raise
                    detach_score += 10.0 * bottom_range_gain
                    detach_score += 8.0 * bottom_std_gain
                    detach_score += 3.0 * sym_gain

                item = (float(detach_score), int(cid), list(subset_ids), int(next_cid))
                if comp_best is None or item[0] > comp_best[0]:
                    comp_best = item

            if comp_best is not None and (best_action is None or comp_best[0] > best_action[0]):
                best_action = comp_best

        if best_action is None:
            break

        _, source_cid, subset_ids, new_cid = best_action
        moved = False
        for seg_id in subset_ids:
            if work_map.get(seg_id) == source_cid:
                work_map[seg_id] = new_cid
                moved = True
        if not moved:
            break
        work_map = base.relabel_components(work_map)

    return base.relabel_components(work_map)


# ============================================================
# Main recovery
# ============================================================

def recover_component_map_v7(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    semantic_model: Dict = None,
    learned_priors: Dict = None,
    enable_z_gong: bool = False,
    target_components_hint: int = 0,
    force_target: bool = False,
    apply_small_dou_postprocess: bool = False,
    apply_strict_upper_dou_postprocess: bool = False,
    enable_bodyfirst_stage1: bool = True,
    enable_bottom_dou_detach: bool = True,
) -> Dict[int, int]:
    if not segments:
        return {}

    if not enable_bodyfirst_stage1:
        comp_map = base.choose_component_map(
            segments=segments,
            edges=edges,
            scores=scores,
            model=model,
            target_components_hint=target_components_hint,
            force_target=force_target,
        )
        return base.relabel_components(comp_map)

    gong_map = layerwise_gong_prototype_map(
        segments,
        semantic_model=semantic_model,
        learned_priors=learned_priors,
    )
    gong_locked = set(gong_map.keys())

    z_gong_map = {}
    if enable_z_gong:
        z_gong_segments = [s for s in segments if s.seg_id not in gong_locked]
        z_gong_map = z_oriented_gong_prototype_map(
            z_gong_segments,
            semantic_model=semantic_model,
            context_segments=segments,
        )
    z_gong_locked = set(z_gong_map.keys())

    residual_segments = [s for s in segments if s.seg_id not in gong_locked and s.seg_id not in z_gong_locked]
    residual_map = {}
    if residual_segments:
        residual_ids = {s.seg_id for s in residual_segments}
        residual_edges, residual_scores = base.filter_edges_and_scores(edges, scores, residual_ids)
        residual_map = base.choose_component_map(
            segments=residual_segments,
            edges=residual_edges,
            scores=residual_scores,
            model=model,
            target_components_hint=0,
            force_target=False,
        )

    comp_map = merge_partial_maps(segments, [gong_map, z_gong_map, residual_map])
    if apply_small_dou_postprocess:
        comp_map = postprocess_attach_small_upper_dou(comp_map, segments, semantic_model)
    if apply_strict_upper_dou_postprocess:
        comp_map = postprocess_attach_strict_upper_dou(comp_map, segments, semantic_model)

    comp_map = base.relabel_components(comp_map)
    if target_components_hint > 0 and force_target:
        comp_map = base.enforce_target_component_count(
            comp_map=comp_map,
            segments=segments,
            edges=edges,
            scores=scores,
            target_components=target_components_hint,
            max_component_segments=int(max(model.get("max_component_segments", 6), 1)),
            max_component_bbox_diag=float(model.get("max_component_bbox_diag", 0.0)),
        )
    if enable_bottom_dou_detach:
        comp_map = postprocess_detach_bottom_dou_like(comp_map, segments, semantic_model)
    return base.relabel_components(comp_map)


# ============================================================
# CLI functions
# ============================================================

def train(args):
    base.train(args)
    print("base model training finished.")
    print(
        "next step: python .\\code\\train_role_classifier_v7.py "
        f"--model_dir {args.out_dir}"
    )


def refine(args):
    uid = args.uid
    np.random.seed(args.seed)
    fragment_file = base.find_fragment_file(args.fragment_dir, uid)
    if not fragment_file:
        raise RuntimeError(f"fragment file not found for uid: {uid}")

    segments, seg_names, center, scale, global_diag = base.load_fragment_segments(fragment_file, args.max_points)
    manual_comp_map = {}
    requested_manual_dir = str(getattr(args, "manual_group_dir", "") or "").strip()
    allow_manual_injection = bool(getattr(args, "allow_manual_grouping_injection", False))
    if requested_manual_dir and not allow_manual_injection:
        raise RuntimeError(
            "Manual grouping injection is disabled by default to avoid contaminating baseline refine results. "
            "If you intentionally want to override model output with manual grouping, rerun with "
            "--allow_manual_grouping_injection."
        )
    if requested_manual_dir and allow_manual_injection:
        manual_comp_map = load_manual_grouping_map(uid, requested_manual_dir, segments)

    edge_model_path = os.path.join(args.model_dir, "merge_edge_model.json")
    ensure_required_file(
        edge_model_path,
        "merge edge model not found, please run train first",
    )
    with open(edge_model_path, "r", encoding="utf-8") as f:
        model = json.load(f)

    semantic_model = load_merge_semantic_model(args.merge_semantic_model_dir, args.model_dir)
    label_semantic_model = load_label_semantic_model(args.semantic_label_model_dir, args.model_dir)
    learned_priors = load_gong_prior_models(args.gong_prior_model_json, args.model_dir)
    manual_edge_calibrator = load_manual_edge_calibrator(args.manual_edge_calibrator_json, args.model_dir)
    gt_parts = base.load_gt_parts_auto(args.gt_dir, uid, center, scale, args.gt_samples)

    edges, feats = build_augmented_edges(
        segments,
        global_diag=global_diag,
        neighbor_ratio=args.neighbor_ratio,
        contact_eps=args.contact_eps,
    )
    x, feature_names = base.features_to_matrix(feats)
    scores = base.score_edges(x, model) if x.shape[0] else np.array([])
    scores = fuse_edge_scores(scores, x, feature_names, manual_edge_calibrator)

    target_hint = len(gt_parts) if (args.target_mode == "gt_count" and gt_parts) else 0
    force_target = bool(target_hint > 0 and args.force_target_count)

    if manual_comp_map:
        comp_map = manual_comp_map
    else:
        comp_map = recover_component_map_v7(
            segments=segments,
            edges=edges,
            scores=scores,
            model=model,
            semantic_model=semantic_model,
            learned_priors=learned_priors,
            enable_z_gong=bool(getattr(args, "enable_z_gong", False)),
            target_components_hint=target_hint,
            force_target=force_target,
            apply_small_dou_postprocess=bool(args.post_attach_small_dou),
            apply_strict_upper_dou_postprocess=bool(args.post_attach_strict_upper_dou),
        )

    seg_points = {s.seg_id: s.points for s in segments}
    comp_points: Dict[int, np.ndarray] = {}
    for seg_id, comp_id in comp_map.items():
        comp_points.setdefault(comp_id, []).append(seg_points[seg_id])
    comp_points = {cid: np.vstack(pts) for cid, pts in comp_points.items()}

    comp_sem, descriptors, pair_relations, global_meta, raw_scores = base.predict_component_semantics(
        comp_points, label_semantic_model
    )
    structure = base.recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)

    underseg = []
    if gt_parts:
        mapping, dominance = base.assign_segments_to_gt(segments, gt_parts)
        for seg_id, dom in dominance.items():
            if dom < args.underseg_threshold:
                underseg.append(seg_id)

    os.makedirs(args.out_dir, exist_ok=True)

    all_points = []
    fragment_labels = []
    comp_labels = []
    semantic_labels = []

    for seg in segments:
        all_points.append(seg.points)
        fragment_labels.append(np.full(len(seg.points), seg.seg_id, dtype=np.int32))
        comp_id = comp_map[seg.seg_id]
        comp_labels.append(np.full(len(seg.points), comp_id, dtype=np.int32))

    all_points = np.vstack(all_points)
    fragment_labels = np.concatenate(fragment_labels)
    comp_labels = np.concatenate(comp_labels)

    sem_to_id = {s: i for i, s in enumerate(sorted(set(comp_sem.values())))}
    for seg in segments:
        comp_id = comp_map[seg.seg_id]
        sem_id = sem_to_id[comp_sem[comp_id]]
        semantic_labels.append(np.full(len(seg.points), sem_id, dtype=np.int32))
    semantic_labels = np.concatenate(semantic_labels)

    np.savez_compressed(
        os.path.join(args.out_dir, f"{uid}_refined.npz"),
        points=all_points,
        fragment_labels=fragment_labels,
        comp_labels=comp_labels,
        semantic_labels=semantic_labels,
        center=np.asarray(center, dtype=np.float32),
        scale=np.asarray(scale, dtype=np.float32),
        segment_names=seg_names,
    )

    summary = {
        "uid": uid,
        "num_segments": len(segments),
        "num_components": len(comp_points),
        "num_edges": len(edges),
        "threshold": model["threshold"],
        "target_keep_ratio": model.get("target_keep_ratio", 0.4),
        "target_component_ratio": model.get("target_component_ratio", 0.55),
        "target_mode": args.target_mode,
        "force_target_count": bool(args.force_target_count),
        "enable_z_gong": bool(getattr(args, "enable_z_gong", False)),
        "post_attach_small_dou": bool(args.post_attach_small_dou),
        "post_attach_strict_upper_dou": bool(args.post_attach_strict_upper_dou),
        "merge_semantic_model_dir": str(args.merge_semantic_model_dir or args.model_dir),
        "semantic_label_model_dir": str(args.semantic_label_model_dir or args.model_dir),
        "gong_prior_model_json": str(args.gong_prior_model_json or os.path.join(args.model_dir, "gong_prior_models.json")),
        "manual_edge_calibrator_json": str(args.manual_edge_calibrator_json or os.path.join(args.model_dir, "manual_edge_calibrator.json")),
        "manual_group_dir_requested": requested_manual_dir,
        "allow_manual_grouping_injection": bool(allow_manual_injection),
        "manual_grouping_used": bool(manual_comp_map),
        "max_component_segments_limit": int(model.get("max_component_segments", 6)),
        "max_component_segments_observed": int(max(sum(1 for s in comp_map.values() if s == cid) for cid in set(comp_map.values()))),
        "components": [
            {
                "component_id": cid,
                "semantic": comp_sem[cid],
                "num_segments": sum(1 for s in comp_map.values() if s == cid),
                "diag_rel": float(descriptors[cid].get("diag_rel", 0.0)),
                "z_rank": float(descriptors[cid].get("z_rank", 0.0)),
                "side_offset": float(descriptors[cid].get("side_offset", 0.0)),
                "symmetry_score": float(descriptors[cid].get("symmetry_score", 0.0)),
                "semantic_scores": {k: float(v) for k, v in sorted(raw_scores.get(cid, {}).items())},
            }
            for cid in sorted(comp_points.keys())
        ],
        "assembly": structure,
        "underseg_candidates": underseg,
    }

    with open(os.path.join(args.out_dir, f"{uid}_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"refined {uid} -> components={len(comp_points)}")
    print(f"saved npz: {os.path.join(args.out_dir, f'{uid}_refined.npz')}")
    print(f"saved summary: {os.path.join(args.out_dir, f'{uid}_summary.json')}")


def evaluate(args):
    ids = base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    edge_model_path = os.path.join(args.model_dir, "merge_edge_model.json")
    ensure_required_file(
        edge_model_path,
        "merge edge model not found, please run train first",
    )
    with open(edge_model_path, "r", encoding="utf-8") as f:
        model = json.load(f)
    semantic_model = load_merge_semantic_model(args.merge_semantic_model_dir, args.model_dir)
    label_semantic_model = load_label_semantic_model(args.semantic_label_model_dir, args.model_dir)
    learned_priors = load_gong_prior_models(args.gong_prior_model_json, args.model_dir)
    manual_edge_calibrator = load_manual_edge_calibrator(args.manual_edge_calibrator_json, args.model_dir)

    results = []
    for uid in ids:
        np.random.seed(args.seed)
        fragment_file = base.find_fragment_file(args.fragment_dir, uid)
        if not fragment_file:
            continue

        segments, _, center, scale, global_diag = base.load_fragment_segments(fragment_file, args.max_points)
        gt_parts = base.load_gt_parts_auto(args.gt_dir, uid, center, scale, args.gt_samples)
        if not gt_parts:
            continue

        edges, feats = build_augmented_edges(
            segments,
            global_diag=global_diag,
            neighbor_ratio=args.neighbor_ratio,
            contact_eps=args.contact_eps,
        )
        x, feature_names = base.features_to_matrix(feats)
        scores = base.score_edges(x, model) if x.shape[0] else np.array([])
        scores = fuse_edge_scores(scores, x, feature_names, manual_edge_calibrator)

        target_hint = len(gt_parts) if (args.target_mode == "gt_count" and gt_parts) else 0
        force_target = bool(target_hint > 0 and args.force_target_count)

        comp_map = recover_component_map_v7(
            segments=segments,
            edges=edges,
            scores=scores,
            model=model,
            semantic_model=semantic_model,
            learned_priors=learned_priors,
            enable_z_gong=bool(getattr(args, "enable_z_gong", False)),
            target_components_hint=target_hint,
            force_target=force_target,
            apply_small_dou_postprocess=bool(args.post_attach_small_dou),
            apply_strict_upper_dou_postprocess=bool(args.post_attach_strict_upper_dou),
        )

        seg_points = {s.seg_id: s.points for s in segments}
        comp_points: Dict[int, np.ndarray] = {}
        for seg_id, comp_id in comp_map.items():
            comp_points.setdefault(comp_id, []).append(seg_points[seg_id])
        comp_points = {cid: np.vstack(pts) for cid, pts in comp_points.items()}

        comp_sem, descriptors, pair_relations, global_meta, _ = base.predict_component_semantics(
            comp_points, label_semantic_model
        )
        structure = base.recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)

        comp_to_gt = {}
        purity = []
        for cid, pts in comp_points.items():
            bmin, bmax, diag = base.bbox_stats(pts)
            tmp_seg = Segment(
                seg_id=cid,
                points=pts,
                centroid=pts.mean(axis=0),
                bbox_min=bmin,
                bbox_max=bmax,
                axis=base.pca_axis(pts),
                bbox_diag=diag,
            )
            mapping, dominance = base.assign_segments_to_gt([tmp_seg], gt_parts)
            if mapping:
                comp_to_gt[cid] = mapping[cid]
                purity.append(dominance[cid])

        mean_purity = float(np.mean(purity)) if purity else 0.0

        correct = 0
        total = 0
        for cid, gt_idx in comp_to_gt.items():
            sem_gt = gt_parts[gt_idx].semantic
            sem_pred = comp_sem.get(cid, "unknown")
            correct += int(sem_pred == sem_gt)
            total += 1
        sem_acc = correct / max(total, 1)

        results.append({
            "uid": uid,
            "num_segments": len(segments),
            "num_components": len(comp_points),
            "num_gt_parts": len(gt_parts),
            "recoverable_case": bool(len(segments) >= len(gt_parts)),
            "component_count_diff": abs(len(comp_points) - len(gt_parts)),
            "mean_purity": mean_purity,
            "semantic_acc": sem_acc,
            "num_support_edges": int(sum(1 for e in structure.get("assembly_edges", []) if e.get("relation") == "support")),
            "num_layers": int(len(structure.get("levels", []))),
        })

    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print(f"evaluated {len(results)} models")


# ============================================================
# Parser
# ============================================================

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Dougong role-aware template refinement v7 final.",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python .\\code\\dougong_refine_v7_final.py train --out_dir .\\models_v7\n"
            "  python .\\code\\dougong_refine_v7_final.py refine --uid f624e1a47839 --model_dir .\\models_v7 --out_dir .\\outputs_v7\n"
            "  python .\\code\\dougong_refine_v7_final.py evaluate --model_dir .\\models_v7 --out_dir .\\outputs_v7_eval\n"
        ),
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_train = sub.add_parser("train")
    p_train.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_train.add_argument("--gt_dir", default=r"data")
    p_train.add_argument("--out_dir", default=r"models")
    p_train.add_argument("--max_points", type=int, default=512)
    p_train.add_argument("--gt_samples", type=int, default=512)
    p_train.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_train.add_argument("--contact_eps", type=float, default=0.01)
    p_train.add_argument("--seed", type=int, default=42)

    p_ref = sub.add_parser("refine")
    p_ref.add_argument("--uid", required=True)
    p_ref.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_ref.add_argument("--gt_dir", default=r"data")
    p_ref.add_argument("--model_dir", default=r"models")
    p_ref.add_argument("--out_dir", default=r"outputs")
    p_ref.add_argument("--manual_group_dir", default="", help="Optional manual grouping dir. Ignored unless --allow_manual_grouping_injection is also set.")
    p_ref.add_argument("--allow_manual_grouping_injection", action="store_true", help="Explicitly allow refine to override model output with manual grouping.")
    p_ref.add_argument("--merge_semantic_model_dir", default="", help="Optional model dir used during merge scoring/gating.")
    p_ref.add_argument("--semantic_label_model_dir", default="", help="Optional model dir used only for final semantic labeling.")
    p_ref.add_argument("--gong_prior_model_json", default="", help="Optional learned gong prior json. Defaults to model_dir\\gong_prior_models.json when present.")
    p_ref.add_argument("--manual_edge_calibrator_json", default="", help="Optional manual edge calibrator json. Defaults to model_dir\\manual_edge_calibrator.json when present.")
    p_ref.add_argument("--max_points", type=int, default=512)
    p_ref.add_argument("--gt_samples", type=int, default=512)
    p_ref.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_ref.add_argument("--contact_eps", type=float, default=0.01)
    p_ref.add_argument("--underseg_threshold", type=float, default=0.6)
    p_ref.add_argument("--seed", type=int, default=11)
    p_ref.add_argument("--target_mode", choices=["ratio", "gt_count"], default="ratio")
    p_ref.add_argument("--force_target_count", action="store_true")
    p_ref.add_argument("--enable_z_gong", action="store_true", help="Enable z-oriented gong prototype recovery. Disabled by default in refreshed fragment experiments.")
    p_ref.add_argument("--post_attach_small_dou", action="store_true")
    p_ref.add_argument("--post_attach_strict_upper_dou", action="store_true")

    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_eval.add_argument("--gt_dir", default=r"data")
    p_eval.add_argument("--model_dir", default=r"models")
    p_eval.add_argument("--merge_semantic_model_dir", default="", help="Optional model dir used during merge scoring/gating.")
    p_eval.add_argument("--semantic_label_model_dir", default="", help="Optional model dir used only for final semantic labeling.")
    p_eval.add_argument("--gong_prior_model_json", default="", help="Optional learned gong prior json. Defaults to model_dir\\gong_prior_models.json when present.")
    p_eval.add_argument("--manual_edge_calibrator_json", default="", help="Optional manual edge calibrator json. Defaults to model_dir\\manual_edge_calibrator.json when present.")
    p_eval.add_argument("--out_dir", default=r"outputs")
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_eval.add_argument("--contact_eps", type=float, default=0.01)
    p_eval.add_argument("--seed", type=int, default=11)
    p_eval.add_argument("--target_mode", choices=["ratio", "gt_count"], default="ratio")
    p_eval.add_argument("--force_target_count", action="store_true")
    p_eval.add_argument("--enable_z_gong", action="store_true", help="Enable z-oriented gong prototype recovery. Disabled by default in refreshed fragment experiments.")
    p_eval.add_argument("--post_attach_small_dou", action="store_true")
    p_eval.add_argument("--post_attach_strict_upper_dou", action="store_true")

    return p


def main():
    args = build_parser().parse_args()
    if args.cmd == "train":
        train(args)
    elif args.cmd == "refine":
        refine(args)
    elif args.cmd == "evaluate":
        evaluate(args)


if __name__ == "__main__":
    main()
