import argparse
import json
import math
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np


THIS_DIR = Path(__file__).resolve().parent
ROOT_DIR = THIS_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if str(THIS_DIR) not in sys.path:
    sys.path.insert(0, str(THIS_DIR))

import dougong_refine_v4 as base
import dougong_refine_generic_graph_baseline_clean_20260426 as generic_base
import task_aware_eval_metrics_20260427 as task_eval


DEFAULT_SEMANTIC_LABEL_MODEL_DIR = generic_base.DEFAULT_SEMANTIC_LABEL_MODEL_DIR
DEFAULT_MANUAL_GROUP_DIR = generic_base.DEFAULT_MANUAL_GROUP_DIR


def merge_bbox_diag(
    cluster_seg_ids: List[int],
    seg_bounds: Dict[int, Tuple[np.ndarray, np.ndarray]],
) -> float:
    mins = np.stack([seg_bounds[sid][0] for sid in cluster_seg_ids], axis=0)
    maxs = np.stack([seg_bounds[sid][1] for sid in cluster_seg_ids], axis=0)
    return float(np.linalg.norm(maxs.max(axis=0) - mins.min(axis=0)))


def build_similarity_matrix(case_row: dict, args) -> Tuple[List[int], np.ndarray, Dict[int, Tuple[np.ndarray, np.ndarray]], float]:
    segments = case_row["segments"]
    global_diag = float(case_row["global_diag"])
    seg_ids = [int(seg.seg_id) for seg in segments]
    seg_bounds = {int(seg.seg_id): (seg.bbox_min.copy(), seg.bbox_max.copy()) for seg in segments}
    seg_index = {sid: idx for idx, sid in enumerate(seg_ids)}

    sim = np.zeros((len(seg_ids), len(seg_ids)), dtype=np.float32)
    edges, feats = base.build_edges(
        segments,
        global_diag=global_diag,
        neighbor_ratio=args.neighbor_ratio,
        contact_eps=args.contact_eps,
    )
    for (sid_a, sid_b), feat in zip(edges, feats):
        i = seg_index[int(sid_a)]
        j = seg_index[int(sid_b)]
        score = generic_base.generic_edge_affinity(feat)
        sim[i, j] = float(score)
        sim[j, i] = float(score)
    return seg_ids, sim, seg_bounds, global_diag


def average_link_score(cluster_a: List[int], cluster_b: List[int], sim: np.ndarray, seg_index: Dict[int, int]) -> float:
    idx_a = [seg_index[sid] for sid in cluster_a]
    idx_b = [seg_index[sid] for sid in cluster_b]
    cross = sim[np.ix_(idx_a, idx_b)]
    if cross.size == 0:
        return 0.0
    return float(cross.sum() / max(len(cluster_a) * len(cluster_b), 1))


def build_agglomerative_component_map(case_row: dict, args) -> dict:
    seg_ids, sim, seg_bounds, global_diag = build_similarity_matrix(case_row, args)
    if not seg_ids:
        return {}
    if len(seg_ids) == 1:
        return {int(seg_ids[0]): 0}

    seg_index = {sid: idx for idx, sid in enumerate(seg_ids)}
    clusters: List[List[int]] = [[int(sid)] for sid in seg_ids]
    max_diag = float(args.max_component_diag_ratio) * global_diag if float(args.max_component_diag_ratio) > 0 else 0.0

    while True:
        best_score = -1.0
        best_pair = None
        for i in range(len(clusters)):
            cluster_a = clusters[i]
            for j in range(i + 1, len(clusters)):
                cluster_b = clusters[j]
                merged_size = len(cluster_a) + len(cluster_b)
                if int(args.max_component_segments) > 0 and merged_size > int(args.max_component_segments):
                    continue
                if max_diag > 0.0:
                    merged_diag = merge_bbox_diag(cluster_a + cluster_b, seg_bounds)
                    if merged_diag > max_diag:
                        continue
                score = average_link_score(cluster_a, cluster_b, sim, seg_index)
                if score > best_score:
                    best_score = score
                    best_pair = (i, j)

        if best_pair is None or best_score < float(args.merge_score_threshold):
            break

        i, j = best_pair
        merged = sorted(clusters[i] + clusters[j])
        clusters[i] = merged
        del clusters[j]

    comp_map: Dict[int, int] = {}
    for cid, cluster in enumerate(clusters):
        for seg_id in cluster:
            comp_map[int(seg_id)] = int(cid)
    return base.relabel_components(comp_map)


def refine_case(uid: str, args) -> Tuple[dict, dict]:
    case_row = generic_base.build_case_data(uid, args)
    comp_map = build_agglomerative_component_map(case_row, args)
    return case_row, comp_map


def summarize_results(results: List[dict], args) -> dict:
    summary = {
        "baseline_name": "agglomerative_average_link_segment_graph_baseline",
        "baseline_scope": "classical_agglomerative_clustering_on_segment_graph",
        "uses_domain_priors": False,
        "shares_final_semantic_label_model": True,
        "seed": int(args.seed),
        "semantic_label_model_dir": str(args.semantic_label_model_dir),
        "num_models": len(results),
        "mean_purity_definition": "harmonic_mean(segment_mean_purity, segment_mean_completeness)",
        "mean_num_components": float(np.mean([r["num_components"] for r in results])) if results else 0.0,
        "mean_component_count_diff": float(np.mean([r["component_count_diff"] for r in results])) if results else 0.0,
        "mean_purity": float(np.mean([r["mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_purity": float(np.mean([r["segment_mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_completeness": float(np.mean([r["segment_mean_completeness"] for r in results])) if results else 0.0,
        "mean_segment_partition_f1": float(np.mean([r["segment_partition_f1"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_precision": float(np.mean([r["gt_bcubed_precision"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_recall": float(np.mean([r["gt_bcubed_recall"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_f1": float(np.mean([r["gt_bcubed_f1"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_precision": float(np.mean([r["gt_pairwise_precision"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_recall": float(np.mean([r["gt_pairwise_recall"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_f1": float(np.mean([r["gt_pairwise_f1"] for r in results])) if results else 0.0,
        "mean_geometry_purity": float(np.mean([r["geometry_mean_purity"] for r in results])) if results else 0.0,
        "mean_geometry_pred_score": float(np.mean([r["geometry_pred_score"] for r in results])) if results else 0.0,
        "mean_geometry_gt_score": float(np.mean([r["geometry_gt_score"] for r in results])) if results else 0.0,
        "mean_geometry_balanced_score": float(np.mean([r["geometry_balanced_score"] for r in results])) if results else 0.0,
        "mean_purity_legacy": float(np.mean([r["mean_purity_legacy"] for r in results])) if results else 0.0,
        "mean_forward_cover": float(np.mean([r["mean_forward_cover"] for r in results])) if results else 0.0,
        "mean_backward_cover": float(np.mean([r["mean_backward_cover"] for r in results])) if results else 0.0,
        "mean_gt_cover": float(np.mean([r["mean_gt_cover"] for r in results])) if results else 0.0,
        "mean_matched_component_purity": float(np.mean([r["mean_matched_component_purity"] for r in results])) if results else 0.0,
        "mean_semantic_acc": float(np.mean([r["semantic_acc"] for r in results])) if results else 0.0,
        "mean_segment_semantic_acc": float(np.mean([r["segment_semantic_acc"] for r in results])) if results else 0.0,
        "mean_num_support_edges": float(np.mean([r["num_support_edges"] for r in results])) if results else 0.0,
        "mean_num_layers": float(np.mean([r["num_layers"] for r in results])) if results else 0.0,
        "params": {
            "neighbor_ratio": float(args.neighbor_ratio),
            "contact_eps": float(args.contact_eps),
            "merge_score_threshold": float(args.merge_score_threshold),
            "max_component_segments": int(args.max_component_segments),
            "max_component_diag_ratio": float(args.max_component_diag_ratio),
        },
    }
    summary.update(task_eval.summarize_task_aware_rows(results))
    manual_rows = [r for r in results if "manual_pairwise_f1" in r]
    if manual_rows:
        summary["manual_case_count"] = len(manual_rows)
        summary["mean_manual_pairwise_precision"] = float(np.mean([r["manual_pairwise_precision"] for r in manual_rows]))
        summary["mean_manual_pairwise_recall"] = float(np.mean([r["manual_pairwise_recall"] for r in manual_rows]))
        summary["mean_manual_pairwise_f1"] = float(np.mean([r["manual_pairwise_f1"] for r in manual_rows]))
        summary["mean_manual_bcubed_f1"] = float(np.mean([r["manual_bcubed_f1"] for r in manual_rows]))
        summary["mean_manual_segment_purity"] = float(np.mean([r["manual_segment_mean_purity"] for r in manual_rows]))
        summary["mean_manual_segment_completeness"] = float(np.mean([r["manual_segment_mean_completeness"] for r in manual_rows]))
        summary["mean_manual_segment_partition_f1"] = float(np.mean([r["manual_segment_partition_f1"] for r in manual_rows]))
    return summary


def refine_one(args) -> None:
    np.random.seed(int(args.seed))
    label_semantic_model = generic_base.load_semantic_model_with_roles(args.semantic_label_model_dir)
    case_row, comp_map = refine_case(args.uid, args)
    generic_base.save_refined_outputs(
        uid=args.uid,
        case_row=case_row,
        comp_map=comp_map,
        semantic_model=label_semantic_model,
        out_dir=args.out_dir,
    )
    print(f"refined {args.uid} -> components={len(set(comp_map.values()))}")


def evaluate_all(args) -> None:
    np.random.seed(int(args.seed))
    label_semantic_model = generic_base.load_semantic_model_with_roles(args.semantic_label_model_dir)
    ids = list(args.uids) if args.uids else base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    os.makedirs(args.out_dir, exist_ok=True)
    results = []
    for uid in ids:
        case_row, comp_map = refine_case(uid, args)
        generic_base.save_refined_outputs(
            uid=uid,
            case_row=case_row,
            comp_map=comp_map,
            semantic_model=label_semantic_model,
            out_dir=args.out_dir,
        )
        row = generic_base.evaluate_case(
            uid=uid,
            case_row=case_row,
            comp_map=comp_map,
            semantic_model=label_semantic_model,
            gt_dir=args.gt_dir,
            gt_samples=args.gt_samples,
        )
        if row is None:
            continue
        results.append(row)
        manual_msg = ""
        if "manual_pairwise_f1" in row:
            manual_msg = (
                f", manual_pairwise_f1={row['manual_pairwise_f1']:.4f}, "
                f"manual_bcubed_f1={row.get('manual_bcubed_f1', 0.0):.4f}"
            )
        print(
            f"evaluated {uid}: components={row['num_components']}, "
            f"cluster_f1={row['segment_partition_f1']:.4f}, "
            f"gt_bcubed_f1={row['gt_bcubed_f1']:.4f}, "
            f"geometry_balanced={row['geometry_balanced_score']:.4f}, "
            f"segment_semantic_acc={row['segment_semantic_acc']:.4f}{manual_msg}"
        )

    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    summary = summarize_results(results, args)
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Classical agglomerative clustering baseline on the fragment segment graph."
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_ref = sub.add_parser("refine")
    p_ref.add_argument("--uid", required=True)
    p_ref.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_ref.add_argument("--semantic_label_model_dir", default=DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    p_ref.add_argument("--manual_group_dir", default=DEFAULT_MANUAL_GROUP_DIR)
    p_ref.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "03_outputs", "smoketest_agglomerative_graph_baseline"))
    p_ref.add_argument("--max_points", type=int, default=512)
    p_ref.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_ref.add_argument("--contact_eps", type=float, default=0.01)
    p_ref.add_argument("--merge_score_threshold", type=float, default=0.26)
    p_ref.add_argument("--max_component_segments", type=int, default=6)
    p_ref.add_argument("--max_component_diag_ratio", type=float, default=0.55)
    p_ref.add_argument("--seed", type=int, default=0)

    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_eval.add_argument("--gt_dir", default=r"data")
    p_eval.add_argument("--semantic_label_model_dir", default=DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    p_eval.add_argument("--manual_group_dir", default=DEFAULT_MANUAL_GROUP_DIR)
    p_eval.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "03_outputs", "outputs_agglomerative_graph_baseline_eval_20260513_seed0"))
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_eval.add_argument("--contact_eps", type=float, default=0.01)
    p_eval.add_argument("--merge_score_threshold", type=float, default=0.26)
    p_eval.add_argument("--max_component_segments", type=int, default=6)
    p_eval.add_argument("--max_component_diag_ratio", type=float, default=0.55)
    p_eval.add_argument("--seed", type=int, default=0)
    p_eval.add_argument("--uids", nargs="*", default=[])
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.cmd == "refine":
        refine_one(args)
    elif args.cmd == "evaluate":
        evaluate_all(args)


if __name__ == "__main__":
    main()
