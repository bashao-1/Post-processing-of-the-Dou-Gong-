import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import build_pure_ablation_report_20260502 as ablation_builder
import build_pure_eval_report_20260502 as eval_builder


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REPORT_ROOT = ROOT / "05_reports" / "paper_experiment_scheme_20260513_final_5v4"
DEFAULT_EVAL_TARGETS: List[Tuple[str, Path]] = [
    ("raw_partgen_1_5", ROOT / "03_outputs" / "outputs_raw_partgen_1_5_eval_20260513_seed0"),
    ("generic_graph_baseline", ROOT / "03_outputs" / "outputs_generic_graph_baseline_eval_20260513_seed0"),
    ("agglomerative_graph_baseline", ROOT / "03_outputs" / "outputs_agglomerative_graph_baseline_eval_20260513_seed0"),
    ("knowledge_guided_rule_only_baseline", ROOT / "03_outputs" / "ablation_study_20260513_seed0" / "wo_learned_boundary_optimization"),
    ("final_system", ROOT / "03_outputs" / "outputs_bodyfirst_semanticopt_final_full_eval_20260513_seed0"),
]
DEFAULT_ABLATION_VARIANTS = [
    ("full", "Full Model"),
    ("wo_bodyfirst_host_recovery", "w/o Body-First Host Recovery"),
    ("wo_conservative_protection", "w/o Conservative Protection"),
    ("wo_semantic_structural_rollback", "w/o Semantic-Structural Rollback"),
]


def build_eval_report(target_specs: List[Tuple[str, Path]], out_dir: Path) -> None:
    all_rows: Dict[str, List[Dict[str, object]]] = {}
    comparison: Dict[str, Dict[str, object]] = {}
    output_dirs: Dict[str, str] = {}

    for key, output_dir in target_specs:
        rows = eval_builder.load_rows(output_dir)
        all_rows[key] = rows
        comparison[key] = eval_builder.summarize_rows(rows)
        output_dirs[key] = str(output_dir)

    pairwise: Dict[str, Dict[str, object]] = {}
    final_key = "final_system" if "final_system" in all_rows else ("full_model" if "full_model" in all_rows else None)
    if final_key:
        for ref_key in [
            "raw_partgen_1_5",
            "generic_graph_baseline",
            "knowledge_guided_rule_only_baseline",
            "agglomerative_graph_baseline",
        ]:
            if ref_key in all_rows:
                pairwise[f"{final_key} vs {ref_key}"] = eval_builder.compute_pairwise_wins(all_rows[final_key], all_rows[ref_key])

    main_rows = eval_builder.build_main_table_rows(comparison)
    paper_rows = eval_builder.build_paper_table_rows(comparison)
    universal_rows = eval_builder.build_universal_table_rows(comparison)
    taskaware_rows = eval_builder.build_taskaware_recovery_rows(comparison)
    relation_rows = eval_builder.build_relation_rows(comparison)
    structure_rows = eval_builder.build_structure_rows(comparison)
    case_rows = eval_builder.build_case_table_rows(all_rows)
    taskaware_case_rows = eval_builder.build_case_metric_rows(
        all_rows,
        [
            "component_recovery_score",
            "semantic_recovery_score",
            "instance_f1_50",
            "semantic_instance_f1_50",
            "support_edge_precision",
            "support_edge_recall",
            "support_edge_f1",
            "support_edge_f1_50",
            "support_edge_f1_75",
            "structure_plausibility",
            "structure_violation_rate",
            "host_legality",
            "gong_clean_ratio",
            "upper_dou_support_ratio",
            "num_support_edges",
        ],
    )
    summary = {
        "comparison": comparison,
        "pairwise_wins": pairwise,
        "output_dirs": output_dirs,
        "target_specs": [(key, str(path)) for key, path in target_specs],
    }

    out_dir.mkdir(parents=True, exist_ok=True)
    eval_builder.write_csv(
        out_dir / "pure_eval_main_table.csv",
        main_rows,
        ["method_key", "method_name", "component_partition_f1", "component_count_deviation", "semantic_accuracy", "bcubed_f1", "pairwise_f1", "exact_count_match_rate", "recoverable_case_rate"],
    )
    eval_builder.write_csv(
        out_dir / "pure_eval_main_table_paper.csv",
        paper_rows,
        ["Method", "Partition Quality (F1)", "Count Deviation", "Semantic Accuracy", "B-Cubed F1", "Pairwise F1"],
    )
    eval_builder.write_csv(
        out_dir / "pure_eval_universal_metrics.csv",
        universal_rows,
        ["method_key", "method_name", "bcubed_precision", "bcubed_recall", "bcubed_f1", "pairwise_precision", "pairwise_recall", "pairwise_f1"],
    )
    eval_builder.write_csv(
        out_dir / "pure_eval_taskaware_recovery.csv",
        taskaware_rows,
        ["method_key", "method_name", "component_recovery_score", "instance_f1_50", "instance_f1_75", "semantic_recovery_score", "semantic_instance_f1_50", "semantic_instance_f1_75"],
    )
    eval_builder.write_csv(
        out_dir / "pure_eval_relation_metrics.csv",
        relation_rows,
        ["method_key", "method_name", "support_edge_precision", "support_edge_recall", "support_edge_f1", "support_edge_f1_50", "support_edge_f1_75"],
    )
    eval_builder.write_csv(
        out_dir / "pure_eval_structure_metrics.csv",
        structure_rows,
        ["method_key", "method_name", "structure_plausibility", "host_legality", "gong_clean_ratio", "upper_dou_support_ratio", "structure_violation_rate", "mean_num_support_edges"],
    )
    eval_builder.write_csv(out_dir / "pure_eval_casewise_table.csv", case_rows, list(case_rows[0].keys()) if case_rows else ["uid"])
    eval_builder.write_csv(
        out_dir / "pure_eval_taskaware_casewise_table.csv",
        taskaware_case_rows,
        list(taskaware_case_rows[0].keys()) if taskaware_case_rows else ["uid"],
    )
    (out_dir / "pure_eval_report_zh.md").write_text(
        eval_builder.build_markdown(comparison, pairwise, output_dirs),
        encoding="utf-8",
    )
    (out_dir / "pure_eval_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def build_ablation_report(variant_specs: List[Tuple[str, str]], ablation_root: Path, out_dir: Path) -> None:
    summaries: List[Dict[str, object]] = []
    for variant_name, variant_label in variant_specs:
        item = ablation_builder.summarize_variant(ablation_root / variant_name)
        item["variant_label"] = variant_label
        summaries.append(item)

    main_rows = ablation_builder.build_ablation_rows(summaries)
    taskaware_rows = ablation_builder.build_taskaware_rows(summaries)
    relation_rows = ablation_builder.build_relation_rows(summaries)
    structure_rows = ablation_builder.build_structure_rows(summaries)
    distribution_rows = ablation_builder.build_distribution_rows(summaries)

    out_dir.mkdir(parents=True, exist_ok=True)
    ablation_builder.write_csv(
        out_dir / "pure_ablation_table_paper.csv",
        main_rows,
        ["Variant", "Partition Quality (F1)", "Count Deviation", "Semantic Accuracy", "B-Cubed F1", "Pairwise F1"],
    )
    ablation_builder.write_csv(
        out_dir / "pure_ablation_distribution.csv",
        distribution_rows,
        ["Variant", "Partition Mean", "Partition Median", "Rate >= 0.50", "Rate >= 0.60", "Rate >= 0.70", "Rate >= 0.80", "Partition Min", "Partition Max"],
    )
    ablation_builder.write_csv(
        out_dir / "pure_ablation_taskaware.csv",
        taskaware_rows,
        ["Variant", "Component Recovery Score", "Instance F1@0.50", "Instance F1@0.75", "Semantic Recovery Score", "Semantic Instance F1@0.50", "Semantic Instance F1@0.75"],
    )
    ablation_builder.write_csv(
        out_dir / "pure_ablation_relation.csv",
        relation_rows,
        ["Variant", "Support Edge Precision", "Support Edge Recall", "Support Edge F1", "Support Edge F1@0.50", "Support Edge F1@0.75"],
    )
    ablation_builder.write_csv(
        out_dir / "pure_ablation_structure.csv",
        structure_rows,
        ["Variant", "Structure Plausibility", "Host Legality", "Gong Clean Ratio", "Upper-Dou Support Ratio", "Structure Violation Rate", "Mean Support Edges"],
    )
    (out_dir / "pure_ablation_report_zh.md").write_text(
        ablation_builder.build_markdown(main_rows, taskaware_rows, relation_rows, structure_rows, distribution_rows),
        encoding="utf-8",
    )
    (out_dir / "pure_ablation_summary.json").write_text(
        json.dumps(
            {
                "variant_specs": variant_specs,
                "ablation_root": str(ablation_root),
                "summaries": summaries,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the reorganized paper-facing experiment scheme reports.")
    parser.add_argument("--report_root", default=str(DEFAULT_REPORT_ROOT))
    parser.add_argument("--ablation_root", default=str(ROOT / "03_outputs" / "ablation_study_20260513_seed0"))
    parser.add_argument("--without_agglomerative", action="store_true", help="Drop the agglomerative graph baseline and fall back to the older 4-row main comparison.")
    args = parser.parse_args()

    report_root = Path(args.report_root)
    eval_out_dir = report_root / "main_comparison"
    ablation_out_dir = report_root / "ablation"
    report_root.mkdir(parents=True, exist_ok=True)

    target_specs = list(DEFAULT_EVAL_TARGETS)
    if args.without_agglomerative:
        target_specs = [item for item in target_specs if item[0] != "agglomerative_graph_baseline"]

    build_eval_report(target_specs, eval_out_dir)
    build_ablation_report(DEFAULT_ABLATION_VARIANTS, Path(args.ablation_root), ablation_out_dir)

    manifest = {
        "report_root": str(report_root),
        "eval_targets": [(name, str(path)) for name, path in target_specs],
        "ablation_variants": DEFAULT_ABLATION_VARIANTS,
        "without_agglomerative": bool(args.without_agglomerative),
    }
    (report_root / "report_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
