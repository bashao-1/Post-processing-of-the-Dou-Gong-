import itertools
import json
import os
from collections import defaultdict
from typing import Dict, List, Tuple

import numpy as np

import dougong_refine_v4 as base
import dougong_refine_v7_fragmentrefresh_20260418_core as core


DEFAULT_STAGE1_GONG_PRIOR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "models_fragmentrefresh_realign_20260418",
    "gong_prior_models_realign.json",
)

DEFAULT_STAGE1_MANUAL_CALIBRATOR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "models_fragmentrefresh_realign_20260418",
    "manual_edge_calibrator_realign.json",
)


def load_manual_groups(path: str) -> Dict[str, List[int]]:
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    groups = data.get("groups", {})
    return {str(name): [int(x) for x in segs] for name, segs in groups.items()}


def fit_logistic_classifier(x: np.ndarray, y: np.ndarray, lr: float = 0.05, iters: int = 2500, reg: float = 1e-4) -> Dict:
    mean = x.mean(axis=0).astype(np.float32)
    std = x.std(axis=0).astype(np.float32)
    std[std < 1e-6] = 1.0
    x_norm = (x - mean) / std
    w = np.zeros(x_norm.shape[1], dtype=np.float32)
    b = 0.0
    pos = float(y.sum())
    neg = float(len(y) - pos)
    class_weight_pos = max(1.0, neg / max(pos, 1.0))
    for _ in range(iters):
        logits = x_norm @ w + b
        probs = 1.0 / (1.0 + np.exp(-np.clip(logits, -30.0, 30.0)))
        sample_w = np.where(y > 0.5, class_weight_pos, 1.0).astype(np.float32)
        diff = (probs - y) * sample_w
        grad_w = (x_norm.T @ diff) / max(float(sample_w.sum()), 1.0) + reg * w
        grad_b = float(diff.sum() / max(float(sample_w.sum()), 1.0))
        w -= lr * grad_w
        b -= lr * grad_b
    return {
        "mean": mean.tolist(),
        "std": std.tolist(),
        "weights": w.tolist(),
        "bias": float(b),
        "positive_ratio": float(pos / max(len(y), 1)),
        "num_rows": int(len(y)),
    }


def predict_logit(x: np.ndarray, model: Dict) -> np.ndarray:
    mean = np.asarray(model.get("mean", []), dtype=np.float32)
    std = np.asarray(model.get("std", []), dtype=np.float32)
    std[std < 1e-6] = 1.0
    w = np.asarray(model.get("weights", []), dtype=np.float32)
    b = float(model.get("bias", 0.0))
    if mean.size == 0 or w.size == 0:
        return np.zeros((x.shape[0],), dtype=np.float32)
    return ((x - mean) / std) @ w + b


def classifier_accuracy(x: np.ndarray, y: np.ndarray, model: Dict) -> float:
    pred = (predict_logit(x, model) >= 0.0).astype(np.int32)
    y = y.astype(np.int32)
    return float((pred == y).mean()) if len(y) else 0.0


def quality_margin_from_desc(desc: Dict, semantic_model: Dict) -> float:
    raw = base.semantic_scores_from_descriptor(desc, semantic_model)
    vals = sorted((float(v), str(k)) for k, v in raw.items() if str(k) != "qiao")
    if not vals:
        return 0.0
    best = vals[0][0]
    second = vals[1][0] if len(vals) > 1 else best + 1.0
    return float(second - best)


def pair_stats(seg_ids_a: List[int], seg_ids_b: List[int], score_map: Dict[Tuple[int, int], float]) -> List[float]:
    vals = []
    for a in seg_ids_a:
        for b in seg_ids_b:
            key = tuple(sorted((int(a), int(b))))
            if key in score_map:
                vals.append(float(score_map[key]))
    if not vals:
        return [0.0, -2.0, -2.0]
    arr = np.asarray(vals, dtype=np.float32)
    return [float(arr.mean()), float(arr.max()), float(arr.min())]


def within_stats(seg_ids: List[int], score_map: Dict[Tuple[int, int], float]) -> List[float]:
    if len(seg_ids) <= 1:
        return [0.0, 0.0]
    vals = []
    seg_ids = sorted(int(x) for x in seg_ids)
    for i, a in enumerate(seg_ids):
        for b in seg_ids[i + 1:]:
            key = tuple(sorted((a, b)))
            if key in score_map:
                vals.append(float(score_map[key]))
    if not vals:
        return [0.0, -2.0]
    arr = np.asarray(vals, dtype=np.float32)
    return [float(arr.mean()), float(arr.min())]


def subset_feature(
    subset: List[int],
    rest: List[int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
    semantic_model: Dict,
) -> np.ndarray:
    subset_points = np.vstack([seg_points[sid] for sid in subset]).astype(np.float32)
    rest_points = np.vstack([seg_points[sid] for sid in rest]).astype(np.float32)
    parent_points = np.vstack([subset_points, rest_points]).astype(np.float32)
    descs, pair_rel, _ = base.build_component_descriptors(
        {0: parent_points, 1: subset_points, 2: rest_points}
    )
    rel = pair_rel.get(
        (1, 2),
        {
            "gap": 1.0,
            "centroid_dist": 1.0,
            "z_overlap": 0.0,
            "xy_overlap": 0.0,
            "axis_dot": 0.0,
            "size_ratio": 0.0,
            "signed_dz": 0.0,
        },
    )
    q_parent = quality_margin_from_desc(descs[0], semantic_model)
    q_subset = quality_margin_from_desc(descs[1], semantic_model)
    q_rest = quality_margin_from_desc(descs[2], semantic_model)
    feat = []
    feat.extend(descs[0]["feature"].tolist())
    feat.extend(descs[1]["feature"].tolist())
    feat.extend(descs[2]["feature"].tolist())
    feat.extend([q_parent, q_subset, q_rest, q_subset + q_rest - q_parent])
    feat.extend(
        [
            float(rel["gap"]),
            float(rel["centroid_dist"]),
            float(rel["z_overlap"]),
            float(rel["xy_overlap"]),
            float(rel["axis_dot"]),
            float(rel["size_ratio"]),
            float(rel["signed_dz"]),
        ]
    )
    feat.extend(pair_stats(subset, rest, score_map))
    feat.extend(within_stats(subset, score_map))
    feat.extend(within_stats(rest, score_map))
    feat.extend([float(len(subset)) / 6.0, float(len(rest)) / 8.0])
    return np.asarray(feat, dtype=np.float32)


def merge_feature(
    group_a: List[int],
    group_b: List[int],
    seg_points: Dict[int, np.ndarray],
    semantic_model: Dict,
) -> np.ndarray:
    points_a = np.vstack([seg_points[sid] for sid in group_a]).astype(np.float32)
    points_b = np.vstack([seg_points[sid] for sid in group_b]).astype(np.float32)
    merged_points = np.vstack([points_a, points_b]).astype(np.float32)
    descs, pair_rel, _ = base.build_component_descriptors(
        {0: points_a, 1: points_b, 2: merged_points}
    )
    rel = pair_rel.get(
        (0, 1),
        {
            "gap": 1.0,
            "centroid_dist": 1.0,
            "z_overlap": 0.0,
            "xy_overlap": 0.0,
            "axis_dot": 0.0,
            "size_ratio": 0.0,
            "signed_dz": 0.0,
        },
    )
    q_a = quality_margin_from_desc(descs[0], semantic_model)
    q_b = quality_margin_from_desc(descs[1], semantic_model)
    q_m = quality_margin_from_desc(descs[2], semantic_model)
    feat = []
    feat.extend(
        [
            float(rel["gap"]),
            float(rel["centroid_dist"]),
            float(rel["z_overlap"]),
            float(rel["xy_overlap"]),
            float(rel["axis_dot"]),
            float(rel["size_ratio"]),
            float(rel["signed_dz"]),
        ]
    )
    feat.extend(descs[0]["feature"].tolist())
    feat.extend(descs[1]["feature"].tolist())
    feat.extend(descs[2]["feature"].tolist())
    feat.extend([q_a, q_b, q_m, q_m - max(q_a, q_b)])
    feat.extend(
        [
            float(len(group_a)) / 8.0,
            float(len(group_b)) / 8.0,
            float(len(group_a) + len(group_b)) / 12.0,
        ]
    )
    return np.asarray(feat, dtype=np.float32)


def relabel_component_map(comp_map: Dict[int, int]) -> Dict[int, int]:
    return base.relabel_components({int(k): int(v) for k, v in comp_map.items()})


def collect_component_members(comp_map: Dict[int, int]) -> Dict[int, List[int]]:
    members: Dict[int, List[int]] = defaultdict(list)
    for seg_id, cid in comp_map.items():
        members[int(cid)].append(int(seg_id))
    return {cid: sorted(segs) for cid, segs in members.items()}


def build_component_stats(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
) -> Tuple[Dict[int, List[int]], Dict[int, Dict], float]:
    members = collect_component_members(comp_map)
    comp_points = {
        cid: np.vstack([seg_points[sid] for sid in segs]).astype(np.float32)
        for cid, segs in members.items()
    }
    all_points = np.vstack(list(comp_points.values())).astype(np.float32)
    global_diag = max(float(np.linalg.norm(all_points.max(axis=0) - all_points.min(axis=0))), 1e-8)
    stats: Dict[int, Dict] = {}
    for cid, pts in comp_points.items():
        bmin, bmax, diag = base.bbox_stats(pts)
        ext = np.maximum(bmax - bmin, 1e-8)
        axis = base.pca_axis(pts)
        stats[cid] = {
            "points": pts,
            "bbox_min": bmin,
            "bbox_max": bmax,
            "extents": ext,
            "diag": float(diag),
            "centroid": pts.mean(axis=0),
            "axis": axis,
            "axis_abs": np.abs(axis),
        }
    return members, stats, global_diag


def interval_overlap_ratio(a0: float, a1: float, b0: float, b1: float) -> float:
    inter = max(0.0, min(a1, b1) - max(a0, b0))
    shorter = max(min(a1 - a0, b1 - b0), 1e-8)
    return float(inter / shorter)


def component_pair_edge_stats(
    seg_ids_a: List[int],
    seg_ids_b: List[int],
    score_map: Dict[Tuple[int, int], float],
) -> Tuple[float, float]:
    vals = []
    for a in seg_ids_a:
        for b in seg_ids_b:
            key = tuple(sorted((int(a), int(b))))
            if key in score_map:
                vals.append(float(score_map[key]))
    if not vals:
        return -2.0, -2.0
    arr = np.asarray(vals, dtype=np.float32)
    return float(arr.mean()), float(arr.max())


def build_segment_stats(seg_points: Dict[int, np.ndarray]) -> Tuple[Dict[int, Dict], float]:
    all_points = np.vstack([np.asarray(pts, dtype=np.float32) for pts in seg_points.values()]).astype(np.float32)
    global_diag = max(float(np.linalg.norm(all_points.max(axis=0) - all_points.min(axis=0))), 1e-8)
    stats: Dict[int, Dict] = {}
    for sid, pts in seg_points.items():
        pts = np.asarray(pts, dtype=np.float32)
        bmin, bmax, diag = base.bbox_stats(pts)
        ext = np.maximum(bmax - bmin, 1e-8)
        axis = base.pca_axis(pts)
        stats[int(sid)] = {
            "bbox_min": bmin,
            "bbox_max": bmax,
            "extents": ext,
            "diag": float(diag),
            "centroid": pts.mean(axis=0),
            "axis": axis,
            "axis_abs": np.abs(axis),
        }
    return stats, global_diag


def singleton_semantic_raw_scores(
    seg_points: Dict[int, np.ndarray],
    semantic_model: Dict,
) -> Dict[int, Dict[str, float]]:
    comp_points = {int(sid): np.asarray(pts, dtype=np.float32) for sid, pts in seg_points.items()}
    _, _, _, _, raw_scores = base.predict_component_semantics(comp_points, semantic_model)
    return {int(sid): {str(k): float(v) for k, v in scores.items()} for sid, scores in raw_scores.items()}


def is_strong_sloped_gong_segment(seg: Dict, raw_scores: Dict[str, float], global_diag: float) -> bool:
    axis_abs = seg["axis_abs"]
    ext = seg["extents"]
    ext_y_rel = float(ext[1] / global_diag)
    xz_balance = float(min(ext[0], ext[2]) / max(ext[0], ext[2], 1e-8))
    xz_diag_rel = float(np.linalg.norm([ext[0], ext[2]]) / global_diag)
    raw_gong = float(raw_scores.get("gong", 1e9))
    raw_dou = float(raw_scores.get("dou", 1e9))
    raw_ang = float(raw_scores.get("ang", 1e9))
    return bool(
        axis_abs[1] <= 0.10
        and axis_abs[0] >= 0.45
        and axis_abs[2] >= 0.45
        and 0.045 <= ext_y_rel <= 0.18
        and xz_balance >= 0.45
        and xz_diag_rel >= 0.16
        and raw_gong <= raw_dou + 2.5
        and raw_gong <= raw_ang + 0.9
    )


def split_out_strong_sloped_gong_segments(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
    semantic_model: Dict,
) -> Dict[int, int]:
    work_map = relabel_component_map(comp_map)
    members = collect_component_members(work_map)
    if len(work_map) <= 1:
        return work_map

    seg_stats, global_diag = build_segment_stats(seg_points)
    raw_scores = singleton_semantic_raw_scores(seg_points, semantic_model)
    strong_sloped = {
        sid for sid, seg in seg_stats.items()
        if is_strong_sloped_gong_segment(seg, raw_scores.get(sid, {}), global_diag)
    }
    if not strong_sloped:
        return work_map

    next_cid = max(work_map.values()) + 1 if work_map else 0
    changed = False
    for cid, seg_ids in members.items():
        seg_ids = sorted(seg_ids)
        if len(seg_ids) <= 1:
            continue
        candidate_ids = [sid for sid in seg_ids if sid in strong_sloped]
        if not candidate_ids:
            continue
        non_candidate_ids = [sid for sid in seg_ids if sid not in strong_sloped]
        if not non_candidate_ids:
            continue
        for sid in candidate_ids:
            _, max_to_non = component_pair_edge_stats([sid], non_candidate_ids, score_map)
            if max_to_non < 0.20:
                continue
            work_map[sid] = next_cid
            next_cid += 1
            changed = True

    return relabel_component_map(work_map) if changed else work_map


def is_small_blocky_attachment_segment(seg: Dict, global_diag: float) -> bool:
    ext = seg["extents"]
    diag_rel = float(seg["diag"] / global_diag)
    ext_y_rel = float(ext[1] / global_diag)
    xz_balance = float(min(ext[0], ext[2]) / max(ext[0], ext[2], 1e-8))
    xz_diag_rel = float(np.linalg.norm([ext[0], ext[2]]) / global_diag)
    return bool(
        0.06 <= diag_rel <= 0.26
        and 0.03 <= ext_y_rel <= 0.14
        and xz_balance >= 0.42
        and xz_diag_rel <= 0.24
    )


def attach_small_blocky_segments_to_sloped_hosts(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
    semantic_model: Dict,
) -> Dict[int, int]:
    work_map = relabel_component_map(comp_map)
    members = collect_component_members(work_map)
    seg_stats, global_diag = build_segment_stats(seg_points)
    raw_scores = singleton_semantic_raw_scores(seg_points, semantic_model)

    host_seg_ids = []
    for cid, seg_ids in members.items():
        if len(seg_ids) != 1:
            continue
        sid = int(seg_ids[0])
        if is_strong_sloped_gong_segment(seg_stats[sid], raw_scores.get(sid, {}), global_diag):
            host_seg_ids.append(sid)
    host_seg_ids = sorted(host_seg_ids)
    if len(host_seg_ids) < 3:
        return work_map

    changed = False
    for sid, seg in seg_stats.items():
        if sid in host_seg_ids:
            continue
        if not is_small_blocky_attachment_segment(seg, global_diag):
            continue
        best = None
        second = None
        for host_sid in host_seg_ids:
            host = seg_stats[host_sid]
            host_axis = np.asarray([host["axis"][0], 0.0, host["axis"][2]], dtype=np.float32)
            norm = float(np.linalg.norm(host_axis))
            if norm < 1e-8:
                continue
            host_axis = host_axis / norm
            host_lat = np.asarray([-host_axis[2], 0.0, host_axis[0]], dtype=np.float32)
            diff = seg["centroid"] - host["centroid"]
            along = abs(float(np.dot(diff, host_axis)))
            lateral = abs(float(np.dot(diff, host_lat)))
            y_gap = abs(float(diff[1]))
            host_long = float(np.linalg.norm([host["extents"][0], host["extents"][2]]))
            cand_long = float(np.linalg.norm([seg["extents"][0], seg["extents"][2]]))
            gap = float(base.bbox_gap(host["bbox_min"], host["bbox_max"], seg["bbox_min"], seg["bbox_max"]) / global_diag)
            mean_edge, max_edge = component_pair_edge_stats([sid], [host_sid], score_map)
            if gap > 0.12:
                continue
            if y_gap > global_diag * 0.14:
                continue
            if lateral > max(global_diag * 0.12, 0.35 * cand_long):
                continue
            if along > 0.58 * host_long + 0.95 * cand_long:
                continue
            score = 0.0
            score += 1.0 * max(0.0, 0.14 - gap) / 0.14
            score += 0.9 * max(0.0, global_diag * 0.14 - y_gap) / max(global_diag * 0.14, 1e-8)
            score += 0.9 * max(0.0, max(global_diag * 0.12, 0.35 * cand_long) - lateral) / max(max(global_diag * 0.12, 0.35 * cand_long), 1e-8)
            score += 0.7 * max(0.0, (0.58 * host_long + 0.95 * cand_long) - along) / max((0.58 * host_long + 0.95 * cand_long), 1e-8)
            score += 0.18 * max_edge
            score += 0.06 * mean_edge
            item = (float(score), host_sid)
            if best is None or item[0] > best[0]:
                second = best
                best = item
            elif second is None or item[0] > second[0]:
                second = item
        if best is None:
            continue
        margin = best[0] - (second[0] if second is not None else -1e9)
        if best[0] < 2.15:
            continue
        if second is not None and margin < 0.28:
            continue
        host_sid = int(best[1])
        host_cid = int(work_map[host_sid])
        work_map[sid] = host_cid
        changed = True

    return relabel_component_map(work_map) if changed else work_map


def maybe_restore_identity_for_clean_tiny_case(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
) -> Dict[int, int]:
    seg_ids = sorted(int(sid) for sid in seg_points.keys())
    if len(seg_ids) > 6:
        return relabel_component_map(comp_map)

    current = relabel_component_map(comp_map)
    members = collect_component_members(current)
    if len(members) >= len(seg_ids):
        return current

    all_points = np.vstack([np.asarray(seg_points[sid], dtype=np.float32) for sid in seg_ids]).astype(np.float32)
    global_diag = max(float(np.linalg.norm(all_points.max(axis=0) - all_points.min(axis=0))), 1e-8)
    min_diag_rel = 1.0
    for sid in seg_ids:
        _, _, diag = base.bbox_stats(np.asarray(seg_points[sid], dtype=np.float32))
        min_diag_rel = min(min_diag_rel, float(diag / global_diag))
    if min_diag_rel < 0.16:
        return current

    for segs in members.values():
        if len(segs) <= 1:
            continue
        mean_edge, max_edge = component_pair_edge_stats(segs, segs, score_map)
        if max_edge > 1.35 or mean_edge > 0.95:
            return current

    return {sid: idx for idx, sid in enumerate(seg_ids)}


def is_vertical_body_host(comp: Dict, global_diag: float, min_segments: int) -> bool:
    ext = comp["extents"]
    if min_segments < 3:
        return False
    if ext[2] < max(ext[0], ext[1]) * 3.0:
        return False
    if ext[1] < global_diag * 0.08:
        return False
    if ext[2] < global_diag * 0.28:
        return False
    return True


def is_horizontal_body_like(comp: Dict) -> bool:
    ext = comp["extents"]
    long_xy = max(float(ext[0]), float(ext[1]))
    return bool(long_xy > float(ext[2]) * 1.6)


def reassign_alien_segments_from_vertical_hosts(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
) -> Dict[int, int]:
    work_map = relabel_component_map(comp_map)
    members, stats, global_diag = build_component_stats(work_map, seg_points)
    if len(members) <= 1:
        return work_map

    changed = False
    for host_cid, host_seg_ids in members.items():
        host = stats[host_cid]
        if not is_vertical_body_host(host, global_diag, len(host_seg_ids)):
            continue
        host_z = float(host["bbox_max"][2] - host["bbox_min"][2])
        host_self_cache = {}
        for sid in list(host_seg_ids):
            if len(host_seg_ids) <= 3:
                break
            pts = np.asarray(seg_points[sid], dtype=np.float32)
            bmin, bmax, _ = base.bbox_stats(pts)
            seg_z = float(bmax[2] - bmin[2])
            if seg_z > host_z * 0.25:
                continue
            host_other = [x for x in host_seg_ids if x != sid]
            if not host_other:
                continue
            _, host_max = component_pair_edge_stats([sid], host_other, score_map)
            best_alt = None
            for alt_cid, alt_seg_ids in members.items():
                if alt_cid == host_cid:
                    continue
                alt = stats[alt_cid]
                if not is_horizontal_body_like(alt):
                    continue
                x_overlap = interval_overlap_ratio(float(bmin[0]), float(bmax[0]), float(alt["bbox_min"][0]), float(alt["bbox_max"][0]))
                z_overlap = interval_overlap_ratio(float(bmin[2]), float(bmax[2]), float(alt["bbox_min"][2]), float(alt["bbox_max"][2]))
                y_gap = max(0.0, max(float(bmin[1]) - float(alt["bbox_max"][1]), float(alt["bbox_min"][1]) - float(bmax[1])))
                if x_overlap < 0.75 or z_overlap < 0.75:
                    continue
                if y_gap > global_diag * 0.035:
                    continue
                _, alt_max = component_pair_edge_stats([sid], alt_seg_ids, score_map)
                if alt_max < 1.4:
                    continue
                if alt_max < host_max + 0.65:
                    continue
                if best_alt is None or alt_max > best_alt[0]:
                    best_alt = (alt_max, alt_cid)
            if best_alt is None:
                continue
            work_map[sid] = int(best_alt[1])
            changed = True

    return relabel_component_map(work_map) if changed else work_map


def attach_vertical_body_upper_caps(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
) -> Dict[int, int]:
    work_map = relabel_component_map(comp_map)
    changed = True
    while changed:
        changed = False
        members, stats, global_diag = build_component_stats(work_map, seg_points)
        best = None
        for host_cid, host_seg_ids in members.items():
            host = stats[host_cid]
            if not is_vertical_body_host(host, global_diag, len(host_seg_ids)):
                continue
            for cand_cid, cand_seg_ids in members.items():
                if cand_cid == host_cid:
                    continue
                cand = stats[cand_cid]
                cand_ext = cand["extents"]
                if cand_ext[1] > global_diag * 0.07:
                    continue
                if cand_ext[2] < host["extents"][2] * 0.82:
                    continue
                if cand["centroid"][1] < host["centroid"][1] - global_diag * 0.015:
                    continue
                x_overlap = interval_overlap_ratio(
                    float(host["bbox_min"][0]), float(host["bbox_max"][0]),
                    float(cand["bbox_min"][0]), float(cand["bbox_max"][0]),
                )
                z_overlap = interval_overlap_ratio(
                    float(host["bbox_min"][2]), float(host["bbox_max"][2]),
                    float(cand["bbox_min"][2]), float(cand["bbox_max"][2]),
                )
                if x_overlap < 0.70 or z_overlap < 0.88:
                    continue
                mean_edge, max_edge = component_pair_edge_stats(host_seg_ids, cand_seg_ids, score_map)
                if max_edge < 0.95 and mean_edge < 0.20:
                    continue
                score = 1.2 * x_overlap + 1.5 * z_overlap + 0.12 * max_edge + 0.04 * mean_edge
                if best is None or score > best[0]:
                    best = (score, host_cid, cand_cid)
        if best is not None:
            _, host_cid, cand_cid = best
            for sid, cid in list(work_map.items()):
                if cid == cand_cid:
                    work_map[sid] = host_cid
            work_map = relabel_component_map(work_map)
            changed = True
    return work_map


def pairwise_f1_from_map(comp_map: Dict[int, int], gold_groups: Dict[str, List[int]]) -> float:
    pred_groups: Dict[int, List[int]] = defaultdict(list)
    for seg_id, cid in comp_map.items():
        pred_groups[int(cid)].append(int(seg_id))
    pred_pairs = set()
    gold_pairs = set()
    for segs in pred_groups.values():
        segs = sorted(segs)
        for i in range(len(segs)):
            for j in range(i + 1, len(segs)):
                pred_pairs.add((segs[i], segs[j]))
    for segs in gold_groups.values():
        segs = sorted(int(x) for x in segs)
        for i in range(len(segs)):
            for j in range(i + 1, len(segs)):
                gold_pairs.add((segs[i], segs[j]))
    if not pred_pairs and not gold_pairs:
        return 1.0
    tp = len(pred_pairs & gold_pairs)
    fp = len(pred_pairs - gold_pairs)
    fn = len(gold_pairs - pred_pairs)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    return float(2.0 * precision * recall / max(precision + recall, 1e-8))


def load_stage1_assets(
    model_dir: str,
    merge_semantic_model_dir: str,
    gong_prior_model_json: str,
    manual_edge_calibrator_json: str,
) -> Tuple[Dict, Dict, Dict, Dict]:
    with open(os.path.join(model_dir, "merge_edge_model.json"), "r", encoding="utf-8") as f:
        merge_edge_model = json.load(f)
    semantic_model = core.load_merge_semantic_model(merge_semantic_model_dir, model_dir)
    learned_priors = core.load_gong_prior_models(gong_prior_model_json, model_dir)
    manual_edge_calibrator = core.load_manual_edge_calibrator(manual_edge_calibrator_json, model_dir)
    return merge_edge_model, semantic_model, learned_priors, manual_edge_calibrator


def build_stage1_case_data(
    uid: str,
    fragment_dir: str,
    model_dir: str,
    merge_semantic_model_dir: str,
    gong_prior_model_json: str,
    manual_edge_calibrator_json: str,
    max_points: int = 512,
    neighbor_ratio: float = 0.08,
    contact_eps: float = 0.01,
) -> Dict:
    fragment_file = base.find_fragment_file(fragment_dir, uid)
    if not fragment_file:
        raise FileNotFoundError(f"fragment file not found for {uid}")
    merge_edge_model, semantic_model, learned_priors, manual_edge_calibrator = load_stage1_assets(
        model_dir=model_dir,
        merge_semantic_model_dir=merge_semantic_model_dir,
        gong_prior_model_json=gong_prior_model_json,
        manual_edge_calibrator_json=manual_edge_calibrator_json,
    )
    segments, segment_names, center, scale, global_diag = base.load_fragment_segments(fragment_file, max_points)
    edges, feats = core.build_augmented_edges(
        segments,
        global_diag=global_diag,
        neighbor_ratio=neighbor_ratio,
        contact_eps=contact_eps,
    )
    x, feature_names = base.features_to_matrix(feats)
    scores = base.score_edges(x, merge_edge_model) if x.shape[0] else np.zeros((0,), dtype=np.float32)
    scores = core.fuse_edge_scores(scores, x, feature_names, manual_edge_calibrator)
    comp_map = core.recover_component_map_v7(
        segments=segments,
        edges=edges,
        scores=scores,
        model=merge_edge_model,
        semantic_model=semantic_model,
        learned_priors=learned_priors,
        enable_z_gong=False,
        target_components_hint=0,
        force_target=False,
    )
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    gold_path = ""
    for manual_dir_name in ("manual_groupings_reference", "manual_gold_groupings"):
        candidate = os.path.join(root_dir, manual_dir_name, f"{uid}_groups_draft.json")
        if os.path.exists(candidate):
            gold_path = candidate
            break
    gold_groups = load_manual_groups(gold_path) if gold_path else {}
    seg_to_group = {}
    for name, segs in gold_groups.items():
        for seg_id in segs:
            seg_to_group[int(seg_id)] = str(name)
    seg_points = {int(seg.seg_id): seg.points for seg in segments}
    score_map = {tuple(sorted((int(a), int(b)))): float(s) for (a, b), s in zip(edges, scores)}
    return {
        "uid": str(uid),
        "segments": segments,
        "segment_names": [str(x) for x in segment_names.tolist()],
        "center": np.asarray(center, dtype=np.float32),
        "scale": float(scale),
        "global_diag": float(global_diag),
        "seg_points": seg_points,
        "score_map": score_map,
        "comp_map": relabel_component_map(comp_map),
        "gold_groups": gold_groups,
        "seg_to_group": seg_to_group,
    }


def apply_stage2_refinement(
    comp_map: Dict[int, int],
    seg_points: Dict[int, np.ndarray],
    score_map: Dict[Tuple[int, int], float],
    semantic_model: Dict,
    stage2_model: Dict,
) -> Dict[int, int]:
    comp_map = relabel_component_map(comp_map)
    split_model = stage2_model.get("split_classifier", {})
    merge_model = stage2_model.get("merge_classifier", {})
    split_threshold = float(stage2_model.get("split_threshold", 1.0))
    merge_threshold = float(stage2_model.get("merge_threshold", 1.5))
    next_cid = max(comp_map.values()) + 1 if comp_map else 0

    changed = True
    while changed:
        changed = False
        members: Dict[int, List[int]] = defaultdict(list)
        for seg_id, cid in comp_map.items():
            members[int(cid)].append(int(seg_id))
        best = None
        for cid, segs in members.items():
            segs = sorted(segs)
            if len(segs) < 2 or len(segs) > 6:
                continue
            for subset_size in (1, 2):
                if subset_size >= len(segs):
                    continue
                for subset in itertools.combinations(segs, subset_size):
                    rest = [sid for sid in segs if sid not in subset]
                    feat = subset_feature(list(subset), rest, seg_points, score_map, semantic_model)[None, :]
                    logit = float(predict_logit(feat, split_model)[0])
                    if best is None or logit > best[0]:
                        best = (logit, int(cid), [int(x) for x in subset])
        if best and best[0] > split_threshold:
            _, source_cid, subset_ids = best
            for seg_id in subset_ids:
                if comp_map.get(seg_id) == source_cid:
                    comp_map[seg_id] = next_cid
            next_cid += 1
            comp_map = relabel_component_map(comp_map)
            changed = True

    changed = True
    while changed:
        changed = False
        members: Dict[int, List[int]] = defaultdict(list)
        for seg_id, cid in comp_map.items():
            members[int(cid)].append(int(seg_id))
        best = None
        cids = sorted(members.keys())
        for i, cid_a in enumerate(cids):
            group_a = sorted(members[cid_a])
            for cid_b in cids[i + 1:]:
                group_b = sorted(members[cid_b])
                feat = merge_feature(group_a, group_b, seg_points, semantic_model)[None, :]
                logit = float(predict_logit(feat, merge_model)[0])
                if best is None or logit > best[0]:
                    best = (logit, int(cid_a), int(cid_b))
        if best and best[0] > merge_threshold:
            _, cid_a, cid_b = best
            for seg_id, cid in list(comp_map.items()):
                if cid == cid_b:
                    comp_map[seg_id] = cid_a
            comp_map = relabel_component_map(comp_map)
            changed = True

    comp_map = reassign_alien_segments_from_vertical_hosts(comp_map, seg_points, score_map)
    comp_map = attach_vertical_body_upper_caps(comp_map, seg_points, score_map)
    comp_map = split_out_strong_sloped_gong_segments(comp_map, seg_points, score_map, semantic_model)
    comp_map = attach_small_blocky_segments_to_sloped_hosts(comp_map, seg_points, score_map, semantic_model)
    comp_map = maybe_restore_identity_for_clean_tiny_case(comp_map, seg_points, score_map)
    return relabel_component_map(comp_map)


def train_stage2_models(case_rows: List[Dict], semantic_model: Dict) -> Dict:
    split_x = []
    split_y = []
    merge_x = []
    merge_y = []
    focus_uid_set = {"f624e1a47839", "0f5c68e92f93", "e0c87a48f5a5"}
    focus_weight = 3

    for row in case_rows:
        uid_weight = focus_weight if row["uid"] in focus_uid_set else 1
        comp_members: Dict[int, List[int]] = defaultdict(list)
        for seg_id, cid in row["comp_map"].items():
            comp_members[int(cid)].append(int(seg_id))

        candidate_groups = set()
        for cid, segs in comp_members.items():
            segs = sorted(segs)
            parent_groups = {row["seg_to_group"][sid] for sid in segs}
            if len(parent_groups) == 1:
                candidate_groups.add(tuple(segs))
            if 2 <= len(segs) <= 6:
                for subset_size in (1, 2):
                    if subset_size >= len(segs):
                        continue
                    for subset in itertools.combinations(segs, subset_size):
                        rest = [sid for sid in segs if sid not in subset]
                        subset_groups = {row["seg_to_group"][sid] for sid in subset}
                        rest_groups = {row["seg_to_group"][sid] for sid in rest}
                        label = 1.0 if (len(subset_groups) == 1 and len(rest_groups) < len(parent_groups)) else 0.0
                        feat = subset_feature(
                            list(subset),
                            rest,
                            row["seg_points"],
                            row["score_map"],
                            semantic_model,
                        )
                        for _ in range(uid_weight):
                            split_x.append(feat)
                            split_y.append(label)
                        if len(subset_groups) == 1:
                            candidate_groups.add(tuple(sorted(subset)))
                        if len(rest_groups) == 1:
                            candidate_groups.add(tuple(sorted(rest)))

        candidate_groups = sorted(candidate_groups)
        for i, group_a in enumerate(candidate_groups):
            sem_a = {row["seg_to_group"][sid] for sid in group_a}
            if len(sem_a) != 1:
                continue
            for group_b in candidate_groups[i + 1:]:
                if set(group_a) & set(group_b):
                    continue
                sem_b = {row["seg_to_group"][sid] for sid in group_b}
                if len(sem_b) != 1:
                    continue
                feat = merge_feature(
                    list(group_a),
                    list(group_b),
                    row["seg_points"],
                    semantic_model,
                )
                label = 1.0 if list(sem_a)[0] == list(sem_b)[0] else 0.0
                for _ in range(uid_weight):
                    merge_x.append(feat)
                    merge_y.append(label)

    split_x_np = np.vstack(split_x).astype(np.float32)
    split_y_np = np.asarray(split_y, dtype=np.float32)
    merge_x_np = np.vstack(merge_x).astype(np.float32)
    merge_y_np = np.asarray(merge_y, dtype=np.float32)

    split_classifier = fit_logistic_classifier(split_x_np, split_y_np)
    merge_classifier = fit_logistic_classifier(merge_x_np, merge_y_np)

    focus_uids = [uid for uid in ["f624e1a47839", "0f5c68e92f93", "e0c87a48f5a5"] if any(row["uid"] == uid for row in case_rows)]
    if not focus_uids:
        focus_uids = [row["uid"] for row in case_rows]

    best = None
    for split_threshold in [0.6, 0.8, 1.0, 1.2, 1.5]:
        for merge_threshold in [1.5, 2.0, 2.5, 3.0]:
            scores = []
            for row in case_rows:
                if row["uid"] not in focus_uids:
                    continue
                refined_map = apply_stage2_refinement(
                    comp_map=row["comp_map"],
                    seg_points=row["seg_points"],
                    score_map=row["score_map"],
                    semantic_model=semantic_model,
                    stage2_model={
                        "split_classifier": split_classifier,
                        "merge_classifier": merge_classifier,
                        "split_threshold": float(split_threshold),
                        "merge_threshold": float(merge_threshold),
                    },
                )
                scores.append(pairwise_f1_from_map(refined_map, row["gold_groups"]))
            if not scores:
                continue
            key = (min(scores), float(sum(scores) / len(scores)), -split_threshold, -merge_threshold)
            if best is None or key > best[0]:
                best = (
                    key,
                    {
                        "split_threshold": float(split_threshold),
                        "merge_threshold": float(merge_threshold),
                        "focus_uids": list(focus_uids),
                        "focus_pairwise_f1": {uid: float(score) for uid, score in zip(focus_uids, scores)},
                    },
                )

    chosen = best[1] if best is not None else {
        "split_threshold": 1.0,
        "merge_threshold": 1.5,
        "focus_uids": list(focus_uids),
        "focus_pairwise_f1": {},
    }

    return {
        "version": "fragmentrefresh_stage2_component_models_20260418",
        "split_classifier": split_classifier,
        "merge_classifier": merge_classifier,
        "split_threshold": float(chosen["split_threshold"]),
        "merge_threshold": float(chosen["merge_threshold"]),
        "focus_uids": list(chosen["focus_uids"]),
        "focus_pairwise_f1": chosen["focus_pairwise_f1"],
        "split_train_accuracy": classifier_accuracy(split_x_np, split_y_np, split_classifier),
        "merge_train_accuracy": classifier_accuracy(merge_x_np, merge_y_np, merge_classifier),
        "split_positive_ratio": float(split_y_np.mean()),
        "merge_positive_ratio": float(merge_y_np.mean()),
        "split_rows": int(split_x_np.shape[0]),
        "merge_rows": int(merge_x_np.shape[0]),
    }
