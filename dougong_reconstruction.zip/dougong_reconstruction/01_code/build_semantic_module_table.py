from __future__ import annotations

import csv
import json
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
SRC = Path(r"data/semantic_optimization_frozen_merge")
REPORTS = {
    "original_semantic_labels": SRC / "reports" / "baseline_semantics_glb_512",
    "raw_semantic_score_argmin": SRC / "reports" / "raw_argmin_512",
    "final_semantic_model": SRC / "FINAL_SEMANTIC_MODEL_PACKAGE_20260822" / "evaluation",
}
DISPLAY = {
    "original_semantic_labels": "Original semantic labels (frozen merge)",
    "raw_semantic_score_argmin": "Raw semantic-score argmin (frozen merge)",
    "final_semantic_model": "Final semantic model (frozen merge)",
}
CLASSES = ("gong", "dou", "fang", "chuan", "ang", "other")


def main() -> None:
    out = PKG / "05_reports" / "semantic_module"
    out.mkdir(parents=True, exist_ok=True)
    overall = []
    classwise = []
    matrices = {}
    casewise = []
    for key, directory in REPORTS.items():
        evaluation = json.loads((directory / "semantic_evaluation.json").read_text(encoding="utf-8"))
        overall.append({
            "method": key,
            "display_name": DISPLAY[key],
            "cases": evaluation["num_cases"],
            "dataset_mass_accuracy": evaluation["dataset_semantic_accuracy_mass"],
            "dataset_macro_f1": evaluation["dataset_semantic_macro_f1"],
            "dataset_weighted_f1": evaluation["dataset_semantic_weighted_f1"],
            "mean_mass_accuracy": evaluation["mean_semantic_accuracy_mass"],
            "mean_macro_f1": evaluation["mean_semantic_macro_f1"],
            "mean_weighted_f1": evaluation["mean_semantic_weighted_f1"],
            "mean_distribution_consistency": evaluation["mean_semantic_distribution_consistency"],
            "mean_component_purity": evaluation["mean_semantic_component_purity"],
        })
        for cls in CLASSES:
            vals = evaluation["dataset_per_class"][cls]
            classwise.append({"method": key, "display_name": DISPLAY[key], "class": cls, **vals})
        matrices[key] = evaluation["dataset_confusion_matrix"]
        for row in evaluation["casewise"]:
            casewise.append({"method": key, "display_name": DISPLAY[key], **row})

    def write(name: str, rows: list[dict]) -> None:
        with (out / name).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)

    write("semantic_module_overall.csv", overall)
    write("semantic_module_classwise.csv", classwise)
    write("semantic_module_casewise.csv", casewise)
    (out / "semantic_module_confusion_matrices.json").write_text(json.dumps(matrices, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "semantic_module_protocol.json").write_text(json.dumps({
        "cases": 26,
        "merge_partition": "fixed Final System partition for all three rows",
        "gt_source": "GLB aligned GT",
        "samples": 512,
        "metric": "soft fragment-to-GT overlap / mass-flow semantic evaluation",
        "classes": list(CLASSES),
        "rows": list(DISPLAY.values()),
        "purpose": "semantic-module-only comparison; not a replacement for the four-method system-level Table 4",
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"out_dir": str(out), "rows": len(overall), "class_rows": len(classwise)}))


if __name__ == "__main__":
    main()
