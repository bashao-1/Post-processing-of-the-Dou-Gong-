import argparse
import json
import os
import sys

import numpy as np

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

import dougong_refine_v4 as base
import task_aware_eval_metrics_20260427 as task_eval
from dougong_refine_generic_graph_baseline_clean_20260426 import (
    DEFAULT_MANUAL_GROUP_DIR,
    DEFAULT_SEMANTIC_LABEL_MODEL_DIR,
    build_case_data,
    evaluate_case,
    load_semantic_model_with_roles,
    save_refined_outputs,
)


def refine_case(uid: str, args) -> tuple[dict, dict]:
    case_row = build_case_data(uid, args)
    comp_map = base.singleton_component_map(case_row["segments"])
    return case_row, comp_map


def evaluate_all(args):
    np.random.seed(int(args.seed))
    label_semantic_model = load_semantic_model_with_roles(args.semantic_label_model_dir)
    ids = base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    os.makedirs(args.out_dir, exist_ok=True)
    results = []
    for uid in ids:
        case_row, comp_map = refine_case(uid, args)
        save_refined_outputs(
            uid=uid,
            case_row=case_row,
            comp_map=comp_map,
            semantic_model=label_semantic_model,
            out_dir=args.out_dir,
        )
        row = evaluate_case(
            uid=uid,
            case_row=case_row,
            comp_map=comp_map,
            semantic_model=label_semantic_model,
            gt_dir=args.gt_dir,
            gt_samples=args.gt_samples,
        )
        if row is not None:
            results.append(row)
            manual_msg = ""
            if "manual_pairwise_f1" in row:
                manual_msg = (
                    f", manual_pairwise_f1={row['manual_pairwise_f1']:.4f}, "
                    f"manual_bcubed_f1={row.get('manual_bcubed_f1', 0.0):.4f}"
                )
            print(
                f"evaluated {uid}: components={row['num_components']}, "
                f"cluster_f1={row['segment_partition_f1']:.4f}, "
                f"gt_bcubed_f1={row['gt_bcubed_f1']:.4f}, "
                f"geometry_balanced={row['geometry_balanced_score']:.4f}, "
                f"segment_semantic_acc={row['segment_semantic_acc']:.4f}{manual_msg}"
            )

    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    summary = {
        "baseline_name": "raw_fragment_identity",
        "baseline_scope": "no_merge_identity_components",
        "uses_domain_priors": False,
        "shares_final_semantic_label_model": True,
        "seed": int(args.seed),
        "semantic_label_model_dir": str(args.semantic_label_model_dir),
        "num_models": len(results),
        "mean_purity_definition": "harmonic_mean(segment_mean_purity, segment_mean_completeness)",
        "mean_num_components": float(np.mean([r["num_components"] for r in results])) if results else 0.0,
        "mean_component_count_diff": float(np.mean([r["component_count_diff"] for r in results])) if results else 0.0,
        "mean_purity": float(np.mean([r["mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_purity": float(np.mean([r["segment_mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_completeness": float(np.mean([r["segment_mean_completeness"] for r in results])) if results else 0.0,
        "mean_segment_partition_f1": float(np.mean([r["segment_partition_f1"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_precision": float(np.mean([r["gt_bcubed_precision"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_recall": float(np.mean([r["gt_bcubed_recall"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_f1": float(np.mean([r["gt_bcubed_f1"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_precision": float(np.mean([r["gt_pairwise_precision"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_recall": float(np.mean([r["gt_pairwise_recall"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_f1": float(np.mean([r["gt_pairwise_f1"] for r in results])) if results else 0.0,
        "mean_geometry_purity": float(np.mean([r["geometry_mean_purity"] for r in results])) if results else 0.0,
        "mean_geometry_pred_score": float(np.mean([r["geometry_pred_score"] for r in results])) if results else 0.0,
        "mean_geometry_gt_score": float(np.mean([r["geometry_gt_score"] for r in results])) if results else 0.0,
        "mean_geometry_balanced_score": float(np.mean([r["geometry_balanced_score"] for r in results])) if results else 0.0,
        "mean_purity_legacy": float(np.mean([r["mean_purity_legacy"] for r in results])) if results else 0.0,
        "mean_forward_cover": float(np.mean([r["mean_forward_cover"] for r in results])) if results else 0.0,
        "mean_backward_cover": float(np.mean([r["mean_backward_cover"] for r in results])) if results else 0.0,
        "mean_gt_cover": float(np.mean([r["mean_gt_cover"] for r in results])) if results else 0.0,
        "mean_matched_component_purity": float(np.mean([r["mean_matched_component_purity"] for r in results])) if results else 0.0,
        "mean_semantic_acc": float(np.mean([r["semantic_acc"] for r in results])) if results else 0.0,
        "mean_segment_semantic_acc": float(np.mean([r["segment_semantic_acc"] for r in results])) if results else 0.0,
        "mean_num_support_edges": float(np.mean([r["num_support_edges"] for r in results])) if results else 0.0,
        "mean_num_layers": float(np.mean([r["num_layers"] for r in results])) if results else 0.0,
    }
    summary.update(task_eval.summarize_task_aware_rows(results))
    manual_rows = [r for r in results if "manual_pairwise_f1" in r]
    if manual_rows:
        summary["manual_case_count"] = len(manual_rows)
        summary["mean_manual_pairwise_precision"] = float(np.mean([r["manual_pairwise_precision"] for r in manual_rows]))
        summary["mean_manual_pairwise_recall"] = float(np.mean([r["manual_pairwise_recall"] for r in manual_rows]))
        summary["mean_manual_pairwise_f1"] = float(np.mean([r["manual_pairwise_f1"] for r in manual_rows]))
        summary["mean_manual_bcubed_f1"] = float(np.mean([r["manual_bcubed_f1"] for r in manual_rows]))
        summary["mean_manual_segment_purity"] = float(np.mean([r["manual_segment_mean_purity"] for r in manual_rows]))
        summary["mean_manual_segment_completeness"] = float(np.mean([r["manual_segment_mean_completeness"] for r in manual_rows]))
        summary["mean_manual_segment_partition_f1"] = float(np.mean([r["manual_segment_partition_f1"] for r in manual_rows]))
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evaluate raw fragment identity components with the current metric stack.")
    parser.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    parser.add_argument("--gt_dir", default=r"data")
    parser.add_argument("--semantic_label_model_dir", default=DEFAULT_SEMANTIC_LABEL_MODEL_DIR)
    parser.add_argument("--manual_group_dir", default=DEFAULT_MANUAL_GROUP_DIR)
    parser.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "03_outputs", "outputs_raw_partgen_1_5_eval_20260502_seed0"))
    parser.add_argument("--max_points", type=int, default=512)
    parser.add_argument("--gt_samples", type=int, default=512)
    parser.add_argument("--seed", type=int, default=0)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    evaluate_all(args)


if __name__ == "__main__":
    main()
