import argparse
import json
import os
import sys
from collections import defaultdict

import numpy as np

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

import dougong_refine_v4 as base
import dougong_refine_v7_fragmentrefresh_20260418_core as core
import task_aware_eval_metrics_20260427 as task_eval
from fragmentrefresh_stage2_utils_20260418 import (
    DEFAULT_STAGE1_GONG_PRIOR,
    DEFAULT_STAGE1_MANUAL_CALIBRATOR,
    apply_stage2_refinement,
    build_stage1_case_data,
    pairwise_f1_from_map,
)


DEFAULT_STAGE2_MODEL = os.path.join(ROOT_DIR, "02_models", "models_fragmentrefresh_realign_20260418", "stage2_component_models.json")


def save_refined_outputs(uid: str, case_row: dict, comp_map: dict, semantic_model: dict, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    segments = case_row["segments"]
    segment_names = case_row["segment_names"]

    fragment_labels = []
    comp_labels = []
    comp_points = defaultdict(list)
    for seg in segments:
        seg_id = int(seg.seg_id)
        cid = int(comp_map[seg_id])
        fragment_labels.append(np.full(len(seg.points), seg_id, dtype=np.int32))
        comp_labels.append(np.full(len(seg.points), cid, dtype=np.int32))
        comp_points[cid].append(seg.points)
    fragment_labels = np.concatenate(fragment_labels)
    comp_labels = np.concatenate(comp_labels)
    comp_points = {cid: np.vstack(v).astype(np.float32) for cid, v in comp_points.items()}

    comp_sem, descriptors, pair_relations, global_meta, raw_scores = base.predict_component_semantics(
        comp_points, semantic_model
    )
    structure = base.recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)

    np.savez_compressed(
        os.path.join(out_dir, f"{uid}_refined.npz"),
        fragment_labels=fragment_labels,
        comp_labels=comp_labels,
        segment_names=np.array(segment_names, dtype=object),
    )

    summary = {
        "uid": uid,
        "num_segments": len(segments),
        "num_components": len(comp_points),
        "components": [
            {
                "component_id": int(cid),
                "semantic": str(comp_sem.get(cid, "unknown")),
                "segment_ids": sorted(int(x) for x in np.unique(fragment_labels[comp_labels == cid]).tolist()),
                "semantic_scores": {str(k): float(v) for k, v in raw_scores.get(cid, {}).items()},
            }
            for cid in sorted(comp_points.keys())
        ],
        "structure": structure,
    }
    with open(os.path.join(out_dir, f"{uid}_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


def load_runtime_models(args):
    with open(args.stage2_model_json, "r", encoding="utf-8") as f:
        stage2_model = json.load(f)
    semantic_model = core.load_merge_semantic_model(args.merge_semantic_model_dir, args.model_dir)
    return stage2_model, semantic_model


def refine_case(uid: str, args, stage2_model: dict, semantic_model: dict):
    case_row = build_stage1_case_data(
        uid=uid,
        fragment_dir=args.fragment_dir,
        model_dir=args.model_dir,
        merge_semantic_model_dir=args.merge_semantic_model_dir,
        gong_prior_model_json=args.gong_prior_model_json,
        manual_edge_calibrator_json=args.manual_edge_calibrator_json,
        max_points=args.max_points,
        neighbor_ratio=args.neighbor_ratio,
        contact_eps=args.contact_eps,
    )
    refined_map = apply_stage2_refinement(
        comp_map=case_row["comp_map"],
        seg_points=case_row["seg_points"],
        score_map=case_row["score_map"],
        semantic_model=semantic_model,
        stage2_model=stage2_model,
    )
    return case_row, refined_map


def build_component_points(case_row: dict, comp_map: dict) -> dict:
    comp_points = defaultdict(list)
    for seg in case_row["segments"]:
        seg_id = int(seg.seg_id)
        comp_points[int(comp_map[seg_id])].append(seg.points)
    return {cid: np.vstack(v).astype(np.float32) for cid, v in comp_points.items()}


def evaluate_case(uid: str, case_row: dict, comp_map: dict, semantic_model: dict, gt_dir: str, gt_samples: int) -> dict | None:
    gt_parts = base.load_gt_parts_auto(
        gt_dir,
        uid,
        np.asarray(case_row["center"], dtype=np.float32),
        float(case_row["scale"]),
        gt_samples,
    )
    if not gt_parts:
        return None

    comp_points = build_component_points(case_row, comp_map)
    comp_sem, descriptors, pair_relations, global_meta, _ = base.predict_component_semantics(comp_points, semantic_model)
    structure = base.recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)
    segments = case_row["segments"]
    seg_weights = base.segment_weight_map(segments)
    seg_to_gt, seg_dom = base.segment_label_map_from_gt(segments, gt_parts)
    segment_mean_purity = base.weighted_cluster_purity_from_seg_labels(comp_map, seg_to_gt, seg_weights)
    segment_mean_completeness = base.weighted_cluster_completeness_from_seg_labels(comp_map, seg_to_gt, seg_weights)
    segment_partition_f1 = base.harmonic_mean_score(segment_mean_purity, segment_mean_completeness)
    gt_bc = base.bcubed_from_maps(comp_map, seg_to_gt, seg_weights)
    gt_pairwise = base.pairwise_prf_from_maps(comp_map, seg_to_gt)
    segment_semantic_acc = base.weighted_semantic_accuracy_from_seg_maps(
        comp_map, seg_to_gt, comp_sem, gt_parts, seg_weights
    )

    comp_to_gt_legacy = {}
    purity_legacy = []
    for cid, pts in comp_points.items():
        bmin, bmax, diag = base.bbox_stats(pts)
        tmp_seg = base.Segment(
            seg_id=cid,
            points=pts,
            centroid=pts.mean(axis=0),
            bbox_min=bmin,
            bbox_max=bmax,
            axis=base.pca_axis(pts),
            bbox_diag=diag,
        )
        mapping, dominance = base.assign_segments_to_gt([tmp_seg], gt_parts)
        if mapping:
            comp_to_gt_legacy[cid] = mapping[cid]
            purity_legacy.append(dominance[cid])
    mean_purity_legacy = float(np.mean(purity_legacy)) if purity_legacy else 0.0

    tau = max(0.05, 0.12 * float(case_row.get("global_diag", 1.0)))
    mean_purity, comp_to_gt, comp_scores, comp_score_details = base.component_mean_purity(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=0.5,
    )
    mean_forward_cover = float(np.mean([v["forward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
    mean_backward_cover = float(np.mean([v["backward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
    geometry_pred_score, _, _, _ = base.component_mean_purity(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=1.0,
    )
    geometry_gt_score, _, _, gt_score_details = base.gt_part_mean_coverage(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=1.0,
    )
    geometry_balanced_score = base.harmonic_mean_score(geometry_pred_score, geometry_gt_score)
    mean_gt_cover = float(np.mean([v["gt_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0
    mean_matched_component_purity = float(np.mean([v["pred_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0

    correct = 0
    total = 0
    for cid, gt_idx in comp_to_gt.items():
        sem_gt = gt_parts[gt_idx].semantic
        sem_pred = comp_sem.get(cid, "unknown")
        correct += int(sem_pred == sem_gt)
        total += 1
    sem_acc = correct / max(total, 1)

    row = {
        "uid": uid,
        "num_segments": len(case_row["segments"]),
        "num_components": len(comp_points),
        "num_gt_parts": len(gt_parts),
        "recoverable_case": bool(len(case_row["segments"]) >= len(gt_parts)),
        "component_count_diff": abs(len(comp_points) - len(gt_parts)),
        "mean_purity": segment_partition_f1,
        "segment_mean_purity": segment_mean_purity,
        "segment_mean_completeness": segment_mean_completeness,
        "segment_partition_f1": segment_partition_f1,
        "gt_bcubed_precision": float(gt_bc["precision"]),
        "gt_bcubed_recall": float(gt_bc["recall"]),
        "gt_bcubed_f1": float(gt_bc["f1"]),
        "gt_pairwise_precision": float(gt_pairwise["precision"]),
        "gt_pairwise_recall": float(gt_pairwise["recall"]),
        "gt_pairwise_f1": float(gt_pairwise["f1"]),
        "geometry_mean_purity": mean_purity,
        "geometry_pred_score": geometry_pred_score,
        "geometry_gt_score": geometry_gt_score,
        "geometry_balanced_score": geometry_balanced_score,
        "mean_purity_legacy": mean_purity_legacy,
        "mean_forward_cover": mean_forward_cover,
        "mean_backward_cover": mean_backward_cover,
        "mean_gt_cover": mean_gt_cover,
        "mean_matched_component_purity": mean_matched_component_purity,
        "purity_tau": float(tau),
        "semantic_acc": sem_acc,
        "segment_semantic_acc": segment_semantic_acc,
        "num_support_edges": int(sum(1 for e in structure.get("assembly_edges", []) if e.get("relation") == "support")),
        "num_layers": int(len(structure.get("levels", []))),
    }
    row.update(
        task_eval.compute_task_aware_case_metrics(
            case_row=case_row,
            comp_map=comp_map,
            gt_parts=gt_parts,
            comp_sem=comp_sem,
            descriptors=descriptors,
            pair_relations=pair_relations,
            tau=tau,
            comp_points=comp_points,
        )
    )
    if case_row.get("gold_groups"):
        gold_map = {}
        group_to_idx = {str(name): idx for idx, name in enumerate(sorted(case_row["gold_groups"].keys(), key=str))}
        for group_name, seg_ids in case_row["gold_groups"].items():
            gid = int(group_to_idx[str(group_name)])
            for seg_id in seg_ids:
                gold_map[int(seg_id)] = gid
        bc = base.bcubed_from_maps(comp_map, gold_map, seg_weights)
        pw = base.pairwise_prf_from_maps(comp_map, gold_map)
        row["manual_pairwise_precision"] = float(pw["precision"])
        row["manual_pairwise_recall"] = float(pw["recall"])
        row["manual_pairwise_f1"] = float(pw["f1"])
        row["manual_bcubed_precision"] = float(bc["precision"])
        row["manual_bcubed_recall"] = float(bc["recall"])
        row["manual_bcubed_f1"] = float(bc["f1"])
        row["manual_segment_mean_purity"] = base.weighted_cluster_purity_from_seg_labels(comp_map, gold_map, seg_weights)
        row["manual_segment_mean_completeness"] = base.weighted_cluster_completeness_from_seg_labels(comp_map, gold_map, seg_weights)
        row["manual_segment_partition_f1"] = base.harmonic_mean_score(
            row["manual_segment_mean_purity"], row["manual_segment_mean_completeness"]
        )
    return row


def refine_one(args):
    stage2_model, semantic_model = load_runtime_models(args)
    case_row, refined_map = refine_case(args.uid, args, stage2_model, semantic_model)
    save_refined_outputs(
        uid=args.uid,
        case_row=case_row,
        comp_map=refined_map,
        semantic_model=semantic_model,
        out_dir=args.out_dir,
    )
    print(f"refined {args.uid} -> components={len(set(refined_map.values()))}")


def evaluate_all(args):
    stage2_model, semantic_model = load_runtime_models(args)
    ids = base.collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")

    os.makedirs(args.out_dir, exist_ok=True)
    results = []
    for uid in ids:
        case_row, refined_map = refine_case(uid, args, stage2_model, semantic_model)
        save_refined_outputs(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=semantic_model,
            out_dir=args.out_dir,
        )
        row = evaluate_case(
            uid=uid,
            case_row=case_row,
            comp_map=refined_map,
            semantic_model=semantic_model,
            gt_dir=args.gt_dir,
            gt_samples=args.gt_samples,
        )
        if row is not None:
            results.append(row)
            manual_msg = ""
            if "manual_pairwise_f1" in row:
                manual_msg = (
                    f", manual_pairwise_f1={row['manual_pairwise_f1']:.4f}, "
                    f"manual_bcubed_f1={row.get('manual_bcubed_f1', 0.0):.4f}"
                )
            print(
                f"evaluated {uid}: components={row['num_components']}, "
                f"cluster_f1={row['segment_partition_f1']:.4f}, "
                f"gt_bcubed_f1={row['gt_bcubed_f1']:.4f}, "
                f"geometry_balanced={row['geometry_balanced_score']:.4f}, "
                f"segment_semantic_acc={row['segment_semantic_acc']:.4f}{manual_msg}"
            )

    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    summary = {
        "num_models": len(results),
        "mean_purity_definition": "harmonic_mean(segment_mean_purity, segment_mean_completeness)",
        "mean_num_components": float(np.mean([r["num_components"] for r in results])) if results else 0.0,
        "mean_component_count_diff": float(np.mean([r["component_count_diff"] for r in results])) if results else 0.0,
        "mean_purity": float(np.mean([r["mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_purity": float(np.mean([r["segment_mean_purity"] for r in results])) if results else 0.0,
        "mean_segment_completeness": float(np.mean([r["segment_mean_completeness"] for r in results])) if results else 0.0,
        "mean_segment_partition_f1": float(np.mean([r["segment_partition_f1"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_precision": float(np.mean([r["gt_bcubed_precision"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_recall": float(np.mean([r["gt_bcubed_recall"] for r in results])) if results else 0.0,
        "mean_gt_bcubed_f1": float(np.mean([r["gt_bcubed_f1"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_precision": float(np.mean([r["gt_pairwise_precision"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_recall": float(np.mean([r["gt_pairwise_recall"] for r in results])) if results else 0.0,
        "mean_gt_pairwise_f1": float(np.mean([r["gt_pairwise_f1"] for r in results])) if results else 0.0,
        "mean_geometry_purity": float(np.mean([r["geometry_mean_purity"] for r in results])) if results else 0.0,
        "mean_geometry_pred_score": float(np.mean([r["geometry_pred_score"] for r in results])) if results else 0.0,
        "mean_geometry_gt_score": float(np.mean([r["geometry_gt_score"] for r in results])) if results else 0.0,
        "mean_geometry_balanced_score": float(np.mean([r["geometry_balanced_score"] for r in results])) if results else 0.0,
        "mean_purity_legacy": float(np.mean([r["mean_purity_legacy"] for r in results])) if results else 0.0,
        "mean_forward_cover": float(np.mean([r["mean_forward_cover"] for r in results])) if results else 0.0,
        "mean_backward_cover": float(np.mean([r["mean_backward_cover"] for r in results])) if results else 0.0,
        "mean_gt_cover": float(np.mean([r["mean_gt_cover"] for r in results])) if results else 0.0,
        "mean_matched_component_purity": float(np.mean([r["mean_matched_component_purity"] for r in results])) if results else 0.0,
        "mean_semantic_acc": float(np.mean([r["semantic_acc"] for r in results])) if results else 0.0,
        "mean_segment_semantic_acc": float(np.mean([r["segment_semantic_acc"] for r in results])) if results else 0.0,
        "mean_num_support_edges": float(np.mean([r["num_support_edges"] for r in results])) if results else 0.0,
        "mean_num_layers": float(np.mean([r["num_layers"] for r in results])) if results else 0.0,
    }
    summary.update(task_eval.summarize_task_aware_rows(results))
    manual_rows = [r for r in results if "manual_pairwise_f1" in r]
    if manual_rows:
        summary["manual_case_count"] = len(manual_rows)
        summary["mean_manual_pairwise_precision"] = float(np.mean([r["manual_pairwise_precision"] for r in manual_rows]))
        summary["mean_manual_pairwise_recall"] = float(np.mean([r["manual_pairwise_recall"] for r in manual_rows]))
        summary["mean_manual_pairwise_f1"] = float(np.mean([r["manual_pairwise_f1"] for r in manual_rows]))
        summary["mean_manual_bcubed_f1"] = float(np.mean([r["manual_bcubed_f1"] for r in manual_rows]))
        summary["mean_manual_segment_purity"] = float(np.mean([r["manual_segment_mean_purity"] for r in manual_rows]))
        summary["mean_manual_segment_completeness"] = float(np.mean([r["manual_segment_mean_completeness"] for r in manual_rows]))
        summary["mean_manual_segment_partition_f1"] = float(np.mean([r["manual_segment_partition_f1"] for r in manual_rows]))
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Standalone stage1+stage2 fragment refresh refine.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_ref = sub.add_parser("refine")
    p_ref.add_argument("--uid", required=True)
    p_ref.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_ref.add_argument("--model_dir", default=r"02_models")
    p_ref.add_argument("--merge_semantic_model_dir", default=r"02_models")
    p_ref.add_argument("--gong_prior_model_json", default=DEFAULT_STAGE1_GONG_PRIOR)
    p_ref.add_argument("--manual_edge_calibrator_json", default=DEFAULT_STAGE1_MANUAL_CALIBRATOR)
    p_ref.add_argument("--stage2_model_json", default=DEFAULT_STAGE2_MODEL)
    p_ref.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "outputs"))
    p_ref.add_argument("--max_points", type=int, default=512)
    p_ref.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_ref.add_argument("--contact_eps", type=float, default=0.01)

    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_eval.add_argument("--gt_dir", default=r"data")
    p_eval.add_argument("--model_dir", default=r"02_models")
    p_eval.add_argument("--merge_semantic_model_dir", default=r"02_models")
    p_eval.add_argument("--gong_prior_model_json", default=DEFAULT_STAGE1_GONG_PRIOR)
    p_eval.add_argument("--manual_edge_calibrator_json", default=DEFAULT_STAGE1_MANUAL_CALIBRATOR)
    p_eval.add_argument("--stage2_model_json", default=DEFAULT_STAGE2_MODEL)
    p_eval.add_argument("--out_dir", default=os.path.join(ROOT_DIR, "outputs"))
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_eval.add_argument("--contact_eps", type=float, default=0.01)

    args = parser.parse_args()
    if args.cmd == "refine":
        refine_one(args)
    elif args.cmd == "evaluate":
        evaluate_all(args)


if __name__ == "__main__":
    main()
