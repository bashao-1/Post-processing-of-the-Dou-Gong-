import argparse
import json
import math
import os
import sys
from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Tuple

import numpy as np
import trimesh

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(THIS_DIR)
PROJECT_ROOT = os.path.dirname(os.path.dirname(ROOT_DIR))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

import dougong_refine_v4 as base
import task_aware_eval_metrics_20260427 as task_eval


DEFAULT_FRAGMENT_DIR = os.path.join(PROJECT_ROOT, "data", "fragments", "glb")
DEFAULT_GT_DIR = os.path.join(PROJECT_ROOT, "meshes")
DEFAULT_FULL_DIR = os.path.join(ROOT_DIR, "03_outputs", "outputs_bodyfirst_semanticopt_final_full_eval_20260502_seed0")
DEFAULT_GENERIC_DIR = os.path.join(ROOT_DIR, "03_outputs", "outputs_generic_graph_baseline_eval_20260502_seed0")
DEFAULT_RAW_DIR = os.path.join(ROOT_DIR, "03_outputs", "outputs_raw_partgen_1_5_eval_20260502_seed0")
DEFAULT_ABLATION_ROOT = os.path.join(ROOT_DIR, "03_outputs", "ablation_study_20260502_seed0")
DEFAULT_SOFT_EVAL_OUT = os.path.join(ROOT_DIR, "05_reports", "soft_eval_20260519")
DEFAULT_SOFT_ABLATION_OUT = os.path.join(ROOT_DIR, "05_reports", "soft_ablation_20260519")
EPS = 1e-8
MATCH_THRESHOLDS = (0.50, 0.75)


def safe_mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return float(np.mean(vals)) if vals else 0.0


def harmonic_mean(a: float, b: float) -> float:
    a = float(a)
    b = float(b)
    if a <= 0.0 or b <= 0.0:
        return 0.0
    return float(2.0 * a * b / max(a + b, EPS))


def parse_target_spec(text: str) -> Tuple[str, str]:
    if "=" not in text:
        raise ValueError(f"invalid target spec: {text}")
    name, path_text = text.split("=", 1)
    return name.strip(), path_text.strip()


def parse_variant_spec(text: str) -> Tuple[str, str]:
    if "=" in text:
        name, label = text.split("=", 1)
        return name.strip(), label.strip()
    return text.strip(), text.strip()


def load_summary_semantics(summary_path: str) -> Dict[int, str]:
    with open(summary_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    out: Dict[int, str] = {}
    for item in data.get("components", []):
        cid = int(item.get("component_id", -1))
        if cid < 0:
            continue
        out[cid] = str(item.get("semantic", "unknown"))
    return out


def load_structure(summary_path: str) -> Dict[str, object]:
    with open(summary_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return dict(data.get("structure", {}))


def load_saved_case(output_dir: str, uid: str) -> Dict[str, object]:
    npz_path = os.path.join(output_dir, f"{uid}_refined.npz")
    summary_path = os.path.join(output_dir, f"{uid}_summary.json")
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"missing refined output: {npz_path}")
    if not os.path.exists(summary_path):
        raise FileNotFoundError(f"missing summary output: {summary_path}")
    data = np.load(npz_path, allow_pickle=True)
    fragment_labels = np.asarray(data["fragment_labels"]).astype(np.int32)
    comp_labels = np.asarray(data["comp_labels"]).astype(np.int32)
    segment_names = [str(x) for x in data["segment_names"].tolist()]
    comp_map: Dict[int, int] = {}
    for seg_id in np.unique(fragment_labels):
        seg_mask = fragment_labels == int(seg_id)
        comp_ids = np.unique(comp_labels[seg_mask])
        if len(comp_ids) != 1:
            raise ValueError(f"{uid}: segment {seg_id} maps to multiple components in saved output")
        comp_map[int(seg_id)] = int(comp_ids[0])
    return {
        "fragment_labels": fragment_labels,
        "comp_labels": comp_labels,
        "segment_names": segment_names,
        "comp_map": comp_map,
        "comp_sem": load_summary_semantics(summary_path),
        "structure": load_structure(summary_path),
    }


def load_fragment_segments_with_areas(fragment_file: str, samples_per_part: int) -> Tuple[List[base.Segment], np.ndarray, np.ndarray, float, float, Dict[int, float], List[str]]:
    if fragment_file.lower().endswith(".fbx"):
        raise RuntimeError("FBX is not supported by trimesh in this environment.")
    scene = trimesh.load(fragment_file, force=None)
    if not isinstance(scene, trimesh.Scene):
        raise ValueError(f"fragment file is not a scene: {fragment_file}")

    seg_items = []
    for node_name in scene.graph.nodes:
        data = scene.graph[node_name]
        try:
            transform, geom_name = data
        except Exception:
            continue
        if geom_name is None:
            continue
        mesh = scene.geometry[geom_name].copy()
        try:
            mesh.apply_transform(transform)
        except Exception:
            pass
        rng_state = np.random.get_state()
        seed_match = base.re.search(r"part_(\d+)", str(node_name))
        seed_value = int(seed_match.group(1)) if seed_match else abs(hash(str(node_name))) % (2 ** 31)
        np.random.seed(seed_value + 12345)
        pts, _ = trimesh.sample.sample_surface(mesh, samples_per_part)
        np.random.set_state(rng_state)
        match = base.re.search(r"part_(\d+)", str(node_name))
        parsed_seg_id = int(match.group(1)) if match else None
        seg_items.append(
            {
                "node_name": str(node_name),
                "points": pts.astype(np.float32),
                "parsed_seg_id": parsed_seg_id,
                "area": float(getattr(mesh, "area", 0.0)),
            }
        )

    if not seg_items:
        raise RuntimeError(f"No parts found in fragment file: {fragment_file}")

    seen_ids = set()
    fallback_id = 0
    for item in seg_items:
        seg_id = item["parsed_seg_id"]
        if seg_id is None or seg_id in seen_ids:
            while fallback_id in seen_ids:
                fallback_id += 1
            seg_id = fallback_id
        item["seg_id"] = int(seg_id)
        seen_ids.add(int(seg_id))

    seg_items.sort(key=lambda item: (int(item["seg_id"]), str(item["node_name"])))
    all_points = np.vstack([item["points"] for item in seg_items])
    center, scale = base.compute_center_scale(all_points)
    normalized_all = base.normalize_points(all_points.astype(np.float32), center, scale)
    global_diag = float(np.linalg.norm(normalized_all.max(axis=0) - normalized_all.min(axis=0)))
    segments: List[base.Segment] = []
    seg_names: List[str] = []
    seg_area_map: Dict[int, float] = {}
    for item in seg_items:
        pts = base.normalize_points(item["points"], center, scale)
        centroid = pts.mean(axis=0)
        bmin, bmax, diag = base.bbox_stats(pts)
        axis = base.pca_axis(pts)
        seg_id = int(item["seg_id"])
        segments.append(
            base.Segment(
                seg_id=seg_id,
                points=pts,
                centroid=centroid,
                bbox_min=bmin,
                bbox_max=bmax,
                axis=axis,
                bbox_diag=diag,
            )
        )
        seg_names.append(str(item["node_name"]))
        seg_area_map[seg_id] = max(float(item["area"]), EPS)
    return segments, np.asarray(seg_names, dtype=object), np.asarray(center, dtype=np.float32), float(scale), global_diag, seg_area_map, seg_names


def build_case_row(uid: str, fragment_dir: str, max_points: int) -> Dict[str, object]:
    fragment_file = base.find_fragment_file(fragment_dir, uid)
    if not fragment_file:
        raise FileNotFoundError(f"fragment file not found for {uid}")
    segments, segment_names, center, scale, global_diag, seg_area_map, seg_name_list = load_fragment_segments_with_areas(fragment_file, max_points)
    return {
        "uid": str(uid),
        "segments": segments,
        "segment_names": [str(x) for x in segment_names.tolist()],
        "center": np.asarray(center, dtype=np.float32),
        "scale": float(scale),
        "global_diag": float(global_diag),
        "seg_area_map": seg_area_map,
        "seg_name_list": seg_name_list,
    }


def build_component_points(case_row: Dict[str, object], comp_map: Dict[int, int]) -> Dict[int, np.ndarray]:
    comp_points = defaultdict(list)
    for seg in case_row["segments"]:
        seg_id = int(seg.seg_id)
        if seg_id not in comp_map:
            continue
        comp_points[int(comp_map[seg_id])].append(np.asarray(seg.points, dtype=np.float32))
    return {cid: np.vstack(v).astype(np.float32) for cid, v in comp_points.items()}


def compute_overlap_weight_matrix(segments: List[base.Segment], gt_parts: List[base.Part]) -> Dict[int, Dict[int, float]]:
    if not gt_parts:
        return {}
    gt_points = [np.asarray(p.points, dtype=np.float32) for p in gt_parts]
    weight_map: Dict[int, Dict[int, float]] = {}
    for seg in segments:
        seg_pts = np.asarray(seg.points, dtype=np.float32)
        if seg_pts.shape[0] == 0:
            continue
        dists = []
        for gp in gt_points:
            diff = seg_pts[:, None, :] - gp[None, :, :]
            d2 = np.sum(diff * diff, axis=-1)
            min_d = np.sqrt(np.min(d2, axis=1))
            dists.append(min_d)
        dist_mat = np.stack(dists, axis=1)
        assign = np.argmin(dist_mat, axis=1)
        counts = np.bincount(assign, minlength=len(gt_parts)).astype(np.float64)
        probs = counts / max(float(seg_pts.shape[0]), 1.0)
        weight_map[int(seg.seg_id)] = {int(gid): float(probs[gid]) for gid in range(len(gt_parts)) if probs[gid] > 0.0}
    return weight_map


def area_weight_map(case_row: Dict[str, object]) -> Dict[int, float]:
    area_map = {int(k): float(v) for k, v in case_row.get("seg_area_map", {}).items()}
    if area_map:
        return area_map
    return {int(seg.seg_id): float(len(seg.points)) for seg in case_row["segments"]}


def soft_partition_metrics(
    soft_tables: Dict[str, object],
) -> Dict[str, float]:
    pred_total = np.asarray(soft_tables["pred_total"], dtype=np.float64)
    gt_total = np.asarray(soft_tables["gt_total"], dtype=np.float64)
    pred_to_gt = np.asarray(soft_tables["pred_to_gt"], dtype=np.float64)
    gt_to_pred = np.asarray(soft_tables["gt_to_pred"], dtype=np.float64)

    if pred_total.size == 0 or gt_total.size == 0:
        return {
            "segment_mean_purity": 0.0,
            "segment_mean_completeness": 0.0,
            "segment_partition_f1": 0.0,
        }

    pred_weights = pred_total / max(pred_total.sum(), EPS)
    gt_weights = gt_total / max(gt_total.sum(), EPS)
    pred_concentration = np.sum(pred_to_gt * pred_to_gt, axis=1)
    gt_concentration = np.sum(gt_to_pred * gt_to_pred, axis=0)
    segment_mean_purity = float(np.sum(pred_weights * pred_concentration))
    segment_mean_completeness = float(np.sum(gt_weights * gt_concentration))

    return {
        "segment_mean_purity": segment_mean_purity,
        "segment_mean_completeness": segment_mean_completeness,
        "segment_partition_f1": harmonic_mean(segment_mean_purity, segment_mean_completeness),
    }


def soft_bcubed_from_maps(
    pred_map: Dict[int, int],
    gold_soft_map: Dict[int, Dict[int, float]],
    weights: Dict[int, float],
) -> Dict[str, float]:
    common_ids = sorted(set(int(k) for k in pred_map.keys()) & set(int(k) for k in gold_soft_map.keys()))
    if not common_ids:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}

    pred_groups: Dict[int, List[int]] = defaultdict(list)
    gold_group_totals: Dict[int, float] = defaultdict(float)
    for seg_id in common_ids:
        pred_groups[int(pred_map[seg_id])].append(seg_id)
        w_i = float(weights.get(seg_id, 1.0))
        for gid, prob in gold_soft_map[seg_id].items():
            gold_group_totals[int(gid)] += w_i * float(prob)

    total_w = 0.0
    precision_sum = 0.0
    recall_sum = 0.0
    for seg_id in common_ids:
        w_i = float(weights.get(seg_id, 1.0))
        pred_cluster = pred_groups[int(pred_map[seg_id])]
        pred_cluster_mass = sum(float(weights.get(other, 1.0)) for other in pred_cluster)

        inter_mass = 0.0
        for other in pred_cluster:
            w_j = float(weights.get(other, 1.0))
            same_soft = 0.0
            for gid, p_i in gold_soft_map[seg_id].items():
                same_soft += float(p_i) * float(gold_soft_map[other].get(int(gid), 0.0))
            inter_mass += w_j * same_soft

        recall_denom = 0.0
        for gid, p_i in gold_soft_map[seg_id].items():
            recall_denom += float(p_i) * float(gold_group_totals.get(int(gid), 0.0))

        precision_i = inter_mass / max(pred_cluster_mass, EPS)
        recall_i = inter_mass / max(recall_denom, EPS)
        total_w += w_i
        precision_sum += w_i * precision_i
        recall_sum += w_i * recall_i

    precision = float(precision_sum / max(total_w, EPS))
    recall = float(recall_sum / max(total_w, EPS))
    return {"precision": precision, "recall": recall, "f1": harmonic_mean(precision, recall)}


def soft_pairwise_prf_from_maps(
    pred_map: Dict[int, int],
    gold_soft_map: Dict[int, Dict[int, float]],
    weights: Dict[int, float],
) -> Dict[str, float]:
    common_ids = sorted(set(int(k) for k in pred_map.keys()) & set(int(k) for k in gold_soft_map.keys()))
    if not common_ids:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}
    if len(common_ids) < 2:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0}

    tp = 0.0
    fp = 0.0
    fn = 0.0
    for idx, a in enumerate(common_ids):
        for b in common_ids[idx + 1:]:
            pair_weight = math.sqrt(max(float(weights.get(a, 1.0)), EPS) * max(float(weights.get(b, 1.0)), EPS))
            gold_same = 0.0
            for gid, p_a in gold_soft_map[a].items():
                gold_same += float(p_a) * float(gold_soft_map[b].get(int(gid), 0.0))
            pred_same = 1.0 if int(pred_map[a]) == int(pred_map[b]) else 0.0
            tp += pair_weight * pred_same * gold_same
            fp += pair_weight * pred_same * (1.0 - gold_same)
            fn += pair_weight * (1.0 - pred_same) * gold_same

    precision = float(tp / max(tp + fp, EPS))
    recall = float(tp / max(tp + fn, EPS))
    return {"precision": precision, "recall": recall, "f1": harmonic_mean(precision, recall)}


def soft_weighted_semantic_accuracy(
    comp_map: Dict[int, int],
    soft_gt: Dict[int, Dict[int, float]],
    comp_sem: Dict[int, str],
    gt_parts: List[base.Part],
    seg_weights: Dict[int, float],
) -> float:
    common_ids = sorted(set(int(k) for k in comp_map.keys()) & set(int(k) for k in soft_gt.keys()))
    if not common_ids:
        return 0.0
    total_weight = 0.0
    total_correct = 0.0
    for seg_id in common_ids:
        w_i = float(seg_weights.get(seg_id, 1.0))
        pred_sem = str(comp_sem.get(int(comp_map[seg_id]), "unknown"))
        correct_prob = 0.0
        for gid, prob in soft_gt[seg_id].items():
            gt_sem = str(gt_parts[int(gid)].semantic)
            if pred_sem == gt_sem:
                correct_prob += float(prob)
        total_weight += w_i
        total_correct += w_i * correct_prob
    return float(total_correct / max(total_weight, EPS))


def build_soft_mass_tables(
    comp_map: Dict[int, int],
    soft_gt: Dict[int, Dict[int, float]],
    seg_weights: Dict[int, float],
) -> Dict[str, object]:
    common_ids = sorted(set(int(k) for k in comp_map.keys()) & set(int(k) for k in soft_gt.keys()))
    pred_ids = sorted(set(int(comp_map[seg_id]) for seg_id in common_ids))
    gt_ids = sorted(set(int(gid) for seg_id in common_ids for gid in soft_gt[seg_id].keys()))
    pred_index = {cid: idx for idx, cid in enumerate(pred_ids)}
    gt_index = {gid: idx for idx, gid in enumerate(gt_ids)}
    mass = np.zeros((len(pred_ids), len(gt_ids)), dtype=np.float64)
    pred_total = np.zeros((len(pred_ids),), dtype=np.float64)
    gt_total = np.zeros((len(gt_ids),), dtype=np.float64)

    for seg_id in common_ids:
        cid = int(comp_map[seg_id])
        i = pred_index[cid]
        seg_mass = float(seg_weights.get(seg_id, 1.0))
        pred_total[i] += seg_mass
        for gid, prob in soft_gt[seg_id].items():
            j = gt_index[int(gid)]
            contrib = seg_mass * float(prob)
            mass[i, j] += contrib
            gt_total[j] += contrib

    pred_to_gt = np.divide(mass, np.maximum(pred_total[:, None], EPS))
    gt_to_pred = np.divide(mass, np.maximum(gt_total[None, :], EPS))
    sym = np.divide(2.0 * pred_to_gt * gt_to_pred, np.maximum(pred_to_gt + gt_to_pred, EPS))
    return {
        "pred_ids": pred_ids,
        "gt_ids": gt_ids,
        "mass": mass,
        "pred_total": pred_total,
        "gt_total": gt_total,
        "pred_to_gt": pred_to_gt,
        "gt_to_pred": gt_to_pred,
        "sym_score": sym,
    }


def build_surface_overlap_tables(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[base.Part],
    tau: float,
    max_points: int = 768,
) -> Dict[str, object]:
    return task_eval.build_surface_overlap_tables(comp_points, gt_parts, tau=tau, max_points=max_points)


def fragmentation_aware_recovery_metrics(
    soft_tables: Dict[str, object],
) -> Dict[str, float]:
    pred_ids = [int(x) for x in soft_tables["pred_ids"]]
    gt_ids = [int(x) for x in soft_tables["gt_ids"]]
    mass = np.asarray(soft_tables["mass"], dtype=np.float64)
    pred_to_gt = np.asarray(soft_tables["pred_to_gt"], dtype=np.float64)
    gt_to_pred = np.asarray(soft_tables["gt_to_pred"], dtype=np.float64)
    sym = np.asarray(soft_tables["sym_score"], dtype=np.float64)
    pred_total = np.asarray(soft_tables["pred_total"], dtype=np.float64)
    gt_total = np.asarray(soft_tables["gt_total"], dtype=np.float64)
    num_pred = len(pred_ids)
    num_gt = len(gt_ids)

    if num_pred == 0 or num_gt == 0:
        return {
            "num_pred_components_eval": float(num_pred),
            "num_gt_components_eval": float(num_gt),
            "count_error_ratio": float(abs(num_pred - num_gt) / max(num_gt, 1)),
            "component_recovery_score": 0.0,
            "matched_geometry_mean": 0.0,
            "matched_forward_mean": 0.0,
            "matched_backward_mean": 0.0,
            "matched_pair_fraction": 0.0,
            "pred_validity_rate_50": 0.0,
            "gt_recovery_rate_50": 0.0,
            "instance_f1_50": 0.0,
            "pred_validity_rate_75": 0.0,
            "gt_recovery_rate_75": 0.0,
            "instance_f1_75": 0.0,
        }

    pred_weights = pred_total / max(pred_total.sum(), EPS)
    gt_weights = gt_total / max(gt_total.sum(), EPS)

    gt_recoveries = []
    gt_best_scores = []
    gt_best_backward = []
    gt_best_forward = []
    for j, _gid in enumerate(gt_ids):
        col = np.asarray(sym[:, j], dtype=np.float64)
        best_idx = int(np.argmax(col))
        best = float(col[best_idx])
        support = float(np.sum(gt_to_pred[:, j]))
        uniqueness = float(best / max(support, EPS))
        gt_recoveries.append(best * uniqueness)
        gt_best_scores.append(best)
        gt_best_backward.append(float(gt_to_pred[best_idx, j]))
        gt_best_forward.append(float(pred_to_gt[best_idx, j]))
    gt_recovery_score = float(np.sum(gt_weights * np.asarray(gt_recoveries, dtype=np.float64)))

    pred_validities = []
    for i, _cid in enumerate(pred_ids):
        row = np.asarray(sym[i, :], dtype=np.float64)
        best_idx = int(np.argmax(row))
        best = float(row[best_idx])
        support = float(np.sum(pred_to_gt[i, :]))
        uniqueness = float(best / max(support, EPS))
        pred_validities.append(best * uniqueness)
    pred_validity_score = float(np.sum(pred_weights * np.asarray(pred_validities, dtype=np.float64)))

    component_recovery_score = harmonic_mean(pred_validity_score, gt_recovery_score)
    matched_geometry_mean = float(np.sum(gt_weights * np.asarray(gt_best_scores, dtype=np.float64)))
    matched_forward_mean = float(np.sum(gt_weights * np.asarray(gt_best_forward, dtype=np.float64)))
    matched_backward_mean = float(np.sum(gt_weights * np.asarray(gt_best_backward, dtype=np.float64)))

    out = {
        "num_pred_components_eval": float(num_pred),
        "num_gt_components_eval": float(num_gt),
        "count_error_ratio": float(abs(num_pred - num_gt) / max(num_gt, 1)),
        "component_recovery_score": component_recovery_score,
        "matched_geometry_mean": matched_geometry_mean,
        "matched_forward_mean": matched_forward_mean,
        "matched_backward_mean": matched_backward_mean,
        "matched_pair_fraction": float(min(num_pred, num_gt) / max(num_pred, num_gt, 1)),
    }

    for thr in MATCH_THRESHOLDS:
        gt_hits = []
        for j in range(num_gt):
            col = np.asarray(sym[:, j], dtype=np.float64)
            best = float(np.max(col))
            support = float(np.sum(gt_to_pred[:, j]))
            uniqueness = float(best / max(support, EPS))
            gt_hits.append(1.0 if best * uniqueness >= thr else 0.0)
        gt_recall = float(np.sum(gt_weights * np.asarray(gt_hits, dtype=np.float64)))

        pred_hits = []
        for i in range(num_pred):
            row = np.asarray(sym[i, :], dtype=np.float64)
            best = float(np.max(row))
            support = float(np.sum(pred_to_gt[i, :]))
            uniqueness = float(best / max(support, EPS))
            pred_hits.append(1.0 if best * uniqueness >= thr else 0.0)
        pred_precision = float(np.sum(pred_weights * np.asarray(pred_hits, dtype=np.float64)))

        suffix = int(thr * 100)
        out[f"pred_validity_rate_{suffix:02d}"] = pred_precision
        out[f"gt_recovery_rate_{suffix:02d}"] = gt_recall
        out[f"instance_f1_{suffix:02d}"] = harmonic_mean(pred_precision, gt_recall)
    return out


def fragmentation_aware_semantic_recovery_metrics(
    soft_tables: Dict[str, object],
    gt_parts: List[base.Part],
    comp_sem: Dict[int, str],
) -> Dict[str, float]:
    pred_ids = [int(x) for x in soft_tables["pred_ids"]]
    gt_ids = [int(x) for x in soft_tables["gt_ids"]]
    sym = np.asarray(soft_tables["sym_score"], dtype=np.float64)
    pred_to_gt = np.asarray(soft_tables["pred_to_gt"], dtype=np.float64)
    gt_to_pred = np.asarray(soft_tables["gt_to_pred"], dtype=np.float64)
    num_pred = len(pred_ids)
    num_gt = len(gt_ids)
    gt_total = np.asarray(soft_tables["gt_total"], dtype=np.float64)
    gt_weights = gt_total / max(gt_total.sum(), EPS) if gt_total.size else np.zeros((0,), dtype=np.float64)
    pred_class_counts = Counter(str(comp_sem.get(cid, "unknown")) for cid in pred_ids)
    gt_class_counts = Counter(str(gt_parts[gid].semantic) for gid in gt_ids)
    classes = sorted(set(pred_class_counts.keys()) | set(gt_class_counts.keys()))

    if num_pred == 0 or num_gt == 0:
        out = {
            "semantic_recovery_score": 0.0,
            "semantic_instance_f1_50": 0.0,
            "semantic_gt_recall_50": 0.0,
            "semantic_macro_f1_50": 0.0,
            "semantic_instance_f1_75": 0.0,
            "semantic_gt_recall_75": 0.0,
            "semantic_macro_f1_75": 0.0,
        }
        return out

    gt_sem_recoveries = []
    for j, gid in enumerate(gt_ids):
        col = np.asarray(sym[:, j], dtype=np.float64)
        best_idx = int(np.argmax(col))
        best = float(col[best_idx])
        support = float(np.sum(gt_to_pred[:, j]))
        uniqueness = float(best / max(support, EPS))
        pred_sem = str(comp_sem.get(pred_ids[best_idx], "unknown"))
        gt_sem = str(gt_parts[gid].semantic)
        correct = 1.0 if pred_sem == gt_sem else 0.0
        gt_sem_recoveries.append(best * uniqueness * correct)
    semantic_recovery_score = float(np.sum(gt_weights * np.asarray(gt_sem_recoveries, dtype=np.float64)))

    out = {"semantic_recovery_score": semantic_recovery_score}
    for thr in MATCH_THRESHOLDS:
        gt_hits = []
        tp_class = Counter()
        correct_pred_ids = set()
        for j, gid in enumerate(gt_ids):
            col = np.asarray(sym[:, j], dtype=np.float64)
            best_idx = int(np.argmax(col))
            best = float(col[best_idx])
            support = float(np.sum(gt_to_pred[:, j]))
            uniqueness = float(best / max(support, EPS))
            pred_sem = str(comp_sem.get(pred_ids[best_idx], "unknown"))
            gt_sem = str(gt_parts[gid].semantic)
            ok = best * uniqueness >= thr and pred_sem == gt_sem
            gt_hits.append(1.0 if ok else 0.0)
            if ok:
                tp_class[gt_sem] += 1
                correct_pred_ids.add(int(pred_ids[best_idx]))
        gt_recall = float(np.sum(gt_weights * np.asarray(gt_hits, dtype=np.float64)))

        pred_precision = float(len(correct_pred_ids) / max(num_pred, 1))
        suffix = int(thr * 100)
        out[f"semantic_instance_f1_{suffix:02d}"] = harmonic_mean(pred_precision, gt_recall)
        out[f"semantic_gt_recall_{suffix:02d}"] = gt_recall

        macro_f1s = []
        for cls in classes:
            tp = float(tp_class.get(cls, 0))
            fp = float(pred_class_counts.get(cls, 0) - tp)
            fn = float(gt_class_counts.get(cls, 0) - tp)
            prec = tp / max(tp + fp, EPS)
            rec = tp / max(tp + fn, EPS)
            macro_f1s.append(harmonic_mean(prec, rec))
        out[f"semantic_macro_f1_{suffix:02d}"] = float(np.mean(macro_f1s)) if macro_f1s else 0.0
    return out


def summarize_task_aware_rows_soft(rows: List[Dict[str, float]]) -> Dict[str, float]:
    if not rows:
        return {}
    keys = [
        "num_pred_components_eval",
        "num_gt_components_eval",
        "count_error_ratio",
        "component_recovery_score",
        "matched_geometry_mean",
        "matched_forward_mean",
        "matched_backward_mean",
        "matched_pair_fraction",
        "pred_validity_rate_50",
        "gt_recovery_rate_50",
        "instance_f1_50",
        "pred_validity_rate_75",
        "gt_recovery_rate_75",
        "instance_f1_75",
        "semantic_recovery_score",
        "semantic_instance_f1_50",
        "semantic_gt_recall_50",
        "semantic_macro_f1_50",
        "semantic_instance_f1_75",
        "semantic_gt_recall_75",
        "semantic_macro_f1_75",
        "num_pred_support_edges_eval",
        "num_gt_support_edges_eval",
        "support_edge_precision",
        "support_edge_recall",
        "support_edge_f1",
        "support_edge_precision_50",
        "support_edge_recall_50",
        "support_edge_f1_50",
        "support_edge_precision_75",
        "support_edge_recall_75",
        "support_edge_f1_75",
        "structure_plausibility",
        "host_legality",
        "gong_clean_ratio",
        "upper_dou_support_ratio",
        "structure_violation_rate",
    ]
    summary = {
        "metric_family": "soft_overlap_fragmentation_eval_v1",
        "matching_basis": "soft_segment_overlap_plus_fragmentation_penalty",
    }
    for key in keys:
        vals = [float(r[key]) for r in rows if key in r]
        if vals:
            summary[f"mean_{key}"] = float(np.mean(vals))
    return summary


def evaluate_case_from_saved(
    uid: str,
    output_dir: str,
    fragment_dir: str,
    gt_dir: str,
    max_points: int,
    gt_samples: int,
) -> Dict[str, object] | None:
    case_row = build_case_row(uid, fragment_dir, max_points)
    gt_parts = base.load_gt_parts_auto(
        gt_dir,
        uid,
        np.asarray(case_row["center"], dtype=np.float32),
        float(case_row["scale"]),
        gt_samples,
    )
    if not gt_parts:
        return None

    saved = load_saved_case(output_dir, uid)
    comp_map = {int(k): int(v) for k, v in saved["comp_map"].items()}
    comp_sem = {int(k): str(v) for k, v in saved["comp_sem"].items()}
    comp_points = build_component_points(case_row, comp_map)

    seg_weights = area_weight_map(case_row)
    soft_gt = compute_overlap_weight_matrix(case_row["segments"], gt_parts)
    soft_tables = build_soft_mass_tables(comp_map, soft_gt, seg_weights)
    partition = soft_partition_metrics(soft_tables)
    gt_bc = soft_bcubed_from_maps(comp_map, soft_gt, seg_weights)
    gt_pairwise = soft_pairwise_prf_from_maps(comp_map, soft_gt, seg_weights)
    segment_semantic_acc = soft_weighted_semantic_accuracy(comp_map, soft_gt, comp_sem, gt_parts, seg_weights)

    tau = max(0.05, 0.12 * float(case_row.get("global_diag", 1.0)))
    mean_purity, comp_to_gt, _comp_scores, comp_score_details = base.component_mean_purity(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=0.5,
    )
    mean_forward_cover = float(np.mean([v["forward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
    mean_backward_cover = float(np.mean([v["backward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
    geometry_pred_score, _, _, _ = base.component_mean_purity(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=1.0,
    )
    geometry_gt_score, _, _, gt_score_details = base.gt_part_mean_coverage(
        comp_points=comp_points,
        gt_parts=gt_parts,
        tau=tau,
        max_points=768,
        size_weighted=True,
        beta=1.0,
    )
    geometry_balanced_score = harmonic_mean(geometry_pred_score, geometry_gt_score)
    mean_gt_cover = float(np.mean([v["gt_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0
    mean_matched_component_purity = float(np.mean([v["pred_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0

    correct = 0
    total = 0
    for cid, gt_idx in comp_to_gt.items():
        sem_gt = gt_parts[int(gt_idx)].semantic
        sem_pred = comp_sem.get(int(cid), "unknown")
        correct += int(sem_pred == sem_gt)
        total += 1
    sem_acc = float(correct / max(total, 1))

    overlap_tables = build_surface_overlap_tables(comp_points, gt_parts, tau=tau, max_points=768)
    task_row = fragmentation_aware_recovery_metrics(soft_tables)
    task_row.update(fragmentation_aware_semantic_recovery_metrics(soft_tables, gt_parts, comp_sem))

    descriptors, pair_relations, global_meta = base.build_component_descriptors(comp_points)
    task_row.update(
        task_eval.support_edge_recovery_metrics(
            task_eval.solve_optimal_component_matching(overlap_tables),
            comp_points,
            comp_sem,
            descriptors,
            pair_relations,
            gt_parts,
            global_meta=global_meta,
        )
    )
    task_row.update(task_eval.structure_plausibility_metrics(comp_sem, descriptors, pair_relations))

    num_support_edges = 0
    structure = saved.get("structure", {})
    for edge in structure.get("assembly_edges", []):
        if edge.get("relation") == "support":
            num_support_edges += 1

    row: Dict[str, object] = {
        "uid": uid,
        "num_segments": len(case_row["segments"]),
        "num_components": len(comp_points),
        "num_gt_parts": len(gt_parts),
        "recoverable_case": bool(len(case_row["segments"]) >= len(gt_parts)),
        "component_count_diff": abs(len(comp_points) - len(gt_parts)),
        "mean_purity": partition["segment_partition_f1"],
        "segment_mean_purity": partition["segment_mean_purity"],
        "segment_mean_completeness": partition["segment_mean_completeness"],
        "segment_partition_f1": partition["segment_partition_f1"],
        "gt_bcubed_precision": float(gt_bc["precision"]),
        "gt_bcubed_recall": float(gt_bc["recall"]),
        "gt_bcubed_f1": float(gt_bc["f1"]),
        "gt_pairwise_precision": float(gt_pairwise["precision"]),
        "gt_pairwise_recall": float(gt_pairwise["recall"]),
        "gt_pairwise_f1": float(gt_pairwise["f1"]),
        "geometry_mean_purity": mean_purity,
        "geometry_pred_score": geometry_pred_score,
        "geometry_gt_score": geometry_gt_score,
        "geometry_balanced_score": geometry_balanced_score,
        "mean_purity_legacy": 0.0,
        "mean_forward_cover": mean_forward_cover,
        "mean_backward_cover": mean_backward_cover,
        "mean_gt_cover": mean_gt_cover,
        "mean_matched_component_purity": mean_matched_component_purity,
        "purity_tau": float(tau),
        "semantic_acc": sem_acc,
        "segment_semantic_acc": segment_semantic_acc,
        "num_support_edges": int(num_support_edges),
        "num_layers": int(len(structure.get("levels", []))) if isinstance(structure, dict) else 0,
    }
    row.update(task_row)
    return row


def evaluate_saved_dir(
    output_dir: str,
    fragment_dir: str,
    gt_dir: str,
    max_points: int,
    gt_samples: int,
    out_dir: str | None = None,
    uids: List[str] | None = None,
    limit: int = 0,
) -> Tuple[List[Dict[str, object]], Dict[str, object]]:
    refined_files = sorted(f for f in os.listdir(output_dir) if f.endswith("_refined.npz"))
    if uids:
        wanted = {str(uid) for uid in uids}
        refined_files = [f for f in refined_files if f[:-len("_refined.npz")] in wanted]
    if limit > 0:
        refined_files = refined_files[:int(limit)]
    results: List[Dict[str, object]] = []
    for fname in refined_files:
        uid = fname[:-len("_refined.npz")]
        row = evaluate_case_from_saved(uid, output_dir, fragment_dir, gt_dir, max_points, gt_samples)
        if row is not None:
            results.append(row)
            print(
                f"soft-evaluated {uid}: components={row['num_components']}, "
                f"cluster_f1={row['segment_partition_f1']:.4f}, "
                f"gt_bcubed_f1={row['gt_bcubed_f1']:.4f}, "
                f"gt_pairwise_f1={row['gt_pairwise_f1']:.4f}, "
                f"component_recovery={row['component_recovery_score']:.4f}, "
                f"semantic_recovery={row['semantic_recovery_score']:.4f}"
            )

    summary = {
        "num_models": len(results),
        "mean_purity_definition": "harmonic_mean(segment_mean_purity, segment_mean_completeness)",
        "mean_num_components": safe_mean(r["num_components"] for r in results),
        "mean_component_count_diff": safe_mean(r["component_count_diff"] for r in results),
        "mean_purity": safe_mean(r["mean_purity"] for r in results),
        "mean_segment_purity": safe_mean(r["segment_mean_purity"] for r in results),
        "mean_segment_completeness": safe_mean(r["segment_mean_completeness"] for r in results),
        "mean_segment_partition_f1": safe_mean(r["segment_partition_f1"] for r in results),
        "mean_gt_bcubed_precision": safe_mean(r["gt_bcubed_precision"] for r in results),
        "mean_gt_bcubed_recall": safe_mean(r["gt_bcubed_recall"] for r in results),
        "mean_gt_bcubed_f1": safe_mean(r["gt_bcubed_f1"] for r in results),
        "mean_gt_pairwise_precision": safe_mean(r["gt_pairwise_precision"] for r in results),
        "mean_gt_pairwise_recall": safe_mean(r["gt_pairwise_recall"] for r in results),
        "mean_gt_pairwise_f1": safe_mean(r["gt_pairwise_f1"] for r in results),
        "mean_geometry_purity": safe_mean(r["geometry_mean_purity"] for r in results),
        "mean_geometry_pred_score": safe_mean(r["geometry_pred_score"] for r in results),
        "mean_geometry_gt_score": safe_mean(r["geometry_gt_score"] for r in results),
        "mean_geometry_balanced_score": safe_mean(r["geometry_balanced_score"] for r in results),
        "mean_purity_legacy": safe_mean(r["mean_purity_legacy"] for r in results),
        "mean_forward_cover": safe_mean(r["mean_forward_cover"] for r in results),
        "mean_backward_cover": safe_mean(r["mean_backward_cover"] for r in results),
        "mean_gt_cover": safe_mean(r["mean_gt_cover"] for r in results),
        "mean_matched_component_purity": safe_mean(r["mean_matched_component_purity"] for r in results),
        "mean_semantic_acc": safe_mean(r["semantic_acc"] for r in results),
        "mean_segment_semantic_acc": safe_mean(r["segment_semantic_acc"] for r in results),
        "mean_num_support_edges": safe_mean(r["num_support_edges"] for r in results),
        "mean_num_layers": safe_mean(r["num_layers"] for r in results),
    }
    summary.update(summarize_task_aware_rows_soft(results))

    if out_dir is not None:
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, "metrics.json"), "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
    return results, summary


def run_eval_targets(args) -> None:
    target_specs = [parse_target_spec(t) for t in args.target] if args.target else [
        ("raw_partgen_1_5", DEFAULT_RAW_DIR),
        ("generic_graph_baseline", DEFAULT_GENERIC_DIR),
        ("final_system", DEFAULT_FULL_DIR),
    ]
    out_root = args.out_root
    os.makedirs(out_root, exist_ok=True)

    for name, src_dir in target_specs:
        dst_dir = os.path.join(out_root, name)
        print(f"[soft-eval] {name}: {src_dir} -> {dst_dir}")
        _rows, summary = evaluate_saved_dir(
            output_dir=src_dir,
            fragment_dir=args.fragment_dir,
            gt_dir=args.gt_dir,
            max_points=args.max_points,
            gt_samples=args.gt_samples,
            out_dir=dst_dir,
            uids=args.uid,
            limit=args.limit,
        )
        print(json.dumps({"target": name, "summary": summary}, ensure_ascii=False, indent=2))


def run_ablation(args) -> None:
    variant_specs = [parse_variant_spec(v) for v in args.variant] if args.variant else [
        ("full", "Full Model"),
        ("wo_bodyfirst_host_recovery", "w/o Body-First Host Recovery"),
        ("wo_conservative_protection", "w/o Conservative Protection"),
        ("wo_learned_boundary_optimization", "w/o Learned Boundary Optimization"),
        ("wo_semantic_structural_rollback", "w/o Semantic-Structural Rollback"),
    ]
    out_root = args.out_root
    os.makedirs(out_root, exist_ok=True)
    for variant_name, label in variant_specs:
        src_dir = os.path.join(args.ablation_root, variant_name)
        dst_dir = os.path.join(out_root, variant_name)
        print(f"[soft-ablation] {label}: {src_dir} -> {dst_dir}")
        _rows, summary = evaluate_saved_dir(
            output_dir=src_dir,
            fragment_dir=args.fragment_dir,
            gt_dir=args.gt_dir,
            max_points=args.max_points,
            gt_samples=args.gt_samples,
            out_dir=dst_dir,
            uids=args.uid,
            limit=args.limit,
        )
        summary["variant_name"] = variant_name
        summary["variant_label"] = label
        with open(os.path.join(dst_dir, "summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print(json.dumps({"variant": variant_name, "summary": summary}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Re-evaluate saved refined outputs with soft overlap and fragmentation-aware metrics.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_eval = sub.add_parser("eval_targets")
    p_eval.add_argument("--target", action="append", default=[], help="Target spec in the form name=path.")
    p_eval.add_argument("--out_root", default=DEFAULT_SOFT_EVAL_OUT)
    p_eval.add_argument("--fragment_dir", default=DEFAULT_FRAGMENT_DIR)
    p_eval.add_argument("--gt_dir", default=DEFAULT_GT_DIR)
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--uid", action="append", default=[], help="Specific uid(s) to evaluate.")
    p_eval.add_argument("--limit", type=int, default=0, help="Evaluate only the first N cases after filtering.")

    p_abl = sub.add_parser("eval_ablation")
    p_abl.add_argument("--ablation_root", default=DEFAULT_ABLATION_ROOT)
    p_abl.add_argument("--variant", action="append", default=[], help="Variant spec in the form name or name=label.")
    p_abl.add_argument("--out_root", default=DEFAULT_SOFT_ABLATION_OUT)
    p_abl.add_argument("--fragment_dir", default=DEFAULT_FRAGMENT_DIR)
    p_abl.add_argument("--gt_dir", default=DEFAULT_GT_DIR)
    p_abl.add_argument("--max_points", type=int, default=512)
    p_abl.add_argument("--gt_samples", type=int, default=512)
    p_abl.add_argument("--uid", action="append", default=[], help="Specific uid(s) to evaluate.")
    p_abl.add_argument("--limit", type=int, default=0, help="Evaluate only the first N cases after filtering.")

    args = parser.parse_args()
    if args.cmd == "eval_targets":
        run_eval_targets(args)
    elif args.cmd == "eval_ablation":
        run_ablation(args)
    else:
        raise ValueError(f"unsupported command: {args.cmd}")


if __name__ == "__main__":
    main()
