# Component-level Dou-Gong post-reconstruction optimization

This repository contains the code and compact model artifacts supporting the manuscript **“Component-level Semantic and Geometric Consistency Constrained Post-reconstruction Optimization for 3D Dou-Gong.”** It provides the staged body-first refinement pipeline, graph baselines, evaluation utilities, and the frozen semantic-labeling implementation used in the study.

**Author:** Han Dang, Beijing Forestry University

## Scope and data policy

The repository intentionally does **not** redistribute the source 3D models, PartGen/Hunyuan outputs, ground-truth annotations, per-case overlays, or evaluation-output archives. The source models remain subject to the original provider's access and reuse conditions; derived annotations and research outputs are available from the corresponding author on reasonable request. This repository contains code and configuration only, plus small model-parameter JSON files needed by the scripts.

## Layout

```text
01_code/             refinement, baselines, evaluation, and visualization code
02_models/            compact JSON model parameters and priors
02_models/semantic_model/  frozen semantic-labeling implementation and documentation
07_manifests/         protocol and consistency manifests
08_reproducibility/   runtime, annotation, and leakage-boundary records
dougong_refine_v4.py  core refinement implementation
```

## Environment

Python 3.10+ is recommended. Install the dependencies with:

```bash
python -m pip install -r requirements.txt
```

The code uses NumPy, SciPy, trimesh, and scikit-learn. GPU software is not required for the evaluation utilities.

## Running with private/local data

Because the data are not redistributed, provide local paths to your own compatible input fragments and reference meshes. The main scripts accept explicit paths; do not rely on the historical Windows defaults embedded in archived experiment scripts. For example:

```bash
python 01_code/route_overseg_then_refine_20260530.py \
  --fragment_dir /path/to/fragment/glb \
  --gt_dir /path/to/gt \
  --model_dir 02_models \
  --out_dir outputs/local_run
```

Use `--help` for the exact options of each entry point. The package's historical aggregate reports are documentation of the manuscript evaluation and are not a substitute for the unavailable source dataset.

## Reproducibility and leakage boundary

The 26-case integrated merge-stage result is development-oriented because the historical six-case development artifact is included in that aggregate. The semantic-only comparison uses nested leave-one-case-out evaluation on a frozen component partition. These boundaries are documented in `08_reproducibility/`.

## Citation

If you use this code, please cite the associated manuscript and retain the notices in this repository.

## License

Code in this repository is released under the MIT License. Third-party data, services, and model assets remain governed by their original terms.
