import argparse
import json
import math
import os
import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Set, Tuple

import numpy as np
import trimesh


@dataclass
class Part:
    name: str
    semantic: str
    points: np.ndarray
    centroid: np.ndarray
    bbox_min: np.ndarray
    bbox_max: np.ndarray
    axis: np.ndarray
    bbox_diag: float


@dataclass
class Segment:
    seg_id: int
    points: np.ndarray
    centroid: np.ndarray
    bbox_min: np.ndarray
    bbox_max: np.ndarray
    axis: np.ndarray
    bbox_diag: float


def find_fragment_file(fragment_dir: str, uid: str) -> str:
    for ext in [".glb", ".fbx"]:
        cand = os.path.join(fragment_dir, f"{uid}{ext}")
        if os.path.exists(cand):
            return cand
    return ""


def extract_semantic_from_name(name: str) -> str:
    base = name.split("/")[-1]
    for sep in [".", "_", "-"]:
        if sep in base:
            return base.split(sep)[0]
    return base or "unknown"


def load_part_info(path: str) -> Dict[str, str]:
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        info = json.load(f)
    mapping = {}
    for p in info.get("parts", []):
        node_name = p.get("node_name")
        sem = p.get("semantic_name", "unknown")
        if node_name:
            mapping[node_name] = sem
    return mapping


def load_part_semantics_by_id(path: str) -> List[str]:
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        info = json.load(f)
    parts = info.get("parts", [])
    parts = sorted(parts, key=lambda p: p.get("id", 0))
    semantics = []
    for p in parts:
        sem = p.get("semantic_name")
        if not sem:
            node = p.get("node_name", "")
            sem = extract_semantic_from_name(node)
        semantics.append(sem or "unknown")
    return semantics


def normalize_points(points: np.ndarray, center: np.ndarray, scale: float) -> np.ndarray:
    return (points - center) / max(scale, 1e-8)


def compute_center_scale(points: np.ndarray) -> Tuple[np.ndarray, float]:
    center = points.mean(axis=0)
    extents = points.max(axis=0) - points.min(axis=0)
    scale = float(extents.max())
    return center, scale


def pca_axis(points: np.ndarray) -> np.ndarray:
    if points.shape[0] < 3:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    pts = points - points.mean(axis=0)
    cov = pts.T @ pts / max(points.shape[0] - 1, 1)
    vals, vecs = np.linalg.eigh(cov)
    axis = vecs[:, np.argmax(vals)]
    axis = axis / (np.linalg.norm(axis) + 1e-8)
    return axis.astype(np.float32)


def bbox_stats(points: np.ndarray) -> Tuple[np.ndarray, np.ndarray, float]:
    bmin = points.min(axis=0)
    bmax = points.max(axis=0)
    diag = float(np.linalg.norm(bmax - bmin))
    return bmin, bmax, diag


def sample_points(points: np.ndarray, max_points: int) -> np.ndarray:
    if points.shape[0] <= max_points:
        return points
    idx = np.random.choice(points.shape[0], max_points, replace=False)
    return points[idx]


def load_gt_parts(gt_glb: str, part_info: str, center: np.ndarray, scale: float,
                  samples_per_part: int) -> List[Part]:
    scene = trimesh.load(gt_glb, force=None)
    if not isinstance(scene, trimesh.Scene):
        raise ValueError(f"GT file is not a scene: {gt_glb}")
    name_to_sem = load_part_info(part_info)
    parts: List[Part] = []
    for node_name in scene.graph.nodes:
        data = scene.graph[node_name]
        try:
            transform, geom_name = data
        except Exception:
            continue
        if geom_name is None:
            continue
        mesh = scene.geometry[geom_name].copy()
        try:
            mesh.apply_transform(transform)
        except Exception:
            pass
        pts, _ = trimesh.sample.sample_surface(mesh, samples_per_part)
        pts = normalize_points(pts.astype(np.float32), center, scale)
        centroid = pts.mean(axis=0)
        bmin, bmax, diag = bbox_stats(pts)
        axis = pca_axis(pts)
        semantic = name_to_sem.get(node_name, extract_semantic_from_name(node_name))
        parts.append(
            Part(
                name=node_name,
                semantic=semantic,
                points=pts,
                centroid=centroid,
                bbox_min=bmin,
                bbox_max=bmax,
                axis=axis,
                bbox_diag=diag,
            )
        )
    return parts


def load_gt_parts_from_npy(points_path: str, part_info: str, center: np.ndarray, scale: float,
                           samples_per_part: int) -> List[Part]:
    obj = np.load(points_path, allow_pickle=True).item()
    parts = obj.get("parts", [])
    semantics = load_part_semantics_by_id(part_info)
    out: List[Part] = []
    for idx, part in enumerate(parts):
        pts = part.get("surface_points")
        if pts is None or len(pts) == 0:
            continue
        pts = np.asarray(pts, dtype=np.float32)
        pts = sample_points(pts, samples_per_part)
        pts = normalize_points(pts, center, scale)
        centroid = pts.mean(axis=0)
        bmin, bmax, diag = bbox_stats(pts)
        axis = pca_axis(pts)
        sem = semantics[idx] if idx < len(semantics) else "unknown"
        out.append(
            Part(
                name=f"part_{idx}",
                semantic=sem,
                points=pts,
                centroid=centroid,
                bbox_min=bmin,
                bbox_max=bmax,
                axis=axis,
                bbox_diag=diag,
            )
        )
    return out


def load_gt_parts_auto(gt_dir: str, uid: str, center: np.ndarray, scale: float,
                       samples_per_part: int) -> List[Part]:
    points_path = os.path.join(gt_dir, uid, "points.npy")
    part_info = os.path.join(gt_dir, uid, "part_info.json")
    if os.path.exists(points_path):
        parts = load_gt_parts_from_npy(points_path, part_info, center, scale, samples_per_part)
        if parts:
            return parts
    gt_glb = os.path.join(gt_dir, f"{uid}.glb")
    if os.path.exists(gt_glb):
        return load_gt_parts(gt_glb, part_info, center, scale, samples_per_part)
    return []


def load_fragment_segments(fragment_file: str, samples_per_part: int) -> Tuple[List[Segment], np.ndarray, np.ndarray, float, float]:
    if fragment_file.lower().endswith(".fbx"):
        raise RuntimeError(
            "FBX is not supported by trimesh in this environment. "
            "Please convert fragment to GLB first."
        )
    scene = trimesh.load(fragment_file, force=None)
    if not isinstance(scene, trimesh.Scene):
        raise ValueError(f"fragment file is not a scene: {fragment_file}")
    seg_items = []
    for node_name in scene.graph.nodes:
        data = scene.graph[node_name]
        try:
            transform, geom_name = data
        except Exception:
            continue
        if geom_name is None:
            continue
        mesh = scene.geometry[geom_name].copy()
        try:
            mesh.apply_transform(transform)
        except Exception:
            pass
        # Keep fragment segment sampling deterministic across training and
        # inference so that manually supervised post-process models see the
        # same geometry each run.
        rng_state = np.random.get_state()
        seed_match = re.search(r"part_(\d+)", str(node_name))
        seed_value = int(seed_match.group(1)) if seed_match else abs(hash(str(node_name))) % (2 ** 31)
        np.random.seed(seed_value + 12345)
        pts, _ = trimesh.sample.sample_surface(mesh, samples_per_part)
        np.random.set_state(rng_state)
        match = re.search(r"part_(\d+)", str(node_name))
        parsed_seg_id = int(match.group(1)) if match else None
        seg_items.append(
            {
                "node_name": str(node_name),
                "points": pts.astype(np.float32),
                "parsed_seg_id": parsed_seg_id,
            }
        )

    if not seg_items:
        raise RuntimeError(f"No parts found in fragment file: {fragment_file}")

    # Use the fragment object suffix `part_Y` as the stable segment id so that
    # manual groupings, visual inspection, and runtime segment ids all refer
    # to the same numbering system.
    seen_ids: Set[int] = set()
    fallback_id = 0
    for item in seg_items:
        seg_id = item["parsed_seg_id"]
        if seg_id is None or seg_id in seen_ids:
            while fallback_id in seen_ids:
                fallback_id += 1
            seg_id = fallback_id
        item["seg_id"] = int(seg_id)
        seen_ids.add(int(seg_id))

    seg_items.sort(key=lambda item: (int(item["seg_id"]), str(item["node_name"])))

    all_points = np.vstack([item["points"] for item in seg_items])
    center, scale = compute_center_scale(all_points)
    normalized_all = normalize_points(all_points.astype(np.float32), center, scale)
    global_diag = float(np.linalg.norm(normalized_all.max(axis=0) - normalized_all.min(axis=0)))
    segments: List[Segment] = []
    seg_names: List[str] = []
    for item in seg_items:
        pts = normalize_points(item["points"], center, scale)
        centroid = pts.mean(axis=0)
        bmin, bmax, diag = bbox_stats(pts)
        axis = pca_axis(pts)
        segments.append(
            Segment(
                seg_id=int(item["seg_id"]),
                points=pts,
                centroid=centroid,
                bbox_min=bmin,
                bbox_max=bmax,
                axis=axis,
                bbox_diag=diag,
            )
        )
        seg_names.append(str(item["node_name"]))
    return segments, np.array(seg_names, dtype=object), center, scale, global_diag


def build_segments(points: np.ndarray, labels: np.ndarray,
                   max_points_per_seg: int) -> List[Segment]:
    segments: List[Segment] = []
    for seg_id in np.unique(labels):
        seg_points = points[labels == seg_id]
        seg_sample = sample_points(seg_points, max_points_per_seg)
        centroid = seg_sample.mean(axis=0)
        bmin, bmax, diag = bbox_stats(seg_sample)
        axis = pca_axis(seg_sample)
        segments.append(
            Segment(
                seg_id=int(seg_id),
                points=seg_sample,
                centroid=centroid,
                bbox_min=bmin,
                bbox_max=bmax,
                axis=axis,
                bbox_diag=diag,
            )
        )
    return segments


def bbox_gap(a_min: np.ndarray, a_max: np.ndarray,
             b_min: np.ndarray, b_max: np.ndarray) -> float:
    gap = np.maximum(0.0, np.maximum(b_min - a_max, a_min - b_max))
    return float(np.linalg.norm(gap))


def min_dist_stats(a_points: np.ndarray, b_points: np.ndarray, contact_eps: float) -> Tuple[float, float, float]:
    diff = a_points[:, None, :] - b_points[None, :, :]
    d2 = np.sum(diff * diff, axis=-1)
    min_d = np.sqrt(np.min(d2, axis=1))
    return float(min_d.mean()), float(min_d.min()), float((min_d < contact_eps).mean())


def overlap_ratio(a_min: float, a_max: float, b_min: float, b_max: float) -> float:
    inter = max(0.0, min(a_max, b_max) - max(a_min, b_min))
    denom = max(min(a_max - a_min, b_max - b_min), 1e-8)
    return float(inter / denom)


def edge_features(seg_a: Segment, seg_b: Segment, contact_eps: float, global_diag: float) -> Dict[str, float]:
    mean_d, min_d, contact_a = min_dist_stats(seg_a.points, seg_b.points, contact_eps)
    mean_d_b, min_d_b, contact_b = min_dist_stats(seg_b.points, seg_a.points, contact_eps)
    axis_dot = float(abs(np.dot(seg_a.axis, seg_b.axis)))
    axis_angle = float(math.acos(max(min(axis_dot, 1.0), -1.0)))
    size_ratio = float(min(seg_a.bbox_diag, seg_b.bbox_diag) / max(seg_a.bbox_diag, seg_b.bbox_diag, 1e-8))
    z_overlap = overlap_ratio(seg_a.bbox_min[2], seg_a.bbox_max[2], seg_b.bbox_min[2], seg_b.bbox_max[2])
    features = {
        "centroid_dist": float(np.linalg.norm(seg_a.centroid - seg_b.centroid) / max(global_diag, 1e-8)),
        "bbox_gap": float(bbox_gap(seg_a.bbox_min, seg_a.bbox_max, seg_b.bbox_min, seg_b.bbox_max) / max(global_diag, 1e-8)),
        "mean_min_dist": float(0.5 * (mean_d + mean_d_b) / max(global_diag, 1e-8)),
        "min_dist": float(0.5 * (min_d + min_d_b) / max(global_diag, 1e-8)),
        "contact_ratio": float(max(contact_a, contact_b)),
        "axis_angle": axis_angle,
        "size_ratio": size_ratio,
        "z_overlap": z_overlap,
    }
    return features


def build_edges(segments: List[Segment], global_diag: float,
                neighbor_ratio: float, contact_eps: float) -> Tuple[List[Tuple[int, int]], List[Dict[str, float]]]:
    edges = []
    feats = []
    n = len(segments)
    for i in range(n):
        for j in range(i + 1, n):
            a = segments[i]
            b = segments[j]
            gap = bbox_gap(a.bbox_min, a.bbox_max, b.bbox_min, b.bbox_max)
            if gap > neighbor_ratio * global_diag:
                continue
            f = edge_features(a, b, contact_eps, global_diag)
            edges.append((a.seg_id, b.seg_id))
            feats.append(f)
    return edges, feats


def assign_segments_to_gt(segments: List[Segment], gt_parts: List[Part]) -> Tuple[Dict[int, int], Dict[int, float]]:
    if not gt_parts:
        return {}, {}
    mapping = {}
    dominance = {}
    gt_points = [p.points for p in gt_parts]
    for seg in segments:
        seg_pts = seg.points
        dists = []
        for gp in gt_points:
            diff = seg_pts[:, None, :] - gp[None, :, :]
            d2 = np.sum(diff * diff, axis=-1)
            min_d = np.sqrt(np.min(d2, axis=1))
            dists.append(min_d)
        dist_mat = np.stack(dists, axis=1)
        assign = np.argmin(dist_mat, axis=1)
        counts = np.bincount(assign, minlength=len(gt_parts))
        best = int(np.argmax(counts))
        mapping[seg.seg_id] = best
        dominance[seg.seg_id] = float(counts[best] / max(len(seg_pts), 1))
    return mapping, dominance


def deterministic_subsample_points(points: np.ndarray, max_points: int) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float32)
    if pts.shape[0] <= max_points:
        return pts
    idx = np.linspace(0, pts.shape[0] - 1, max_points, dtype=np.int32)
    return pts[idx]


def coverage_with_tolerance(src_points: np.ndarray, dst_points: np.ndarray, tau: float, chunk_size: int = 256) -> float:
    src = np.asarray(src_points, dtype=np.float32)
    dst = np.asarray(dst_points, dtype=np.float32)
    if src.shape[0] == 0 or dst.shape[0] == 0:
        return 0.0
    tau2 = float(tau * tau)
    covered = 0
    for start in range(0, src.shape[0], chunk_size):
        block = src[start:start + chunk_size]
        diff = block[:, None, :] - dst[None, :, :]
        d2 = np.sum(diff * diff, axis=-1)
        covered += int(np.sum(np.min(d2, axis=1) <= tau2))
    return float(covered / max(src.shape[0], 1))


def symmetric_component_match_score(
    pred_points: np.ndarray,
    gt_points: np.ndarray,
    tau: float,
    max_points: int = 768,
    beta: float = 0.5,
) -> Tuple[float, float, float]:
    pred = deterministic_subsample_points(pred_points, max_points)
    gt = deterministic_subsample_points(gt_points, max_points)
    forward = coverage_with_tolerance(pred, gt, tau)
    backward = coverage_with_tolerance(gt, pred, tau)
    beta2 = float(beta * beta)
    score = float((1.0 + beta2) * forward * backward / max(beta2 * forward + backward, 1e-8))
    return score, forward, backward


def match_components_to_gt_parts(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[Part],
    tau: float,
    max_points: int = 768,
    beta: float = 0.5,
) -> Tuple[Dict[int, int], Dict[int, float], Dict[int, Dict[str, float]]]:
    if not comp_points or not gt_parts:
        return {}, {}, {}
    mapping: Dict[int, int] = {}
    scores: Dict[int, float] = {}
    details: Dict[int, Dict[str, float]] = {}
    for cid, pts in comp_points.items():
        best_gt = -1
        best_score = -1.0
        best_forward = 0.0
        best_backward = 0.0
        for gt_idx, gt_part in enumerate(gt_parts):
            score, forward, backward = symmetric_component_match_score(
                pts, gt_part.points, tau=tau, max_points=max_points, beta=beta
            )
            if score > best_score:
                best_gt = int(gt_idx)
                best_score = float(score)
                best_forward = float(forward)
                best_backward = float(backward)
        if best_gt >= 0:
            mapping[int(cid)] = best_gt
            scores[int(cid)] = max(0.0, best_score)
            details[int(cid)] = {
                "score": max(0.0, best_score),
                "forward_cover": max(0.0, best_forward),
                "backward_cover": max(0.0, best_backward),
            }
    return mapping, scores, details


def component_mean_purity(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[Part],
    tau: float,
    max_points: int = 768,
    size_weighted: bool = True,
    beta: float = 0.5,
) -> Tuple[float, Dict[int, int], Dict[int, float], Dict[int, Dict[str, float]]]:
    mapping, scores, details = match_components_to_gt_parts(
        comp_points, gt_parts, tau=tau, max_points=max_points, beta=beta
    )
    if not scores:
        return 0.0, mapping, scores, details
    if not size_weighted:
        return float(np.mean(list(scores.values()))), mapping, scores, details
    weights = []
    values = []
    for cid, score in scores.items():
        pts = np.asarray(comp_points.get(cid, np.zeros((0, 3), dtype=np.float32)), dtype=np.float32)
        weights.append(float(len(pts)))
        values.append(float(score))
    weights = np.asarray(weights, dtype=np.float64)
    values = np.asarray(values, dtype=np.float64)
    mean_score = float((values * weights).sum() / max(weights.sum(), 1.0))
    return mean_score, mapping, scores, details


def match_gt_parts_to_components(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[Part],
    tau: float,
    max_points: int = 768,
    beta: float = 1.0,
) -> Tuple[Dict[int, int], Dict[int, float], Dict[int, Dict[str, float]]]:
    if not comp_points or not gt_parts:
        return {}, {}, {}
    mapping: Dict[int, int] = {}
    scores: Dict[int, float] = {}
    details: Dict[int, Dict[str, float]] = {}
    for gt_idx, gt_part in enumerate(gt_parts):
        best_cid = -1
        best_score = -1.0
        best_gt_cover = 0.0
        best_pred_cover = 0.0
        for cid, pts in comp_points.items():
            score, gt_cover, pred_cover = symmetric_component_match_score(
                gt_part.points, pts, tau=tau, max_points=max_points, beta=beta
            )
            if score > best_score:
                best_cid = int(cid)
                best_score = float(score)
                best_gt_cover = float(gt_cover)
                best_pred_cover = float(pred_cover)
        if best_cid >= 0:
            mapping[int(gt_idx)] = best_cid
            scores[int(gt_idx)] = max(0.0, best_score)
            details[int(gt_idx)] = {
                "score": max(0.0, best_score),
                "gt_cover": max(0.0, best_gt_cover),
                "pred_cover": max(0.0, best_pred_cover),
            }
    return mapping, scores, details


def gt_part_mean_coverage(
    comp_points: Dict[int, np.ndarray],
    gt_parts: List[Part],
    tau: float,
    max_points: int = 768,
    size_weighted: bool = True,
    beta: float = 1.0,
) -> Tuple[float, Dict[int, int], Dict[int, float], Dict[int, Dict[str, float]]]:
    mapping, scores, details = match_gt_parts_to_components(
        comp_points, gt_parts, tau=tau, max_points=max_points, beta=beta
    )
    if not scores:
        return 0.0, mapping, scores, details
    if not size_weighted:
        return float(np.mean(list(scores.values()))), mapping, scores, details
    weights = []
    values = []
    for gt_idx, score in scores.items():
        pts = np.asarray(gt_parts[int(gt_idx)].points, dtype=np.float32)
        weights.append(float(len(pts)))
        values.append(float(score))
    weights = np.asarray(weights, dtype=np.float64)
    values = np.asarray(values, dtype=np.float64)
    mean_score = float((values * weights).sum() / max(weights.sum(), 1.0))
    return mean_score, mapping, scores, details


def segment_label_map_from_gt(segments: List[Segment], gt_parts: List[Part]) -> Tuple[Dict[int, int], Dict[int, float]]:
    return assign_segments_to_gt(segments, gt_parts)


def segment_weight_map(segments: List[Segment]) -> Dict[int, float]:
    return {int(seg.seg_id): float(len(seg.points)) for seg in segments}


def weighted_cluster_purity_from_seg_labels(
    comp_map: Dict[int, int],
    seg_label_map: Dict[int, int],
    seg_weight_map: Dict[int, float] | None = None,
) -> float:
    if not comp_map or not seg_label_map:
        return 0.0
    if seg_weight_map is None:
        seg_weight_map = {int(seg_id): 1.0 for seg_id in seg_label_map.keys()}
    comp_members: Dict[int, List[int]] = {}
    for seg_id, cid in comp_map.items():
        if int(seg_id) not in seg_label_map:
            continue
        comp_members.setdefault(int(cid), []).append(int(seg_id))
    if not comp_members:
        return 0.0
    total_weight = 0.0
    total_score = 0.0
    for seg_ids in comp_members.values():
        label_weights: Dict[int, float] = {}
        comp_weight = 0.0
        for seg_id in seg_ids:
            w = float(seg_weight_map.get(int(seg_id), 1.0))
            comp_weight += w
            label = int(seg_label_map[int(seg_id)])
            label_weights[label] = label_weights.get(label, 0.0) + w
        if comp_weight <= 0.0:
            continue
        purity = max(label_weights.values()) / comp_weight if label_weights else 0.0
        total_weight += comp_weight
        total_score += purity * comp_weight
    return float(total_score / max(total_weight, 1e-8))


def weighted_cluster_completeness_from_seg_labels(
    comp_map: Dict[int, int],
    seg_label_map: Dict[int, int],
    seg_weight_map: Dict[int, float] | None = None,
) -> float:
    if not comp_map or not seg_label_map:
        return 0.0
    if seg_weight_map is None:
        seg_weight_map = {int(seg_id): 1.0 for seg_id in seg_label_map.keys()}
    gold_members: Dict[int, List[int]] = {}
    for seg_id, gold_label in seg_label_map.items():
        sid = int(seg_id)
        if sid not in comp_map:
            continue
        gold_members.setdefault(int(gold_label), []).append(sid)
    if not gold_members:
        return 0.0
    total_weight = 0.0
    total_score = 0.0
    for seg_ids in gold_members.values():
        pred_weights: Dict[int, float] = {}
        gold_weight = 0.0
        for seg_id in seg_ids:
            w = float(seg_weight_map.get(int(seg_id), 1.0))
            gold_weight += w
            cid = int(comp_map[int(seg_id)])
            pred_weights[cid] = pred_weights.get(cid, 0.0) + w
        if gold_weight <= 0.0:
            continue
        completeness = max(pred_weights.values()) / gold_weight if pred_weights else 0.0
        total_weight += gold_weight
        total_score += completeness * gold_weight
    return float(total_score / max(total_weight, 1e-8))


def harmonic_mean_score(a: float, b: float) -> float:
    a = float(a)
    b = float(b)
    if a <= 0.0 or b <= 0.0:
        return 0.0
    return float(2.0 * a * b / max(a + b, 1e-8))


def bcubed_from_maps(
    pred_map: Dict[int, int],
    gold_map: Dict[int, int],
    weights: Dict[int, float] | None = None,
) -> Dict[str, float]:
    common_ids = sorted(set(int(k) for k in pred_map.keys()) & set(int(k) for k in gold_map.keys()))
    if not common_ids:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}
    if weights is None:
        weights = {seg_id: 1.0 for seg_id in common_ids}

    pred_groups: Dict[int, Set[int]] = {}
    gold_groups: Dict[int, Set[int]] = {}
    for seg_id in common_ids:
        pred_groups.setdefault(int(pred_map[seg_id]), set()).add(seg_id)
        gold_groups.setdefault(int(gold_map[seg_id]), set()).add(seg_id)

    total_w = 0.0
    precision_sum = 0.0
    recall_sum = 0.0
    for seg_id in common_ids:
        w = float(weights.get(seg_id, 1.0))
        pred_cluster = pred_groups[int(pred_map[seg_id])]
        gold_cluster = gold_groups[int(gold_map[seg_id])]
        inter = len(pred_cluster & gold_cluster)
        precision_i = inter / max(len(pred_cluster), 1)
        recall_i = inter / max(len(gold_cluster), 1)
        total_w += w
        precision_sum += w * precision_i
        recall_sum += w * recall_i
    precision = float(precision_sum / max(total_w, 1e-8))
    recall = float(recall_sum / max(total_w, 1e-8))
    f1 = float(2.0 * precision * recall / max(precision + recall, 1e-8))
    return {"precision": precision, "recall": recall, "f1": f1}


def pairwise_prf_from_maps(
    pred_map: Dict[int, int],
    gold_map: Dict[int, int],
) -> Dict[str, float]:
    common_ids = sorted(set(int(k) for k in pred_map.keys()) & set(int(k) for k in gold_map.keys()))
    if not common_ids:
        return {"precision": 0.0, "recall": 0.0, "f1": 0.0}
    if len(common_ids) < 2:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0}

    tp = 0
    fp = 0
    fn = 0
    for i, a in enumerate(common_ids):
        for b in common_ids[i + 1:]:
            pred_same = int(pred_map[a]) == int(pred_map[b])
            gold_same = int(gold_map[a]) == int(gold_map[b])
            if pred_same and gold_same:
                tp += 1
            elif pred_same and not gold_same:
                fp += 1
            elif (not pred_same) and gold_same:
                fn += 1
    precision = float(tp / max(tp + fp, 1))
    recall = float(tp / max(tp + fn, 1))
    f1 = float(2.0 * precision * recall / max(precision + recall, 1e-8))
    return {"precision": precision, "recall": recall, "f1": f1}


def weighted_semantic_accuracy_from_seg_maps(
    comp_map: Dict[int, int],
    seg_to_gt: Dict[int, int],
    comp_sem: Dict[int, str],
    gt_parts: List[Part],
    seg_weight_map: Dict[int, float] | None = None,
) -> float:
    common_ids = sorted(set(int(k) for k in comp_map.keys()) & set(int(k) for k in seg_to_gt.keys()))
    if not common_ids:
        return 0.0
    if seg_weight_map is None:
        seg_weight_map = {seg_id: 1.0 for seg_id in common_ids}

    total_weight = 0.0
    total_correct = 0.0
    for seg_id in common_ids:
        w = float(seg_weight_map.get(int(seg_id), 1.0))
        gt_idx = int(seg_to_gt[int(seg_id)])
        if gt_idx < 0 or gt_idx >= len(gt_parts):
            continue
        pred_sem = str(comp_sem.get(int(comp_map[int(seg_id)]), "unknown"))
        gt_sem = str(gt_parts[gt_idx].semantic)
        total_weight += w
        total_correct += w * float(pred_sem == gt_sem)
    return float(total_correct / max(total_weight, 1e-8))


def semantic_distribution_iou_from_seg_maps(
    comp_map: Dict[int, int],
    seg_to_gt: Dict[int, int],
    comp_sem: Dict[int, str],
    gt_parts: List[Part],
    seg_weight_map: Dict[int, float] | None = None,
) -> float:
    common_ids = sorted(set(int(k) for k in comp_map.keys()) & set(int(k) for k in seg_to_gt.keys()))
    if not common_ids:
        return 0.0
    if seg_weight_map is None:
        seg_weight_map = {seg_id: 1.0 for seg_id in common_ids}

    pred_hist: Dict[str, float] = defaultdict(float)
    gt_hist: Dict[str, float] = defaultdict(float)
    for seg_id in common_ids:
        w = float(seg_weight_map.get(int(seg_id), 1.0))
        gt_idx = int(seg_to_gt[int(seg_id)])
        if gt_idx < 0 or gt_idx >= len(gt_parts):
            continue
        pred_sem = str(comp_sem.get(int(comp_map[int(seg_id)]), "unknown"))
        gt_sem = str(gt_parts[gt_idx].semantic)
        pred_hist[pred_sem] += w
        gt_hist[gt_sem] += w

    classes = sorted(set(pred_hist.keys()) | set(gt_hist.keys()))
    numerator = sum(min(float(pred_hist.get(cls, 0.0)), float(gt_hist.get(cls, 0.0))) for cls in classes)
    denominator = sum(max(float(pred_hist.get(cls, 0.0)), float(gt_hist.get(cls, 0.0))) for cls in classes)
    return float(numerator / max(denominator, 1e-8))


def segments_to_edge_labels(edges: List[Tuple[int, int]], mapping: Dict[int, int]) -> np.ndarray:
    labels = []
    for a, b in edges:
        if a in mapping and b in mapping and mapping[a] == mapping[b]:
            labels.append(1)
        else:
            labels.append(0)
    return np.array(labels, dtype=np.int32)


def features_to_matrix(feats: List[Dict[str, float]]) -> Tuple[np.ndarray, List[str]]:
    if not feats:
        return np.zeros((0, 0), dtype=np.float32), []
    keys = sorted(feats[0].keys())
    mat = np.array([[f[k] for k in keys] for f in feats], dtype=np.float32)
    return mat, keys


def best_f1_threshold(scores: np.ndarray, labels: np.ndarray) -> float:
    if scores.size == 0:
        return 0.0
    order = np.argsort(scores)
    best_f1 = -1.0
    best_t = scores[order[0]]
    for idx in order:
        t = scores[idx]
        preds = (scores >= t).astype(np.int32)
        tp = int(((preds == 1) & (labels == 1)).sum())
        fp = int(((preds == 1) & (labels == 0)).sum())
        fn = int(((preds == 0) & (labels == 1)).sum())
        prec = tp / max(tp + fp, 1)
        rec = tp / max(tp + fn, 1)
        f1 = 2 * prec * rec / max(prec + rec, 1e-8)
        if f1 > best_f1:
            best_f1 = f1
            best_t = t
    return float(best_t)


def train_edge_model(x: np.ndarray, y: np.ndarray) -> Dict:
    mean = x.mean(axis=0)
    std = x.std(axis=0) + 1e-8
    z = (x - mean) / std
    pos = z[y == 1]
    neg = z[y == 0]
    if pos.shape[0] == 0 or neg.shape[0] == 0:
        weights = np.zeros(z.shape[1], dtype=np.float32)
    else:
        w = (pos.mean(axis=0) - neg.mean(axis=0)) / (pos.std(axis=0) + neg.std(axis=0) + 1e-8)
        weights = w.astype(np.float32)
    scores = z @ weights
    threshold = best_f1_threshold(scores, y)
    return {
        "mean": mean.tolist(),
        "std": std.tolist(),
        "weights": weights.tolist(),
        "threshold": float(threshold),
    }


def score_edges(x: np.ndarray, model: Dict) -> np.ndarray:
    mean = np.array(model["mean"], dtype=np.float32)
    std = np.array(model["std"], dtype=np.float32)
    weights = np.array(model["weights"], dtype=np.float32)
    z = (x - mean) / std
    return z @ weights


def relabel_components(comp_map: Dict[int, int]) -> Dict[int, int]:
    remap = {}
    next_id = 0
    out = {}
    for seg_id, root in comp_map.items():
        if root not in remap:
            remap[root] = next_id
            next_id += 1
        out[seg_id] = remap[root]
    return out


def constrained_union_by_score(
    node_ids: List[int],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    target_components: int,
    min_score: float,
    max_component_segments: int = 0,
    segment_bounds: Dict[int, Tuple[np.ndarray, np.ndarray]] = None,
    max_component_bbox_diag: float = 0.0,
) -> Dict[int, int]:
    parent = {nid: nid for nid in node_ids}
    size = {nid: 1 for nid in node_ids}
    if segment_bounds is None:
        segment_bounds = {}
    bmin = {nid: segment_bounds.get(nid, (np.zeros(3), np.zeros(3)))[0].copy() for nid in node_ids}
    bmax = {nid: segment_bounds.get(nid, (np.zeros(3), np.zeros(3)))[1].copy() for nid in node_ids}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return False
        if max_component_segments > 0 and (size[ra] + size[rb] > max_component_segments):
            return False
        if max_component_bbox_diag > 0:
            cmb_min = np.minimum(bmin[ra], bmin[rb])
            cmb_max = np.maximum(bmax[ra], bmax[rb])
            cmb_diag = float(np.linalg.norm(cmb_max - cmb_min))
            if cmb_diag > max_component_bbox_diag:
                return False
        if size[ra] < size[rb]:
            ra, rb = rb, ra
        parent[rb] = ra
        size[ra] += size[rb]
        bmin[ra] = np.minimum(bmin[ra], bmin[rb])
        bmax[ra] = np.maximum(bmax[ra], bmax[rb])
        return True

    current_components = len(node_ids)
    order = np.argsort(-scores)
    for idx in order:
        if current_components <= target_components:
            break
        if float(scores[idx]) < min_score:
            break
        a, b = edges[int(idx)]
        if union(a, b):
            current_components -= 1

    comp = {}
    for nid in node_ids:
        comp[nid] = find(nid)
    return comp


def attach_small_components(
    comp_map: Dict[int, int],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    target_components: int,
    small_component_max_segments: int,
    attach_min_score: float,
    max_component_segments: int,
    segment_bounds: Dict[int, Tuple[np.ndarray, np.ndarray]],
    max_component_bbox_diag: float,
) -> Dict[int, int]:
    if not comp_map or not edges or scores.size == 0:
        return comp_map

    def count_components(m: Dict[int, int]) -> int:
        return len(set(m.values()))

    changed = True
    while changed and count_components(comp_map) > target_components:
        changed = False
        members: Dict[int, List[int]] = {}
        for seg_id, cid in comp_map.items():
            members.setdefault(cid, []).append(seg_id)
        comp_sizes = {cid: len(v) for cid, v in members.items()}
        comp_bounds = {}
        for cid, segs in members.items():
            mins = [segment_bounds[s][0] for s in segs if s in segment_bounds]
            maxs = [segment_bounds[s][1] for s in segs if s in segment_bounds]
            if mins and maxs:
                comp_bounds[cid] = (np.min(np.vstack(mins), axis=0), np.max(np.vstack(maxs), axis=0))

        pair_best: Dict[Tuple[int, int], float] = {}
        for (a, b), s in zip(edges, scores):
            ca = comp_map[a]
            cb = comp_map[b]
            if ca == cb:
                continue
            key = (ca, cb) if ca < cb else (cb, ca)
            prev = pair_best.get(key)
            val = float(s)
            if prev is None or val > prev:
                pair_best[key] = val

        small_ids = [cid for cid, sz in comp_sizes.items() if sz <= small_component_max_segments]
        small_ids.sort(key=lambda x: comp_sizes[x])
        for cid in small_ids:
            best_other = None
            best_score = -1e9
            for (a, b), s in pair_best.items():
                if cid not in (a, b):
                    continue
                other = b if a == cid else a
                if s < attach_min_score:
                    continue
                merged_size = comp_sizes[cid] + comp_sizes.get(other, 0)
                if max_component_segments > 0 and merged_size > max_component_segments:
                    continue
                if max_component_bbox_diag > 0 and cid in comp_bounds and other in comp_bounds:
                    cmb_min = np.minimum(comp_bounds[cid][0], comp_bounds[other][0])
                    cmb_max = np.maximum(comp_bounds[cid][1], comp_bounds[other][1])
                    cmb_diag = float(np.linalg.norm(cmb_max - cmb_min))
                    if cmb_diag > max_component_bbox_diag:
                        continue
                if s > best_score:
                    best_score = s
                    best_other = other
            if best_other is None:
                continue
            for seg_id in members[cid]:
                comp_map[seg_id] = best_other
            changed = True
            break

    return comp_map


def enforce_target_component_count(
    comp_map: Dict[int, int],
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    target_components: int,
    max_component_segments: int,
    max_component_bbox_diag: float,
) -> Dict[int, int]:
    if not comp_map:
        return comp_map

    seg_by_id = {s.seg_id: s for s in segments}
    edge_score: Dict[Tuple[int, int], float] = {}
    for (a, b), sc in zip(edges, scores):
        key = (a, b) if a < b else (b, a)
        edge_score[key] = float(sc)

    def score_between(seg_a: int, seg_b: int) -> float:
        key = (seg_a, seg_b) if seg_a < seg_b else (seg_b, seg_a)
        if key in edge_score:
            return edge_score[key]
        sa = seg_by_id[seg_a]
        sb = seg_by_id[seg_b]
        dist = float(np.linalg.norm(sa.centroid - sb.centroid))
        return -dist

    def members_map() -> Dict[int, List[int]]:
        out: Dict[int, List[int]] = {}
        for seg_id, cid in comp_map.items():
            out.setdefault(cid, []).append(seg_id)
        return out

    def component_bbox_diag(seg_ids: List[int]) -> float:
        mins = [seg_by_id[sid].bbox_min for sid in seg_ids]
        maxs = [seg_by_id[sid].bbox_max for sid in seg_ids]
        bmin = np.min(np.vstack(mins), axis=0)
        bmax = np.max(np.vstack(maxs), axis=0)
        return float(np.linalg.norm(bmax - bmin))

    comp_map = relabel_components(comp_map)

    while len(set(comp_map.values())) > target_components:
        members = members_map()
        best = None
        for cid_a, segs_a in members.items():
            for cid_b, segs_b in members.items():
                if cid_b <= cid_a:
                    continue
                merged_size = len(segs_a) + len(segs_b)
                if max_component_segments > 0 and merged_size > max_component_segments:
                    continue
                if max_component_bbox_diag > 0.0:
                    merged_diag = component_bbox_diag(segs_a + segs_b)
                    if merged_diag > max_component_bbox_diag:
                        continue
                pair_score = None
                for sid_a in segs_a:
                    for sid_b in segs_b:
                        sc = score_between(sid_a, sid_b)
                        if pair_score is None or sc > pair_score:
                            pair_score = sc
                if pair_score is None:
                    continue
                small_bonus = 0.08 * float(min(len(segs_a), len(segs_b)) == 1)
                value = float(pair_score + small_bonus)
                if best is None or value > best[0]:
                    best = (value, cid_a, cid_b)
        if best is None:
            break
        _, cid_a, cid_b = best
        for seg_id in members[cid_b]:
            comp_map[seg_id] = cid_a
        comp_map = relabel_components(comp_map)

    while len(set(comp_map.values())) < target_components:
        members = members_map()
        next_cid = max(comp_map.values()) + 1 if comp_map else 0
        best = None
        for cid, seg_ids in members.items():
            if len(seg_ids) <= 1:
                continue
            for sid in seg_ids:
                others = [oid for oid in seg_ids if oid != sid]
                if not others:
                    continue
                conn_scores = [score_between(sid, oid) for oid in others]
                cohesion = float(sum(conn_scores) / max(len(conn_scores), 1))
                size_penalty = 0.04 * max(len(seg_ids) - 2, 0)
                value = -cohesion + size_penalty
                if best is None or value > best[0]:
                    best = (value, cid, sid, next_cid)
        if best is None:
            break
        _, cid, sid, new_cid = best
        comp_map[sid] = new_cid
        comp_map = relabel_components(comp_map)

    return relabel_components(comp_map)


def choose_component_map(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    target_components_hint: int = 0,
    force_target: bool = False,
) -> Dict[int, int]:
    node_ids = [s.seg_id for s in segments]
    if len(node_ids) == 0:
        return {}
    if len(edges) == 0 or scores.size == 0:
        return {nid: nid for nid in node_ids}

    base_threshold = float(model.get("threshold", 0.0))
    keep_target_ratio = float(model.get("target_keep_ratio", 0.4))
    keep_target_ratio = min(max(keep_target_ratio, 0.2), 0.55)
    quantile_floor = float(np.quantile(scores, 1.0 - keep_target_ratio))
    min_score = max(base_threshold, quantile_floor)

    component_ratio = float(model.get("target_component_ratio", 0.55))
    component_ratio = min(max(component_ratio, 0.35), 0.7)
    target_components = int(round(len(node_ids) * component_ratio))
    if target_components_hint > 0:
        target_components = int(target_components_hint)
    target_components = max(2, min(len(node_ids), target_components))
    if force_target:
        min_score = -1e9

    max_comp_seg = int(model.get("max_component_segments", 0))
    if max_comp_seg <= 0:
        max_comp_seg = 6

    max_comp_diag = float(model.get("max_component_bbox_diag", 0.0))
    seg_bounds = {s.seg_id: (s.bbox_min, s.bbox_max) for s in segments}

    comp_map = constrained_union_by_score(
        node_ids=node_ids,
        edges=edges,
        scores=scores,
        target_components=target_components,
        min_score=min_score,
        max_component_segments=max_comp_seg,
        segment_bounds=seg_bounds,
        max_component_bbox_diag=max_comp_diag,
    )
    comp_map = relabel_components(comp_map)

    if len(set(comp_map.values())) > target_components:
        small_max = int(model.get("small_component_max_segments", 2))
        attach_q = float(model.get("small_attach_score_quantile", 0.6))
        attach_q = min(max(attach_q, 0.5), 0.95)
        attach_min = float(np.quantile(scores, attach_q))
        comp_map = attach_small_components(
            comp_map=comp_map,
            edges=edges,
            scores=scores,
            target_components=target_components,
            small_component_max_segments=small_max,
            attach_min_score=attach_min,
            max_component_segments=max_comp_seg,
            segment_bounds=seg_bounds,
            max_component_bbox_diag=max_comp_diag,
        )
    comp_map = relabel_components(comp_map)

    if force_target and target_components_hint > 0:
        comp_map = enforce_target_component_count(
            comp_map=comp_map,
            segments=segments,
            edges=edges,
            scores=scores,
            target_components=target_components,
            max_component_segments=max_comp_seg,
            max_component_bbox_diag=max_comp_diag,
        )
    return relabel_components(comp_map)


def singleton_component_map(segments: List[Segment]) -> Dict[int, int]:
    return {s.seg_id: s.seg_id for s in segments}


def filter_edges_and_scores(
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    allowed_ids: Set[int],
) -> Tuple[List[Tuple[int, int]], np.ndarray]:
    keep_idx = []
    keep_edges = []
    for idx, (a, b) in enumerate(edges):
        if a in allowed_ids and b in allowed_ids:
            keep_idx.append(idx)
            keep_edges.append((a, b))
    if scores.size == 0 or not keep_idx:
        return keep_edges, np.array([], dtype=np.float32)
    return keep_edges, scores[np.array(keep_idx, dtype=np.int32)]

# ---------------------------
# v4 Gong-centric refinement
# ---------------------------

def build_components_from_map(comp_map: Dict[int, int], segments: List[Segment]) -> Dict[int, Dict]:
    seg_by_id = {s.seg_id: s for s in segments}
    members: Dict[int, List[int]] = {}
    for seg_id, cid in comp_map.items():
        members.setdefault(cid, []).append(seg_id)

    comps: Dict[int, Dict] = {}
    for cid, seg_ids in members.items():
        pts = np.vstack([seg_by_id[sid].points for sid in seg_ids]).astype(np.float32)
        centroid = pts.mean(axis=0)
        bmin, bmax, diag = bbox_stats(pts)
        axis = pca_axis(pts)
        extents = np.maximum(bmax - bmin, 1e-8)
        sorted_ext = np.sort(extents)[::-1]
        elongation = float(sorted_ext[0] / max(sorted_ext[1], 1e-8))
        # Use bbox-horizontal axes rather than PCA direction; this is much more stable
        # for symmetric gong bodies whose PCA can flip toward the vertical fillet/shoulder.
        if extents[0] >= extents[1]:
            axis_xy = np.array([1.0, 0.0, 0.0], dtype=np.float32)
            lateral_xy = np.array([0.0, 1.0, 0.0], dtype=np.float32)
            major_span = float(extents[0])
            minor_span = float(extents[1])
        else:
            axis_xy = np.array([0.0, 1.0, 0.0], dtype=np.float32)
            lateral_xy = np.array([1.0, 0.0, 0.0], dtype=np.float32)
            major_span = float(extents[1])
            minor_span = float(extents[0])

        centered = pts - centroid
        long_coords = centered @ axis_xy
        lat_coords = centered @ lateral_xy
        z_coords = centered[:, 2]

        long_span = float(max(long_coords.max() - long_coords.min(), 1e-8))
        lat_span = float(max(lat_coords.max() - lat_coords.min(), 1e-8))
        z_span = float(max(z_coords.max() - z_coords.min(), 1e-8))
        horizontal_elongation = float(long_span / max(lat_span, 1e-8))
        height_ratio = float(z_span / max(long_span, 1e-8))
        q_low, q_high = np.quantile(long_coords, [0.25, 0.75])
        left_mask = long_coords <= q_low
        right_mask = long_coords >= q_high
        center_mask = (long_coords > q_low) & (long_coords < q_high)
        if left_mask.sum() < 8 or right_mask.sum() < 8 or center_mask.sum() < 8:
            left_top = right_top = center_top = float(np.percentile(z_coords, 75))
            left_width = right_width = lat_span
        else:
            left_top = float(np.percentile(z_coords[left_mask], 75))
            right_top = float(np.percentile(z_coords[right_mask], 75))
            center_top = float(np.percentile(z_coords[center_mask], 75))
            left_width = float(np.max(lat_coords[left_mask]) - np.min(lat_coords[left_mask]))
            right_width = float(np.max(lat_coords[right_mask]) - np.min(lat_coords[right_mask]))
        end_lift = float(0.5 * ((left_top - center_top) + (right_top - center_top)))
        end_lift_min = float(min(left_top - center_top, right_top - center_top))
        end_symmetry = float(abs(left_top - right_top))
        end_width_asym = float(abs(left_width - right_width) / max(max(left_width, right_width), 1e-8))
        left_lift = float(left_top - center_top)
        right_lift = float(right_top - center_top)

        comps[cid] = {
            "component_id": cid,
            "segment_ids": list(seg_ids),
            "points": pts,
            "centroid": centroid,
            "bbox_min": bmin,
            "bbox_max": bmax,
            "bbox_diag": diag,
            "axis": axis,
            "axis_xy": axis_xy,
            "lateral_xy": lateral_xy,
            "extents": extents,
            "sorted_extents": sorted_ext,
            "elongation": elongation,
            "long_span": long_span,
            "lat_span": lat_span,
            "z_span": z_span,
            "major_span": major_span,
            "minor_span": minor_span,
            "horizontal_elongation": horizontal_elongation,
            "height_ratio": height_ratio,
            "end_lift": end_lift,
            "end_lift_min": end_lift_min,
            "end_symmetry": end_symmetry,
            "end_width_asym": end_width_asym,
            "left_lift": left_lift,
            "right_lift": right_lift,
        }
    return comps


def compute_global_component_context(comps: Dict[int, Dict]) -> Dict[str, np.ndarray]:
    if not comps:
        return {
            "global_min": np.zeros(3, dtype=np.float32),
            "global_max": np.ones(3, dtype=np.float32),
            "global_center": np.zeros(3, dtype=np.float32),
            "global_diag": np.array([1.0], dtype=np.float32),
            "global_height": np.array([1.0], dtype=np.float32),
        }
    all_points = np.vstack([c["points"] for c in comps.values()]).astype(np.float32)
    global_min = all_points.min(axis=0)
    global_max = all_points.max(axis=0)
    global_center = 0.5 * (global_min + global_max)
    global_diag = max(float(np.linalg.norm(global_max - global_min)), 1e-8)
    global_height = max(float(global_max[2] - global_min[2]), 1e-8)
    return {
        "global_min": global_min.astype(np.float32),
        "global_max": global_max.astype(np.float32),
        "global_center": global_center.astype(np.float32),
        "global_diag": np.array([global_diag], dtype=np.float32),
        "global_height": np.array([global_height], dtype=np.float32),
    }


def component_diag_rel(comp: Dict, global_ctx: Dict) -> float:
    return float(comp["bbox_diag"] / max(float(global_ctx["global_diag"][0]), 1e-8))


def component_z_norm(comp: Dict, global_ctx: Dict) -> float:
    global_min = global_ctx["global_min"]
    global_height = max(float(global_ctx["global_height"][0]), 1e-8)
    return float((comp["centroid"][2] - global_min[2]) / global_height)


def component_compactness(comp: Dict) -> float:
    sorted_ext = comp["sorted_extents"]
    return float(sorted_ext[1] / max(sorted_ext[0], 1e-8))


def is_small_dou_like(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    elong = float(comp["elongation"])
    z_norm = component_z_norm(comp, global_ctx)
    compactness = component_compactness(comp)

    if diag_rel > 0.18:
        return False
    if elong > 2.4:
        return False
    if z_norm < 0.10:
        return False
    if compactness < 0.18:
        return False
    return True


def is_bottom_independent_dou_candidate(comp: Dict, global_ctx: Dict) -> bool:
    z_norm = component_z_norm(comp, global_ctx)
    diag_rel = component_diag_rel(comp, global_ctx)
    elong = float(comp["elongation"])
    compactness = component_compactness(comp)
    if z_norm <= 0.16 and diag_rel <= 0.20 and elong <= 2.1 and compactness >= 0.25:
        return True
    return False


def is_fang_or_chuan_like_component(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(max(comp["elongation"], comp.get("horizontal_elongation", 1.0)))
    axis_z = float(abs(comp["axis"][2]))
    # 更接近规则长方体梁件，不作为gong吸附宿主
    return bool(diag_rel >= 0.16 and horiz_elong >= 5.2 and axis_z <= 0.55 and comp.get("z_span", 0.0) <= 0.20 * max(comp["bbox_diag"], 1e-8))


def is_gong_chain_candidate(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    elong = float(max(comp["elongation"], comp.get("horizontal_elongation", 1.0)))
    axis_z = float(abs(comp["axis"][2]))

    if diag_rel < 0.06:
        return False
    if elong < 1.6:
        return False
    if axis_z > 0.85:
        return False
    if is_bottom_independent_dou_candidate(comp, global_ctx):
        return False
    if is_fang_or_chuan_like_component(comp, global_ctx):
        return False
    return True


def is_gong_body_candidate(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    axis_z = float(abs(comp["axis"][2]))

    if diag_rel < 0.08:
        return False
    if horiz_elong < 1.8:
        return False
    if axis_z > 0.80:
        return False
    if is_bottom_independent_dou_candidate(comp, global_ctx):
        return False
    if is_fang_or_chuan_like_component(comp, global_ctx):
        return False
    return True


def describe_small_relative_to_host(host_comp: Dict, small_comp: Dict, global_ctx: Dict) -> Dict[str, float]:
    global_diag = float(global_ctx["global_diag"][0])
    global_height = max(float(global_ctx["global_height"][0]), 1e-8)
    global_min = global_ctx["global_min"]

    axis_xy = host_comp["axis_xy"]
    lateral_xy = host_comp["lateral_xy"]

    rel = small_comp["centroid"] - host_comp["centroid"]
    rel_xy = np.array([rel[0], rel[1], 0.0], dtype=np.float32)

    long_coord = float(np.dot(rel_xy, axis_xy))
    lateral_coord = float(np.dot(rel_xy, lateral_xy))

    host_long_half = 0.5 * float(host_comp["long_span"])
    host_lat_half = 0.5 * float(host_comp["lat_span"])
    small_long_half = 0.5 * float(small_comp["long_span"])
    small_lat_half = 0.5 * float(small_comp["lat_span"])

    long_overhang = max(0.0, abs(long_coord) - (host_long_half + 0.55 * small_long_half))
    lateral_overhang = max(0.0, abs(lateral_coord) - (host_lat_half + 0.90 * small_lat_half))

    gap = float(
        bbox_gap(host_comp["bbox_min"], host_comp["bbox_max"], small_comp["bbox_min"], small_comp["bbox_max"])
        / max(global_diag, 1e-8)
    )
    top_gap = float((small_comp["bbox_min"][2] - host_comp["bbox_max"][2]) / global_height)
    bottom_gap = float((host_comp["bbox_min"][2] - small_comp["bbox_max"][2]) / global_height)
    z_delta = float((small_comp["centroid"][2] - host_comp["centroid"][2]) / global_height)
    z_norm = float((small_comp["centroid"][2] - global_min[2]) / global_height)

    body_center = host_comp["centroid"]
    body_pts = host_comp["points"]
    body_axis = host_comp["axis_xy"]
    body_proj = (body_pts - body_center) @ body_axis
    min_proj = float(body_proj.min())
    max_proj = float(body_proj.max())
    c_proj = float(np.dot(small_comp["centroid"] - body_center, body_axis))
    body_half_len = max(abs(min_proj), abs(max_proj), 1e-8)
    endness = abs(c_proj) / body_half_len

    return {
        "long_coord": long_coord,
        "lateral_coord": lateral_coord,
        "main_offset": float(abs(long_coord) / max(global_diag, 1e-8)),
        "lateral_offset": float(abs(lateral_coord) / max(global_diag, 1e-8)),
        "long_overhang": float(long_overhang / max(global_diag, 1e-8)),
        "lateral_overhang": float(lateral_overhang / max(global_diag, 1e-8)),
        "bbox_gap": gap,
        "top_gap": top_gap,
        "bottom_gap": bottom_gap,
        "z_delta": z_delta,
        "z_norm": z_norm,
        "endness": float(endness),
    }


def is_connection_dou_candidate(small_comp: Dict, comps: Dict[int, Dict], global_ctx: Dict) -> bool:
    if not is_small_dou_like(small_comp, global_ctx):
        return False

    hosts = []
    for cid, comp in comps.items():
        if cid == small_comp["component_id"]:
            continue
        if not is_gong_body_candidate(comp, global_ctx):
            continue
        rel = describe_small_relative_to_host(comp, small_comp, global_ctx)
        if rel["bbox_gap"] <= 0.08 and rel["lateral_overhang"] <= 0.08:
            hosts.append((comp, rel))

    if len(hosts) < 2:
        return False

    global_diag = float(global_ctx["global_diag"][0])
    for i, (host_a, rel_a) in enumerate(hosts):
        for host_b, rel_b in hosts[i + 1:]:
            axis_dot = float(abs(np.dot(host_a["axis_xy"], host_b["axis_xy"])))
            if axis_dot < 0.75:
                continue
            host_sep = float(np.linalg.norm(host_b["centroid"] - host_a["centroid"]) / max(global_diag, 1e-8))
            if host_sep <= 0.10:
                continue
            if rel_a["long_coord"] * rel_b["long_coord"] < 0.0:
                return True
    return False


def score_top_dou_attachment(host_comp: Dict, small_comp: Dict, comps: Dict[int, Dict], global_ctx: Dict) -> Tuple[bool, float, Dict[str, float]]:
    if not is_small_dou_like(small_comp, global_ctx):
        return False, -1e9, {}
    if is_bottom_independent_dou_candidate(small_comp, global_ctx):
        return False, -1e9, {}
    if is_connection_dou_candidate(small_comp, comps, global_ctx):
        return False, -1e9, {}
    if not is_gong_body_candidate(host_comp, global_ctx):
        return False, -1e9, {}

    info = describe_small_relative_to_host(host_comp, small_comp, global_ctx)

    if info["bbox_gap"] > 0.10:
        return False, -1e9, info
    if info["lateral_overhang"] > 0.10:
        return False, -1e9, info
    if info["long_overhang"] > 0.18:
        return False, -1e9, info
    if info["top_gap"] > 0.22:
        return False, -1e9, info
    if info["bottom_gap"] > 0.08:
        return False, -1e9, info
    if info["z_delta"] < -0.08:
        return False, -1e9, info

    top_fit = 1.0 - min(abs(info["top_gap"]), 0.22) / 0.22
    score = (
        1.15 * max(0.0, 0.10 - info["bbox_gap"]) / 0.10
        + 1.10 * max(0.0, 0.10 - info["lateral_overhang"]) / 0.10
        + 0.80 * max(0.0, 0.18 - info["long_overhang"]) / 0.18
        + 0.75 * top_fit
        + 0.65 * min(info["endness"], 1.3) / 1.3
        + 0.25 * max(0.0, info["z_delta"] + 0.08) / 0.22
    )
    return True, float(score), info


def chain_merge_score(comp_a: Dict, comp_b: Dict, global_ctx: Dict) -> Tuple[float, Dict[str, float]]:
    global_diag = float(global_ctx["global_diag"][0])
    global_height = max(float(global_ctx["global_height"][0]), 1e-8)

    axis_a = comp_a["axis_xy"]
    axis_b = comp_b["axis_xy"]
    axis_sign = 1.0 if float(np.dot(axis_a, axis_b)) >= 0.0 else -1.0

    merged_axis_xy = axis_a + axis_sign * axis_b
    merged_axis_xy_norm = float(np.linalg.norm(merged_axis_xy))
    if merged_axis_xy_norm < 1e-8:
        merged_axis_xy = axis_a
    else:
        merged_axis_xy = merged_axis_xy / merged_axis_xy_norm
    merged_lat_xy = np.array([-merged_axis_xy[1], merged_axis_xy[0], 0.0], dtype=np.float32)

    axis_dot = float(abs(np.dot(axis_a, axis_b)))
    rel = comp_b["centroid"] - comp_a["centroid"]
    rel_xy = np.array([rel[0], rel[1], 0.0], dtype=np.float32)

    main_gap = float(abs(np.dot(rel_xy, merged_axis_xy)) / max(global_diag, 1e-8))
    side_gap = float(abs(np.dot(rel_xy, merged_lat_xy)) / max(global_diag, 1e-8))
    vertical_gap = float(abs(rel[2]) / global_height)

    gap = float(
        bbox_gap(comp_a["bbox_min"], comp_a["bbox_max"], comp_b["bbox_min"], comp_b["bbox_max"]) / max(global_diag, 1e-8)
    )

    proj_a = comp_a["points"] @ merged_axis_xy
    proj_b = comp_b["points"] @ merged_axis_xy
    chain_gap = max(
        0.0,
        max(float(proj_b.min() - proj_a.max()), float(proj_a.min() - proj_b.max()))
    ) / max(global_diag, 1e-8)

    merged_pts = np.vstack([comp_a["points"], comp_b["points"]]).astype(np.float32)
    merged_long = merged_pts @ merged_axis_xy
    merged_lat = merged_pts @ merged_lat_xy
    merged_long_span = float(max(merged_long.max() - merged_long.min(), 1e-8))
    merged_lat_span = float(max(merged_lat.max() - merged_lat.min(), 1e-8))
    merged_elong = float(merged_long_span / max(merged_lat_span, 1e-8))

    score = (
        1.8 * axis_dot
        + 1.15 * min(merged_elong / 4.0, 1.0)
        - 1.8 * side_gap
        - 1.1 * vertical_gap
        - 1.0 * gap
        - 0.45 * main_gap
        - 0.7 * chain_gap
    )

    info = {
        "axis_dot": axis_dot,
        "main_gap": main_gap,
        "side_gap": side_gap,
        "vertical_gap": vertical_gap,
        "chain_gap": chain_gap,
        "bbox_gap": gap,
        "merged_elong": merged_elong,
    }
    return float(score), info


def grow_gong_chains_v4(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    if not comp_map:
        return comp_map

    max_comp_seg = int(model.get("max_component_segments", 6))
    max_comp_seg = max(4, min(max_comp_seg, 9))

    changed = True
    while changed:
        changed = False
        comps = build_components_from_map(comp_map, segments)
        global_ctx = compute_global_component_context(comps)
        comp_ids = sorted(comps.keys())
        best = None

        for i, cid_a in enumerate(comp_ids):
            comp_a = comps[cid_a]
            if not is_gong_chain_candidate(comp_a, global_ctx):
                continue

            for cid_b in comp_ids[i + 1:]:
                comp_b = comps[cid_b]
                if not is_gong_chain_candidate(comp_b, global_ctx):
                    continue

                merged_size = len(comp_a["segment_ids"]) + len(comp_b["segment_ids"])
                if merged_size > max_comp_seg:
                    continue

                score, info = chain_merge_score(comp_a, comp_b, global_ctx)

                if info["axis_dot"] < 0.72:
                    continue
                if info["side_gap"] > 0.16:
                    continue
                if info["vertical_gap"] > 0.20:
                    continue
                if info["bbox_gap"] > 0.12:
                    continue
                if info["chain_gap"] > 0.24:
                    continue
                if info["merged_elong"] < 1.9:
                    continue

                if best is None or score > best[0]:
                    best = (score, cid_a, cid_b)

        if best is None:
            break

        _, cid_a, cid_b = best
        for seg_id, cid in list(comp_map.items()):
            if cid == cid_b:
                comp_map[seg_id] = cid_a
        comp_map = relabel_components(comp_map)
        changed = True

    return relabel_components(comp_map)


def merge_top_dou_into_hosts_v4(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    if not comp_map:
        return comp_map

    max_comp_seg = int(model.get("max_component_segments", 6))
    max_comp_seg = max(4, min(max_comp_seg, 9))

    changed = True
    while changed:
        changed = False
        comps = build_components_from_map(comp_map, segments)
        global_ctx = compute_global_component_context(comps)

        small_ids = [
            cid for cid, comp in comps.items()
            if len(comp["segment_ids"]) <= 2 and is_small_dou_like(comp, global_ctx)
        ]
        if not small_ids:
            break

        host_to_candidates: Dict[int, List[Tuple[float, int, Dict[str, float]]]] = {}

        for cid_s in small_ids:
            small_comp = comps[cid_s]
            for cid_h, host_comp in comps.items():
                if cid_h == cid_s:
                    continue
                if len(host_comp["segment_ids"]) + len(small_comp["segment_ids"]) > max_comp_seg:
                    continue
                ok, score, info = score_top_dou_attachment(host_comp, small_comp, comps, global_ctx)
                if not ok:
                    continue
                host_to_candidates.setdefault(cid_h, []).append((score, cid_s, info))

        best_host_merge = None
        for cid_h, items in host_to_candidates.items():
            host_comp = comps[cid_h]
            if not is_gong_body_candidate(host_comp, global_ctx):
                continue

            items.sort(key=lambda x: x[0], reverse=True)
            cap = max_comp_seg - len(host_comp["segment_ids"])
            if cap <= 0:
                continue

            chosen: List[Tuple[float, int, Dict[str, float]]] = []
            chosen_long = []

            for score, cid_s, info in items:
                need = len(comps[cid_s]["segment_ids"])
                if need > cap:
                    continue

                this_long = info["long_coord"]
                if chosen_long:
                    if min(abs(this_long - prev) for prev in chosen_long) < 0.04 * float(global_ctx["global_diag"][0]):
                        continue

                chosen.append((score, cid_s, info))
                chosen_long.append(this_long)
                cap -= need

            if not chosen:
                continue

            total_score = float(sum(v[0] for v in chosen))

            # symmetry bonus for left/right attachments
            if len(chosen) >= 2:
                lefts = [item for item in chosen if item[2]["long_coord"] < 0]
                rights = [item for item in chosen if item[2]["long_coord"] > 0]
                if lefts and rights:
                    best_sym = 0.0
                    for l in lefts:
                        for r in rights:
                            proj_gap = abs(abs(l[2]["long_coord"]) - abs(r[2]["long_coord"])) / max(float(global_ctx["global_diag"][0]), 1e-8)
                            z_gap = abs(l[2]["z_delta"] - r[2]["z_delta"])
                            sym = (
                                max(0.0, 0.14 - proj_gap) / 0.14
                                + max(0.0, 0.18 - z_gap) / 0.18
                            )
                            if sym > best_sym:
                                best_sym = sym
                    total_score += 0.85 * best_sym

            total_score += 0.35 * max(0, len(chosen) - 1)

            if best_host_merge is None or total_score > best_host_merge[0]:
                best_host_merge = (total_score, cid_h, chosen)

        if best_host_merge is None:
            break

        _, cid_h, chosen = best_host_merge
        for _, cid_s, _ in chosen:
            for seg_id, cid in list(comp_map.items()):
                if cid == cid_s:
                    comp_map[seg_id] = cid_h
        comp_map = relabel_components(comp_map)
        changed = True

    return relabel_components(comp_map)


def assemble_gong_prototypes_v4(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    """
    v4 prototype assembly:
    - first recover chain-like gong body
    - then attach upper small dou around the body
    - encourage symmetric left/right attachments
    """
    comp_map = grow_gong_chains_v4(comp_map, segments, model)
    comp_map = merge_top_dou_into_hosts_v4(comp_map, segments, model)
    comp_map = grow_gong_chains_v4(comp_map, segments, model)
    comp_map = merge_top_dou_into_hosts_v4(comp_map, segments, model)
    return relabel_components(comp_map)


def refine_gong_structure_v4(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    # keep old idea, but make it prototype-aware
    comp_map = assemble_gong_prototypes_v4(comp_map, segments, model)
    return relabel_components(comp_map)


# Strategy override: use height ratio + prototype-first assembly rather than
# PCA verticality + generic merge-first assembly.
def is_fang_or_chuan_like_component(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(max(comp["elongation"], comp.get("horizontal_elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    return bool(diag_rel >= 0.16 and horiz_elong >= 5.2 and height_ratio <= 0.32)


def is_gong_chain_candidate(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    elong = float(max(comp["elongation"], comp.get("horizontal_elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))

    if diag_rel < 0.06:
        return False
    if elong < 1.6:
        return False
    if height_ratio > 0.95:
        return False
    if is_bottom_independent_dou_candidate(comp, global_ctx):
        return False
    if is_fang_or_chuan_like_component(comp, global_ctx):
        return False
    return True


def is_gong_body_candidate(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))

    if diag_rel < 0.08:
        return False
    if horiz_elong < 1.8:
        return False
    if height_ratio > 0.72:
        return False
    if is_bottom_independent_dou_candidate(comp, global_ctx):
        return False
    if is_fang_or_chuan_like_component(comp, global_ctx):
        return False
    return True


def is_top_dou_host_candidate(comp: Dict, global_ctx: Dict) -> bool:
    if not is_gong_body_candidate(comp, global_ctx):
        return False

    global_height = max(float(global_ctx["global_height"][0]), 1e-8)
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    lift = normalized_end_lift(comp, global_ctx)
    lift_asym = float(abs(comp.get("left_lift", 0.0) - comp.get("right_lift", 0.0)) / global_height)
    end_width_asym = float(comp.get("end_width_asym", 0.0))

    beam_like = bool(horiz_elong >= 5.0 and height_ratio <= 0.32 and lift <= 0.02 and end_width_asym <= 0.18)
    ang_like = bool(end_width_asym >= 0.35 and lift_asym >= 0.08)
    if beam_like or ang_like:
        return False
    if lift < -0.01:
        return False
    return True


def is_strong_gong_prototype(comp: Dict, global_ctx: Dict) -> bool:
    if not is_gong_body_candidate(comp, global_ctx):
        return False
    seg_count = len(comp["segment_ids"])
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    diag_rel = component_diag_rel(comp, global_ctx)
    height_ratio = float(comp.get("height_ratio", 1.0))
    if seg_count >= 5 and horiz_elong >= 2.0 and height_ratio <= 0.72:
        return True
    if seg_count >= 4 and horiz_elong >= 2.5 and diag_rel >= 0.20 and height_ratio <= 0.65:
        return True
    if seg_count >= 3 and horiz_elong >= 4.0 and diag_rel >= 0.25 and height_ratio <= 0.55:
        return True
    return False


def prototype_first_component_map(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    target_components_hint: int = 0,
    force_target: bool = False,
) -> Dict[int, int]:
    if not segments:
        return {}

    base_map = choose_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=target_components_hint,
        force_target=force_target,
    )
    raw_map = refine_gong_structure_v4(singleton_component_map(segments), segments, model)
    raw_comps = build_components_from_map(raw_map, segments)
    raw_ctx = compute_global_component_context(raw_comps)

    strong_proto_ids = [
        cid for cid, comp in raw_comps.items()
        if is_strong_gong_prototype(comp, raw_ctx)
    ]
    if not strong_proto_ids:
        return relabel_components(base_map)

    locked_seg_ids: Set[int] = set()
    for cid in strong_proto_ids:
        locked_seg_ids.update(raw_comps[cid]["segment_ids"])

    residual_segments = [s for s in segments if s.seg_id not in locked_seg_ids]
    residual_map: Dict[int, int] = {}
    if residual_segments:
        residual_edges, residual_scores = filter_edges_and_scores(
            edges=edges,
            scores=scores,
            allowed_ids={s.seg_id for s in residual_segments},
        )
        residual_map = choose_component_map(
            segments=residual_segments,
            edges=residual_edges,
            scores=residual_scores,
            model=model,
            target_components_hint=0,
            force_target=False,
        )

    combined: Dict[int, int] = {}
    next_cid = 0
    for cid in strong_proto_ids:
        for seg_id in raw_comps[cid]["segment_ids"]:
            combined[seg_id] = next_cid
        next_cid += 1

    residual_groups: Dict[int, List[int]] = {}
    for seg_id, cid in residual_map.items():
        residual_groups.setdefault(cid, []).append(seg_id)
    for _, seg_ids in sorted(residual_groups.items(), key=lambda kv: (len(kv[1]), kv[0])):
        for seg_id in seg_ids:
            combined[seg_id] = next_cid
        next_cid += 1

    for seg in segments:
        if seg.seg_id not in combined:
            combined[seg.seg_id] = next_cid
            next_cid += 1

    combined = relabel_components(combined)
    combined = refine_gong_structure_v4(combined, segments, model)
    return relabel_components(combined)


def component_axis_alignment(comp: Dict, axis_xy: np.ndarray) -> float:
    axis = np.asarray(axis_xy, dtype=np.float32)
    norm = float(np.linalg.norm(axis))
    if norm < 1e-8:
        return 0.0
    axis = axis / norm
    return float(abs(np.dot(comp["axis_xy"], axis)))


def normalized_end_lift(comp: Dict, global_ctx: Dict) -> float:
    return float(comp.get("end_lift_min", 0.0) / max(float(global_ctx["global_height"][0]), 1e-8))


def infer_gong_primary_axis(comps: Dict[int, Dict], global_ctx: Dict) -> np.ndarray:
    candidates = []
    for comp in comps.values():
        if is_strong_gong_prototype(comp, global_ctx) or is_gong_body_candidate(comp, global_ctx):
            candidates.append(comp)
    if not candidates:
        candidates = sorted(
            comps.values(),
            key=lambda c: (c.get("horizontal_elongation", 0.0), c["bbox_diag"]),
            reverse=True,
        )[:4]
    if not candidates:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)

    accum = None
    for comp in candidates:
        axis = comp["axis_xy"].astype(np.float32)
        if accum is None:
            accum = axis * float(comp["bbox_diag"])
            continue
        if float(np.dot(axis, accum)) < 0.0:
            axis = -axis
        accum = accum + axis * float(comp["bbox_diag"])
    norm = float(np.linalg.norm(accum))
    if norm < 1e-8:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    return (accum / norm).astype(np.float32)


def build_partial_map_from_component_ids(
    comp_map: Dict[int, int],
    selected_component_ids: Set[int],
) -> Dict[int, int]:
    out: Dict[int, int] = {}
    next_cid = 0
    cid_to_new: Dict[int, int] = {}
    for seg_id, cid in comp_map.items():
        if cid not in selected_component_ids:
            continue
        if cid not in cid_to_new:
            cid_to_new[cid] = next_cid
            next_cid += 1
        out[seg_id] = cid_to_new[cid]
    return out


def merge_partial_component_maps(
    segments: List[Segment],
    partial_maps: List[Dict[int, int]],
) -> Dict[int, int]:
    merged: Dict[int, int] = {}
    next_cid = 0
    for partial in partial_maps:
        groups: Dict[int, List[int]] = {}
        for seg_id, cid in partial.items():
            if seg_id in merged:
                continue
            groups.setdefault(cid, []).append(seg_id)
        for _, seg_ids in sorted(groups.items(), key=lambda kv: (len(kv[1]), kv[0]), reverse=True):
            for seg_id in seg_ids:
                merged[seg_id] = next_cid
            next_cid += 1
    for seg in segments:
        if seg.seg_id not in merged:
            merged[seg.seg_id] = next_cid
            next_cid += 1
    return relabel_components(merged)


def is_high_confidence_gong_component(comp: Dict, global_ctx: Dict) -> bool:
    if not is_strong_gong_prototype(comp, global_ctx):
        return False
    lift = normalized_end_lift(comp, global_ctx)
    end_sym = float(comp.get("end_symmetry", 1e9)) / max(float(global_ctx["global_height"][0]), 1e-8)
    seg_count = len(comp["segment_ids"])
    horiz_elong = float(comp.get("horizontal_elongation", 1.0))
    if seg_count >= 5 and horiz_elong >= 2.0:
        return True
    return bool(lift >= -0.01 and end_sym <= 0.10 and seg_count >= 3)


def is_rectilinear_beam_candidate(comp: Dict, primary_axis: np.ndarray, global_ctx: Dict) -> bool:
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    lift = normalized_end_lift(comp, global_ctx)
    end_width_asym = float(comp.get("end_width_asym", 1.0))
    align = component_axis_alignment(comp, primary_axis)
    if horiz_elong < 2.2:
        return False
    if height_ratio > 0.55:
        return False
    if lift > 0.025:
        return False
    if end_width_asym > 0.22:
        return False
    return bool(align >= 0.78 or align <= 0.22)


def is_ang_prototype_candidate(comp: Dict, primary_axis: np.ndarray, global_ctx: Dict) -> bool:
    horiz_elong = float(comp.get("horizontal_elongation", comp.get("elongation", 1.0)))
    height_ratio = float(comp.get("height_ratio", 1.0))
    align = component_axis_alignment(comp, primary_axis)
    left_lift = float(comp.get("left_lift", 0.0))
    right_lift = float(comp.get("right_lift", 0.0))
    lift_asym = float(abs(left_lift - right_lift) / max(float(global_ctx["global_height"][0]), 1e-8))
    end_width_asym = float(comp.get("end_width_asym", 0.0))
    if horiz_elong < 2.1:
        return False
    if height_ratio > 0.70:
        return False
    if align >= 0.40:
        return False
    return bool(lift_asym >= 0.10 or end_width_asym >= 0.35)


def is_dou_prototype_candidate(comp: Dict, global_ctx: Dict) -> bool:
    diag_rel = component_diag_rel(comp, global_ctx)
    compactness = component_compactness(comp)
    if is_bottom_independent_dou_candidate(comp, global_ctx):
        return True
    if is_small_dou_like(comp, global_ctx) and compactness >= 0.22:
        return True
    return bool(len(comp["segment_ids"]) <= 2 and diag_rel <= 0.16 and compactness >= 0.30)


def stage_recover_gong_prototypes(
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    raw_map = refine_gong_structure_v4(singleton_component_map(segments), segments, model)
    comps = build_components_from_map(raw_map, segments)
    ctx = compute_global_component_context(comps)
    selected = {
        cid for cid, comp in comps.items()
        if is_high_confidence_gong_component(comp, ctx)
    }
    return build_partial_map_from_component_ids(raw_map, selected)


def stage_recover_rectilinear_prototypes(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    primary_axis: np.ndarray,
) -> Dict[int, int]:
    if not segments:
        return {}
    comp_map = choose_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=0,
        force_target=False,
    )
    comps = build_components_from_map(comp_map, segments)
    ctx = compute_global_component_context(comps)
    selected = {
        cid for cid, comp in comps.items()
        if is_rectilinear_beam_candidate(comp, primary_axis, ctx)
    }
    return build_partial_map_from_component_ids(comp_map, selected)


def stage_recover_ang_prototypes(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    primary_axis: np.ndarray,
) -> Dict[int, int]:
    if not segments:
        return {}
    comp_map = choose_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=0,
        force_target=False,
    )
    comps = build_components_from_map(comp_map, segments)
    ctx = compute_global_component_context(comps)
    selected = {
        cid for cid, comp in comps.items()
        if is_ang_prototype_candidate(comp, primary_axis, ctx)
    }
    return build_partial_map_from_component_ids(comp_map, selected)


def stage_recover_dou_prototypes(
    segments: List[Segment],
    model: Dict,
    primary_axis: np.ndarray,
) -> Dict[int, int]:
    if not segments:
        return {}
    comp_map = singleton_component_map(segments)
    comps = build_components_from_map(comp_map, segments)
    ctx = compute_global_component_context(comps)
    selected = {
        cid for cid, comp in comps.items()
        if is_dou_prototype_candidate(comp, ctx)
    }
    return build_partial_map_from_component_ids(comp_map, selected)


def stage_merge_residual_segments(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
) -> Dict[int, int]:
    if not segments:
        return {}
    return choose_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=0,
        force_target=False,
    )


def stage_apply_global_consistency(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    comp_map = relabel_components(comp_map)
    comp_map = refine_gong_structure_v4(comp_map, segments, model)
    return relabel_components(comp_map)


def reconstruct_component_map_by_prototypes(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    target_components_hint: int = 0,
    force_target: bool = False,
) -> Dict[int, int]:
    if not segments:
        return {}

    # Stage 1: fragment segments are already the base geometric units.
    gong_partial = stage_recover_gong_prototypes(segments, model)
    gong_locked = set(gong_partial.keys())

    temp_map = gong_partial if gong_partial else singleton_component_map(segments)
    temp_comps = build_components_from_map(temp_map, segments)
    temp_ctx = compute_global_component_context(temp_comps)
    primary_axis = infer_gong_primary_axis(temp_comps, temp_ctx)

    residual_segments = [s for s in segments if s.seg_id not in gong_locked]
    residual_ids = {s.seg_id for s in residual_segments}
    residual_edges, residual_scores = filter_edges_and_scores(edges, scores, residual_ids)

    beam_partial = stage_recover_rectilinear_prototypes(
        residual_segments, residual_edges, residual_scores, model, primary_axis
    )
    beam_locked = set(beam_partial.keys())

    residual_segments = [s for s in residual_segments if s.seg_id not in beam_locked]
    residual_ids = {s.seg_id for s in residual_segments}
    residual_edges, residual_scores = filter_edges_and_scores(edges, scores, residual_ids)

    ang_partial = stage_recover_ang_prototypes(
        residual_segments, residual_edges, residual_scores, model, primary_axis
    )
    ang_locked = set(ang_partial.keys())

    residual_segments = [s for s in residual_segments if s.seg_id not in ang_locked]
    residual_ids = {s.seg_id for s in residual_segments}
    residual_edges, residual_scores = filter_edges_and_scores(edges, scores, residual_ids)

    dou_partial = stage_recover_dou_prototypes(
        residual_segments, model, primary_axis
    )
    dou_locked = set(dou_partial.keys())

    residual_segments = [s for s in residual_segments if s.seg_id not in dou_locked]
    residual_ids = {s.seg_id for s in residual_segments}
    residual_edges, residual_scores = filter_edges_and_scores(edges, scores, residual_ids)

    residual_map = stage_merge_residual_segments(
        residual_segments, residual_edges, residual_scores, model
    )

    merged = merge_partial_component_maps(
        segments,
        [gong_partial, beam_partial, ang_partial, dou_partial, residual_map],
    )
    merged = stage_apply_global_consistency(merged, segments, model)

    if target_components_hint > 0 and force_target:
        merged = enforce_target_component_count(
            comp_map=merged,
            segments=segments,
            edges=edges,
            scores=scores,
            target_components=target_components_hint,
            max_component_segments=int(max(model.get("max_component_segments", 6), 1)),
            max_component_bbox_diag=float(model.get("max_component_bbox_diag", 0.0)),
        )
    return relabel_components(merged)


def score_component_map_quality(comp_map: Dict[int, int], segments: List[Segment]) -> float:
    comp_map = relabel_components(comp_map)
    comps = build_components_from_map(comp_map, segments)
    ctx = compute_global_component_context(comps)
    primary_axis = infer_gong_primary_axis(comps, ctx)

    strong_gong = 0
    rect_beams = 0
    ang_like = 0
    dou_singletons = 0
    small_singletons = 0
    for comp in comps.values():
        if is_high_confidence_gong_component(comp, ctx):
            strong_gong += 1
        if is_rectilinear_beam_candidate(comp, primary_axis, ctx):
            rect_beams += 1
        if is_ang_prototype_candidate(comp, primary_axis, ctx):
            ang_like += 1
        if len(comp["segment_ids"]) == 1 and is_dou_prototype_candidate(comp, ctx):
            dou_singletons += 1
        if len(comp["segment_ids"]) == 1 and component_diag_rel(comp, ctx) <= 0.14:
            small_singletons += 1

    return (
        3.0 * strong_gong
        + 1.2 * rect_beams
        + 0.8 * ang_like
        - 0.9 * dou_singletons
        - 0.35 * small_singletons
        - 0.12 * len(comps)
    )


def select_best_component_map(
    segments: List[Segment],
    edges: List[Tuple[int, int]],
    scores: np.ndarray,
    model: Dict,
    target_components_hint: int = 0,
    force_target: bool = False,
) -> Dict[int, int]:
    candidates: List[Dict[int, int]] = []

    stage_map = reconstruct_component_map_by_prototypes(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=target_components_hint,
        force_target=force_target,
    )
    candidates.append(stage_map)

    legacy_map = prototype_first_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=target_components_hint,
        force_target=force_target,
    )
    candidates.append(legacy_map)

    base_map = choose_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=target_components_hint,
        force_target=force_target,
    )
    base_map = refine_gong_structure_v4(base_map, segments, model)
    candidates.append(relabel_components(base_map))

    best = None
    for cand in candidates:
        score = score_component_map_quality(cand, segments)
        if best is None or score > best[0]:
            best = (score, cand)
    return relabel_components(best[1] if best is not None else candidates[0])

def refine_gong_structure_v3(
    comp_map: Dict[int, int],
    segments: List[Segment],
    model: Dict,
) -> Dict[int, int]:
    comp_map = merge_top_dou_into_hosts_v3(comp_map, segments, model)
    comp_map = grow_gong_chains_v3(comp_map, segments, model)
    comp_map = merge_top_dou_into_hosts_v3(comp_map, segments, model)
    comp_map = attach_small_dou_to_gong_v3(comp_map, segments, model)
    return relabel_components(comp_map)


# ---------------------------
# semantic + structure
# ---------------------------

def component_features(points: np.ndarray) -> np.ndarray:
    centroid = points.mean(axis=0)
    bmin, bmax, diag = bbox_stats(points)
    extents = bmax - bmin
    axis = pca_axis(points)
    feat = np.concatenate([
        centroid,
        extents,
        np.array([diag], dtype=np.float32),
        axis,
    ])
    return feat.astype(np.float32)


def _rank_map(values: Dict[int, float]) -> Dict[int, float]:
    if not values:
        return {}
    order = sorted(values.items(), key=lambda kv: kv[1])
    denom = max(len(order) - 1, 1)
    return {cid: float(i / denom) for i, (cid, _) in enumerate(order)}


def _safe_overlap_2d(a_min: np.ndarray, a_max: np.ndarray,
                     b_min: np.ndarray, b_max: np.ndarray) -> float:
    ox = overlap_ratio(float(a_min[0]), float(a_max[0]), float(b_min[0]), float(b_max[0]))
    oy = overlap_ratio(float(a_min[1]), float(a_max[1]), float(b_min[1]), float(b_max[1]))
    return float(min(ox, oy))


def _stable_basis_from_axis(axis: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    axis = np.array(axis, dtype=np.float32)
    axis = axis / (np.linalg.norm(axis) + 1e-8)
    ref = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    if abs(float(np.dot(axis, ref))) >= 0.92:
        ref = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    side_a = np.cross(axis, ref)
    side_a = side_a / (np.linalg.norm(side_a) + 1e-8)
    side_b = np.cross(axis, side_a)
    side_b = side_b / (np.linalg.norm(side_b) + 1e-8)
    return axis.astype(np.float32), side_a.astype(np.float32), side_b.astype(np.float32)


def _flatness_score(z_values: np.ndarray, z_span: float) -> float:
    if z_values.size < 8:
        return 0.5
    spread = float(np.std(z_values))
    norm = spread / max(0.035 * max(z_span, 1e-8), 1e-8)
    return float(np.clip(1.0 - norm, 0.0, 1.0))


def _component_shape_cues(points: np.ndarray, centroid: np.ndarray, axis_raw: np.ndarray) -> Dict[str, float]:
    pts = sample_points(points.astype(np.float32), 1024)
    axis, side_a, side_b = _stable_basis_from_axis(axis_raw)
    rel = pts - centroid.astype(np.float32)
    axis_coord = rel @ axis
    side_coord_a = rel @ side_a
    side_coord_b = rel @ side_b
    z_values = pts[:, 2]

    z_min = float(z_values.min())
    z_max = float(z_values.max())
    z_span = max(z_max - z_min, 1e-8)
    band = max(0.12 * z_span, 1e-8)
    bottom_mask = z_values <= (z_min + band)
    top_mask = z_values >= (z_max - band)
    bottom_flatness = _flatness_score(z_values[bottom_mask], z_span)
    top_flatness = _flatness_score(z_values[top_mask], z_span)

    axis_min = float(axis_coord.min())
    axis_max = float(axis_coord.max())
    axis_span = max(axis_max - axis_min, 1e-8)
    bins = min(7, max(5, int(points.shape[0] // 80) if points.shape[0] >= 80 else 5))
    edges = np.linspace(axis_min, axis_max, bins + 1, dtype=np.float32)

    profiles: List[Tuple[float, float, float, float]] = []
    for i in range(bins):
        if i == bins - 1:
            mask = (axis_coord >= edges[i]) & (axis_coord <= edges[i + 1])
        else:
            mask = (axis_coord >= edges[i]) & (axis_coord < edges[i + 1])
        if int(mask.sum()) < 10:
            continue
        local_z = z_values[mask]
        local_a = side_coord_a[mask]
        local_b = side_coord_b[mask]
        top_q = float(np.percentile(local_z, 82))
        bot_q = float(np.percentile(local_z, 18))
        span_a = float(np.percentile(local_a, 90) - np.percentile(local_a, 10))
        span_b = float(np.percentile(local_b, 90) - np.percentile(local_b, 10))
        section_area = max(span_a * span_b, 1e-8)
        center_t = 0.5 * float(edges[i] + edges[i + 1])
        profiles.append((center_t, top_q, bot_q, section_area))

    vertical_relief = 0.0
    end_asymmetry = 0.0
    end_taper_asymmetry = 0.0
    wedge_bias = 0.0
    section_stability = 0.5

    if len(profiles) >= 3:
        centers = np.array([p[0] for p in profiles], dtype=np.float32)
        tops = np.array([p[1] for p in profiles], dtype=np.float32)
        bottoms = np.array([p[2] for p in profiles], dtype=np.float32)
        areas = np.array([p[3] for p in profiles], dtype=np.float32)
        center_idx = int(np.argmin(np.abs(centers)))
        left_idx = int(np.argmin(centers))
        right_idx = int(np.argmax(centers))

        center_top = float(tops[center_idx])
        end_top = 0.5 * float(tops[left_idx] + tops[right_idx])
        vertical_relief = float(max(0.0, end_top - center_top) / z_span)

        left_area = float(areas[left_idx])
        right_area = float(areas[right_idx])
        center_area = float(max(areas[center_idx], 1e-8))
        left_taper = float(max(0.0, center_area - left_area) / center_area)
        right_taper = float(max(0.0, center_area - right_area) / center_area)
        end_asymmetry = float(abs(left_area - right_area) / max(max(left_area, right_area), 1e-8))
        end_taper_asymmetry = float(abs(left_taper - right_taper))

        end_height_asym = float(abs(tops[left_idx] - tops[right_idx]) / z_span)
        area_mean = float(max(np.mean(areas), 1e-8))
        area_cv = float(np.std(areas) / area_mean)
        thickness = np.maximum(tops - bottoms, 1e-8)
        thickness_cv = float(np.std(thickness) / max(float(np.mean(thickness)), 1e-8))
        section_stability = float(np.clip(1.0 - (area_cv + 0.35 * thickness_cv) / 0.85, 0.0, 1.0))
        wedge_bias = float(np.clip(max(end_taper_asymmetry, 0.7 * end_height_asym + 0.6 * end_asymmetry), 0.0, 1.5))

    return {
        "bottom_flatness": float(bottom_flatness),
        "top_flatness": float(top_flatness),
        "vertical_relief": float(vertical_relief),
        "end_asymmetry": float(end_asymmetry),
        "end_asymetry": float(end_asymmetry),
        "end_taper_asymmetry": float(end_taper_asymmetry),
        "end_taper_asymetry": float(end_taper_asymmetry),
        "wedge_bias": float(wedge_bias),
        "section_stability": float(section_stability),
    }


def build_component_descriptors(comp_points: Dict[int, np.ndarray]) -> Tuple[Dict[int, Dict], Dict[Tuple[int, int], Dict[str, float]], Dict[str, np.ndarray]]:
    if not comp_points:
        return {}, {}, {}

    comp_ids = sorted(comp_points.keys())
    stats: Dict[int, Dict] = {}
    all_points = np.vstack([comp_points[cid] for cid in comp_ids]).astype(np.float32)
    global_min = all_points.min(axis=0)
    global_max = all_points.max(axis=0)
    global_center = 0.5 * (global_min + global_max)
    global_extents = np.maximum(global_max - global_min, 1e-8)
    global_diag = max(float(np.linalg.norm(global_max - global_min)), 1e-8)

    centroids = []
    for cid in comp_ids:
        points = comp_points[cid]
        centroid = points.mean(axis=0)
        bmin, bmax, diag = bbox_stats(points)
        extents = np.maximum(bmax - bmin, 1e-8)
        axis_raw = pca_axis(points)
        axis = np.abs(axis_raw)
        centered = points - centroid
        if points.shape[0] >= 3:
            cov = centered.T @ centered / max(points.shape[0] - 1, 1)
            eigvals, _ = np.linalg.eigh(cov)
            eigvals = np.sort(np.maximum(eigvals, 1e-8))[::-1]
        else:
            eigvals = np.array([1.0, 1.0, 1.0], dtype=np.float32)
        sorted_extents = np.sort(extents)[::-1]
        shape_cues = _component_shape_cues(points, centroid, axis_raw)
        stats[cid] = {
            "points": points,
            "centroid": centroid,
            "bbox_min": bmin,
            "bbox_max": bmax,
            "diag": float(diag),
            "extents": extents,
            "sorted_extents": sorted_extents,
            "axis": axis_raw,
            "axis_abs": axis,
            "eigvals": eigvals.astype(np.float32),
            "contact_degree": 0,
            "horizontal_degree": 0,
            "support_below_count": 0,
            "support_above_count": 0,
            "symmetry_score": 0.0,
            "symmetry_partner_gap": 1.0,
            "symmetry_partner": -1,
        }
        stats[cid].update(shape_cues)
        centroids.append(centroid)

    centroids_np = np.vstack(centroids).astype(np.float32)
    if len(comp_ids) >= 2:
        centered_xy = centroids_np[:, :2] - centroids_np[:, :2].mean(axis=0, keepdims=True)
        cov_xy = centered_xy.T @ centered_xy / max(centered_xy.shape[0] - 1, 1)
        vals_xy, vecs_xy = np.linalg.eigh(cov_xy)
        axis_xy = vecs_xy[:, np.argmax(vals_xy)]
        sym_axis = np.array([axis_xy[0], axis_xy[1], 0.0], dtype=np.float32)
    else:
        sym_axis = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    sym_axis = sym_axis / (np.linalg.norm(sym_axis) + 1e-8)

    proj = {
        cid: float(np.dot(stats[cid]["centroid"] - global_center, sym_axis))
        for cid in comp_ids
    }
    axis_extent = max(float(np.max(np.abs(np.array(list(proj.values()), dtype=np.float32)))), 1e-6)
    z_rank = _rank_map({cid: float(stats[cid]["centroid"][2]) for cid in comp_ids})
    size_rank = _rank_map({cid: float(stats[cid]["diag"]) for cid in comp_ids})

    pair_relations: Dict[Tuple[int, int], Dict[str, float]] = {}
    for i, cid_a in enumerate(comp_ids):
        sa = stats[cid_a]
        for cid_b in comp_ids[i + 1:]:
            sb = stats[cid_b]
            gap = float(bbox_gap(sa["bbox_min"], sa["bbox_max"], sb["bbox_min"], sb["bbox_max"]) / global_diag)
            centroid_dist = float(np.linalg.norm(sa["centroid"] - sb["centroid"]) / global_diag)
            z_overlap = overlap_ratio(float(sa["bbox_min"][2]), float(sa["bbox_max"][2]),
                                      float(sb["bbox_min"][2]), float(sb["bbox_max"][2]))
            xy_overlap = _safe_overlap_2d(sa["bbox_min"], sa["bbox_max"], sb["bbox_min"], sb["bbox_max"])
            axis_dot = float(np.clip(np.dot(sa["axis_abs"], sb["axis_abs"]), 0.0, 1.0))
            size_ratio = float(min(sa["diag"], sb["diag"]) / max(sa["diag"], sb["diag"], 1e-8))
            signed_dz = float((sb["centroid"][2] - sa["centroid"][2]) / global_diag)

            rel = {
                "gap": gap,
                "centroid_dist": centroid_dist,
                "z_overlap": z_overlap,
                "xy_overlap": xy_overlap,
                "axis_dot": axis_dot,
                "size_ratio": size_ratio,
                "signed_dz": signed_dz,
            }
            pair_relations[(cid_a, cid_b)] = rel

            if gap <= 0.05 or (gap <= 0.08 and xy_overlap >= 0.20):
                stats[cid_a]["contact_degree"] += 1
                stats[cid_b]["contact_degree"] += 1
            if xy_overlap >= 0.20 and abs(signed_dz) <= 0.08:
                stats[cid_a]["horizontal_degree"] += 1
                stats[cid_b]["horizontal_degree"] += 1

            if sb["centroid"][2] >= sa["centroid"][2]:
                vertical_gap = max(0.0, float(sb["bbox_min"][2] - sa["bbox_max"][2])) / global_diag
                if vertical_gap <= 0.06 and xy_overlap >= 0.18:
                    stats[cid_a]["support_above_count"] += 1
                    stats[cid_b]["support_below_count"] += 1
            else:
                vertical_gap = max(0.0, float(sa["bbox_min"][2] - sb["bbox_max"][2])) / global_diag
                if vertical_gap <= 0.06 and xy_overlap >= 0.18:
                    stats[cid_b]["support_above_count"] += 1
                    stats[cid_a]["support_below_count"] += 1

    for cid_a in comp_ids:
        best_partner = -1
        best_gap = None
        for cid_b in comp_ids:
            if cid_a == cid_b:
                continue
            pa = proj[cid_a]
            pb = proj[cid_b]
            if pa * pb > 0.0:
                continue
            abs_gap = abs(abs(pa) - abs(pb)) / axis_extent
            z_gap = abs(float(stats[cid_a]["centroid"][2] - stats[cid_b]["centroid"][2])) / global_diag
            size_gap = abs(math.log(max(stats[cid_a]["diag"], 1e-8) / max(stats[cid_b]["diag"], 1e-8)))
            pair_gap = abs_gap + 0.7 * z_gap + 0.35 * size_gap
            if best_gap is None or pair_gap < best_gap:
                best_gap = pair_gap
                best_partner = cid_b
        if best_partner >= 0 and best_gap is not None:
            score = max(0.0, 1.0 - best_gap / 1.6)
            stats[cid_a]["symmetry_partner"] = best_partner
            stats[cid_a]["symmetry_partner_gap"] = float(best_gap)
            stats[cid_a]["symmetry_score"] = float(score)

    feature_names = [
        "centroid_norm_x", "centroid_norm_y", "centroid_norm_z",
        "centered_abs_x", "centered_abs_y", "centered_abs_z",
        "extent_x", "extent_y", "extent_z",
        "sorted_extent_0", "sorted_extent_1", "sorted_extent_2",
        "diag_rel", "aspect_01", "aspect_12", "aspect_02", "flat_ratio", "planar_ratio",
        "eig_0_rel", "eig_1_rel", "eig_2_rel",
        "axis_abs_x", "axis_abs_y", "axis_abs_z",
        "z_rank", "size_rank", "side_offset",
        "contact_degree_norm", "horizontal_degree_norm",
        "support_below_norm", "support_above_norm",
        "symmetry_score", "symmetry_gap",
    ]

    max_degree = max(len(comp_ids) - 1, 1)
    for cid in comp_ids:
        s = stats[cid]
        extents = s["extents"]
        sorted_extents = s["sorted_extents"]
        eigvals = s["eigvals"]
        centroid_norm = (s["centroid"] - global_min) / global_extents
        centered_abs = np.abs((s["centroid"] - global_center) / global_extents)
        diag_rel = float(s["diag"] / global_diag)
        side_offset = float(abs(proj[cid]) / axis_extent)
        elongation = float(sorted_extents[0] / max(sorted_extents[1], 1e-8))
        thickness_ratio = float(sorted_extents[1] / max(sorted_extents[2], 1e-8))
        feature = np.concatenate([
            centroid_norm.astype(np.float32),
            centered_abs.astype(np.float32),
            extents.astype(np.float32),
            sorted_extents.astype(np.float32),
            np.array([
                diag_rel,
                elongation,
                thickness_ratio,
                float(sorted_extents[0] / max(sorted_extents[2], 1e-8)),
                float(extents[2] / max(extents[0], extents[1], 1e-8)),
                float(min(extents[0], extents[1]) / max(extents[0], extents[1], 1e-8)),
                float(eigvals[0] / max(eigvals[0], 1e-8)),
                float(eigvals[1] / max(eigvals[0], 1e-8)),
                float(eigvals[2] / max(eigvals[0], 1e-8)),
            ], dtype=np.float32),
            s["axis_abs"].astype(np.float32),
            np.array([
                z_rank.get(cid, 0.0),
                size_rank.get(cid, 0.0),
                side_offset,
                float(s["contact_degree"] / max_degree),
                float(s["horizontal_degree"] / max_degree),
                float(s["support_below_count"] / max_degree),
                float(s["support_above_count"] / max_degree),
                float(s["symmetry_score"]),
                float(s["symmetry_partner_gap"]),
            ], dtype=np.float32),
        ]).astype(np.float32)
        s["feature"] = feature
        s["diag_rel"] = diag_rel
        s["elongation"] = elongation
        s["thickness_ratio"] = thickness_ratio
        s["side_offset"] = side_offset
        s["side_proj"] = float(proj[cid] / axis_extent)
        s["z_rank"] = z_rank.get(cid, 0.0)
        s["size_rank"] = size_rank.get(cid, 0.0)

    global_meta = {
        "global_min": global_min.astype(np.float32),
        "global_max": global_max.astype(np.float32),
        "global_center": global_center.astype(np.float32),
        "global_extents": global_extents.astype(np.float32),
        "global_diag": np.array([global_diag], dtype=np.float32),
        "sym_axis": sym_axis.astype(np.float32),
        "feature_names": np.array(feature_names, dtype=object),
    }
    return stats, pair_relations, global_meta


def extract_semantic_training_rows(gt_parts: List[Part]) -> Tuple[List[np.ndarray], List[str], List[str], Dict[str, int]]:
    comp_points = {idx: p.points for idx, p in enumerate(gt_parts)}
    descriptors, _, global_meta = build_component_descriptors(comp_points)
    rows = []
    labels = []
    for idx, p in enumerate(gt_parts):
        if idx not in descriptors:
            continue
        rows.append(descriptors[idx]["feature"])
        labels.append(p.semantic)
    counts: Dict[str, int] = {}
    for sem in labels:
        counts[sem] = counts.get(sem, 0) + 1
    feature_names = [str(x) for x in global_meta.get("feature_names", np.array([], dtype=object)).tolist()]
    return rows, labels, feature_names, counts


def build_semantic_model(rows: List[np.ndarray], labels: List[str],
                         per_model_counts: List[Dict[str, int]], feature_names: List[str]) -> Dict:
    if not rows:
        return {
            "version": 2,
            "feature_schema": "structural_context_v2",
            "feature_names": feature_names,
            "global_mean": [],
            "global_std": [],
            "classes": {},
            "count_stats": {},
        }
    x = np.stack(rows, axis=0).astype(np.float32)
    global_mean = x.mean(axis=0)
    global_std = x.std(axis=0) + 1e-8
    z = (x - global_mean) / global_std

    label_counts: Dict[str, int] = {}
    label_to_feats: Dict[str, List[np.ndarray]] = {}
    for feat, sem in zip(z, labels):
        label_counts[sem] = label_counts.get(sem, 0) + 1
        label_to_feats.setdefault(sem, []).append(feat)
    total = max(len(labels), 1)

    count_stats: Dict[str, Dict] = {}
    presence_counts: Dict[str, int] = {}
    for counts in per_model_counts:
        for sem, cnt in counts.items():
            presence_counts[sem] = presence_counts.get(sem, 0) + 1
            count_stats.setdefault(sem, {"present_counts": []})
            count_stats[sem]["present_counts"].append(int(cnt))
    num_models = max(len(per_model_counts), 1)

    classes = {}
    for sem, feats in label_to_feats.items():
        feats_np = np.stack(feats, axis=0)
        present_counts = count_stats.get(sem, {}).get("present_counts", [])
        classes[sem] = {
            "mean": feats_np.mean(axis=0).tolist(),
            "std": (feats_np.std(axis=0) + 1e-8).tolist(),
            "count": int(label_counts.get(sem, 0)),
            "prior": float(label_counts.get(sem, 0) / total),
            "model_presence_rate": float(presence_counts.get(sem, 0) / num_models),
            "max_count": int(max(present_counts) if present_counts else label_counts.get(sem, 0)),
            "median_present_count": float(np.median(present_counts) if present_counts else label_counts.get(sem, 0)),
        }

    compact_count_stats = {}
    for sem, stats in count_stats.items():
        present_counts = stats.get("present_counts", [])
        compact_count_stats[sem] = {
            "max_count": int(max(present_counts) if present_counts else 0),
            "median_present_count": float(np.median(present_counts) if present_counts else 0.0),
            "model_presence_rate": float(presence_counts.get(sem, 0) / num_models),
        }

    return {
        "version": 2,
        "feature_schema": "structural_context_v2",
        "feature_names": feature_names,
        "global_mean": global_mean.tolist(),
        "global_std": global_std.tolist(),
        "classes": classes,
        "count_stats": compact_count_stats,
    }


def normalize_semantic_model(model: Dict) -> Dict:
    if "classes" in model and "global_mean" in model:
        return model

    classes = {}
    feature_dim = 0
    for sem, stats in model.items():
        mean = np.array(stats.get("mean", []), dtype=np.float32)
        std = np.array(stats.get("std", []), dtype=np.float32)
        feature_dim = max(feature_dim, int(mean.size))
        classes[sem] = {
            "mean": mean.tolist(),
            "std": (std + 1e-8).tolist(),
            "count": 1,
            "prior": 1.0 / max(len(model), 1),
            "model_presence_rate": 1.0,
            "max_count": 999,
            "median_present_count": 1.0,
        }
    return {
        "version": 1,
        "feature_schema": "legacy_component_features",
        "feature_names": [],
        "global_mean": [0.0] * feature_dim,
        "global_std": [1.0] * feature_dim,
        "classes": classes,
        "count_stats": {},
    }


def semantic_scores_from_descriptor(desc: Dict, semantic_model: Dict) -> Dict[str, float]:
    classes = semantic_model.get("classes", {})
    if not classes:
        return {"unknown": 0.0}

    global_mean = np.array(semantic_model.get("global_mean", []), dtype=np.float32)
    global_std = np.array(semantic_model.get("global_std", []), dtype=np.float32)
    feat = desc["feature"].astype(np.float32)
    if global_mean.size == feat.size and global_std.size == feat.size:
        z = (feat - global_mean) / (global_std + 1e-8)
    else:
        z = feat

    diag_rel = float(desc.get("diag_rel", 0.0))
    elong = float(desc.get("elongation", 1.0))
    thickness = float(desc.get("thickness_ratio", 1.0))
    side_offset = float(desc.get("side_offset", 0.0))
    axis_z = float(desc["axis_abs"][2])
    contact_degree = float(desc.get("contact_degree", 0))
    horizontal_degree = float(desc.get("horizontal_degree", 0))
    support_below = float(desc.get("support_below_count", 0))
    support_above = float(desc.get("support_above_count", 0))
    symmetry_score = float(desc.get("symmetry_score", 0.0))
    z_rank = float(desc.get("z_rank", 0.0))
    centered_abs = np.array(np.abs(desc["centroid"]), dtype=np.float32)
    bottom_flatness = float(desc.get("bottom_flatness", 0.5))
    top_flatness = float(desc.get("top_flatness", 0.5))
    vertical_relief = float(desc.get("vertical_relief", 0.0))
    end_asymmetry = float(desc.get("end_asymmetry", desc.get("end_asymetry", 0.0)))
    end_taper_asymmetry = float(desc.get("end_taper_asymmetry", desc.get("end_taper_asymetry", 0.0)))
    wedge_bias = float(desc.get("wedge_bias", 0.0))
    section_stability = float(desc.get("section_stability", 0.5))
    beam_like = (
        0.30 * bottom_flatness
        + 0.24 * top_flatness
        + 0.30 * section_stability
        + 0.12 * min(elong / 6.0, 1.0)
        - 0.38 * min(vertical_relief / 0.10, 1.0)
        - 0.32 * min(wedge_bias / 0.45, 1.0)
    )
    gong_like = (
        0.34 * min(diag_rel / 0.24, 1.0)
        + 0.28 * min(max(elong - 1.8, 0.0) / 3.8, 1.0)
        + 0.22 * bottom_flatness
        + 0.18 * min(max(vertical_relief, 0.012) / 0.09, 1.0)
        + 0.18 * min((support_above + contact_degree) / 3.0, 1.0)
        - 0.24 * min(wedge_bias / 0.55, 1.0)
    )
    ang_like = (
        0.35 * min(wedge_bias / 0.55, 1.0)
        + 0.28 * min(end_taper_asymmetry / 0.45, 1.0)
        + 0.20 * min(end_asymmetry / 0.45, 1.0)
        + 0.12 * min(max(elong - 1.8, 0.0) / 4.0, 1.0)
        - 0.18 * section_stability
    )

    scores: Dict[str, float] = {}
    for sem, stats in classes.items():
        cls_mean = np.array(stats.get("mean", []), dtype=np.float32)
        cls_std = np.array(stats.get("std", []), dtype=np.float32)
        if cls_mean.size == z.size and cls_std.size == z.size:
            dist = float(np.linalg.norm((z - cls_mean) / (cls_std + 1e-6)))
        elif cls_mean.size == feat.size and cls_std.size == feat.size:
            dist = float(np.linalg.norm((feat - cls_mean) / (cls_std + 1e-6)))
        else:
            dist = float(np.linalg.norm(z))

        prior = float(stats.get("prior", 1e-3))
        score = dist + 0.18 * max(0.0, -math.log(max(prior, 1e-6)))

        if sem == "dou":
            if diag_rel <= 0.19 and elong <= 1.65:
                score -= 1.45
            if diag_rel > 0.30 or elong > 3.0:
                score += 1.1
        elif sem == "gong":
            if diag_rel >= 0.18 and side_offset <= 0.26 and contact_degree >= 2:
                score -= 0.95
            if gong_like >= 0.62:
                score -= 0.78
            elif gong_like >= 0.50:
                score -= 0.38
            if bottom_flatness >= 0.50:
                score -= 0.20
            if vertical_relief >= 0.025:
                score -= 0.32
            if support_above >= 1:
                score -= 0.16
            if beam_like >= 0.70 and support_above <= 0 and vertical_relief <= 0.025:
                score += 0.36
            if wedge_bias >= 0.45:
                score += 0.30
            if elong > 6.4:
                score += 0.6
        elif sem == "fang":
            if elong >= 4.8 and beam_like >= 0.68:
                score -= 0.72
            if bottom_flatness >= 0.62 and top_flatness >= 0.55:
                score -= 0.28
            if section_stability >= 0.72:
                score -= 0.22
            if vertical_relief >= 0.04:
                score += 0.55
            if wedge_bias >= 0.30:
                score += 0.42
            if diag_rel < 0.16:
                score += 0.5
            if side_offset <= 0.12 and elong < 5.0:
                score += 0.35
        elif sem == "ang":
            if 2.0 <= elong <= 5.8 and ang_like >= 0.42:
                score -= 0.86
            if end_taper_asymmetry >= 0.22:
                score -= 0.55
            if end_asymmetry >= 0.18:
                score -= 0.25
            if side_offset >= 0.12:
                score -= 0.10
            if section_stability >= 0.82 and wedge_bias <= 0.18:
                score += 0.50
            if side_offset <= 0.08:
                score += 0.55
            if elong >= 6.0:
                score += 0.45
        elif sem == "chuan":
            if elong >= 5.8 and beam_like >= 0.70:
                score -= 0.62
            if axis_z >= 0.40:
                score -= 0.14
            if side_offset >= 0.10:
                score -= 0.12
            if vertical_relief >= 0.035:
                score += 0.48
            if wedge_bias >= 0.28:
                score += 0.34
        elif sem == "other":
            if diag_rel >= 0.33 and side_offset <= 0.15:
                score -= 0.75
            if diag_rel < 0.14:
                score += 0.6
        elif sem == "qiao":
            if z_rank >= 0.72 and axis_z >= 0.8 and elong >= 2.4:
                score -= 0.55
            else:
                score += 0.55

        if support_below > 0 and support_above > 0 and sem == "gong":
            score -= 0.25
        if horizontal_degree >= 2 and sem in {"fang", "gong"}:
            score -= 0.18
        if centered_abs[0] > 0.5 and sem == "gong":
            score += 0.20
        if thickness >= 3.0 and sem == "dou":
            score += 0.35

        scores[sem] = score
    return scores


def rebalance_semantic_predictions(raw_scores: Dict[int, Dict[str, float]],
                                   descriptors: Dict[int, Dict],
                                   semantic_model: Dict) -> Dict[int, str]:
    labels = {}
    ranked_choices: Dict[int, List[Tuple[str, float]]] = {}
    for cid, scores in raw_scores.items():
        ordered = sorted(scores.items(), key=lambda kv: kv[1])
        ranked_choices[cid] = ordered
        labels[cid] = ordered[0][0] if ordered else "unknown"

    count_stats = semantic_model.get("count_stats", {})
    present_caps = {}
    for sem, stats in count_stats.items():
        max_count = int(stats.get("max_count", 0))
        presence = float(stats.get("model_presence_rate", 0.0))
        if max_count > 0 and presence < 0.5:
            present_caps[sem] = max_count

    def relabel_one(cid: int, banned_sem: str) -> bool:
        for cand_sem, _ in ranked_choices.get(cid, [])[1:]:
            if cand_sem != banned_sem:
                labels[cid] = cand_sem
                return True
        return False

    for sem, cap in present_caps.items():
        while sum(1 for v in labels.values() if v == sem) > cap:
            candidates = []
            for cid, current in labels.items():
                if current != sem:
                    continue
                ordered = ranked_choices.get(cid, [])
                if len(ordered) < 2:
                    continue
                margin = float(ordered[1][1] - ordered[0][1])
                candidates.append((margin, cid))
            if not candidates:
                break
            _, cid = min(candidates)
            if not relabel_one(cid, sem):
                break

    if labels and sum(1 for v in labels.values() if v == "gong") == 0:
        gong_candidate = None
        for cid, desc in descriptors.items():
            gong_score = raw_scores.get(cid, {}).get("gong", 1e9)
            center_bonus = (1.0 - desc.get("side_offset", 0.0)) + desc.get("diag_rel", 0.0)
            value = float(gong_score - 0.35 * center_bonus)
            if gong_candidate is None or value < gong_candidate[0]:
                gong_candidate = (value, cid)
        if gong_candidate is not None:
            labels[gong_candidate[1]] = "gong"

    if labels and sum(1 for v in labels.values() if v == "dou") == 0:
        dou_candidate = None
        for cid, desc in descriptors.items():
            if desc.get("diag_rel", 1.0) > 0.22:
                continue
            if desc.get("elongation", 9.0) > 1.9:
                continue
            value = float(raw_scores.get(cid, {}).get("dou", 1e9))
            if dou_candidate is None or value < dou_candidate[0]:
                dou_candidate = (value, cid)
        if dou_candidate is not None:
            labels[dou_candidate[1]] = "dou"

    return labels


def _desc_dou_like(desc: Dict) -> bool:
    diag_rel = float(desc.get("diag_rel", 1.0))
    elong = float(desc.get("elongation", 9.0))
    thickness = float(desc.get("thickness_ratio", 9.0))
    axis_z = float(desc.get("axis_abs", np.zeros(3, dtype=np.float32))[2])
    return bool(diag_rel <= 0.20 and elong <= 1.95 and thickness <= 2.8 and axis_z <= 0.92)


def _desc_beam_like(desc: Dict) -> bool:
    elong = float(desc.get("elongation", 1.0))
    bottom_flatness = float(desc.get("bottom_flatness", 0.5))
    top_flatness = float(desc.get("top_flatness", 0.5))
    vertical_relief = float(desc.get("vertical_relief", 0.0))
    wedge_bias = float(desc.get("wedge_bias", 0.0))
    section_stability = float(desc.get("section_stability", 0.5))
    axis_z = float(desc.get("axis_abs", np.zeros(3, dtype=np.float32))[2])
    return bool(
        elong >= 4.8
        and axis_z <= 0.78
        and bottom_flatness >= 0.62
        and top_flatness >= 0.54
        and vertical_relief <= 0.030
        and wedge_bias <= 0.20
        and section_stability >= 0.68
    )


def _desc_ang_like(desc: Dict) -> bool:
    elong = float(desc.get("elongation", 1.0))
    wedge_bias = float(desc.get("wedge_bias", 0.0))
    end_asymmetry = float(desc.get("end_asymmetry", desc.get("end_asymetry", 0.0)))
    end_taper_asymmetry = float(desc.get("end_taper_asymmetry", desc.get("end_taper_asymetry", 0.0)))
    vertical_relief = float(desc.get("vertical_relief", 0.0))
    return bool(
        elong >= 2.0
        and elong <= 6.2
        and (
            wedge_bias >= 0.42
            or end_taper_asymmetry >= 0.30
            or (end_asymmetry >= 0.28 and vertical_relief >= 0.025)
        )
    )


def _desc_strong_gong_like(desc: Dict) -> bool:
    diag_rel = float(desc.get("diag_rel", 0.0))
    elong = float(desc.get("elongation", 1.0))
    side_offset = float(desc.get("side_offset", 1.0))
    axis_z = float(desc.get("axis_abs", np.zeros(3, dtype=np.float32))[2])
    support_below = float(desc.get("support_below_count", 0.0))
    thickness = float(desc.get("thickness_ratio", 1.0))
    bottom_flatness = float(desc.get("bottom_flatness", 0.5))
    vertical_relief = float(desc.get("vertical_relief", 0.0))
    wedge_bias = float(desc.get("wedge_bias", 0.0))
    section_stability = float(desc.get("section_stability", 0.5))
    return bool(
        diag_rel >= 0.15
        and elong >= 2.35
        and elong <= 6.6
        and side_offset <= 0.42
        and axis_z <= 0.72
        and thickness >= 1.15
        and support_below >= 1.0
        and bottom_flatness >= 0.48
        and (vertical_relief >= 0.012 or support_below >= 2.0)
        and wedge_bias <= 0.58
    )


def _desc_upper_compact_false_gong_risk(desc: Dict, ctx: Dict[str, int]) -> bool:
    elong = float(desc.get("elongation", 1.0))
    support_below = float(desc.get("support_below_count", 0.0))
    support_above = float(desc.get("support_above_count", 0.0))
    bottom_flatness = float(desc.get("bottom_flatness", 0.5))
    top_flatness = float(desc.get("top_flatness", 0.5))
    wedge_bias = float(desc.get("wedge_bias", 0.0))
    return bool(
        elong <= 1.28
        and support_above >= 4.0
        and support_below <= 2.0
        and support_above >= support_below + 3.0
        and bottom_flatness <= 0.08
        and top_flatness <= 0.12
        and wedge_bias >= 0.65
        and int(ctx.get("small_above", 0)) >= 1
    )


def build_semantic_context(descriptors: Dict[int, Dict],
                           pair_relations: Dict[Tuple[int, int], Dict[str, float]]) -> Dict[int, Dict[str, int]]:
    ctx = {
        cid: {
            "small_above": 0,
            "small_below": 0,
            "same_layer_parallel": 0,
            "close_neighbors": 0,
        }
        for cid in descriptors.keys()
    }

    for (cid_a, cid_b), rel in pair_relations.items():
        desc_a = descriptors[cid_a]
        desc_b = descriptors[cid_b]
        if rel.get("gap", 1e9) <= 0.10:
            ctx[cid_a]["close_neighbors"] += 1
            ctx[cid_b]["close_neighbors"] += 1

        if rel.get("axis_dot", 0.0) >= 0.82 and abs(rel.get("signed_dz", 1e9)) <= 0.08 and rel.get("gap", 1e9) <= 0.12:
            ctx[cid_a]["same_layer_parallel"] += 1
            ctx[cid_b]["same_layer_parallel"] += 1

        if rel.get("xy_overlap", 0.0) < 0.16:
            continue

        signed_dz = float(rel.get("signed_dz", 0.0))
        if signed_dz >= 0.0:
            lower_id, upper_id = cid_a, cid_b
            upper_desc = desc_b
            lower_desc = desc_a
        else:
            lower_id, upper_id = cid_b, cid_a
            upper_desc = desc_a
            lower_desc = desc_b

        if abs(signed_dz) <= 0.20 and rel.get("gap", 1e9) <= 0.12 and _desc_dou_like(upper_desc):
            ctx[lower_id]["small_above"] += 1
        if abs(signed_dz) <= 0.20 and rel.get("gap", 1e9) <= 0.12 and _desc_dou_like(lower_desc):
            ctx[upper_id]["small_below"] += 1

    return ctx


def apply_structural_semantic_consistency(labels: Dict[int, str],
                                          raw_scores: Dict[int, Dict[str, float]],
                                          descriptors: Dict[int, Dict],
                                          pair_relations: Dict[Tuple[int, int], Dict[str, float]]) -> Dict[int, str]:
    if not labels:
        return labels

    adjusted = dict(labels)
    context = build_semantic_context(descriptors, pair_relations)

    for cid, desc in descriptors.items():
        current = adjusted.get(cid, "unknown")
        scores = raw_scores.get(cid, {})
        gong_score = float(scores.get("gong", 1e9))
        dou_score = float(scores.get("dou", 1e9))
        fang_score = float(scores.get("fang", 1e9))
        chuan_score = float(scores.get("chuan", 1e9))
        ang_score = float(scores.get("ang", 1e9))
        other_score = float(scores.get("other", 1e9))
        ctx = context.get(cid, {})
        beam_like = _desc_beam_like(desc)
        ang_like = _desc_ang_like(desc)
        vertical_relief = float(desc.get("vertical_relief", 0.0))
        wedge_bias = float(desc.get("wedge_bias", 0.0))

        if _desc_strong_gong_like(desc):
            gong_support = 0
            if ctx.get("small_above", 0) >= 1:
                gong_support += 2
            if float(desc.get("symmetry_score", 0.0)) >= 0.40:
                gong_support += 1
            if float(desc.get("support_above_count", 0.0)) >= 1.0:
                gong_support += 1

            if current in {"dou", "other"} and gong_support >= 2 and gong_score <= min(dou_score + 1.0, scores.get(current, 1e9) + 1.2):
                adjusted[cid] = "gong"
                current = "gong"
            elif current in {"fang", "chuan"} and gong_support >= 2 and gong_score <= min(fang_score, chuan_score) + 0.55:
                adjusted[cid] = "gong"
                current = "gong"

        if _desc_dou_like(desc):
            compact_bonus = 0
            if ctx.get("small_above", 0) == 0:
                compact_bonus += 1
            if ctx.get("small_below", 0) >= 1:
                compact_bonus += 1
            if float(desc.get("support_below_count", 0.0)) >= 1.0:
                compact_bonus += 1

            if current in {"gong", "other"} and compact_bonus >= 2 and dou_score <= min(gong_score + 0.85, scores.get(current, 1e9) + 0.9):
                adjusted[cid] = "dou"
                current = "dou"

        if ang_like and current in {"fang", "chuan", "other"}:
            if ang_score <= min(fang_score, chuan_score, scores.get(current, 1e9)) + 0.25:
                adjusted[cid] = "ang"
                current = "ang"

        # Guard against compact upper attachments that the augmented label model
        # can over-promote to gong on gong-dominant datasets.
        if current == "gong" and not _desc_strong_gong_like(desc) and _desc_upper_compact_false_gong_risk(desc, ctx):
            fallback = None
            if wedge_bias >= 0.65 and ang_score <= min(other_score + 1.0, gong_score + 2.0):
                fallback = "ang"
            elif other_score <= gong_score + 1.2:
                fallback = "other"
            elif ang_score <= gong_score + 1.2:
                fallback = "ang"
            if fallback is not None:
                adjusted[cid] = fallback
                current = fallback

        if current == "gong" and beam_like and ctx.get("small_above", 0) == 0 and vertical_relief <= 0.025:
            if min(fang_score, chuan_score) <= gong_score - 0.20:
                adjusted[cid] = "fang" if fang_score <= chuan_score else "chuan"
                current = adjusted[cid]

        if current == "other":
            elong = float(desc.get("elongation", 1.0))
            axis_z = float(desc.get("axis_abs", np.zeros(3, dtype=np.float32))[2])
            side_offset = float(desc.get("side_offset", 0.0))
            if beam_like and side_offset <= 0.18 and fang_score <= chuan_score + 0.20:
                adjusted[cid] = "fang"
            elif beam_like and axis_z <= 0.78 and side_offset >= 0.12 and chuan_score <= fang_score + 0.20:
                adjusted[cid] = "chuan"
            elif ang_like and ang_score <= scores.get(current, 1e9) + 0.30:
                adjusted[cid] = "ang"

    return adjusted


def apply_dataset_semantic_priors(labels: Dict[int, str],
                                  raw_scores: Dict[int, Dict[str, float]],
                                  descriptors: Dict[int, Dict],
                                  pair_relations: Dict[Tuple[int, int], Dict[str, float]],
                                  semantic_model: Dict) -> Dict[int, str]:
    """
    Dataset-level semantic guard.

    The GT set is gong-dominant; over-segmented gong fragments are often small
    and blocky, so raw nearest-prototype scores can over-predict dou.  This
    pass only relabels surplus dou components when the component count is high
    and the component has enough structural context to be a gong fragment.
    It never changes the component map.
    """
    if not labels:
        return labels

    adjusted = dict(labels)
    n = len(adjusted)
    if n < 8:
        return adjusted

    dou_ids = [cid for cid, sem in adjusted.items() if sem == "dou"]
    if len(dou_ids) <= 2:
        return adjusted

    count_stats = semantic_model.get("count_stats", {})
    dou_stats = count_stats.get("dou", {})
    max_dou = int(dou_stats.get("max_count", 8))
    max_dou = max(2, max_dou)

    rare_sem_count = sum(1 for sem in adjusted.values() if sem in {"fang", "chuan", "ang", "qiao"})
    ratio_cap = 0.42 if rare_sem_count else 0.34
    soft_cap = int(math.ceil(ratio_cap * n))
    soft_cap = max(2, min(max_dou, soft_cap))
    if len(dou_ids) <= soft_cap:
        return adjusted

    context = build_semantic_context(descriptors, pair_relations)
    candidates = []
    for cid in dou_ids:
        desc = descriptors.get(cid, {})
        scores = raw_scores.get(cid, {})
        gong_score = float(scores.get("gong", 1e9))
        dou_score = float(scores.get("dou", 1e9))
        next_best = sorted(
            [(sem, float(score)) for sem, score in scores.items() if sem != "dou"],
            key=lambda kv: kv[1],
        )
        if not next_best:
            continue

        ctx = context.get(cid, {})
        support = float(desc.get("support_below_count", 0.0) + desc.get("support_above_count", 0.0))
        close_neighbors = float(ctx.get("close_neighbors", 0))
        diag_rel = float(desc.get("diag_rel", 0.0))
        z_rank = float(desc.get("z_rank", 0.0))

        structural_fragment = bool(
            diag_rel >= 0.20
            or support >= 2.0
            or close_neighbors >= 4.0
            or (0.18 <= z_rank <= 0.88 and close_neighbors >= 2.0)
        )
        if not structural_fragment:
            continue

        # Keep very isolated bottom/top dou unless we must relabel them later.
        keep_bias = 0.0
        if z_rank <= 0.10 or z_rank >= 0.92:
            keep_bias += 0.75
        if close_neighbors <= 1.0 and support <= 1.0:
            keep_bias += 0.90

        relabel_priority = (
            1.15 * min(diag_rel / 0.24, 1.5)
            + 0.28 * close_neighbors
            + 0.38 * support
            + 0.45 * float(0.12 <= z_rank <= 0.90)
            - 0.10 * max(0.0, gong_score - dou_score)
            - keep_bias
        )
        target = "gong" if gong_score <= next_best[0][1] + 3.0 else next_best[0][0]
        candidates.append((relabel_priority, cid, target))

    surplus = len(dou_ids) - soft_cap
    for _, cid, target in sorted(candidates, reverse=True)[:surplus]:
        if target == "dou":
            continue
        adjusted[cid] = target

    return adjusted


def predict_component_semantics(comp_points: Dict[int, np.ndarray], semantic_model: Dict) -> Tuple[Dict[int, str], Dict[int, Dict], Dict[Tuple[int, int], Dict[str, float]], Dict[str, np.ndarray], Dict[int, Dict[str, float]]]:
    descriptors, pair_relations, global_meta = build_component_descriptors(comp_points)
    semantic_model = normalize_semantic_model(semantic_model)
    raw_scores = {
        cid: semantic_scores_from_descriptor(desc, semantic_model)
        for cid, desc in descriptors.items()
    }
    comp_sem = rebalance_semantic_predictions(raw_scores, descriptors, semantic_model)
    comp_sem = apply_structural_semantic_consistency(comp_sem, raw_scores, descriptors, pair_relations)
    comp_sem = apply_dataset_semantic_priors(comp_sem, raw_scores, descriptors, pair_relations, semantic_model)
    return comp_sem, descriptors, pair_relations, global_meta, raw_scores


def recover_component_structure(comp_points: Dict[int, np.ndarray], comp_sem: Dict[int, str],
                                descriptors: Dict[int, Dict],
                                pair_relations: Dict[Tuple[int, int], Dict[str, float]],
                                global_meta: Dict[str, np.ndarray]) -> Dict:
    if not comp_points:
        return {"components": [], "assembly_edges": [], "levels": []}

    comp_ids = sorted(comp_points.keys())
    global_diag = max(float(global_meta.get("global_diag", np.array([1.0], dtype=np.float32))[0]), 1e-8)
    z_values = {cid: float(descriptors[cid]["centroid"][2]) for cid in comp_ids}
    sorted_ids = sorted(comp_ids, key=lambda cid: z_values[cid])
    levels: List[Dict] = []
    current_level = []
    current_mean_z = None
    layer_gap = 0.05 * global_diag
    for cid in sorted_ids:
        z = z_values[cid]
        if current_mean_z is None or abs(z - current_mean_z) <= layer_gap:
            current_level.append(cid)
            current_mean_z = float(np.mean([z_values[x] for x in current_level]))
        else:
            levels.append({"level_id": len(levels), "component_ids": current_level[:]})
            current_level = [cid]
            current_mean_z = z
    if current_level:
        levels.append({"level_id": len(levels), "component_ids": current_level[:]})
    comp_to_level = {
        cid: level["level_id"]
        for level in levels
        for cid in level["component_ids"]
    }

    assembly_edges = []
    seen_sym = set()
    for (cid_a, cid_b), rel in pair_relations.items():
        lower = cid_a
        upper = cid_b
        if descriptors[cid_a]["centroid"][2] > descriptors[cid_b]["centroid"][2]:
            lower, upper = upper, lower
        support_gap = max(0.0, float(descriptors[upper]["bbox_min"][2] - descriptors[lower]["bbox_max"][2])) / global_diag
        if support_gap <= 0.06 and rel["xy_overlap"] >= 0.18:
            assembly_edges.append({
                "source": lower,
                "target": upper,
                "relation": "support",
                "score": float(max(0.0, 1.0 - support_gap / 0.06) * rel["xy_overlap"]),
            })
        elif rel["gap"] <= 0.05:
            assembly_edges.append({
                "source": cid_a,
                "target": cid_b,
                "relation": "adjacent",
                "score": float(max(0.0, 1.0 - rel["gap"] / 0.05)),
            })

        sym_a = int(descriptors[cid_a].get("symmetry_partner", -1))
        if sym_a == cid_b:
            key = tuple(sorted((cid_a, cid_b)))
            if key not in seen_sym:
                seen_sym.add(key)
                assembly_edges.append({
                    "source": cid_a,
                    "target": cid_b,
                    "relation": "symmetric",
                    "score": float(min(descriptors[cid_a].get("symmetry_score", 0.0),
                                       descriptors[cid_b].get("symmetry_score", 0.0))),
                })

    components = []
    for cid in comp_ids:
        desc = descriptors[cid]
        components.append({
            "component_id": cid,
            "semantic": comp_sem.get(cid, "unknown"),
            "num_points": int(comp_points[cid].shape[0]),
            "centroid": [float(x) for x in desc["centroid"].tolist()],
            "bbox_min": [float(x) for x in desc["bbox_min"].tolist()],
            "bbox_max": [float(x) for x in desc["bbox_max"].tolist()],
            "diag_rel": float(desc.get("diag_rel", 0.0)),
            "elongation": float(desc.get("elongation", 1.0)),
            "z_rank": float(desc.get("z_rank", 0.0)),
            "size_rank": float(desc.get("size_rank", 0.0)),
            "side_offset": float(desc.get("side_offset", 0.0)),
            "contact_degree": int(desc.get("contact_degree", 0)),
            "support_below_count": int(desc.get("support_below_count", 0)),
            "support_above_count": int(desc.get("support_above_count", 0)),
            "symmetry_score": float(desc.get("symmetry_score", 0.0)),
            "layer_id": int(comp_to_level.get(cid, 0)),
        })

    return {
        "components": components,
        "assembly_edges": assembly_edges,
        "levels": levels,
    }


def collect_ids(fragment_dir: str, gt_dir: str) -> List[str]:
    ids = []
    for fname in os.listdir(fragment_dir):
        base, ext = os.path.splitext(fname)
        if ext.lower() not in {".glb", ".fbx"}:
            continue
        uid = base
        gt_glb = os.path.join(gt_dir, f"{uid}.glb")
        gt_points = os.path.join(gt_dir, uid, "points.npy")
        if os.path.exists(gt_glb) or os.path.exists(gt_points):
            ids.append(uid)
    return sorted(ids)


def train(args):
    np.random.seed(args.seed)
    ids = collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No training pairs found.")

    all_edge_feats = []
    all_edge_labels = []
    semantic_rows: List[np.ndarray] = []
    semantic_labels: List[str] = []
    semantic_count_rows: List[Dict[str, int]] = []
    semantic_feature_names: List[str] = []
    component_ratios = []
    edge_keep_ratios = []
    seg_per_gt_counts = []
    gt_part_bbox_diags = []

    for uid in ids:
        fragment_file = find_fragment_file(args.fragment_dir, uid)
        if not fragment_file:
            continue
        segments, _, center, scale, global_diag = load_fragment_segments(fragment_file, args.max_points)
        gt_parts = load_gt_parts_auto(args.gt_dir, uid, center, scale, args.gt_samples)
        if not gt_parts:
            continue

        # Skip unrecoverable under-seg cases for merge training.
        if len(segments) < len(gt_parts):
            continue

        mapping, _ = assign_segments_to_gt(segments, gt_parts)
        edges, feats = build_edges(
            segments, global_diag=global_diag,
            neighbor_ratio=args.neighbor_ratio,
            contact_eps=args.contact_eps
        )
        x, keys = features_to_matrix(feats)
        y = segments_to_edge_labels(edges, mapping)
        if x.shape[0] == 0:
            continue

        all_edge_feats.append(x)
        all_edge_labels.append(y)

        sem_rows, sem_labels, sem_feature_names, sem_counts = extract_semantic_training_rows(gt_parts)
        semantic_rows.extend(sem_rows)
        semantic_labels.extend(sem_labels)
        semantic_count_rows.append(sem_counts)
        if sem_feature_names:
            semantic_feature_names = sem_feature_names

        for p in gt_parts:
            gt_part_bbox_diags.append(float(p.bbox_diag))

        if len(segments) > 0 and len(gt_parts) > 0:
            ratio = len(gt_parts) / len(segments)
            if 0.05 <= ratio <= 1.0:
                component_ratios.append(ratio)
            gt_bins = np.bincount(list(mapping.values()), minlength=len(gt_parts))
            for v in gt_bins:
                if int(v) > 0:
                    seg_per_gt_counts.append(int(v))

        if len(y) > 0:
            edge_keep_ratios.append(float((y == 1).mean()))

    if not all_edge_feats:
        raise RuntimeError("No edges found for training.")

    x_all = np.vstack(all_edge_feats)
    y_all = np.concatenate(all_edge_labels)
    model = train_edge_model(x_all, y_all)
    model["feature_names"] = keys

    if edge_keep_ratios:
        model["target_keep_ratio"] = float(np.clip(np.median(edge_keep_ratios), 0.2, 0.55))
    else:
        model["target_keep_ratio"] = 0.4

    if component_ratios:
        model["target_component_ratio"] = float(np.clip(np.median(component_ratios), 0.35, 0.65))
    else:
        model["target_component_ratio"] = 0.5

    if seg_per_gt_counts:
        model["max_component_segments"] = int(np.clip(np.quantile(np.array(seg_per_gt_counts), 0.90), 4, 8))
    else:
        model["max_component_segments"] = 6

    if gt_part_bbox_diags:
        q = float(np.quantile(np.array(gt_part_bbox_diags, dtype=np.float32), 0.90))
        model["max_component_bbox_diag"] = float(np.clip(q * 1.20, 0.25, 1.5))
    else:
        model["max_component_bbox_diag"] = 0.0

    model["small_component_max_segments"] = 2
    model["small_attach_score_quantile"] = 0.6

    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "merge_edge_model.json"), "w", encoding="utf-8") as f:
        json.dump(model, f, indent=2)

    sem_out = build_semantic_model(
        rows=semantic_rows,
        labels=semantic_labels,
        per_model_counts=semantic_count_rows,
        feature_names=semantic_feature_names,
    )
    with open(os.path.join(args.out_dir, "semantic_prototypes.json"), "w", encoding="utf-8") as f:
        json.dump(sem_out, f, indent=2)

    print(f"trained on recoverable models, edges={x_all.shape[0]}")


def refine(args):
    np.random.seed(args.seed)
    uid = args.uid
    fragment_file = find_fragment_file(args.fragment_dir, uid)
    if not fragment_file:
        raise RuntimeError(f"fragment file not found for uid: {uid}")
    segments, seg_names, center, scale, global_diag = load_fragment_segments(fragment_file, args.max_points)

    with open(os.path.join(args.model_dir, "merge_edge_model.json"), "r", encoding="utf-8") as f:
        model = json.load(f)
    with open(os.path.join(args.model_dir, "semantic_prototypes.json"), "r", encoding="utf-8") as f:
        semantic_model = normalize_semantic_model(json.load(f))
    gt_parts = load_gt_parts_auto(args.gt_dir, uid, center, scale, args.gt_samples)

    edges, feats = build_edges(segments, global_diag=global_diag, neighbor_ratio=args.neighbor_ratio,
                               contact_eps=args.contact_eps)
    x, _ = features_to_matrix(feats)
    scores = score_edges(x, model) if x.shape[0] else np.array([])
    target_hint = len(gt_parts) if (args.target_mode == "gt_count" and gt_parts) else 0
    force_target = bool(target_hint > 0 and args.force_target_count)

    comp_map = select_best_component_map(
        segments=segments,
        edges=edges,
        scores=scores,
        model=model,
        target_components_hint=target_hint,
        force_target=force_target,
    )

    seg_points = {s.seg_id: s.points for s in segments}
    comp_points: Dict[int, np.ndarray] = {}
    for seg_id, comp_id in comp_map.items():
        comp_points.setdefault(comp_id, []).append(seg_points[seg_id])
    comp_points = {comp_id: np.vstack(pts_list) for comp_id, pts_list in comp_points.items()}

    comp_sem, descriptors, pair_relations, global_meta, raw_scores = predict_component_semantics(comp_points, semantic_model)
    structure = recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)

    underseg = []
    if gt_parts:
        mapping, dominance = assign_segments_to_gt(segments, gt_parts)
        for seg_id, dom in dominance.items():
            if dom < args.underseg_threshold:
                underseg.append(seg_id)

    os.makedirs(args.out_dir, exist_ok=True)

    all_points = []
    fragment_labels = []
    comp_labels = []
    semantic_labels = []
    for seg in segments:
        all_points.append(seg.points)
        fragment_labels.append(np.full(len(seg.points), seg.seg_id, dtype=np.int32))
        comp_id = comp_map[seg.seg_id]
        comp_labels.append(np.full(len(seg.points), comp_id, dtype=np.int32))
    all_points = np.vstack(all_points)
    fragment_labels = np.concatenate(fragment_labels)
    comp_labels = np.concatenate(comp_labels)

    sem_to_id = {s: i for i, s in enumerate(sorted(set(comp_sem.values())))}
    for seg in segments:
        comp_id = comp_map[seg.seg_id]
        sem_id = sem_to_id[comp_sem[comp_id]]
        semantic_labels.append(np.full(len(seg.points), sem_id, dtype=np.int32))
    semantic_labels = np.concatenate(semantic_labels)

    np.savez_compressed(
        os.path.join(args.out_dir, f"{uid}_refined.npz"),
        points=all_points,
        fragment_labels=fragment_labels,
        comp_labels=comp_labels,
        semantic_labels=semantic_labels,
        center=np.asarray(center, dtype=np.float32),
        scale=np.asarray(scale, dtype=np.float32),
        segment_names=seg_names,
    )

    summary = {
        "uid": uid,
        "num_segments": len(segments),
        "num_components": len(comp_points),
        "num_edges": len(edges),
        "threshold": model["threshold"],
        "target_keep_ratio": model.get("target_keep_ratio", 0.4),
        "target_component_ratio": model.get("target_component_ratio", 0.55),
        "target_mode": args.target_mode,
        "force_target_count": bool(args.force_target_count),
        "max_component_segments_limit": int(model.get("max_component_segments", 6)),
        "max_component_segments_observed": int(max(sum(1 for s in comp_map.values() if s == cid) for cid in set(comp_map.values()))),
        "components": [
            {
                "component_id": cid,
                "semantic": comp_sem[cid],
                "num_segments": sum(1 for s in comp_map.values() if s == cid),
                "diag_rel": float(descriptors[cid].get("diag_rel", 0.0)),
                "z_rank": float(descriptors[cid].get("z_rank", 0.0)),
                "side_offset": float(descriptors[cid].get("side_offset", 0.0)),
                "symmetry_score": float(descriptors[cid].get("symmetry_score", 0.0)),
                "semantic_scores": {k: float(v) for k, v in sorted(raw_scores.get(cid, {}).items())},
            }
            for cid in sorted(comp_points.keys())
        ],
        "assembly": structure,
        "underseg_candidates": underseg,
    }
    with open(os.path.join(args.out_dir, f"{uid}_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"refined {uid} -> components={len(comp_points)}")


def evaluate(args):
    np.random.seed(args.seed)
    ids = collect_ids(args.fragment_dir, args.gt_dir)
    if not ids:
        raise RuntimeError("No evaluation pairs found.")
    with open(os.path.join(args.model_dir, "merge_edge_model.json"), "r", encoding="utf-8") as f:
        model = json.load(f)
    with open(os.path.join(args.model_dir, "semantic_prototypes.json"), "r", encoding="utf-8") as f:
        semantic_model = normalize_semantic_model(json.load(f))

    results = []
    for uid in ids:
        fragment_file = find_fragment_file(args.fragment_dir, uid)
        if not fragment_file:
            continue
        segments, _, center, scale, global_diag = load_fragment_segments(fragment_file, args.max_points)
        gt_parts = load_gt_parts_auto(args.gt_dir, uid, center, scale, args.gt_samples)
        if not gt_parts:
            continue

        edges, feats = build_edges(segments, global_diag=global_diag, neighbor_ratio=args.neighbor_ratio,
                                   contact_eps=args.contact_eps)
        x, _ = features_to_matrix(feats)
        scores = score_edges(x, model) if x.shape[0] else np.array([])
        target_hint = len(gt_parts) if (args.target_mode == "gt_count" and gt_parts) else 0
        force_target = bool(target_hint > 0 and args.force_target_count)

        comp_map = select_best_component_map(
            segments=segments,
            edges=edges,
            scores=scores,
            model=model,
            target_components_hint=target_hint,
            force_target=force_target,
        )

        seg_points = {s.seg_id: s.points for s in segments}
        comp_points: Dict[int, np.ndarray] = {}
        for seg_id, comp_id in comp_map.items():
            comp_points.setdefault(comp_id, []).append(seg_points[seg_id])
        comp_points = {cid: np.vstack(pts) for cid, pts in comp_points.items()}

        comp_sem, descriptors, pair_relations, global_meta, _ = predict_component_semantics(comp_points, semantic_model)
        structure = recover_component_structure(comp_points, comp_sem, descriptors, pair_relations, global_meta)
        seg_weights = segment_weight_map(segments)
        seg_to_gt, _ = segment_label_map_from_gt(segments, gt_parts)
        segment_mean_purity = weighted_cluster_purity_from_seg_labels(comp_map, seg_to_gt, seg_weights)
        segment_mean_completeness = weighted_cluster_completeness_from_seg_labels(comp_map, seg_to_gt, seg_weights)
        segment_partition_f1 = harmonic_mean_score(segment_mean_purity, segment_mean_completeness)
        gt_bc = bcubed_from_maps(comp_map, seg_to_gt, seg_weights)
        gt_pairwise = pairwise_prf_from_maps(comp_map, seg_to_gt)
        segment_semantic_acc = weighted_semantic_accuracy_from_seg_maps(
            comp_map, seg_to_gt, comp_sem, gt_parts, seg_weights
        )
        semantic_distribution_score = semantic_distribution_iou_from_seg_maps(
            comp_map, seg_to_gt, comp_sem, gt_parts, seg_weights
        )

        comp_to_gt_legacy = {}
        purity_legacy = []
        for cid, pts in comp_points.items():
            bmin, bmax, diag = bbox_stats(pts)
            tmp_seg = Segment(
                seg_id=cid,
                points=pts,
                centroid=pts.mean(axis=0),
                bbox_min=bmin,
                bbox_max=bmax,
                axis=pca_axis(pts),
                bbox_diag=diag,
            )
            mapping, dominance = assign_segments_to_gt([tmp_seg], gt_parts)
            if mapping:
                comp_to_gt_legacy[cid] = mapping[cid]
                purity_legacy.append(dominance[cid])
        mean_purity_legacy = float(np.mean(purity_legacy)) if purity_legacy else 0.0

        tau = max(0.05, 0.12 * float(global_diag))
        mean_purity, comp_to_gt, _, comp_score_details = component_mean_purity(
            comp_points=comp_points,
            gt_parts=gt_parts,
            tau=tau,
            max_points=768,
            size_weighted=True,
            beta=0.5,
        )
        mean_forward_cover = float(np.mean([v["forward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
        mean_backward_cover = float(np.mean([v["backward_cover"] for v in comp_score_details.values()])) if comp_score_details else 0.0
        geometry_pred_score, _, _, _ = component_mean_purity(
            comp_points=comp_points,
            gt_parts=gt_parts,
            tau=tau,
            max_points=768,
            size_weighted=True,
            beta=1.0,
        )
        geometry_gt_score, _, _, gt_score_details = gt_part_mean_coverage(
            comp_points=comp_points,
            gt_parts=gt_parts,
            tau=tau,
            max_points=768,
            size_weighted=True,
            beta=1.0,
        )
        geometry_balanced_score = harmonic_mean_score(geometry_pred_score, geometry_gt_score)
        mean_gt_cover = float(np.mean([v["gt_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0
        mean_matched_component_purity = float(np.mean([v["pred_cover"] for v in gt_score_details.values()])) if gt_score_details else 0.0

        correct = 0
        total = 0
        for cid, gt_idx in comp_to_gt.items():
            sem_gt = gt_parts[gt_idx].semantic
            sem_pred = comp_sem.get(cid, "unknown")
            correct += int(sem_pred == sem_gt)
            total += 1
        sem_acc = correct / max(total, 1)

        results.append({
            "uid": uid,
            "num_segments": len(segments),
            "num_components": len(comp_points),
            "num_gt_parts": len(gt_parts),
            "recoverable_case": bool(len(segments) >= len(gt_parts)),
            "component_count_diff": abs(len(comp_points) - len(gt_parts)),
            "mean_purity": segment_mean_purity,
            "segment_mean_purity": segment_mean_purity,
            "segment_mean_completeness": segment_mean_completeness,
            "segment_partition_f1": segment_partition_f1,
            "gt_bcubed_precision": float(gt_bc["precision"]),
            "gt_bcubed_recall": float(gt_bc["recall"]),
            "gt_bcubed_f1": float(gt_bc["f1"]),
            "gt_pairwise_precision": float(gt_pairwise["precision"]),
            "gt_pairwise_recall": float(gt_pairwise["recall"]),
            "gt_pairwise_f1": float(gt_pairwise["f1"]),
            "geometry_mean_purity": mean_purity,
            "geometry_pred_score": geometry_pred_score,
            "geometry_gt_score": geometry_gt_score,
            "geometry_balanced_score": geometry_balanced_score,
            "mean_purity_legacy": mean_purity_legacy,
            "mean_forward_cover": mean_forward_cover,
            "mean_backward_cover": mean_backward_cover,
            "mean_gt_cover": mean_gt_cover,
            "mean_matched_component_purity": mean_matched_component_purity,
            "purity_tau": float(tau),
            "semantic_acc": sem_acc,
            "segment_semantic_acc": segment_semantic_acc,
            "semantic_distribution_score": semantic_distribution_score,
            "num_support_edges": int(sum(1 for e in structure.get("assembly_edges", []) if e.get("relation") == "support")),
            "num_layers": int(len(structure.get("levels", []))),
        })

    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"evaluated {len(results)} models")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Dougong structure-guided refinement v3.")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_train = sub.add_parser("train")
    p_train.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_train.add_argument("--gt_dir", default=r"data")
    p_train.add_argument("--out_dir", default=r"models")
    p_train.add_argument("--max_points", type=int, default=512)
    p_train.add_argument("--gt_samples", type=int, default=512)
    p_train.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_train.add_argument("--contact_eps", type=float, default=0.01)
    p_train.add_argument("--seed", type=int, default=42)

    p_ref = sub.add_parser("refine")
    p_ref.add_argument("--uid", required=True)
    p_ref.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_ref.add_argument("--gt_dir", default=r"data")
    p_ref.add_argument("--model_dir", default=r"models")
    p_ref.add_argument("--out_dir", default=r"outputs")
    p_ref.add_argument("--max_points", type=int, default=512)
    p_ref.add_argument("--gt_samples", type=int, default=512)
    p_ref.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_ref.add_argument("--contact_eps", type=float, default=0.01)
    p_ref.add_argument("--underseg_threshold", type=float, default=0.6)
    p_ref.add_argument("--seed", type=int, default=42)
    p_ref.add_argument("--target_mode", choices=["ratio", "gt_count"], default="ratio")
    p_ref.add_argument("--force_target_count", action="store_true")

    p_eval = sub.add_parser("evaluate")
    p_eval.add_argument("--fragment_dir", default=r"data/fragmentss/glb")
    p_eval.add_argument("--gt_dir", default=r"data")
    p_eval.add_argument("--model_dir", default=r"models")
    p_eval.add_argument("--out_dir", default=r"outputs")
    p_eval.add_argument("--max_points", type=int, default=512)
    p_eval.add_argument("--gt_samples", type=int, default=512)
    p_eval.add_argument("--neighbor_ratio", type=float, default=0.08)
    p_eval.add_argument("--contact_eps", type=float, default=0.01)
    p_eval.add_argument("--seed", type=int, default=42)
    p_eval.add_argument("--target_mode", choices=["ratio", "gt_count"], default="ratio")
    p_eval.add_argument("--force_target_count", action="store_true")

    return p

def main():
    args = build_parser().parse_args()
    if args.cmd == "train":
        train(args)
    elif args.cmd == "refine":
        refine(args)
    elif args.cmd == "evaluate":
        evaluate(args)


if __name__ == "__main__":
    main()
