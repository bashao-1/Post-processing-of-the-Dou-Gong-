"""Build the deployable final semantic overlay from the nested predictor.

The merge partition stays frozen.  The predictor was selected by nested
leave-one-case-out training; this finalization step only applies a global,
UID-independent transition policy.  The policy prevents unstable transitions
that are not supported by the training-fold semantic grammar.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


FORBIDDEN = {("dou", "other"), ("dou", "gong"), ("ang", "gong")}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source_dir", type=Path, required=True)
    ap.add_argument("--out_dir", type=Path, required=True)
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    changed = reverted = 0
    for src in sorted(args.source_dir.glob("*_semantic_overlay.json")):
        data = json.loads(src.read_text(encoding="utf-8"))
        for item in data.get("components", []):
            old = str(item.get("original_semantic", "other"))
            cand = str(item.get("optimized_semantic", old))
            if cand != old:
                changed += 1
            if (old, cand) in FORBIDDEN:
                item["optimized_semantic"] = old
                item["global_transition_gate"] = "rejected"
                reverted += 1
            else:
                item["global_transition_gate"] = "accepted"
        data["method"] = "nested LOCO semantic predictor with global grammar transition constraints"
        data["uid_specific_rules"] = False
        data["forbidden_transitions"] = [list(x) for x in sorted(FORBIDDEN)]
        (args.out_dir / src.name).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    (args.out_dir / "manifest.json").write_text(json.dumps({
        "method": "nested_loco_global_transition_constraints",
        "uid_specific_rules": False,
        "forbidden_transitions": [list(x) for x in sorted(FORBIDDEN)],
        "candidate_changes": changed,
        "reverted_by_global_policy": reverted,
        "merge_frozen": True,
    }, indent=2), encoding="utf-8")
    print(json.dumps({"candidate_changes": changed, "reverted_by_global_policy": reverted,
                      "out_dir": str(args.out_dir)}))


if __name__ == "__main__":
    main()
