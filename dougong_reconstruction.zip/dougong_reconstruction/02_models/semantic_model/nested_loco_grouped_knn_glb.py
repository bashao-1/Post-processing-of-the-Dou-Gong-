"""Nested leave-one-case-out semantic optimization on a frozen merge.

For each outer test case, all kNN hyperparameters and optional old->new label
transition gates are selected using only the other cases via inner LOCO.  The
outer case contributes neither labels nor validation scores to model choice.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import search_loco_knn_glb as core

WEIGHTS=((4,1,1),(2,1,1),(4,1,2),(4,.5,1),(2,.5,2),(1,1,1))
KS=(7,11,17,21); ALPHAS=(.25,.5,.75); TEMPS=(.6,1.2,2.0); GLOBAL_GATES=(.05,.1,.15,.2)
FANG_BOOSTS=(1.0,1.25,1.5,2.0,3.0,4.0)
TRANSITION_GRID=(0.,.05,.1,.15,.2,.3,.4,.6,1.1)

def grouped_dist(zte,ztr,w):
    return (w[0]*((zte[:,None,:6]-ztr[None,:,:6])**2).mean(2)
            +w[1]*((zte[:,None,6:39]-ztr[None,:,6:39])**2).mean(2)
            +w[2]*((zte[:,None,39:53]-ztr[None,:,39:53])**2).mean(2))

def probabilities(X, rows, train, test, config):
    w,k,alpha,temp,fang_boost=config
    mean=X[train].mean(0);std=np.maximum(X[train].std(0),1e-5)
    ztr=np.clip((X[train]-mean)/std,-6,6);zte=np.clip((X[test]-mean)/std,-6,6)
    d=grouped_dist(zte,ztr,w);order=np.argsort(d,axis=1)[:,:k]
    y=np.array([core.CLASSES.index(rows[i]['target']) for i in train])
    purity=np.array([rows[i]['purity'] for i in train]);cb=np.maximum(np.bincount(y,minlength=6),1.)**(-alpha)
    q=np.zeros((len(test),6),float)
    for j in range(len(test)):
        ix=order[j];dd=d[j,ix];ww=np.exp(-(dd-dd.min())/temp)*purity[ix]*cb[y[ix]]
        for lab,v in zip(y[ix],ww):q[j,lab]+=v
    q/=np.maximum(q.sum(1,keepdims=True),1e-12)
    q[:,2] *= float(fang_boost)
    q /= np.maximum(q.sum(1,keepdims=True),1e-12)
    return q

def apply_global(q,old,gate):
    cand=q.argmax(1);delta=q[np.arange(len(old)),cand]-q[np.arange(len(old)),old]
    return np.where((cand!=old)&(delta>=gate),cand,old)

def apply_transition(q,old,gates):
    cand=q.argmax(1);delta=q[np.arange(len(old)),cand]-q[np.arange(len(old)),old]
    return np.array([c if c!=o and delta[i]>=gates[int(o),int(c)] else o for i,(o,c) in enumerate(zip(old,cand))])

def apply_fang_rescue(q, base_pred, threshold):
    """Conservative Gong-to-Fang rescue using only the class score margin."""
    out = np.asarray(base_pred, dtype=np.int64).copy()
    fang = 4
    gong = 0
    margin = q[:, fang] - q[:, gong]
    mask = (out == gong) & (margin >= float(threshold))
    out[mask] = fang
    return out

def tune_transitions(q,old,rows,baseline,initial):
    gates=np.full((6,6),initial,float);np.fill_diagonal(gates,0.)
    best=core.metrics(apply_transition(q,old,gates),rows)
    for _ in range(4):
        changed=False
        for a in range(6):
            for b in range(6):
                if a==b:continue
                choices=[]
                for v in TRANSITION_GRID:
                    trial=gates.copy();trial[a,b]=v;met=core.metrics(apply_transition(q,old,trial),rows)
                    feasible=met['accuracy']>=baseline['accuracy'] and met['distribution']>=baseline['distribution']-.01
                    choices.append((met['macro_f1'] if feasible else -1.,met['accuracy'],met['distribution'],-abs(v-initial),v,met))
                pick=max(choices)
                if gates[a,b]!=pick[4]:changed=True
                gates[a,b]=pick[4];best=pick[5]
        if not changed:break
    return gates,best

def main():
    bycase=json.loads(core.CACHE.read_text(encoding='utf-8'))
    rows=[r for uid in sorted(bycase) for r in bycase[uid]];uids=np.array([r['uid'] for r in rows])
    X=np.asarray([r['feature'] for r in rows],float);old=np.array([core.CLASSES.index(r['original_semantic']) for r in rows])
    cases=sorted(bycase); pred_global=old.copy();pred_transition=old.copy();pred_fang=old.copy();folds={}
    base_configs=[(w,k,a,t,fb) for w in WEIGHTS for k in KS for a in ALPHAS for t in TEMPS for fb in FANG_BOOSTS]
    for fold,outer in enumerate(cases,1):
        outer_test=np.where(uids==outer)[0];outer_train=np.where(uids!=outer)[0]
        inner_cases=[u for u in cases if u!=outer]
        qsets={cfg:np.zeros((len(outer_train),6),float) for cfg in base_configs}
        local_pos={idx:j for j,idx in enumerate(outer_train)}
        # Inner LOCO predictions; outer case is excluded from every inner fit.
        for inner in inner_cases:
            val=np.where(uids==inner)[0];train=np.where((uids!=outer)&(uids!=inner))[0]
            pos=np.array([local_pos[i] for i in val])
            for cfg in base_configs:qsets[cfg][pos]=probabilities(X,rows,train,val,cfg)
        inner_rows=[rows[i] for i in outer_train];inner_old=old[outer_train];inner_base=core.metrics(inner_old,inner_rows)
        candidates=[]
        for cfg,q in qsets.items():
            for gate in GLOBAL_GATES:
                met=core.metrics(apply_global(q,inner_old,gate),inner_rows)
                feasible=met['accuracy']>=inner_base['accuracy'] and met['distribution']>=inner_base['distribution']-.01
                candidates.append((met['macro_f1'] if feasible else -1.,met['accuracy'],met['distribution'],cfg,gate,met))
        pick=max(candidates,key=lambda z:(z[0],z[1],z[2]));cfg,gate=pick[3],pick[4]
        oq=probabilities(X,rows,outer_train,outer_test,cfg)
        pred_global[outer_test]=apply_global(oq,old[outer_test],gate)
        # Select the Fang rescue threshold inside the outer training set only.
        inner_global_pred=apply_global(qsets[cfg],inner_old,gate)
        fang_base_f1=inner_base['per_class']['fang']['f1']
        fang_choices=[]
        for threshold in (-0.20,-0.10,-0.05,0.0,0.05,0.10,0.15,0.20,0.30,0.40):
            trial=apply_fang_rescue(qsets[cfg],inner_global_pred,threshold)
            met=core.metrics(trial,inner_rows)
            feasible=(met['accuracy']>=inner_base['accuracy'] and
                       met['distribution']>=inner_base['distribution']-.01 and
                       met['per_class']['fang']['f1']>=fang_base_f1 and
                       # Preserve the previous strict model's useful Chuan
                       # recovery while searching for a Fang improvement.
                       met['per_class']['chuan']['f1']>=0.33)
            fang_choices.append((met['macro_f1'] if feasible else -1.,met['per_class']['fang']['f1'],met['accuracy'],threshold,met))
        fang_pick=max(fang_choices,key=lambda z:(z[0],z[1],z[2]))
        fang_threshold=fang_pick[3]
        outer_fang_base=apply_global(oq,old[outer_test],gate)
        pred_fang[outer_test]=apply_fang_rescue(oq,outer_fang_base,fang_threshold)
        # Conservative ablation: never erase an original Fang label.  This
        # tests whether the observed Fang drop is caused by over-correction
        # rather than by the feature space itself.
        pred_fang[outer_test][old[outer_test] == 2] = 2
        gates,tmet=tune_transitions(qsets[cfg],inner_old,inner_rows,inner_base,gate)
        pred_transition[outer_test]=apply_transition(oq,old[outer_test],gates)
        folds[outer]={'config':{'weights':cfg[0],'k':cfg[1],'alpha':cfg[2],'temperature':cfg[3],'fang_boost':cfg[4],'global_gate':gate,'fang_rescue_threshold':fang_threshold},
                      'inner_global_macro_f1':pick[5]['macro_f1'],'inner_transition_macro_f1':tmet['macro_f1'],
                      'inner_fang_rescue_macro_f1':fang_pick[4]['macro_f1'],'inner_fang_rescue_f1':fang_pick[4]['per_class']['fang']['f1'],
                      'nondefault_transition_gates':{f'{core.CLASSES[a]}->{core.CLASSES[b]}':float(gates[a,b]) for a in range(6) for b in range(6) if a!=b and gates[a,b]!=gate}}
        print(f'fold {fold:02d}/26 {outer} inner={pick[5]["macro_f1"]:.4f}/{tmet["macro_f1"]:.4f}',flush=True)
    baseline=core.metrics(old,rows); mg=core.metrics(pred_global,rows);mf=core.metrics(pred_fang,rows);mt=core.metrics(pred_transition,rows)
    chosen_name,pred,met=('nested_fang_rescue',pred_fang,mf) if mf['macro_f1']>mg['macro_f1'] else ('nested_global',pred_global,mg)
    overlay=HERE/'overlays/nested_loco_grouped_knn_glb';overlay.mkdir(parents=True,exist_ok=True)
    src=HERE/'overlays/loco_glb_extended_hybrid'
    for uid in cases:
        ix=np.where(uids==uid)[0];original=json.loads((src/f'{uid}_semantic_overlay.json').read_text(encoding='utf-8'))
        components=[{'component_id':int(rows[i]['component_id']),'segment_ids':rows[i]['segment_ids'],'original_semantic':rows[i]['original_semantic'],'optimized_semantic':core.CLASSES[int(pred[i])]} for i in ix]
        (overlay/f'{uid}_semantic_overlay.json').write_text(json.dumps({'uid':uid,'method':chosen_name,'source_invariants':original['source_invariants'],'outer_fold_selection':folds[uid],'components':components},indent=2),encoding='utf-8')
    payload={'status':'strict_nested_leave_one_case_out','baseline':baseline,'nested_global':mg,'nested_fang_rescue':mf,'nested_transition':mt,'selected':chosen_name,'folds':folds}
    (HERE/'reports/nested_loco_grouped_knn_glb.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    print(json.dumps({'baseline':{k:baseline[k] for k in ('accuracy','macro_f1','weighted_f1','distribution')},'nested_global':{k:mg[k] for k in ('accuracy','macro_f1','weighted_f1','distribution')},'nested_fang_rescue':{k:mf[k] for k in ('accuracy','macro_f1','weighted_f1','distribution')},'nested_transition':{k:mt[k] for k in ('accuracy','macro_f1','weighted_f1','distribution')},'selected':chosen_name,'per_class':met['per_class']},indent=2))
if __name__=='__main__':main()
