"""Evaluate semantic labels while keeping the saved merge/partition frozen.

The script only reads the original bundle.  It uses the initial fragments as
the common evaluation universe and distributes each fragment's surface mass
over GT parts using soft nearest-surface overlap.  Thus a fragmented or
over-merged prediction is not forced into an arbitrary one-to-one instance
pair merely to compute a semantic score.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

HERE = Path(__file__).resolve().parent
BUNDLE = Path(__file__).resolve().parents[2]
CODE = BUNDLE / "01_code"
sys.path.insert(0, str(BUNDLE))
sys.path.insert(0, str(CODE))
import dougong_refine_v4 as base  # type: ignore  # noqa: E402
import evaluate_saved_outputs_softmetrics_20260519 as saved  # type: ignore  # noqa: E402

CLASSES = ("gong", "dou", "fang", "chuan", "ang", "other")
ALIASES = {
    "gong": "gong", "dou": "dou", "fang": "fang", "chuan": "chuan",
    "ang": "ang", "other": "other", "qiao": "other", "unknown": "other",
}


def norm_semantic(value: object) -> str:
    key = str(value or "unknown").strip().lower().replace(" ", "_")
    return ALIASES.get(key, "other")


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def frozen_invariants(saved_case: Dict[str, object]) -> Dict[str, object]:
    labels = np.asarray(saved_case["comp_labels"], dtype=np.int32)
    fragment = np.asarray(saved_case["fragment_labels"], dtype=np.int32)
    comp_map = {int(k): int(v) for k, v in saved_case["comp_map"].items()}
    mapping_text = json.dumps(sorted(comp_map.items()), separators=(",", ":"))
    return {
        "comp_labels_sha256": sha256_array(labels),
        "fragment_labels_sha256": sha256_array(fragment),
        "comp_map_sha256": hashlib.sha256(mapping_text.encode("utf-8")).hexdigest(),
        "num_points": int(labels.size),
        "num_components": int(len(set(comp_map.values()))),
        "num_fragments": int(len(comp_map)),
        "component_segments": {
            str(cid): sorted(int(s) for s, c in comp_map.items() if c == cid)
            for cid in sorted(set(comp_map.values()))
        },
    }


def mass_tables(case: Dict[str, object], out: Dict[str, object], gt_parts: List[base.Part]):
    segments = case["segments"]
    # Existing implementation supplies normalized nearest-surface weights.
    soft_gt = saved.compute_overlap_weight_matrix(segments, gt_parts)
    weights = saved.area_weight_map(case)
    comp_map = {int(k): int(v) for k, v in out["comp_map"].items()}
    comp_sem = {int(k): norm_semantic(v) for k, v in out["comp_sem"].items()}
    matrix = np.zeros((len(CLASSES), len(CLASSES)), dtype=np.float64)
    gt_mass = np.zeros(len(CLASSES), dtype=np.float64)
    pred_mass = np.zeros(len(CLASSES), dtype=np.float64)
    component_mass: Dict[int, np.ndarray] = defaultdict(lambda: np.zeros(len(CLASSES), dtype=np.float64))
    common = sorted(set(comp_map) & set(soft_gt))
    for sid in common:
        area = float(weights.get(int(sid), 1.0))
        cid = int(comp_map[sid])
        pred = comp_sem.get(cid, "other")
        pi = CLASSES.index(pred)
        pred_mass[pi] += area
        for gid, prob in soft_gt[sid].items():
            gi = CLASSES.index(norm_semantic(gt_parts[int(gid)].semantic))
            amount = area * float(prob)
            matrix[gi, pi] += amount
            gt_mass[gi] += amount
            component_mass[cid][gi] += amount
    return matrix, gt_mass, pred_mass, component_mass, len(common), comp_sem


def prf(matrix: np.ndarray) -> Dict[str, Dict[str, float]]:
    result: Dict[str, Dict[str, float]] = {}
    for i, cls in enumerate(CLASSES):
        tp = float(matrix[i, i])
        fp = float(matrix[:, i].sum() - tp)
        fn = float(matrix[i, :].sum() - tp)
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        f = 2 * p * r / (p + r) if p + r else 0.0
        result[cls] = {"support": float(matrix[i, :].sum()), "tp": tp,
                       "precision": p, "recall": r, "f1": f}
    return result


def apply_overlay(uid: str, out: Dict[str, object], overlay_dir: Path | None) -> None:
    if overlay_dir is None:
        return
    path = overlay_dir / f"{uid}_semantic_overlay.json"
    if not path.exists():
        raise FileNotFoundError(f"missing semantic overlay: {path}")
    overlay = json.loads(path.read_text(encoding="utf-8"))
    expected = frozen_invariants(out)
    source = overlay.get("source_invariants", {})
    for key in ("comp_labels_sha256", "fragment_labels_sha256", "comp_map_sha256", "num_components", "num_fragments"):
        if source.get(key) != expected.get(key):
            raise ValueError(f"{uid}: frozen merge invariant mismatch for {key}")
    labels = {int(item["component_id"]): norm_semantic(item["optimized_semantic"])
              for item in overlay.get("components", [])}
    if set(labels) != set(int(k) for k in out["comp_sem"]):
        raise ValueError(f"{uid}: overlay component IDs do not match frozen output")
    out["comp_sem"] = labels


def load_gt_consistent(uid: str, gt_dir: Path, center: np.ndarray, scale: float,
                       samples: int, source: str) -> List[base.Part]:
    if source == "auto":
        return base.load_gt_parts_auto(str(gt_dir), uid, center, scale, samples)
    # The GLB is already in the same aligned coordinate convention as fragment.
    # The legacy points.npy files are not used here because several are scaled
    # by approximately 2x relative to their sibling GLB.
    glb = gt_dir / f"{uid}.glb"
    info = gt_dir / uid / "part_info.json"
    if not glb.exists():
        raise FileNotFoundError(f"missing GT GLB: {glb}")
    return base.load_gt_parts(str(glb), str(info), center, scale, samples)


def evaluate_case(uid: str, output_dir: Path, fragment_dir: Path, gt_dir: Path, samples: int,
                  overlay_dir: Path | None = None, gt_source: str = "auto") -> Dict[str, object]:
    case = saved.build_case_row(uid, str(fragment_dir), samples)
    out = saved.load_saved_case(str(output_dir), uid)
    apply_overlay(uid, out, overlay_dir)
    gt_parts = load_gt_consistent(uid, gt_dir, case["center"], case["scale"], samples, gt_source)
    if not gt_parts:
        raise RuntimeError(f"{uid}: no GT parts")
    matrix, gt_mass, pred_mass, component_mass, n_common, comp_sem = mass_tables(case, out, gt_parts)
    per_class = prf(matrix)
    total = float(matrix.sum())
    macro_f1 = float(np.mean([per_class[c]["f1"] for c in CLASSES]))
    weighted_f1 = float(sum(per_class[c]["f1"] * per_class[c]["support"] for c in CLASSES) / max(total, 1e-12))
    pred_dist = pred_mass / max(float(pred_mass.sum()), 1e-12)
    gt_dist = gt_mass / max(float(gt_mass.sum()), 1e-12)
    distribution_iou = float(np.minimum(pred_dist, gt_dist).sum() / max(np.maximum(pred_dist, gt_dist).sum(), 1e-12))
    purity_num = purity_den = 0.0
    for cid, masses in component_mass.items():
        m = float(masses.sum())
        if m <= 0:
            continue
        purity_num += float(masses.max())
        purity_den += m
    return {
        "uid": uid,
        "num_pred_components": int(len(comp_sem)),
        "num_gt_components": int(len(gt_parts)),
        "num_common_fragments": int(n_common),
        "semantic_accuracy_mass": float(np.trace(matrix) / max(total, 1e-12)),
        "semantic_macro_f1": macro_f1,
        "semantic_weighted_f1": weighted_f1,
        "semantic_distribution_consistency": distribution_iou,
        "semantic_component_purity": float(purity_num / max(purity_den, 1e-12)),
        "per_class": per_class,
        "confusion_matrix": {g: {p: float(matrix[i, j]) for j, p in enumerate(CLASSES)} for i, g in enumerate(CLASSES)},
        "invariants": frozen_invariants(out),
    }


def discover_ids(output_dir: Path) -> List[str]:
    return sorted(p.name[:-len("_refined.npz")] for p in output_dir.glob("*_refined.npz"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output_dir", type=Path, required=True)
    ap.add_argument("--fragment_dir", type=Path, default=BUNDLE.parent.parent / "meshes" / "fragment" / "glb")
    ap.add_argument("--gt_dir", type=Path, default=BUNDLE.parent.parent / "meshes")
    ap.add_argument("--out_dir", type=Path, default=HERE / "reports" / "baseline_semantics")
    ap.add_argument("--semantic_overlay_dir", type=Path)
    ap.add_argument("--gt_source", choices=("auto", "glb"), default="auto")
    ap.add_argument("--samples", type=int, default=512)
    args = ap.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for uid in discover_ids(args.output_dir):
        try:
            rows.append(evaluate_case(uid, args.output_dir, args.fragment_dir, args.gt_dir, args.samples,
                                      args.semantic_overlay_dir, args.gt_source))
        except Exception as exc:
            print(f"skip {uid}: {exc}", file=sys.stderr)
    if not rows:
        raise SystemExit("No cases evaluated")
    total_matrix = np.zeros((len(CLASSES), len(CLASSES)), dtype=np.float64)
    for row in rows:
        cm = row["confusion_matrix"]
        for i, gold in enumerate(CLASSES):
            for j, pred in enumerate(CLASSES):
                total_matrix[i, j] += float(cm[gold][pred])
    dataset_per_class = prf(total_matrix)
    dataset_total = float(total_matrix.sum())
    aggregate = {
        "num_cases": len(rows),
        "classes": list(CLASSES),
        "metric_definition": "soft fragment-to-GT overlap; rows=GT class, columns=predicted class",
        "mean_semantic_accuracy_mass": float(np.mean([r["semantic_accuracy_mass"] for r in rows])),
        "mean_semantic_macro_f1": float(np.mean([r["semantic_macro_f1"] for r in rows])),
        "mean_semantic_weighted_f1": float(np.mean([r["semantic_weighted_f1"] for r in rows])),
        "mean_semantic_distribution_consistency": float(np.mean([r["semantic_distribution_consistency"] for r in rows])),
        "mean_semantic_component_purity": float(np.mean([r["semantic_component_purity"] for r in rows])),
        "dataset_semantic_accuracy_mass": float(np.trace(total_matrix) / max(dataset_total, 1e-12)),
        "dataset_semantic_macro_f1": float(np.mean([dataset_per_class[c]["f1"] for c in CLASSES])),
        "dataset_semantic_weighted_f1": float(sum(dataset_per_class[c]["f1"] * dataset_per_class[c]["support"] for c in CLASSES) / max(dataset_total, 1e-12)),
        "dataset_per_class": dataset_per_class,
        "dataset_confusion_matrix": {
            g: {p: float(total_matrix[i, j]) for j, p in enumerate(CLASSES)}
            for i, g in enumerate(CLASSES)
        },
        "casewise": rows,
    }
    (args.out_dir / "semantic_evaluation.json").write_text(json.dumps(aggregate, indent=2, ensure_ascii=False), encoding="utf-8")
    with (args.out_dir / "semantic_casewise.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["uid", "accuracy_mass", "macro_f1", "weighted_f1", "distribution_consistency", "component_purity", "num_common_fragments"])
        for r in rows:
            w.writerow([r["uid"], r["semantic_accuracy_mass"], r["semantic_macro_f1"], r["semantic_weighted_f1"], r["semantic_distribution_consistency"], r["semantic_component_purity"], r["num_common_fragments"]])
    with (args.out_dir / "semantic_per_class.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["class", "support_area", "precision", "recall", "f1"])
        for cls in CLASSES:
            m = dataset_per_class[cls]
            w.writerow([cls, m["support"], m["precision"], m["recall"], m["f1"]])
    shown = {k: aggregate[k] for k in aggregate if k.startswith("mean_") or k.startswith("dataset_semantic_")}
    print(json.dumps(shown, indent=2))


if __name__ == "__main__":
    main()
