"""Explore label-only LOCO kNN corrections using GLB-derived soft targets.

No merge data are written.  Hyperparameter selection here is exploratory; the
selected configuration must later be nested or fixed before held-out reporting.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
CACHE=HERE/'overlays/loco_glb_extended_hybrid/feature_records.json'
OUT=HERE/'reports/loco_knn_glb_search.json'
OVERLAY=HERE/'overlays/loco_knn_glb_best_exploratory'
CLASSES=('gong','dou','fang','chuan','ang','other')

def prf(m):
    out={}
    for i,c in enumerate(CLASSES):
        tp=m[i,i]; fp=m[:,i].sum()-tp; fn=m[i,:].sum()-tp
        p=tp/(tp+fp) if tp+fp else 0.; r=tp/(tp+fn) if tp+fn else 0.
        out[c]={'precision':float(p),'recall':float(r),'f1':float(2*p*r/(p+r) if p+r else 0.),'support':float(m[i,:].sum())}
    return out

def metrics(pred, rows):
    m=np.zeros((6,6),float)
    for y,r in zip(pred,rows):
        mass=np.array([r['target_mass_by_class'][c] for c in CLASSES],float)
        m[:,int(y)]+=mass
    per=prf(m); total=m.sum(); pd=m.sum(0)/total; gd=m.sum(1)/total
    return {'accuracy':float(np.trace(m)/total),'macro_f1':float(np.mean([per[c]['f1'] for c in CLASSES])),
            'weighted_f1':float(sum(per[c]['f1']*per[c]['support'] for c in CLASSES)/total),
            'distribution':float(np.minimum(pd,gd).sum()/np.maximum(pd,gd).sum()),'per_class':per,'matrix':m.tolist()}

def main():
    bycase=json.loads(CACHE.read_text(encoding='utf-8'))
    rows=[r for uid in sorted(bycase) for r in bycase[uid]]
    uids=np.array([r['uid'] for r in rows]); old=np.array([CLASSES.index(r['original_semantic']) for r in rows])
    X=np.asarray([r['feature'] for r in rows],float) # score(6) + geometry(33)
    one=np.eye(6)[old]
    modes={'score':X[:,:6], 'geometry':X[:,6:], 'hybrid':X, 'hybrid_old':np.c_[X,one], 'geometry_old':np.c_[X[:,6:],one]}
    baseline=metrics(old,rows); oracle=metrics([int(np.argmax([r['target_mass_by_class'][c] for c in CLASSES])) for r in rows],rows)
    configs=[]; predictions={}
    for mode,A in modes.items():
        # Store probabilities for each parameter combination in original row order.
        probsets={(k,a,t):np.zeros((len(rows),6),float) for k in (5,11,21) for a in (.25,.5,.75,1.) for t in (.25,.75,2.)}
        for uid in sorted(bycase):
            te=np.where(uids==uid)[0]; tr=np.where(uids!=uid)[0]
            mean=A[tr].mean(0); std=np.maximum(A[tr].std(0),1e-5)
            ztr=np.clip((A[tr]-mean)/std,-6,6); zte=np.clip((A[te]-mean)/std,-6,6)
            d=((zte[:,None,:]-ztr[None,:,:])**2).mean(2)
            order=np.argsort(d,axis=1)
            ytr=np.array([CLASSES.index(rows[i]['target']) for i in tr])
            purity=np.array([rows[i]['purity'] for i in tr],float)
            counts=np.bincount(ytr,minlength=6).astype(float)
            for k in (5,11,21):
                ix=order[:,:k]
                for alpha in (.25,.5,.75,1.):
                    cb=np.maximum(counts,1.)**(-alpha)
                    for temp in (.25,.75,2.):
                        q=np.zeros((len(te),6),float)
                        for j in range(len(te)):
                            jj=ix[j]; dd=d[j,jj]; w=np.exp(-(dd-dd.min())/temp)*purity[jj]*cb[ytr[jj]]
                            for lab,ww in zip(ytr[jj],w): q[j,lab]+=ww
                        q/=np.maximum(q.sum(1,keepdims=True),1e-12)
                        probsets[(k,alpha,temp)][te]=q
        for (k,alpha,temp),q in probsets.items():
            cand=q.argmax(1); oldp=q[np.arange(len(rows)),old]; bestp=q[np.arange(len(rows)),cand]
            for gate in (-.10,0.,.05,.10,.15,.20,.30,.40):
                pred=np.where((cand!=old)&((bestp-oldp)>=gate),cand,old)
                met=metrics(pred,rows); key=f'{mode}_k{k}_a{alpha}_t{temp}_g{gate}'
                item={'key':key,'mode':mode,'k':k,'class_balance_alpha':alpha,'temperature':temp,'gate':gate,**{z:met[z] for z in ('accuracy','macro_f1','weighted_f1','distribution')}}
                configs.append(item); predictions[key]=pred
    feasible=[x for x in configs if x['accuracy']>=baseline['accuracy'] and x['distribution']>=baseline['distribution']-0.01]
    best=max(feasible or configs,key=lambda x:(x['macro_f1'],x['accuracy'],x['distribution']))
    bestpred=predictions[best['key']]; bestmet=metrics(bestpred,rows)
    OVERLAY.mkdir(parents=True,exist_ok=True)
    by_uid={}
    for i,r in enumerate(rows):
        by_uid.setdefault(r['uid'],[]).append({'component_id':int(r['component_id']),'segment_ids':r['segment_ids'],'original_semantic':r['original_semantic'],'optimized_semantic':CLASSES[int(bestpred[i])]})
    # Reuse invariant snapshots from the GLB-hybrid overlay.
    src=HERE/'overlays/loco_glb_hybrid_masscache'
    for uid,components in by_uid.items():
        original=json.loads((src/f'{uid}_semantic_overlay.json').read_text(encoding='utf-8'))
        (OVERLAY/f'{uid}_semantic_overlay.json').write_text(json.dumps({'uid':uid,'method':best,'source_invariants':original['source_invariants'],'components':components},indent=2),encoding='utf-8')
    payload={'status':'exploratory_all_case_model_selection','baseline':baseline,'oracle':oracle,'best':best,'best_metrics':bestmet,'top20':sorted(configs,key=lambda x:(x['macro_f1'],x['accuracy']),reverse=True)[:20]}
    OUT.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    print(json.dumps({'baseline':{k:baseline[k] for k in ('accuracy','macro_f1','weighted_f1','distribution')},'best':best,'best_per_class':bestmet['per_class'],'oracle':{k:oracle[k] for k in ('accuracy','macro_f1')}},indent=2))

if __name__=='__main__': main()
