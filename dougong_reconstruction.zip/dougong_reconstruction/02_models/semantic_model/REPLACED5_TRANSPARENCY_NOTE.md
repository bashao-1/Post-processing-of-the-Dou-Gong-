# Explanation of `replaced5`

The label `replaced5` is a historical dataset-version label created on 3 June
2026. It refers to the replacement of five benchmark slots (`bu1`, `bu2`,
`bu3`, `bu4`, and `bu6`) by the current case UIDs `751837c802c5`,
`44c76d872d82`, `099e0786fd7a`, `99ad8a8b4897`, and `2159bdad7036`.

The current quantitative tables use the resulting 26-case version, including
those five cases. The replacements were made before the reported evaluation
run; they were not substitutions made after inspecting a test result. The
archived replacement manifest records the mapping and date, but does not
preserve a detailed scientific rationale for each substitution. We therefore
report the mapping and this provenance limitation explicitly instead of
claiming an undocumented reason.

Suggested manuscript wording:

> The directory suffix `replaced5` denotes a dataset-version update performed
> on 3 June 2026, in which five original benchmark slots were replaced by five
> cases from the aligned third-batch collection. The replacement mapping is
> provided in Supplementary Table S1. All quantitative results reported in this
> manuscript use the resulting fixed set of 26 cases, and the replacement was
> completed before evaluation. The archived manifest preserves the mapping and
> date but not a detailed per-case rationale; this provenance limitation is
> disclosed explicitly.

Do not describe this as five cases being removed after model evaluation, and do
not imply that the five cases were selected based on their results.
