# Final semantic model

The final semantic model is the nested leave-one-case-out grouped kNN
predictor, followed by three global grammar transition constraints:

- `Dou -> Other` is rejected;
- `Dou -> Gong` is rejected;
- `Ang -> Gong` is rejected.

These constraints are UID-independent and are applied to every case. They do
not use GT geometry or GT labels at inference time. The merge/component
partition is frozen; only `optimized_semantic` labels are changed.

The final overlay is in `overlays/final_semantic_model/`.

Using the aligned GT-GLB soft-overlap evaluator with 512 samples, the result
is:

| metric | frozen final system | final semantic model |
|---|---:|---:|
| dataset semantic accuracy | 0.6951 | 0.7527 |
| dataset macro-F1 | 0.3584 | 0.4891 |
| dataset weighted-F1 | 0.6686 | 0.7437 |
| mean distribution consistency | 0.7129 | 0.7687 |

For `a28db58955f9`, all ten semantic labels remain identical to the original
final system. This is a consequence of the global transition policy, not a
case-specific exception.
