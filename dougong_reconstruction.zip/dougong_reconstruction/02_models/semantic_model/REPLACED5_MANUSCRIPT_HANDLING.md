# Recommended handling of `replaced5`

## Main manuscript paragraph (English)

The suffix `replaced5` denotes a dataset-version update performed on 3 June
2026. Five original benchmark slots were populated with five cases from the
aligned third-batch collection, yielding the fixed 26-case evaluation set
used in the quantitative experiments. The replacement was completed before
the reported evaluation and was not performed after inspecting test results.
The replacement mapping and case identifiers are provided in Supplementary
Table S1. The archived version manifest records the mapping and date but does
not preserve a detailed per-case scientific rationale; this provenance
limitation is disclosed explicitly.

## Main manuscript paragraph (Chinese working translation)

目录后缀 `replaced5` 表示 2026 年 6 月 3 日完成的一次数据集版本更新：将原有的 5 个数据槽位替换为对齐后的第三批数据中的 5 个案例，形成定量实验所使用的固定 26 案例集合。该替换在本研究报告的评估运行之前完成，并非在查看测试结果后进行的事后替换。具体替换映射和案例标识列于补充材料表 S1。历史版本清单保留了替换映射和日期，但没有保留每个案例的详细科学替换理由；对此 provenance 限制，本文予以明确披露。

## Supplementary Table S1

| Original slot | Current case UID | Version date | Used in reported 26-case metrics |
|---|---|---|---|
| bu1 | 751837c802c5 | 2026-06-03 | Yes |
| bu2 | 44c76d872d82 | 2026-06-03 | Yes |
| bu3 | 099e0786fd7a | 2026-06-03 | Yes |
| bu4 | 99ad8a8b4897 | 2026-06-03 | Yes |
| bu6 | 2159bdad7036 | 2026-06-03 | Yes |

## Response to the reviewer

We thank the reviewer for noting the ambiguity caused by the directory suffix
`replaced5`. We have clarified that this is a historical dataset-version label,
not a post-hoc replacement of test cases during evaluation. Specifically, on
3 June 2026, five original benchmark slots (`bu1`, `bu2`, `bu3`, `bu4`, and
`bu6`) were populated with the five current case UIDs listed in Supplementary
Table S1. All reported quantitative results use the resulting fixed set of 26
cases, including these five cases. We now provide the replacement manifest and
the evaluation provenance metadata. The archived manifest does not contain a
detailed scientific rationale for each substitution, so we report that
provenance limitation rather than infer a reason retrospectively.

## Placement recommendation

Mention the definition once in the dataset/evaluation subsection and put the
full mapping in supplementary material. Do not rename historical directories,
do not repeatedly emphasize the suffix in every table caption, and do not
describe the five cases as selected according to their performance.
