# Training / threshold / test protocol audit

## Evidence from the historical merge-stage model

`stage2_component_models.json` records:

- `uids`: six cases (`0274e0b63d6b`, `0f5c68e92f93`, `9bb3e8247d5b`, `9fc08a316ad7`, `e0c87a48f5a5`, `f624e1a47839`);
- split candidates: 625 rows, positive ratio about 0.096;
- merge candidates: 31,012 rows, positive ratio about 0.0647;
- split and merge thresholds: 1.5 and 1.5;
- `focus_uids`: `f624e1a47839`, `0f5c68e92f93`, `e0c87a48f5a5`;
- threshold search is scored on the focus cases.

This is evidence that the historical model-development artifact is not a clean 26-case held-out evaluation protocol. It must not be described as fully leakage-free without a rerun or an explicit limitation statement.

## Evidence from the final semantic-only package

The final semantic package documents a nested leave-one-case-out predictor with UID-independent grammar transitions. It freezes component partitions and changes only semantic labels. This supports a leakage-safe semantic-label evaluation, but it does not retroactively validate the historical merge-stage model.

## Required decision before manuscript finalization

Choose one of the following and state it plainly:

1. **Preferred:** rerun the complete merge-stage model with nested leave-one-case-out fitting and threshold selection, then regenerate all four-method results; or
2. **Conservative fallback:** retain the historical merge results but label them as development-set/preliminary results, remove strong generalization claims, and report the leakage limitation explicitly.

The current audit therefore marks the overall training/threshold/test protocol as **not yet cleared**.
