# Runtime and data provenance record

## Input data

- Source: publicly available manually modelled Chinese Dou-Gong models published by 时之沙漏 on Aigei.com: https://www.aigei.com/set/zhongshigujianzhudou.html
- The study did not use real measurement or field-scan data.
- Ground-truth models were manually decomposed and labelled by Han Dang after obtaining the public models.
- Initial fragments used for post-processing were produced with Tencent Hunyuan 3D Studio using PartGen 1.5 component decomposition.

## Annotation

- Annotator: Han Dang, M.S. student in Mechanical Engineering, Beijing Forestry University.
- Annotation date: February 2026.
- All cases were reviewed by Jian Zhao, Professor, School of Technology, Beijing Forestry University, as quality control in March 2026.
- No labels were modified after review; the GT annotation was frozen on 2026-03-27. The six supplementary fine-grained cases followed the same procedure.

## Hardware

- CPU: AMD Ryzen 9 7945HX with Radeon Graphics.
- GPU: NVIDIA GeForce RTX 4060 Laptop GPU, 8 GB.
- Memory: 32 GB Samsung DDR5-5200.
- Storage: 1 TB UMIS RPJY1T24MLR1HWW SSD.

## Timing measurement

A representative case (`0274e0b63d6b`) was evaluated using the frozen semantic evaluation script with 512 surface samples, the frozen merge output, and the semantic overlay. On the hardware above, the single-case semantic evaluation took approximately **4.6 s** wall-clock time (PowerShell `Measure-Command`, including Python process startup and file I/O). This is an evaluation-time measurement, not a claim for the full Tencent Hunyuan 3D Studio/PartGen 1.5 generation time. If the manuscript reports end-to-end reconstruction time, it should be measured separately from the PartGen service and the merge pipeline.
