# Consistency checklist

- [x] Four principal methods use the same 26-case `replaced5` case list.
- [x] Initial fragment/GT paths are fixed and recorded.
- [x] Geometry/grouping metrics are regenerated in `unified_main_metrics`.
- [x] Final semantic overlays are present for all four methods.
- [x] Final System uses the exact frozen semantic package overlays.
- [x] Semantic evaluation uses the same GLB GT source and 512 samples.
- [x] Table 4 is generated from one script rather than manually transcribed values.
- [x] Class-wise semantic and confusion outputs are generated for all four rows.
- [x] Merge maps are never edited by semantic overlay materialization.
- [ ] Re-run exact paired significance tests after the final four-method casewise table is selected for the manuscript.
- [ ] Insert the generated tables into the final DOCX and perform visual/numeric QA.
